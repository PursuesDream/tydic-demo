const Mock = require('mockjs')
module.exports = [
  {
    url: '/FixCompany/fixCompanyList',
    type: 'post',
    response: config => {
      return Mock.mock(
        {
          code: 200,
          msg: '成功啦！',
          'data|10': [
            {
              comId: '@guid',
              'vehicleType|1': ['1', '2'],
              'vehicleBrand|1': ['1', '2', '3'],
              comName: '@cword(5,10)',
              'tel|13': '@integer(0, 9)',
              'dadui|1': ['南山大队', '福田大队', '罗湖大队', '宝安大队', '龙岗大队', '龙华大队'],
              gangwei: '巡逻岗@natural(0, 100)',
              banci: '通宵班@natural(0, 100)',
              contact: '@cname',
              address: '@county(true)',
              inTime: '@date("yyyy-MM-dd") @time("HH:mm:ss")',
              states: '@natural(0, 2)'
            }
          ]
        }
      )
    }
  },
  {
    url: '/FixCompany/deleteFixCompany',
    type: 'post',
    response: config => {
      return Mock.mock(
        {
          code: 200,
          msg: '成功啦！',
          data: null
        }
      )
    }
  },
  {
    url: '/FixCompany/insertOrUpdateFixCompany',
    type: 'post',
    response: config => {
      return Mock.mock(
        {
          code: 200,
          msg: '成功啦！',
          data: null
        }
      )
    }
  },
  // 维保项目列表查询
  {
    url: '/FixItemconfig/fixItemconfigList',
    type: 'post',
    response: config => {
      return Mock.mock(
        {
          code: 200,
          msg: '成功啦！',
          'data|10': [
            {
              'fixItemId|1': '@natural(0, 9)',
              'guaranteeType|1': ['一年', '两年'],
              'vehicleType|1': ['铁骑', '警用车'],
              'vehicleTypeName|1': ['铁骑', '警用车'],
              'vehicleBrandName|1': ['铁骑', '警用车'],
              'categoryCodeName|1': ['铁骑', '警用车'],
              'vehicleBrand|1': ['春风', '雅马哈'],
              'categoryCode|1': ['111', '222'],
              'guaranteeExpire|1': ['一年', '两年'],
              'ports|1': ['一年', '两年'],
              'itemName|1': ['一年', '两年'],
              'price|1': ['一年', '两年'],
              'hourPrice|1': ['一年', '两年'],
              'states|1': ['一年', '两年']
            }
          ]
        }
      )
    }
  },
  // 维保项目列表删除
  {
    url: '/FixItemconfig/deleteFixItemconfig',
    type: 'post',
    response: config => {
      return Mock.mock(
        {
          code: 200,
          msg: '成功啦！',
          data: null
        }
      )
    }
  },
  // 维保项目列表新增或修改
  {
    url: '/FixItemconfig/insertOrUpdateFixItemconfig',
    type: 'post',
    response: config => {
      return Mock.mock(
        {
          code: 200,
          msg: '成功啦！',
          data: null
        }
      )
    }
  },
  // 维保单位下拉查询
  {
    url: '/FixItemconfig/fixCompanyList',
    type: 'post',
    response: config => {
      return Mock.mock(
        {
          code: 200,
          msg: '成功啦！',
          data: null
        }
      )
    }
  }
]
