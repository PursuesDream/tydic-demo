const Mock = require('mockjs')
module.exports = [
  // user login
  {
    url: '/scheduling/list',
    type: 'post',
    response: config => {
      return Mock.mock(
        {
          code: 200,
          msg: '成功啦！',
          'data|10': [
            {
              id: '@guid',
              text: '@cparagraph(2)',
              bigImage: '@image(139x104,@color)',
              'dadui|1': ['南山大队', '福田大队', '罗湖大队', '宝安大队', '龙岗大队', '龙华大队'],
              gangwei: '巡逻岗@natural(0, 100)',
              banci: '通宵班@natural(0, 100)',
              week0: '@cname',
              week1: '@cname',
              week2: '@cname',
              week3: '@cname',
              week4: '@cname',
              week5: '@cname',
              week6: '@cname'
            }
          ]
        }
      )
    }
  }
]
