const Mock = require('mockjs')
module.exports = [
  // 车辆超速信息列表查询
  {
    url: '/VehicleState/selectVehicleSpeedingList',
    type: 'post',
    response: config => {
      return Mock.mock(
        {
          code: 200,
          msg: '成功啦！',
          'data|10': [
            {
              'vehicleNo|4': '@natural(0, 9)',
              'policeCode|4': '@natural(0, 9)',
              'policeName|1': ['张三', '李四', '王麻子', '狗腿子'],
              'position|1': ['福田区莲花支路', '龙岗区坂雪岗大道', '罗湖区解放路'],
              'speedingType|1': ['类型1', '类型2', '类型3'],
              'speedingContent|1': ['南山大队', '福田大队', '罗湖大队', '宝安大队', '龙岗大队', '龙华大队'],
              beginTime: '@date("yyyy-MM-dd") @time("HH:mm:ss")'
            }
          ]
        }
      )
    }
  },
  // 地图打点车辆信息
  {
    url: '/VehicleState/selectVehicleStateList',
    type: 'post',
    response: config => {
      return Mock.mock(
        {
          code: 200,
          msg: '成功啦！',
          'data|10': [
            {
              'vehicleNo|4': '@natural(0, 9)',
              'policeCode|4': '@natural(0, 9)',
              'position|1': ['福田区莲花支路', '龙岗区坂雪岗大道', '罗湖区解放路'],
              'timeRaw|1': ['100km/h', '80km/h', '50km/h'],
              beginTime: '@date("yyyy-MM-dd") @time("HH:mm:ss")',
              'longBaidu|114.1-10': 1,
              'latBaidu|22-23.1-10': 1
            }
          ]
        }
      )
    }
  },
  // 根据车牌号查询车辆超速信息列表查询
  {
    url: '/VehicleState/selectVehicleSpeedingByNo',
    type: 'post',
    response: config => {
      return Mock.mock(
        {
          code: 200,
          msg: '成功啦！',
          'data|10': [
            {
              'vehicleNo|4': '@natural(0, 9)',
              'policeCode|4': '@natural(0, 9)',
              'policeName|1': ['张三', '李四', '王麻子', '狗腿子'],
              'position|1': ['福田区莲花支路', '龙岗区坂雪岗大道', '罗湖区解放路'],
              'speedingType|1': ['类型1', '类型2', '类型3'],
              'speedingContent|1': ['南山大队', '福田大队', '罗湖大队', '宝安大队', '龙岗大队', '龙华大队'],
              beginTime: '@date("yyyy-MM-dd") @time("HH:mm:ss")'
            }
          ]
        }
      )
    }
  },
  {
    url: '/VehicleState/selectVehicleMenueList',
    type: 'post',
    response: config => {
      return Mock.mock(
        {
          code: 200,
          msg: '成功啦！',
          'data|10': [
            {
              vehicleNo: '@guid',
              'vehicleType|1': ['铁骑', '警用车'],
              'vehicleBrand|1': ['春风', '宝马', '大众', '奔驰'],
              comName: '@cparagraph(2,5)',
              tel: '@natural(13, 13)',
              'dadui|1': ['南山大队', '福田大队', '罗湖大队', '宝安大队', '龙岗大队', '龙华大队'],
              gangwei: '巡逻岗@natural(0, 100)',
              banci: '通宵班@natural(0, 100)',
              contact: '@cname',
              address: '@county(true)',
              inTime: '@date("yyyy-MM-dd") @time("HH:mm:ss")',
              states: '@natural(0, 2)'
            }
          ]
        }
      )
    }
  },
  // 预警轨迹查询
  {
    url: '/VehicleStateHis/selectVehicleStateHisListSpeeding',
    type: 'post',
    response: config => {
      return Mock.mock(
        {
          code: 200,
          msg: '成功啦！',
          'data|10': [
            {
              'vehicleNo|4': '@natural(0, 9)',
              'policeCode|4': '@natural(0, 9)',
              'position|1': ['福田区莲花支路', '龙岗区坂雪岗大道', '罗湖区解放路'],
              'timeRaw|1': ['100km/h', '80km/h', '50km/h'],
              beginTime: '@date("yyyy-MM-dd") @time("HH:mm:ss")',
              'longBaidu|113-114.10-20': 1
            }
          ]
        }
      )
    }
  }
]
