import { login, getInfo } from '@/api/user'
import { getToken, setToken, removeToken, getMapData, setMapData, removeUserInfo, removeMapData, setUserInfo, getUserInfoData } from '@/utils/auth'
import router, { resetRouter } from '@/router'
import { getListDict, getUnit, getUserInfo } from '@/api/public'
import { getQueryObject } from '@/utils'

const state = {
  token: getToken(),
  name: '',
  avatar: '',
  introduction: '',
  roles: [],
  mapData: {},
  unitData: [],
  userInfo: {},
  hasGetUserInfo: false,
  showLevelObj: {
    ZD: [],
    DD: [],
    level: 0 // 考核管理，可视化考核默认展示级别 0 支队 1 大队 2 民警
  }
}
const setLevel = (data = {}) => {
  const organLevel = { ...data }
  let level
  let ZD = []
  let DD = []
  if (organLevel['0']) {
    if (organLevel['0'].length > 1) {
      level = 0
    } else {
      if (organLevel['1'].length > 1) {
        let DDLength = 0 // 当前支队下大队的个数
        let DDObj = null // 大队
        const ZDCode = organLevel['0'][0].organCode
        organLevel['1'].forEach(o => {
          if (o.parentCode === ZDCode) {
            DDLength++
            DDObj = o
          }
        })
        if (DDLength === 1) {
          level = 2
          ZD = organLevel['0']
          DD = [DDObj]
        } else {
          level = 1
          ZD = organLevel['0']
        }
      } else {
        level = 2
        ZD = organLevel['0']
        DD = organLevel['1']
      }
    }
  } else {
    if (organLevel['1'].length > 1) {
      level = 1
    } else {
      level = 2
      DD = organLevel['1']
    }
  }
  return { level, ZD, DD }
}
const mutations = {
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_INTRODUCTION: (state, introduction) => {
    state.introduction = introduction
  },
  SET_NAME: (state, name) => {
    state.name = name
  },
  SET_AVATAR: (state, avatar) => {
    state.avatar = avatar
  },
  SET_ROLES: (state, roles) => {
    state.roles = roles
  },
  SET_MAPS: (state, mapData) => {
    state.mapData = mapData
  },
  SET_UNIT: (state, data) => {
    state.unitData = data
  },
  SET_USERINFO: (state, data) => {
    state.userInfo = data
    if (!state.hasGetUserInfo) state.hasGetUserInfo = true
  },
  SET_SHOW_LEVEL: (state, data) => {
    state.showLevelObj = data
  }
}
const actions = {
  // user login
  login({ commit }, userInfo) {
    const { username, password } = userInfo
    return new Promise((resolve, reject) => {
      login({ username: username.trim(), password: password }).then(response => {
        const { data } = response
        commit('SET_TOKEN', data.token)
        setToken(data.token)
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  // get user info
  getInfo({ commit, state }) {
    return new Promise((resolve, reject) => {
      getInfo(state.token).then(response => {
        const { data } = response

        if (!data) {
          reject('Verification failed, please Login again.')
        }

        const { roles, name, avatar, introduction } = data

        // roles must be a non-empty array
        if (!roles || roles.length <= 0) {
          reject('getInfo: roles must be a non-null array!')
        }

        commit('SET_ROLES', roles)
        commit('SET_NAME', name)
        commit('SET_AVATAR', avatar)
        commit('SET_INTRODUCTION', introduction)
        resolve(data)
      }).catch(error => {
        reject(error)
      })
    })
  },

  // user logout
  logout({ commit, state, dispatch }) {
    return new Promise((resolve, reject) => {
      removeToken()
      resetRouter()

      // reset visited views and cached views
      // to fixed https://github.com/PanJiaChen/vue-element-admin/issues/2485
      dispatch('tagsView/delAllViews', null, { root: true })
      window.location.href = window.CONFIG.UC
      resolve()
    })
  },

  // remove token
  resetToken({ commit }) {
    return new Promise(resolve => {
      commit('SET_TOKEN', '')
      commit('SET_ROLES', [])
      removeToken()
      removeUserInfo()
      removeMapData()
      resolve()
    })
  },

  // dynamically modify permissions
  async changeRoles({ commit, dispatch }, role = []) {
    resetRouter()
    // generate accessible routes policeMap based on roles
    const routerRoles = role
    const accessRoutes = await dispatch('permission/generateRoutes', routerRoles, { root: true })
    // dynamically add accessible routes
    router.addRoutes(accessRoutes)
    // reset visited views and cached views
    dispatch('tagsView/delAllViews', null, { root: true })
  },
  // 获取字典
  async getMapData({ commit, dispatch }) {
    const Params = getQueryObject()
    if (!Params.TICKET) {
      if (getMapData()) commit('SET_MAPS', getMapData())
    } else {
      return new Promise((resolve, reject) => {
        getListDict().then(response => {
          const { data, code } = response
          if (code === 200) {
            setMapData(data)
            commit('SET_MAPS', data)
            resolve(data)
          }
        }).catch(error => {
          reject(error)
        })
      })
    }
  },
  // 获取用户信息
  async getUserInfo({ commit, dispatch }) {
    const Params = getQueryObject()
    if (!Params.TICKET) {
      const userInfoData = getUserInfoData()
      if (userInfoData) {
        await commit('SET_USERINFO', userInfoData)
        commit('SET_SHOW_LEVEL', setLevel(userInfoData.organLevelMap))
        await dispatch('changeRoles', userInfoData.privateCode)
      }
    } else {
      const resData = await getUserInfo()
      const { data, code } = resData
      if (code === 200) {
        setUserInfo(data)
        await commit('SET_USERINFO', data)
        commit('SET_SHOW_LEVEL', setLevel(data.organLevelMap))
        await dispatch('changeRoles', data.privateCode)
      }
    }
  },
  // 获取TICKET or token
  async getTicket({ commit, dispatch }) {
    const Params = getQueryObject()
    let Token = ''
    if (Params.TICKET) {
      Token = Params.TICKET
      setToken(Token)
    } else {
      Token = getToken()
    }
    commit('SET_TOKEN', Token)
    await dispatch('getMapData')
  },
  // 获取单位数据
  getUnitData({ commit, dispatch }, param) {
    return new Promise((resove, reject) => {
      getUnit({ orgLevel: 1, orgSubType: 0, parentCode: 1 }).then(res => {
        commit('SET_UNIT', res.data)
        resove(res)
      }).catch(error => {
        reject(error)
      })
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
