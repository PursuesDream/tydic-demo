import {dapeng} from './dapeng.js'
import {yantian} from './yantian.js'
import {longhua} from './longhua.js'
import {longgang} from './longgang.js'
import {pingshan} from './pingshan.js'
import {luohu} from './luohu.js'
export const dongbu = {
	"type": "FeatureCollection",
	"features": [
		dapeng.features[0],
		yantian.features[0],
		longhua.features[0],
		longgang.features[0],
		pingshan.features[0],
		luohu.features[0],
	]
}