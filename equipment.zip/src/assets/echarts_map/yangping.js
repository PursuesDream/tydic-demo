export const geoGson =  {
	"type": "FeatureCollection",
	"features": [
	]
}
		