import {baoan} from './baoan.js'
import {nanshan} from './nanshan.js'
import {dapeng} from './dapeng.js'
import {guangming} from './guangming.js'
import {futian} from './futian.js'
import {yantian} from './yantian.js'
import {longhua} from './longhua.js'
import {longgang} from './longgang.js'
import {pingshan} from './pingshan.js'
import {luohu} from './luohu.js'
export const jixun = {
	"type": "FeatureCollection",
	"features": [
		baoan.features[0],
		nanshan.features[0],
		dapeng.features[0],
		guangming.features[0],
		futian.features[0],
		yantian.features[0],
		longhua.features[0],
		longgang.features[0],
		pingshan.features[0],
		luohu.features[0],
	]
}