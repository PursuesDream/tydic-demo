import {baoan} from './baoan.js'
import {nanshan} from './nanshan.js'
import {futian} from './futian.js'
import {longhua} from './longhua.js'
export const xibu = {
	"type": "FeatureCollection",
	"features": [
		baoan.features[0],
		nanshan.features[0],
		futian.features[0],
		longhua.features[0],
	]
}