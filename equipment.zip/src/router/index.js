import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)
/* Layout */
// import Layout from '@/layout'
import LifeCycleLayout from '@/layout/lifeCycle'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    noCache: true                if set true, the page will no be cached(default is false)
    affix: true                  if set true, the tag will affix in the tags-view
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    path: '/auth-redirect',
    component: () => import('@/views/login/auth-redirect'),
    hidden: true
  },
  {
    path: '/404',
    component: () => import('@/views/error-page/404'),
    hidden: true
  },
  {
    path: '/401',
    component: LifeCycleLayout,
    hidden: true,
    children: [
      {
        path: '',
        component: () => import('@/views/error-page/401'),
        name: '401',
        meta: { title: '401' }
      }
    ]
  },
  {
    path: '/',
    redirect: '/trafficMap',
    // component: LifeCycleLayout,
    hidden: true
  },
  // 首页
  /* {
    path: '/pageIndex',
    hidden: true,
    component: () => import('@/views/pageIndex/index'),
    name: 'PageIndex',
    meta: { title: '装备可视化' }
  }, */
  // 铁骑一张图
  {
    // path: '/trafficMap',
    path: '',
    component: LifeCycleLayout,
    hidden: true,
    children: [
      {
        path: '/trafficMap',
        component: () => import('@/views/trafficMap'),
        name: 'TrafficMap',
        meta: { title: '铁骑一张图', noCache: true }
      },
      {
        path: '/policeAppraisal/assessStatistics',
        component: () => import('@/views/policeAppraisal/assessStatistics'),
        name: 'assessStatistics',
        meta: { title: '考核统计', noCache: true }
      },
      {
        path: '/policeAppraisal/monthlyAssess',
        component: () => import('@/views/policeAppraisal/monthlyAssess'),
        name: 'monthlyAssess',
        meta: { title: '月底考核统计', noCache: true }
      }
    ]
  },
  // 实时监控
  {
    path: '/realTimeMonitoring',
    redirect: '/realTimeMonitoring/monitoring',
    component: LifeCycleLayout,
    hidden: true,
    children: [
      {
        path: 'monitoring',
        component: () => import('@/views/realTimeMonitoring/monitoring'),
        name: 'MonitoringPage',
        meta: { title: '实时监控' }
      }
    ]
  },
  // 统计分析
  {
    path: '/statisticAnalysis',
    component: LifeCycleLayout,
    hidden: true,
    children: [
      {
        path: 'maintainAnalysis',
        component: () => import('@/views/statisticAnalysis/maintainAnalysis'),
        name: 'MaintainAnalysis',
        meta: { title: '维保统计分析', icon: 'dashboard' }
      },
      {
        path: 'carAnalysis',
        component: () => import('@/views/statisticAnalysis/carAnalysis'),
        name: 'CarAnalysis',
        meta: { title: '车辆运营分析', icon: 'dashboard' }
      },
      {
        path: 'insuranceRecord',
        component: () => import('@/views/statisticAnalysis/insuranceRecord'),
        name: 'InsuranceRecord',
        meta: { title: '出险记录', icon: 'dashboard' }
      }
    ]
  }
]

const RoleKeys = window.CONFIG.roleKeys
// 需权限校验路由
const roleRoutes = [
  // 设备管理
  {
    path: '/equipmentManage',
    component: LifeCycleLayout,
    hidden: true,
    meta: { roleCode: RoleKeys.page1 },
    children: [
      {
        path: 'interphone',
        component: () => import('@/views/equipmentManage/interphone'),
        name: 'Interphone',
        meta: { title: '骑行装备管理', roleCode: RoleKeys.page3 }
      },
      {
        path: 'car',
        component: () => import('@/views/equipmentManage/car'),
        name: 'Car',
        meta: { title: '车辆管理', roleCode: RoleKeys.page2 }
      },
      {
        path: 'archives/:id(.*)',
        component: () => import('@/views/equipmentManage/archives'),
        name: 'Archives',
        meta: { title: '配套装备档案', noCache: true, activeMenu: '/equipmentManage/interphone' },
        hidden: true
      },
      {
        path: 'carArchives/:id(.*)',
        component: () => import('@/views/equipmentManage/carArchives'),
        name: 'CarArchives',
        meta: { title: '车辆档案', noCache: true, activeMenu: '/equipmentManage/car', roleCode: RoleKeys.button9 },
        hidden: true
      },
      {
        path: 'helmet',
        component: () => import('@/views/equipmentManage/helmet'),
        name: 'Helmet',
        meta: { title: '头盔管理' }
      },
      {
        path: 'manage',
        component: () => import('@/views/process/manage'),
        name: 'ProcessManage',
        meta: { title: '流程管理', roleCode: RoleKeys.page4 }
      }
    ]
  },
  // 流程管理
  {
    path: '/process',
    component: LifeCycleLayout,
    hidden: true,
    meta: { roleCode: RoleKeys.page1 },
    children: [
      // {
      //   path: 'manage',
      //   component: () => import('@/views/process/manage'),
      //   name: 'ProcessManage',
      //   meta: { title: '流程管理' }
      // },
      {
        path: 'info/:status(read|approval|back|invalid)/:id(.*)/:applyNumber(.*)',
        component: () => import('@/views/process/info'),
        name: 'ProcessInfo',
        meta: { title: '流程详情', noCache: true, activeMenu: '/process/manage', roleCode: RoleKeys.page4 },
        hidden: true
      },
      {
        path: 'apply/:id(.*)/:applyNumber(.*)',
        component: () => import('@/views/process/apply'),
        name: 'ProcessApply',
        meta: { title: '申请流程', noCache: true, activeMenu: '/process/manage', roleCode: RoleKeys.page4 },
        hidden: true
      }
    ]
  },
  // 民警考核
  {
    path: '/policeAppraisal',
    redirect: '/policeAppraisal/manage',
    component: LifeCycleLayout,
    name: 'PoliceAppraisal',
    hidden: true,
    meta: { roleCode: RoleKeys.page5 },
    children: [
      {
        path: 'manage',
        component: () => import('@/views/policeAppraisal/manage'),
        name: 'AppraisalManage',
        meta: { title: '考核管理', roleCode: RoleKeys.page6 }
      },
      {
        path: 'view',
        component: () => import('@/views/policeAppraisal/view'),
        name: 'AppraisalView',
        meta: {
          title: '可视化考核',
          noCache: true,
          roleCode: RoleKeys.page7
        }
      },
      {
        path: 'policeDetail/:id(.*)/:timeRange(.*)',
        component: () => import('@/views/policeAppraisal/policeDetail'),
        name: 'PoliceDetail',
        meta: { title: '民警档案 — ', noCache: true, activeMenu: '/policeAppraisal/manage', roleCode: RoleKeys.page6 },
        hidden: true
      },
      {
        path: 'claimResults',
        component: () => import('@/views/policeAppraisal/claimResults'),
        name: 'ClaimResults',
        meta: { title: '战果认领', roleCode: RoleKeys.page8 }
      }
    ]
  },
  // 综合管理
  {
    path: '/integratedManage',
    component: LifeCycleLayout,
    hidden: true,
    meta: { roleCode: RoleKeys.page9 },
    children: [
      // {
      //   path: 'category',
      //   component: () => import('@/views/integratedManage/category'),
      //   name: 'Category',
      //   meta: { title: '类目管理' }
      // },
      {
        path: 'systemSettings',
        component: () => import('@/views/systemSettings/index'),
        name: 'SettingEq',
        meta: { title: '装备配置管理', roleCode: RoleKeys.page14 }
      },
      {
        path: 'maintenance',
        component: () => import('@/views/integratedManage/maintenance'),
        name: 'Maintenance',
        meta: { title: '维保单位管理', roleCode: RoleKeys.page10 }
      },
      {
        path: 'project',
        component: () => import('@/views/integratedManage/project'),
        name: 'Project',
        meta: { title: '维保项目管理', roleCode: RoleKeys.page11 }
      },
      {
        path: 'workflowManage',
        component: () => import('@/views/integratedManage/workflowManage'),
        name: 'WorkflowManage',
        meta: { title: '流程配置', roleCode: RoleKeys.page13 }
      },
      // {
      //   path: 'workflowConfig',
      //   component: () => import('@/views/integratedManage/workflowConfig'),
      //   name: 'WorkflowConfig',
      //   meta: { title: '流程配置' }
      // },
      {
        path: 'workflowConfig/:id(.*)',
        component: () => import('@/views/integratedManage/workflowConfig'),
        name: 'WorkflowConfig',
        meta: { title: '流程配置', roleCode: RoleKeys.page13 }
      },
      {
        path: 'qrcode',
        component: () => import('@/views/qrcode/index'),
        name: 'Qrcode',
        meta: { title: '二维码管理', noCache: true, activeMenu: '/integratedManage/category', roleCode: RoleKeys.page12 }
      }
      // {
      //   path: 'attributeManage',
      //   component: () => import('@/views/attributeManage/index'),
      //   name: 'AttributeManage',
      //   meta: { title: '装备属性管理' }
      // }
    ]
  },
  { path: '*', redirect: '/404', hidden: true }
]
/**
 * asyncRoutes
 * the routes that need to be dynamically loaded based on user roles
 */
export const asyncRoutes = roleRoutes || []

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes,
  base: process.env.VUE_APP_PUBLIC_PATH
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
