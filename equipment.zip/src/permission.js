import router from './router'
/* import store from './store'
import { Message } from 'element-ui' */
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
import { getTokenByUrl } from '@/utils/auth' // get token from cookie
import getPageTitle from '@/utils/get-page-title'
import store from '@/store'
NProgress.configure({ showSpinner: false }) // NProgress Configuration

const whiteList = ['/login', '/401', '/auth-redirect'] // no redirect whitelist
const noPermisiion = ['/trafficMap', '/policeAppraisal/assessStatistics', '/policeAppraisal/monthlyAssess']
router.beforeEach(async(to, from, next) => {
  // start progress bar
  NProgress.start()

  // set page title
  document.title = getPageTitle(to.meta.title)

  // determine whether the user has logged in
  const hasTokenByUrl = await getTokenByUrl()
  if (hasTokenByUrl) {
    if (to.path === '/login') {
      // if is logged in, redirect to the home page
      // next({ path: '/' })
      window.location.href = window.CONFIG.UC
      NProgress.done() // hack: https://github.com/PanJiaChen/vue-element-admin/pull/2939
    } else {
      // determine whether the user has obtained his permission roles through getInfo
      // next()
      const addRoutes = store.state.permission.addRoutes
      const hasGetUserInfo = store.state.user.hasGetUserInfo
      if (addRoutes.length === 0 && !hasGetUserInfo) {
        // 获取动态路由
        await store.dispatch('user/getUserInfo').then(_ => {
          next(to.path)
        })
      } else {
        // 匹配路由权限
        const roleCode = to.meta && to.meta.roleCode || ''
        const newList = whiteList.concat(noPermisiion)
        if (newList.indexOf(to.path) !== -1) { // 不需校验权限
          next()
        } else if (roleCode) { // 有权限
          next()
        } else { // 无权限
          next('/401')
        }
      }
    }
  } else {
    /* has no token*/
    if (whiteList.indexOf(to.path) !== -1) {
      // in the free login whitelist, go directly
      next()
    } else {
      // other pages that do not have permission to access are redirected to the login page.
      // next(`/login?redirect=${to.path}`)
      window.location.href = window.CONFIG.UC
      // next()
      NProgress.done()
    }
  }
})
/* const resizeFontSize = () => {
  const htmlDom = document.getElementsByTagName('html')[0]
  const htmlWidth = document.documentElement.clientWidth || document.body.clientWidth
  htmlDom.style.fontSize = htmlWidth / 19.2 + 'px'
} */
// 清除 图盟地图（高德）MapABC的selectstart 不可复制事件
const unbindDefaultEvent = () => {
  let L = null
  if (window.L) L = window.L
  if (L) {
    L.DomEvent.off(window, 'selectstart', L.DomEvent.preventDefault)
  }
}
router.afterEach((to, from) => {
  // finish progress bar
  const path = to.path
  /* if (path === '/pageIndex') {
    resizeFontSize()
    window.addEventListener('resize', resizeFontSize)
  } else {
    document.getElementsByTagName('html')[0].style.fontSize = ''
    window.removeEventListener('resize', resizeFontSize)
  } */
  if (path !== '/trafficMap') unbindDefaultEvent()
  NProgress.done()
})
