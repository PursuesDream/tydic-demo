import { getQueryObject } from './index'
import store from '@/store'

const TokenKey = 'TICKET'
const MapDataKey = 'MapData'
const UserInfoKey = 'UserInfo'
export function getToken() {
  // store.dispatch('user/getMapData')
  return sessionStorage.getItem(TokenKey)
}
export function setToken(token) {
  return sessionStorage.setItem(TokenKey, token)
}

export function removeToken() {
  return sessionStorage.removeItem(TokenKey)
}
export function getMapData() {
  const mapDataStr = sessionStorage.getItem(MapDataKey)
  if (mapDataStr) return JSON.parse(mapDataStr)
  else return ''
}

export function setMapData(mapData) {
  const mapDataStr = JSON.stringify(mapData)
  sessionStorage.setItem(MapDataKey, mapDataStr)
}

export function removeMapData() {
  return sessionStorage.removeItem(MapDataKey)
}

export function getUserInfoData() {
  const userInfoStr = sessionStorage.getItem(UserInfoKey)
  if (userInfoStr) return JSON.parse(userInfoStr)
  else return ''
}
export function setUserInfo(userInfo) {
  const userInfoStr = JSON.stringify(userInfo)
  sessionStorage.setItem(UserInfoKey, userInfoStr)
}
export function removeUserInfo() {
  return sessionStorage.removeItem(UserInfoKey)
}
export async function getTokenByUrl() {
  const Params = getQueryObject()
  let hasToken = false
  if (Params[TokenKey] || getToken()) {
    await store.dispatch('user/getTicket')
    hasToken = true
  }
  return hasToken
}
