import motoIcon from '../../assets/map/icon_22.png'
import warningMotoIcon from '../../assets/map/warning.png'
import motoIcon2 from '../../assets/map/icon_23.png'
import closeIcon from '../../assets/mapIcon/close_icon.png'
import mapStartIcon from '../../assets/mapIcon/map_origin_icon.png'
// import mapEndIcon from '../../assets/mapIcon/map_terminus_icon.png'
import {
  Notification
} from 'element-ui'
const BMap = window.BMap
const BMapLib = window.BMapLib
let intervalWarn
// const infoBox = window.infoBox

function initMap(dom) {
  const maps = new BMap.Map(dom)
  const point = new BMap.Point(116.417804, 39.940296)
  maps.centerAndZoom(point, 13)
  maps.enableScrollWheelZoom() // 启用滚轮放大缩小，默认禁用
  maps.enableContinuousZoom() // 启用地图惯性拖拽，默认禁用
  return maps
}
/*
 * 创建点位
 * map：创建地图元素
 * data：坐标数据
 * layerId：覆盖物标识
 * */
function addAreaPoint(map, data, layerId) {
  const pt = new BMap.Point(data.longBaidu, data.latBaidu)
  const icons = new BMap.Icon(motoIcon, new BMap.Size(62, 52), {
    anchor: new BMap.Size(31, 26)
  })
  const mkr = new BMap.Marker(pt, {
    icon: icons
  })
  window.lastInfoBox = null
  mkr.layerId = layerId
  // map.addOverlay(mkr)
  let stateColor = ''
  if (Number(data.speed) > 70) {
    stateColor = 'red'
  } else {
    stateColor = '#fff'
  }
  // <p style="color:#0000ff">位置: ${data.position || ''}</p><p style="color:red;font-weight:bold;padding-top:10px">超速预警</p>
  const dom = `<div style="background: rgba(0,0,0,.7);padding-left: 20px;border-radius:5px">
                <p style="color:#fff;padding-top: 20px;">时间: ${data.timeRaw || ''}</p>
                <p style="color:#fff">位置: ${data.position || ''}</p>
                <p style="color:#fff">行驶速度:<span style="padding:0px 5px;color:${stateColor}"> ${data.speed || '0'}</span>km/h</p>
                <p style="color:#fff;padding-bottom: 10px;">车牌号: ${data.vehicleNo || ''}</p>
              </div>`
  mkr.addEventListener('click', function() {
    const infoBox = new BMapLib.InfoBox(map, dom, {
      boxStyle: {
        width: '300px'
      },
      closeIconMargin: '17px 4px 0 0',
      closeIconUrl: closeIcon,
      enableAutoPan: false
      // offset: new BMap.Size(50, 50)
    })
    const marker = new BMap.Marker(pt, {
      icon: icons
    })
    if (window.lastInfoBox) {
      window.lastInfoBox.close()
    }
    window.lastInfoBox = infoBox
    infoBox.open(marker)
  })
  return mkr
}
// 轨迹动画
function trackAnimation(map, pointArr, speedVal, endCallBack) {
  speedVal = 1000 * 500 / speedVal
  let iconType = null
  let iconSize = null
  let imgSize = null
  iconType = motoIcon
  iconSize = new BMap.Size(38, 30)
  imgSize = {
    imageSize: new BMap.Size(38, 30)
  }
  var PointArr = pointArr
  map.centerAndZoom(PointArr, 13) // 根据经纬度显示地图的范围
  map.setViewport(PointArr, {
    zoomFactor: 0
  }) // 根据提供的地理区域或坐标设置地图视野

  if (PointArr.length > 0) {
    addStartMarker(new BMap.Point(PointArr[0].lng, PointArr[0].lat), '起点', map)
    var carMk // 先将终点坐标展示的mark对象定义
    // 小车行驶图标
    var drivingPoint = new BMap.Icon(iconType, iconSize, imgSize)
    // 终点图标
    var terminalPoint = new BMap.Icon(iconType, new BMap.Size(26, 32), {
      // anchor : new BMap.Size(20, 45),
      imageSize: new BMap.Size(26, 32)
    })
    var i = 0
    intervalWarn = setInterval(function() {
      if (i >= PointArr.length) {
        clearInterval(intervalWarn)
        endCallBack && endCallBack()
        return
      }
      drowLine(map, PointArr[i], PointArr[i + 1]) // 画线调用
      i = i + 1
    }, speedVal)
    return intervalWarn
  } else {
    Notification({
      title: '提示',
      message: '此车辆此时间段暂无轨迹数据',
      type: 'warning',
      duration: 2000
    })
    return null
  }

  // 划线
  function drowLine(map, PointArr, PointArrNext) {
    if (PointArrNext !== undefined) {
      var polyline = new BMap.Polyline(
        [
          new BMap.Point(PointArr.lng, PointArr.lat),
          new BMap.Point(PointArrNext.lng, PointArrNext.lat)
        ], {
          strokeColor: '#ff00ff',
          strokeWeight: 5,
          strokeStyle: 'dashed'
        }) // 创建折线
      polyline.layerId = '小车运动'
      map.addOverlay(polyline)
      addMarkerEnd(new BMap.Point(PointArrNext.lng, PointArrNext.lat), '小车行驶', map, PointArrNext, new BMap.Point(PointArr.lng, PointArr.lat)) // 添加图标
    } else {
      addMarkerEnd(new BMap.Point(PointArr.lng, PointArr.lat), '终点', map) // 添加终点图标
    }
  }
  // 添加起始图标
  function addStartMarker(point, name, mapInit) {
    if (name === '起点') {
      var myIcon = new BMap.Icon(mapStartIcon, new BMap.Size(26, 32), {
        imageSize: new BMap.Size(26, 32) // 图标所用的图片的大小，此功能的作用等同于CSS中的background-size属性。可用于实现高清屏的高清效果
      })
      window.marker = new BMap.Marker(point, {
        icon: myIcon
      }) // 创建标注
      window.marker.layerId = '小车运动'
      mapInit.addOverlay(window.marker) // 将标注添加到地图中
      // marker.setAnimation(BMAP_ANIMATION_BOUNCE); //跳动的动画
    }
  }
  // 添加行驶和终点图标
  function addMarkerEnd(point, name, mapInit, trackUnit, prePoint) {
    if (name === '小车行驶') {
      if (carMk) { // 先判断第一次进来的时候这个值有没有定义，有的话就清除掉上一次的。然后在进行画图标。第一次进来时候没有定义也就不走这块，直接进行画图标
        mapInit.removeOverlay(carMk)
      }
      carMk = new BMap.Marker(point, {
        icon: drivingPoint
      }) // 创建标注
      carMk.layerId = '小车运动'
      carMk.setRotation(trackUnit.route) // trackUnit.route
      mapInit.addOverlay(carMk) // 将标注添加到地图中
    } else {
      mapInit.removeOverlay(carMk)
      carMk = new BMap.Marker(point, {
        icon: terminalPoint
      }) // 创建标注
      carMk.layerId = '小车运动'
      mapInit.addOverlay(carMk)
    }
  }
}
/*
 * 创建轨迹
 * policeMap：创建地图元素
 * data：坐标数据
 * layerId：覆盖物标识
 * */
function addTrack(map, data, layerId, color = '#1a67d3') {
  const point = []
  data.forEach(item => {
    point.push(new BMap.Point(item.lng, item.lat))
  })
  var polygon = new BMap.Polyline(point, {
    strokeColor: color,
    strokeWeight: 3,
    strokeOpacity: 1
  })
  polygon.layerId = layerId
  map.addOverlay(polygon)
}

function addMotoPoint(map, data, layerId, vehicle, callback, isShowMap = true) {
  const pt = new BMap.Point(data.lng, data.lat)
  // 没有扫码的，需要感叹号车辆
  let Icon = motoIcon
  const icons = new BMap.Icon(Icon, new BMap.Size(52, 48))
  const mkr = new BMap.Marker(pt, {
    icon: icons
  })
  mkr.layerId = layerId
  let className = ''
  if (data.flag === 1) {
    Icon = warningMotoIcon
    className = 'map-warning'
  } else if (data.flag === 2) {
    Icon = warningMotoIcon
    className = 'map-gray'
  }

  const dom = `<div class="map-info ${className}">
                <div>${vehicle.deviceNo}</div>
                <div>${vehicle.speed || 0} km/h</div>
              </div>`
  const label = new BMap.Label(dom, {
    offset: new BMap.Size(-20, 50)
  })
  label.setStyles({
    border: 'none'
  })
  mkr.setLabel(label)
  const infoBoxOption = {
    dom,
    option: {
      boxStyle: {
        width: '256px',
        align: window.INFOBOX_AT_BOTTOM
      },
      enableAutoPan: true,
      offset: new BMap.Size(10, 10)
    },
    isOpen: false
  }
  // infoBox.open(mkr)
  mkr.infoBoxOption = infoBoxOption
  if (callback) {
    mkr.addEventListener('click', function(e) {
      callback(vehicle)
    })
  }
  if (isShowMap) map.addOverlay(mkr)
  return mkr
}

function getpointitem(xoy1, xoy2, num, m) {
  return (xoy2 - xoy1) / num * m + xoy1
}

function movePoint(map, statPoint, endPoint, speed = 100, vehicle, isSetCenter = false) {
  const count = 10
  const _startPoint = map.getMapType().getProjection().lngLatToPoint(statPoint)
  const _endPoint = map.getMapType().getProjection().lngLatToPoint(endPoint)
  // if (carMap[vehicle.vehicleId]) {
  //   carMap[vehicle.vehicleId].infoBox.close()
  //   map.removeOverlay(carMap[vehicle.vehicleId])
  //   carMap[vehicle.vehicleId] = null
  // }
  removeMapOverlay(map, '警车' + vehicle.vehicleId)
  addMotoPoint(map, statPoint, '警车' + vehicle.vehicleId, vehicle)

  var currentCount = 0
  // 两点之间匀速移动
  var intervalFlag = setInterval(function() {
    // 两点之间当前帧数大于总帧数的时候，则说明已经完成移动
    if (currentCount >= count) {
      clearInterval(intervalFlag)
      // lastCarMkr = carMkr
      // carMap[vehicle.vehicleId] = carMkr
    } else {
      // 动画移动
      currentCount++ // 计数
      var x = getpointitem(_startPoint.x, _endPoint.x, count, currentCount)
      var y = getpointitem(_startPoint.y, _endPoint.y, count, currentCount)
      // 根据平面坐标转化为球面坐标
      var pos = map.getMapType().getProjection().pointToLngLat(new BMap.Pixel(x, y))

      removeMapOverlay(map, '警车' + vehicle.vehicleId)

      addMotoPoint(map, pos, '警车' + vehicle.vehicleId, vehicle)
      // carMkr.setRotation(getAngle(statPoint, endPoint) - 90) // 旋转的角度
      if (isSetCenter) map.panTo(pos)
    }
  }, speed)
}
/*
 * 删除地图覆盖物
 * map：创建地图元素
 * layerId：覆盖物标识
 * */
function removeMapOverlay(map, layerId) {
  const allOverlay = map.getOverlays()
  const newReg = new RegExp(layerId)
  allOverlay.forEach(item => {
    if (newReg.test(item.layerId)) {
      map.removeOverlay(item)
    }
  })
}
let markerClusterer = null
// 聚合添加
function markerClustersPoint(map, data = [], callback) {
  if (data.length === 0) return null
  const layerId = '铁骑'
  const markers = data.map(o => {
    const type = (o.isUse === null || o.isUse === undefined) ? '0' : o.isUse // 是否使用0-使用中1-未使用
    const point = {
      lat: o.latBaidu,
      lng: o.longBaidu,
      type: type,
      flag: o.flag
    }
    return addMotoPoint(map, point, layerId, o, callback, false)
  })
  markerClusterer = new BMapLib.MarkerClusterer(map, {
    markers
  })

  var myStyles = [{
    url: motoIcon2,
    size: new BMap.Size(75, 66),
    anchor: new BMap.Size(1, 1),
    textColor: '#fff',
    textSize: 12
  }, {
    url: motoIcon2,
    size: new BMap.Size(75, 66),
    anchor: new BMap.Size(1, 1),
    textColor: '#fff',
    textSize: 12
  }, {
    url: motoIcon2,
    size: new BMap.Size(75, 66),
    anchor: new BMap.Size(1, 1),
    textColor: '#fff',
    textSize: 12
  }]
  markerClusterer.setStyles(myStyles)
  return markerClusterer
}

// 清理聚合
function clearDataCluster(maps) {
  if (markerClusterer) {
    markerClusterer.clearMarkers()
    markerClusterer = null
  }
  removeMapOverlay(maps, '铁骑')
}
// 暂无实现
function districtSearch(map, keyword) {
  console.info('显示行政区域：' + keyword)
}
// 暂无实现
function trafficLayerMap(map, isOn) {

}

export default {
  initMap(dom) {
    return initMap(dom)
  },
  addMotoPoint(map, data, layerId, vehicle) {
    return addMotoPoint(map, data, layerId, vehicle)
  },
  addTrack(map, data, layerId, color) {
    return addTrack(map, data, layerId, color)
  },
  addAreaPoint(map, data, layerId) {
    return addAreaPoint(map, data, layerId)
  },
  trackAnimation(map, data, speedVal, endCallBack) {
    return trackAnimation(map, data, speedVal, endCallBack)
  },
  removeMapOverlay(map, layerId) {
    return removeMapOverlay(map, layerId)
  },
  clearWarnTime(map, layerId) {
    removeMapOverlay(map, layerId)
    clearInterval(intervalWarn)
  },
  markerClustersPoint(map, markers, callback) {
    return markerClustersPoint(map, markers, callback)
  },
  movePoint(map, statPoint, endPoint, vehicle, speed, isSetCenter) {
    return movePoint(map, statPoint, endPoint, speed, vehicle, isSetCenter)
  },
  // 清理聚合的
  clearDataCluster(maps) {
    return clearDataCluster(maps)
  },
  // 区域电子围栏，第二个参数为区名，比如西城
  districtSearch(map, keyword) {
    return districtSearch(map, keyword)
  },
  // 路况,第二个参数为是否开启路口
  trafficLayerMap(map, isOn) {
    return trafficLayerMap(map, isOn)
  }
}
