import motoIcon from '../../assets/map/icon_22.png'
import warningMotoIcon from '../../assets/map/warning.png'
import motoIcon2 from '../../assets/map/icon_23.png'
// import closeIcon from '../../assets/mapIcon/close_icon.png'
import mapStartIcon from '../../assets/mapIcon/map_origin_icon.png'
import mapEndIcon from '../../assets/mapIcon/map_terminus_icon.png'
import {
  Notification
} from 'element-ui'
const IMAP = window.IMAP
// const BMapLib = window.BMapLib
let intervalWarn
const maxZoom = 20
// 存储覆盖物集合
// const overlayMap = new Map()
// const infoBox = window.infoBox
import { getDistrictArea } from '@/api/boundaryZone'

function initMap(dom = 'map', isBlack = false) {
  var host = window.host
  var opts = {
    minZoom: 3,
    maxZoom: maxZoom,
    zoom: 13, // 设置地图初始化级别
    center: new IMAP.LngLat(116.417804, 39.940296), // 设置地图中心点坐标
    animation: true // 设置地图缩放动画效果
  }
  if (!isBlack) {
    opts.tileUrl = ['http://{s}/v3/tile?z={z}&x={x}&y={y}', [host + ':25333', host + ':25333']]
  }
  var maps = new IMAP.Map(dom, opts)
  RoadNetLayer = addRoadNetLayer(maps, isBlack)

  // 比例尺
  //  let navi = new IMAP.NavigationControl({
  //     visible: true
  //     });
  //     maps.addControl(navi);

  return maps
}
var RoadNetLayer = null
var host = window.host

// 添加路网图层,黑底地图的图层
function addRoadNetLayer(map, isBlack) {
  var port = isBlack ? 25033 : 25333
  var ROADNET_URL = 'http://' + host + ':' + port + '/v3/tile?x={x}&y={y}&z={z}'
  var getRoadTileUrl = function(x, y, z) {
    return ROADNET_URL.replace('{x}', x)
      .replace('{y}', y)
      .replace('{z}', z)
  }
  var RoadLayer = new IMAP.TileLayer({
    maxZoom: maxZoom,
    minZoom: 1,
    tileSize: 256
  })
  RoadLayer.setTileUrlFunc(getRoadTileUrl)
  RoadLayer.setOpacity(0.9)
  // 设置图层透明度，取值范围0-1
  map.addLayer(RoadLayer)

  return RoadLayer
}
/*
 * 创建点位
 * map：创建地图元素
 * data：坐标数据
 * layerId：覆盖物标识
 * */
function addAreaPoint(map, data, layerId) {
  // const pt = new BMap.Point(data.longGaode, data.latGaode)
  // const icons = new BMap.Icon(motoIcon, new BMap.Size(62, 52), {
  //   anchor: new BMap.Size(31, 26)
  // })
  // const mkr = new BMap.Marker(pt, {
  //   icon: icons
  // })
  // window.lastInfoBox = null
  // mkr.layerId = layerId
  // // map.addOverlay(mkr)
  // let stateColor = ''
  // if (Number(data.speed) > 70) {
  //   stateColor = 'red'
  // } else {
  //   stateColor = '#fff'
  // }
  // // <p style="color:#0000ff">位置: ${data.position || ''}</p><p style="color:red;font-weight:bold;padding-top:10px">超速预警</p>
  // const dom = `<div style="background: rgba(0,0,0,.7);padding-left: 20px;border-radius:5px">
  //               <p style="color:#fff;padding-top: 20px;">时间: ${data.timeRaw || ''}</p>
  //               <p style="color:#fff">位置: ${data.position || ''}</p>
  //               <p style="color:#fff">行驶速度:<span style="padding:0px 5px;color:${stateColor}"> ${data.speed || '0'}</span>km/h</p>
  //               <p style="color:#fff;padding-bottom: 10px;">车牌号: ${data.vehicleNo || ''}</p>
  //             </div>`
  // mkr.addEventListener('click', function () {
  //   const infoBox = new BMapLib.InfoBox(map, dom, {
  //     boxStyle: {
  //       width: '300px'
  //     },
  //     closeIconMargin: '17px 4px 0 0',
  //     closeIconUrl: closeIcon,
  //     enableAutoPan: false
  //     // offset: new BMap.Size(50, 50)
  //   })
  //   const marker = new BMap.Marker(pt, {
  //     icon: icons
  //   })
  //   if (window.lastInfoBox) {
  //     window.lastInfoBox.close()
  //   }
  //   window.lastInfoBox = infoBox
  //   infoBox.open(marker)
  // })
  // return mkr
}

function addStartMarker(map, data, layerId) {
  var myIcon = new IMAP.Icon(mapStartIcon, {
    'size': new IMAP.Size(26, 33)
  })
  var sMarker = new IMAP.Marker(new IMAP.LngLat(data.longGaode, data.latGaode), {
    icon: myIcon,
    anchor: IMAP.Constants.BOTTOM_CENTER
  }) // 创建标注
  sMarker.layerId = layerId
  map.getOverlayLayer().addOverlay(sMarker) // 将标注添加到地图中
}

function addPointMarker(map, data, layerId) {
  var opts = new IMAP.MarkerOptions()
  opts.anchor = IMAP.Constants.CENTER
  opts.icon = new IMAP.Icon(motoIcon, {
    'size': new IMAP.Size(74, 66)
  })
  var marker = new IMAP.Marker(new IMAP.LngLat(data.longGaode, data.latGaode), opts)
  marker.layerId = layerId
  map.getOverlayLayer().addOverlay(marker, false)
  return marker
}

function addMarkerEnd(map, data, layerId) {
  var myIcon = new IMAP.Icon(mapEndIcon, {
    'size': new IMAP.Size(26, 33)
  })
  var sMarker = new IMAP.Marker(new IMAP.LngLat(data.longGaode, data.latGaode), {
    icon: myIcon,
    anchor: IMAP.Constants.BOTTOM_CENTER
  }) // 创建标注
  sMarker.layerId = layerId
  map.getOverlayLayer().addOverlay(sMarker) // 将标注添加到地图中
}

function trackAnimation(map, pointArr, speedVal, endCallBack) {
  if (pointArr.length > 0) {
    var path = pointArr.map(item => {
      return new IMAP.LngLat(item.longGaode, item.latGaode)
    })

    map.setBestMap(path)
    const layerId = '小车运动'

    addStartMarker(map, pointArr[0], layerId)
    var marker = addPointMarker(map, pointArr[0], layerId)
    addMarkerEnd(map, pointArr[pointArr.length - 1], layerId)

    var line = new IMAP.Polyline(path, {
      strokeColor: '#ff00ff',
      strokeWeight: 3,
      strokeStyle: [10, 5] // 无效
    })
    line.layerId = layerId
    map.getOverlayLayer().addOverlay(line)
    // 参数3，是否重复播放  参数4 是否车头跟随
    marker.moveAlong(path, speedVal / 50, false, false)
    return marker
  } else {
    Notification({
      title: '提示',
      message: '此车辆此时间段暂无轨迹数据',
      type: 'warning',
      duration: 2000
    })
    return null
  }
}
/*
 * 创建轨迹
 * policeMap：创建地图元素
 * data：坐标数据
 * layerId：覆盖物标识
 * */
function addTrack(map, data, layerId, color = '#1a67d3') {
  const point = []
  data.forEach(item => {
    point.push(new IMAP.LngLat(item.longGaode, item.latGaode))
  })

  var polyline = new IMAP.Polyline(point, {
    strokeColor: color,
    strokeWeight: 3,
    'strokeOpacity': 1
  })
  polyline.layerId = layerId
  map.getOverlayLayer().addOverlay(polyline, false)
}

function addMotoPoint(map, data, layerId, vehicle, callback, isShowMap = true) {
  var opts = new IMAP.MarkerOptions()
  opts.anchor = IMAP.Constants.CENTER
  let Icon = motoIcon
  opts.icon = new IMAP.Icon(Icon, {
    'size': new IMAP.Size(52, 48)
  })

  var lnglat = new IMAP.LngLat(data.longGaode, data.latGaode)
  var marker = new IMAP.Marker(lnglat, opts)
  marker.layerId = layerId

  let className = ''
  if (data.flag === 1) {
    Icon = warningMotoIcon
    className = 'map-warning'
  } else if (data.flag === 2) {
    Icon = warningMotoIcon
    className = 'map-gray'
  }

  const dom = `<div class="map-info ${className}">
                <div>${vehicle.deviceNo}</div>
                <div>${vehicle.speed || 0} km/h</div>
              </div>`
  marker.domLabel = dom

  if (callback) {
    marker.addEventListener('click', function(e) {
      callback(vehicle)
    })
  }
  if (isShowMap) {
    map.getOverlayLayer().addOverlay(marker, false)
    marker.setLabel(dom, {
      'offset': new IMAP.Pixel(-50, 30)
    })
  }
  return marker
}

// function getpointitem(xoy1, xoy2, num, m) {
//   return (xoy2 - xoy1) / num * m + xoy1
// }

function movePoint(map, statPoint, endPoint, speed = 100, vehicle, isSetCenter = false) {
  // const count = 10
  // const _startPoint = map.getMapType().getProjection().lngLatToPoint(statPoint)
  // const _endPoint = map.getMapType().getProjection().lngLatToPoint(endPoint)
  // // if (carMap[vehicle.vehicleId]) {
  // //   carMap[vehicle.vehicleId].infoBox.close()
  // //   map.removeOverlay(carMap[vehicle.vehicleId])
  // //   carMap[vehicle.vehicleId] = null
  // // }
  // removeMapOverlay(map, '警车' + vehicle.vehicleId)
  // addMotoPoint(map, statPoint, '警车' + vehicle.vehicleId, vehicle)

  // var currentCount = 0
  // // 两点之间匀速移动
  // var intervalFlag = setInterval(function() {
  //   // 两点之间当前帧数大于总帧数的时候，则说明已经完成移动
  //   if (currentCount >= count) {
  //     clearInterval(intervalFlag)
  //     // lastCarMkr = carMkr
  //     // carMap[vehicle.vehicleId] = carMkr
  //   } else {
  //     // 动画移动
  //     currentCount++ // 计数
  //     var x = getpointitem(_startPoint.x, _endPoint.x, count, currentCount)
  //     var y = getpointitem(_startPoint.y, _endPoint.y, count, currentCount)
  //     // 根据平面坐标转化为球面坐标
  //     var pos = map.getMapType().getProjection().pointToLngLat(new BMap.Pixel(x, y))

  //     removeMapOverlay(map, '警车' + vehicle.vehicleId)

  //     addMotoPoint(map, pos, '警车' + vehicle.vehicleId, vehicle)
  //     // carMkr.setRotation(getAngle(statPoint, endPoint) - 90) // 旋转的角度
  //     if (isSetCenter) map.panTo(pos)
  //   }
  // }, speed)
}
/*
 * 删除地图覆盖物
 * map：创建地图元素
 * layerId：覆盖物标识
 * */
function removeMapOverlay(maps, layerId) {
  const allOverlay = maps.getOverlayLayer()
  for (const item in allOverlay.getOverlays()) {
    // console.info(allOverlay.getOverlayById(item).layerId)
    if (allOverlay.getOverlayById(item).layerId === layerId) {
      allOverlay.removeOverlay(item)
    }
  }
}
// 聚合实体类记录
let clusterList = []
// var dataCluster
// 聚合添加
function markerClustersPoint(map, data = [], callback) {
  clearDataCluster(map)
  // console.info('调用')
  if (data.length === 0) {
    return
  }
  // console.info(new Date())
  const layerId = '铁骑'
  const markers = data.map(o => {
    const type = (o.isUse === null || o.isUse === undefined) ? '0' : o.isUse // 是否使用0-使用中1-未使用
    const point = {
      latGaode: o.latGaode,
      longGaode: o.longGaode,
      type: type,
      flag: o.flag
    }
    return addMotoPoint(map, point, layerId, o, callback, false)
  })

  // map.getOverlayLayer().addOverlays(markers)
  // console.info(new Date())
  // 创建聚合管理对象 并将各参数设置到其中
  map.plugin(['IMAP.DataCluster'], function() {
    const dataCluster = new IMAP.DataCluster(map, markers, {
      zoomOnClick: true,
      // minimumClusterSize: 3,
      averageCenter: true,
      // maxZoom: maxZoom,
      styles: [{
        url: motoIcon2,
        height: 69,
        width: 83,
        textSize: 10,
        textColor: 'white',
        anchor: [7, 17]
      },
      {
        url: motoIcon2,
        height: 69,
        width: 79,
        textSize: 10,
        textColor: 'white',
        anchor: [7, 13]
      }, {
        url: motoIcon2,
        height: 69,
        width: 76,
        textSize: 8,
        textColor: 'white',
        anchor: [7, 10]
      }
      ]
    })
    clusterList.push(dataCluster)

    markers.forEach(item => {
      if (item.getMap()) {
        item.showLabel = true
        item.setLabel(item.domLabel, {
          'offset': new IMAP.Pixel(-50, 30)
        })
      }
    })

    map.addEventListener(IMAP.Constants.ZOOM_CHANGED, e => {
      setTimeout(() => {
        markers.forEach(item => {
          if (item.getMap() && !item.showLabel) {
            item.showLabel = true
            item.setLabel(item.domLabel, {
              'offset': new IMAP.Pixel(-50, 30)
            })
          }
        })
      }, 80)
    }, map)
  })
}

function clearDataCluster(maps) {
  // console.info(clusterList.length)
  clusterList.forEach(dataCluster => {
    if (dataCluster && dataCluster.getClusters().length > 0) {
      dataCluster.clearMarkers()
    }
    dataCluster = null
  })
  clusterList = []
  removeMapOverlay(maps, '铁骑')
}
// const colors = ['#3366cc', '#dc3912', '#ffc100', '#9fb40f', '#76523b', '#0e8e89', '#651067', '#f383a2', '#247fea', '#2bcb95', '#bbabf4', '#1d42c2', '#1d9ed1', '#d64bc0', '#e67300', '#8b0707', '#3b3eac']
// // '顺义',, '大兴', '门头沟', '平谷', '怀柔', '密云', '延庆'
// const citys = ['西城', '东城', '朝阳', '丰台', '石景山', '海淀', '通州', '房山', '昌平']

function districtSearch(map, organCode, type, check = 0) {
  if (type === 1 || (type === 2 && check === 1)) {
    getDistrictArea({
      parentCode: organCode
    }).then(res => {
      if (res.data) {
        // 全支队，全大队
        districtBrigade(map, res.data)
      }
    })
  }
  if ((type === 2 && check === 0) || type === 3) {
    getDistrictArea({
      areaCode: organCode
    }).then(res => {
      if (res.data) {
        // 单个支队，单个大队
        districtBrigade(map, res.data)
      }
    })
  }
}

// function districtSearch2(map, keyword, fillColor = '#80d8ff', strokeColor = '#0091ea', isFocus = true) {
//   // console.info('keyword:' + keyword + ' fillColor:' + fillColor + ' strokeColor:' + strokeColor)
//   // map.plugin(['IMAP.DistrictSearch'], function() {
//   //   var boundarySearch = new IMAP.DistrictSearch()
//   var overlays = []
//   //   boundarySearch.search(keyword,
//   //     function(status, result) {
//   // const result = districtData[keyword]
//   var paths = result.results
//   var pathArray
//   for (var i = 0, l = paths.length; i < l; ++i) {
//     if (paths[i]) {
//       pathArray = paths[i].polyline.split('|')
//       var path
//       for (var j = 0, jl = pathArray.length; j < jl; ++j) {
//         var lnglats = []
//         path = pathArray[j].split(';')
//         for (var n = 0, nl = path.length; n < nl; ++n) {
//           var lnglat = path[n].split(',')
//           lnglat = new IMAP.LngLat(lnglat[0], lnglat[1])
//           lnglats.push(lnglat)
//         }
//         var polygon = new IMAP.Polygon(lnglats, {
//           fillOpacity: 0.2,
//           // strokeStyle: IMAP.Constants.OVERLAY_LINE_DASHED,
//           strokeWeight: 1,
//           strokeColor: strokeColor,
//           fillColor: fillColor
//         })
//         polygon.layerId = '行政区域'
//         overlays.push(polygon)
//       }
//     }
//   }
//   map.getOverlayLayer().addOverlays(overlays, isFocus)
//   //     })
//   // })
// }

function districtBrigade(map, data, fillOpacity = 0.2) {
  const polygons = []
  data.forEach(item => {
    const polylines = JSON.parse(item.polyline)
    polylines.forEach(points => {
      var lnglats = points.map(point => {
        return new IMAP.LngLat(point.longGaode, point.latGaode)
      })
      var polygon = new IMAP.Polygon(lnglats, {
        fillOpacity: fillOpacity,
        // strokeStyle: IMAP.Constants.OVERLAY_LINE_DASHED,
        strokeWeight: 2,
        strokeColor: item.strokeColor,
        fillColor: item.fillColor
      })
      polygon.layerId = '行政区域'
      polygons.push(polygon)
    })
  })

  map.getOverlayLayer().addOverlays(polygons, true)
}

// 删除地图图层的方法
var trafficLayer = null
// var isOnTraffic = true
let trafficTimerId = null
// var RoadNetLayer = null;
var time; var stime = time = 30

function removeTraffic(map) {
  if (trafficLayer) {
    map.removeLayer(trafficLayer)
    trafficLayer = null
  }
}

/**
 * 路况图层
 */
function trafficLayerMap(map, isOn = true) {
  // isOnTraffic = isOn
  if (!isOn) {
    removeTraffic(map)
    if (trafficTimerId) {
      clearInterval(trafficTimerId)
      trafficTimerId = null
    }

    return
  }
  // 30s定时更新图层
  var timerToUpateLayer = function() {
    trafficTimerId = window.setInterval(function() {
      if (time <= 0) {
        time = stime
        resetMapLayers()
      }
      time--
    }, 1 * 1000)
  }
  // 更新图层的方法
  var resetMapLayers = function() {
    removeTraffic(map)
    addtraffic()
    try {
      map.layerToTop(RoadNetLayer.getId())
    } catch (error) {
      // console.error(error)
    }
  }

  var addtraffic = function() {
    trafficLayer = new IMAP.TileLayer({
      maxZoom: maxZoom,
      minZoom: 1,
      tileSize: 256
    })
    trafficLayer.setTileUrlFunc(function(x, y, z) {
      // add time chuo _dc= new Date().getTime() ; 每次取到最新的
      // z = 17-z; //互联网路况
      var url = 'http://' + host + ':8883/tile?lid=traffic&get=map&cache=off&x={x}&y={y}&z={z}&_dc=' + new Date().getTime()
      // var url = "http://tm.amap.com/trafficengine/mapabc/traffictile?v=1.0&;t=1&zoom="+z+"&x="+x+"&y="+y+"&t="+new Date().getTime(); //互联网路况
      // var url = "http://192.168.11.250:8080/img/?t=t-"+z+"-"+x+"-"+y+"&e="+new Date().getTime();
      return url.replace('{x}', x).replace('{y}', y).replace('{z}', z)
      // return url;//互联网路况
    })
    map.addLayer(trafficLayer)
  }

  addtraffic()
  timerToUpateLayer()
}

export default {
  initMap(dom) {
    return initMap(dom)
  },
  // 创建点，已修改
  addMotoPoint(map, data, layerId, vehicle) {
    return addMotoPoint(map, data, layerId, vehicle)
  },
  // 创建轨迹的线，已修改
  addTrack(map, data, layerId, color) {
    return addTrack(map, data, layerId, color)
  },
  // 没用到
  addAreaPoint(map, data, layerId) {
    return addAreaPoint(map, data, layerId)
  },
  // 播放轨迹，已修改
  trackAnimation(map, data, speedVal, endCallBack) {
    return trackAnimation(map, data, speedVal, endCallBack)
  },
  // 删除覆盖物，已修改
  removeMapOverlay(map, layerId) {
    return removeMapOverlay(map, layerId)
  },
  // 没用到
  clearWarnTime(map, layerId) {
    removeMapOverlay(map, layerId)
    clearInterval(intervalWarn)
  },
  // 聚合，已修改
  markerClustersPoint(map, markers, callback) {
    return markerClustersPoint(map, markers, callback)
  },
  // 没用到
  movePoint(map, statPoint, endPoint, vehicle, speed, isSetCenter) {
    return movePoint(map, statPoint, endPoint, speed, vehicle, isSetCenter)
  },
  // 清理聚合的
  clearDataCluster(maps) {
    return clearDataCluster(maps)
  },
  // 区域电子围栏
  districtSearch(map, keyword, type, check) {
    return districtSearch(map, keyword, type, check)
  },
  // 路况，参数二，是否开启路况
  trafficLayerMap(map, isOn) {
    return trafficLayerMap(map, isOn)
  }
}
