import mapBD from './mapUtilBD' // 百度API
import mapGD from './mapUtilGd' // 高德图盟API

const mode = process.env.NODE_ENV
const map = mode === 'bj-production' ? mapGD : mapBD
export default map
