import store from '@/store'
import { Message } from 'element-ui'
/**
 * @param {String} val
 * @returns {Boolean}
 * @example see @/views/view/stationManage/index.vue
 */
// 页面方法校验权限 checkPermission(key) key为config文件的roleKeys对应的key值 例如：checkPermission('button2')
export default function checkPermission(val) {
  const value = val
  const roles = window.CONFIG.roleKeys
  if (value) {
    const permissionRole = roles[value] || ''
    const userInfo = store.state.user.userInfo
    const privateCode = userInfo.privateCode || []
    const hasPermission = privateCode.includes(permissionRole)
    if (!hasPermission) {
      const msg = '你没有权限操作！请联系管理员！'
      Message.error({
        showClose: true,
        message: msg
      })
      return false
    } else {
      return true
    }
  } else {
    console.error(`需要权限！`)
    return false
  }
}
