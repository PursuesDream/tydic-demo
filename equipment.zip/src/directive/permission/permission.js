// import { Message } from 'element-ui'
import store from '@/store'
/* checkPermission旧，用于弹框提示 */
/* function checkPermission(el, binding, vnode) {
  const { value } = binding
  const roles = window.CONFIG.roleKeys
  if (value) {
    const permissionRole = roles[value] || ''
    const userInfo = store.state.user.userInfo
    const privateCode = userInfo.privateCode || []
    const hasPermission = privateCode.includes(permissionRole)
    if (!hasPermission) {
      const componentInstance = vnode.componentInstance
      componentInstance._events = {
        click: [() => {
          const msg = '你没有权限操作！请联系管理员！'
          Message.error({
            showClose: true,
            message: msg
          })
        }]
      }
    }
  } else {
    throw new Error(`需要权限！`)
  }
} */
/* checkPermission2新 直接隐藏 */
function checkPermission2(el, binding, vnode) {
  const dom = el
  const { value } = binding
  const roles = window.CONFIG.roleKeys
  if (dom && value) {
    const permissionRole = roles[value] || ''
    const userInfo = store.state.user.userInfo
    const privateCode = userInfo.privateCode || []
    const hasPermission = privateCode.includes(permissionRole)
    if (!hasPermission) {
      const parent = dom.parentNode
      if (parent) parent.removeChild(dom)
    }
  } else {
    throw new Error(`需要权限！`)
  }
}
// 页面按钮功能权限 v-permission="key" key为config文件的roleKeys对应的key值 例如： v-permission="'button1'"
export default {
  componentUpdated(el, binding, vnode) {
    checkPermission2(el, binding, vnode)
  },
  inserted(el, binding, vnode) {
    checkPermission2(el, binding, vnode)
  }
}
