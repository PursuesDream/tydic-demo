import Vue from 'vue'
Vue.directive('animate-height', {
  inserted(el) {
    const dom = el
    let i = 0
    dom.style.height = '0px'

    function addHeight() {
      i += 12
      dom.style.height = i + 'px'
    }

    const t = setInterval(() => {
      addHeight()
      if (i > 120) {
        dom.style.height = 'auto'
        clearInterval(t)
      }
    }, 1)
  }
})
Vue.directive('table-scroll', {
  bind(el, binding, vnode, oldVnode) {
    let scrollTop = 0
    const dom = el.querySelector('.el-table__body-wrapper')
    dom.addEventListener('scroll', (e) => {
      const isBottom = dom.scrollHeight - dom.scrollTop === dom.clientHeight
      const isHorizontal = scrollTop === dom.scrollTop
      if (isBottom && !isHorizontal && dom.scrollTop !== 0) {
        if (binding.value) {
          binding.value(true)
        }
      }
      if (!isHorizontal) {
        scrollTop = dom.scrollTop
      }
    })
  }
})
