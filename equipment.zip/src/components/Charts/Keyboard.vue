<template>
  <div :id="id" :class="className" :style="{ height: height, width: width }" />
</template>

<script>
import * as echarts from 'echarts'
import resize from './mixins/resize'

const colorList = [
  '#015dad',
  '#0005cc',
  '#3082c4',
  '#b961cd',
  '#8f5ecc',
  '#9436c5',
  '#7f20ab',
  '#591fad',
  '#4b0890'
]
const colorLinearList = [
  {
    c1: '#790893',
    c2: '#631992'
  },
  {
    c1: '#2e3f94',
    c2: '#2f2696'
  },
  {
    c1: '#015a93',
    c2: '#047695'
  },
  {
    c1: '#032c89',
    c2: '#075791'
  },
  {
    c1: '#70752e',
    c2: '#77352f'
  }
]
export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '200px'
    },
    height: {
      type: String,
      default: '200px'
    },
    chartData: {
      type: null,
      default: null
    }
  },
  data() {
    return {
      chart: null
    }
  },
  watch: {
    chartData(val) {
      this.initChart()
    }
  },
  mounted() {
    // this.initChart()
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      this.chart = echarts.init(document.getElementById(this.id))

      let option
      switch (this.id) {
        case 'brand':
          option = this.getBrandPieOption()
          break
        case 'model':
          option = this.getModelPieOption()
          break
        case 'riseLine':
          option = this.getRiseLineOption()
          break
        case 'maintenance':
          option = this.getMaintenanceOption()
          break
        case 'costComparison':
          option = this.getCostComparison()
          break
      }

      this.chart.setOption(option)
    },
    // 铁骑品牌占比分析
    getBrandPieOption() {
      const pieData = []
      this.chartData.forEach(item => {
        pieData.push({ name: item.brand, value: item.num })
      })
      return {
        tooltip: {
          trigger: 'item',
          color: colorList,
          formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        roseType: 'angle', // 设置成 南丁格尔图
        color: function(params) {
          return new echarts.graphic.LinearGradient(0, 1, 1, 0, [
            {
              offset: 0,
              color: colorLinearList[params.dataIndex].c1
            },
            {
              offset: 1,
              color: colorLinearList[params.dataIndex].c2
            }
          ])
        },
        series: [
          {
            name: '铁骑品牌占比分析',
            type: 'pie',
            radius: '55%',
            center: ['50%', '50%'],
            label: {
              formatter: '{b}  {d}%  ',
              color: '#0257a7'
            },
            data: pieData,
            roseType: 'radius',
            animationType: 'scale',
            animationEasing: 'elasticOut',
            animationDelay: function(idx) {
              return Math.random() * 200
            }
          }
        ]
      }
    },
    // 铁骑型号占比分析
    getModelPieOption() {
      const pieData = []
      this.chartData.forEach(item => {
        pieData.push({ name: item.brand + '(' + item.category + ')', value: item.num })
      })
      return {
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        color: colorList,
        series: [
          {
            name: '铁骑型号占比分析',
            type: 'pie',
            radius: '55%',
            center: ['50%', '50%'],
            label: {
              formatter: '{b}'
            },
            data: pieData,
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      }
    },
    // 增长趋势
    getRiseLineOption() {
      const that = this
      return {
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b} : {c}'
        },
        grid: {
          left: '10%',
          right: '5%',
          top: '30',
          bottom: '50'
        },
        xAxis: {
          type: 'category',
          data: that.chartData.months,
          /* 改变xy轴颜色*/
          axisLine: {
            lineStyle: {
              color: '#0270ce',
              width: 1 // 这里是为了突出显示加上的
            }
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            color: '#767b8e',
            rotate: 45
          },
          // 网格样式
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#001b44'],
              width: 1,
              type: 'solid'
            }
          }
          // axisLabel: {
          //   interval: 0, //X轴信息全部展示
          //   rotate: -60, //60 标签倾斜的角度
          // },
        },
        yAxis: {
          type: 'value',
          /* 改变xy轴颜色*/
          axisLine: {
            lineStyle: {
              color: '#0270ce',
              width: 1 // 这里是为了突出显示加上的
            }
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            color: '#767b8e'
          },
          // 网格样式
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#012a58'],
              width: 1,
              type: 'solid'
            }
          }
        },

        // #0270ce
        series: [
          {
            name: '铁骑增长趋势分析',
            data: that.chartData.nums,
            type: 'line',
            lineStyle: {
              color: '#0270ce'
            },
            itemStyle: {
              normal: {
                color: '#ffffff'
              }
            }
          }
        ]
      }
    },
    // 铁骑维保项目距对比分析
    getMaintenanceOption() {
      // const that = this
      const xData = []
      const seriesData = []
      this.chartData.itemInfo.forEach(item => {
        xData.push(item.ports)
        seriesData.push(item.num)
      })
      return {
        grid: {
          left: '10%',
          right: '5%',
          top: '30'
        },
        legend: {
          y: 'bottom',
          itemWidth: 18,
          textStyle: {
            color: '#23abe1'
          }
        },
        tooltip: {},
        xAxis: {
          type: 'category',
          /* 改变xy轴颜色*/
          axisLine: {
            lineStyle: {
              color: '#0270ce',
              width: 1 // 这里是为了突出显示加上的
            }
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            color: '#767b8e'
          },
          data: xData
        },
        yAxis: {
          /* 改变xy轴颜色*/
          axisLine: {
            lineStyle: {
              color: '#0270ce',
              width: 1 // 这里是为了突出显示加上的
            }
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            color: '#767b8e'
          },
          // 网格样式
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#001b44'],
              width: 1,
              type: 'solid'
            }
          }
        },
        color: ['#2d7bbd', '#0257a7', '#541da6', '#8a32ba', '#8758c4'],
        // Declare several bar series, each will be mapped
        // to a column of dataset.source by default.
        series: [
          {
            data: seriesData,
            type: 'bar',
            showBackground: true
          }
        ]
      }
    },
    // 维保费用对比分析
    getCostComparison() {
      const pieData = []
      this.chartData.forEach(item => {
        pieData.push({ name: item.organName, value: item.num })
      })
      return {
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        color: colorList,
        series: [
          {
            name: '铁骑型号占比分析',
            type: 'pie',
            radius: '55%',
            center: ['46%', '65%'],
            label: {
              formatter: '{b}  {d}%  '
            },
            data: pieData,
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      }
    }
  }
}
</script>
