<template>
  <div :ref="id" :class="className" :style="{height:height,width:width}" />
</template>

<script>
import * as echarts from 'echarts'
import resize from './mixins/resize'

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    chartData: {
      type: Object,
      default() {
        return {} // 这样可以指定默认的值
      }
    },
    count: {
      type: Number,
      default() {
        return 0
      }
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '200px'
    },
    height: {
      type: String,
      default: '200px'
    },
    isTopRed: {
      type: Boolean,
      default() {
        return true
      }
    }
  },
  data() {
    return {
      chart: null
    }
  },
  watch: {
    count(val) {
      if (val) {
        const xData = this.chartData.indicator.map(o => {
          const obj = {
            name: o.text,
            max: 1 // parseFloat(o.max)
          }
          if (obj.max === 0) obj.max = 1
          return obj
        })
        const yData = this.chartData.values
        this.setChartOption(xData, yData)
      }
    }
  },
  mounted() {
    this.initChart()
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      const divDom = this.$refs[this.id]
      this.chart = echarts.init(divDom)
      const indicator = this.chartData.indicator || []
      if (indicator.length === 0) return false
      const xData = indicator.map(o => {
        const obj = {
          name: o.text,
          max: 1 // parseFloat(o.max)
        }
        if (obj.max === 0) obj.max = 1
        return obj
      })
      const yData = this.chartData.values.map(o => {
        return parseFloat(o)
      })
      this.setChartOption(xData, yData)
    },
    setChartOption(x, y) {
      const yData = y
      const xData = x
      const topIndexs = []
      if (this.isTopRed) {
        let max = 0
        yData.forEach((o, index) => {
          const maxValue = xData[index].max
          if (maxValue !== 0 && ((o / maxValue) > max)) {
            max = (o / maxValue)
          }
        })
        yData.forEach((o, index) => {
          if (max !== 0 && (o / xData[index].max) === max) {
            topIndexs.push(index)
          }
        })
      }
      if (topIndexs.length) {
        topIndexs.forEach(o => {
          xData[o].color = '#ed1c24'
        })
      }
      this.chart.setOption(
        {
          grid: {
            top: 10,
            bottom: 10
          },
          radar: {
            radius: '70%', // 调整缩放比例
            splitNumber: 2,
            nameGap: 2,
            name: {
              textStyle: {
                color: '#333'
              }
            },
            indicator: xData,
            axisLine: {
              lineStyle: {
                color: '#47b7e7'
              }
            },
            splitLine: {
              show: false
            },
            splitArea: {
              areaStyle: {
                color: ['rgba(80,188,255,0.3)', 'rgba(80,188,255,0.15)']
              }
            }
          },
          series: [{
            type: 'radar',
            symbolSize: 0.1,
            data: [
              {
                value: yData,
                name: '数量',
                areaStyle: {
                  color: 'rgba(79, 155, 255, 0.7)'
                },
                lineStyle: {
                  color: '#47b7e7'
                },
                itemStyle: {
                  // opacity: 0
                }
              }
            ]
            /* label: {
              normal: {
                show: true,
                position: [10, 0],
                formatter: (params) => {
                  console.log(params)
                  const value = `${params.value}%`
                  const text = `{value|${value}}`
                  return text
                },
                rich: {
                  value: {
                    color: '#00FFFF',
                    fontWeight: 700,
                    fontSize: 12
                  }
                }
              }
            } */
          }]
        }
      )
    }
  }
}
</script>
