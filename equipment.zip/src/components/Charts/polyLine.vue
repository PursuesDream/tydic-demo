<template>
  <div :ref="id" :class="className" :style="{height:height,width:width}" />
</template>

<script>
import * as echarts from 'echarts'
import resize from './mixins/resize'

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    chartData: {
      type: Object,
      default() {
        return {} // 这样可以指定默认的值
      }
    },
    count: {
      type: Number,
      default() {
        return 0
      }
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '200px'
    },
    height: {
      type: String,
      default: '200px'
    }
  },
  data() {
    return {
      chart: null
    }
  },
  watch: {
    count(val) {
      if (val) {
        const xData = this.chartData.xAxis.map(o => {
          return o + '时'
        })
        const yData = this.chartData.yAxis
        this.setChartOption(xData, yData)
      }
    }
  },
  mounted() {
    this.initChart()
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      const divDom = this.$refs[this.id]
      this.chart = echarts.init(divDom)
      const xData = this.chartData.xAxis.map(o => {
        return o + '时'
      })
      const yData = this.chartData.yAxis
      this.setChartOption(xData, yData)
    },
    setChartOption(x, y) {
      const yData = y
      const xData = x
      this.chart.setOption(
        {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
            offset: 0,
            color: '#57d2ff'
          }, {
            offset: 1,
            color: '#4f9bff'
          }]),
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'shadow'
            },
            formatter(obj) {
              let { value } = obj[0] || {}
              const { name } = obj[0] || {}
              value = parseInt(value)
              return name + ': ' + value + '起'
            }
          },
          grid: {
            left: '5%',
            right: '5%',
            top: 20,
            bottom: '5%',
            containLabel: true
          },
          xAxis: {
            type: 'category',
            boundaryGap: false,
            axisTick: {
              show: false
            },
            axisLine: {
              show: false
            },
            data: xData
          },
          yAxis: {
            type: 'value',
            show: false
          },
          series: [{
            data: yData,
            type: 'line',
            symbol: 'none',
            areaStyle: {
              color: 'rgba(87, 210, 255,0.2)'
            },
            markLine: {
              symbol: ['none', 'none'],
              itemStyle: {
                normal: {
                  color: '#57d2ff',
                  label: {
                    color: '#333333',
                    padding: [0, -25, 25, 0],
                    position: 'start',
                    formatter: '{c}起'
                  }
                }
              },
              data: [
                { type: 'max',
                  name: '预警线'
                }
              ]
            }
          }]
        }
      )
    }
  }
}
</script>
