<template>
  <div :ref="id" :class="className" :style="{height:height,width:width}" />
</template>

<script>
import * as echarts from 'echarts'
import resize from './mixins/resize'

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    chartData: {
      type: Object,
      default() {
        return {} // 这样可以指定默认的值
      }
    },
    count: {
      type: Number,
      default() {
        return 0
      }
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '200px'
    },
    height: {
      type: String,
      default: '200px'
    }
  },
  data() {
    return {
      chart: null,
      dataList: []
    }
  },
  // watch: {
  //   dataList(val) {
  //     if (val) {
  //       this.setChartOption()
  //     }
  //   }
  // },
  mounted() {
    this.initChart()
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      const divDom = this.$refs[this.id]
      this.chart = echarts.init(divDom)
      this.setChartOption()
    },
    updateChart(dataList) {
      this.dataList = dataList
      this.setChartOption()
    },
    setChartOption() {
      const divDom = this.$refs[this.id]
      const CWidth = divDom.clientWidth
      const CHeigth = divDom.clientHeight
      const x = CWidth / 2 - 60
      const y = CHeigth / 2
      const r = 70
      const lineX = CWidth - 120
      const margin = 40
      // const colors = ['#99d0f8', '#47b1fc', '#249efd', '#0a91ff', '#0672ff', '#005afe']
      const colors = this.gradient('#99d0f8', '#055cff', this.dataList.length)
      const list = this.dataList.sort((a, b) => b.count - a.count)
      const circleList = list.map((item, index) => {
        let p = 1
        if (index > 0) {
          p = item.count / list[0].count
        }
        return {
          name: item.key + '日未骑行',
          value: item.count,
          val: p,
          color: colors[index]
        }
      })
      const deg = 120 / (circleList.length - 1)
      const textY = (CHeigth - margin) / (circleList.length - 1)
      const seriesArr = []
      circleList.forEach((item, index) => {
        const xx = x - (r - r * item.val)
        const ty = margin / 2 + textY * index
        const radius = r * item.val
        seriesArr.push(
          {
            name: item.name,
            type: 'pie',
            radius: radius,
            data: [
              { value: item.value, name: item.name }
            ],
            zlevel: index,
            center: [xx, y],
            itemStyle: {
              color: item.color
              // borderColor: '#ffffff',
              // borderWidth: 1
            },
            label: {
              formatter: '{c|{c}} 辆\n{a}',
              rich: {
                c: {
                  fontSize: 20,
                  color: '#3c9bff'
                }
              }
            },
            labelLine: {
              length2: 30,
              lineStyle: {
                color: item.color
              }
            },
            labelLayout(params) {
              const xx = Math.sin(changeRadian(deg)) * radius + params.rect.x
              const yy = Math.cos(changeRadian(deg)) * radius + params.rect.y
              return {
                x: lineX + 35,
                y: ty + 2,
                verticalAlign: 'middle',
                align: 'left',
                labelLinePoints: [[xx, yy], [lineX, ty], [lineX + 30, ty]]
              }
            }
          }
        )
      })
      function changeRadian(deg) {
        return Math.PI / 180 * deg
      }
      this.chart.setOption({
        tooltip: {
          show: false,
          trigger: 'item'
        },
        legend: {
          orient: 'vertical',
          left: 'left',
          show: false
        },
        series: seriesArr
      })
    },
    gradient(startColor, endColor, step) {
    // 将hex转换为rgb
      var sColor = this.hexToRgb(startColor)
      var eColor = this.hexToRgb(endColor)

      // 计算R\G\B每一步的差值
      var rStep = (eColor[0] - sColor[0]) / step
      const gStep = (eColor[1] - sColor[1]) / step
      const bStep = (eColor[2] - sColor[2]) / step

      var gradientColorArr = []
      for (var i = 0; i < step; i++) {
        // 计算每一步的hex值
        gradientColorArr.push(this.rgbToHex(parseInt(rStep * i + sColor[0]), parseInt(gStep * i + sColor[1]), parseInt(bStep * i + sColor[2])))
      }
      return gradientColorArr
    },
    rgbToHex(r, g, b) {
      var hex = ((r << 16) | (g << 8) | b).toString(16)
      return '#' + new Array(Math.abs(hex.length - 7)).join('0') + hex
    },
    hexToRgb(hex) {
      var rgb = []
      for (var i = 1; i < 7; i += 2) {
        rgb.push(parseInt('0x' + hex.slice(i, i + 2)))
      }
      return rgb
    }
  }
}
</script>
