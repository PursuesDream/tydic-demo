<template>
  <div :ref="id" :class="className" :style="{height:height,width:width}" />
</template>

<script>
import * as echarts from 'echarts'
import resize from './mixins/resize'

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    chartData: {
      type: Object,
      default() {
        return {} // 这样可以指定默认的值
      }
    },
    count: {
      type: Number,
      default() {
        return 0
      }
    },
    unit: {
      type: String,
      default: ''
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '200px'
    },
    height: {
      type: String,
      default: '200px'
    },
    toFixed: {
      type: Number,
      default: 1
    }
  },
  data() {
    return {
      chart: null
    }
  },
  watch: {
    count(val) {
      if (val) {
        const xData = this.chartData.xAxis.map(o => {
          return o + '时'
        })
        const yData = this.chartData.yAxis
        this.setChartOption(xData, yData)
      }
    }
  },
  mounted() {
    this.initChart()
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      const divDom = this.$refs[this.id]
      this.chart = echarts.init(divDom)
      const xData = this.chartData.xAxis.map(o => {
        return o + '时'
      })
      const yData = this.chartData.yAxis
      this.setChartOption(xData, yData)
    },
    setChartOption(x, y) {
      const yData = y
      const xData = x
      const that = this
      this.chart.setOption(
        {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
            offset: 0,
            color: '#57d2ff'
          }, {
            offset: 1,
            color: '#4f9bff'
          }]),
          tooltip: {
            trigger: 'axis',
            axisPointer: { // 坐标轴指示器，坐标轴触发有效
              type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
            },
            formatter(obj) {
              let { value } = obj[0] || {}
              const { name } = obj[0] || {}
              value = parseFloat(value)
              value = value.toFixed(that.toFixed)
              if (parseFloat(value) === 0) value = 0
              return name + ': ' + value + that.unit
            }
          },
          grid: {
            left: '5%',
            right: '5%',
            top: 20,
            bottom: '5%',
            containLabel: true
          },
          xAxis: [
            {
              type: 'category',
              data: xData,
              axisTick: {
                alignWithLabel: true,
                show: false
              },
              axisLine: {
                show: false
              }
            }
          ],
          yAxis: [
            {
              type: 'value',
              show: false
            }
          ],
          series: [
            {
              name: '骑巡时长',
              type: 'bar',
              barWidth: '60%',
              data: yData,
              markLine: {
                symbol: ['none', 'none'],
                itemStyle: {
                  normal: {
                    color: '#57d2ff',
                    label: {
                      color: '#333333',
                      padding: [0, -45, 25, 0],
                      position: 'start',
                      formatter: '{c} ' + this.unit
                    }
                  }
                },
                data: [
                  {
                    type: 'max',
                    name: '预警线'
                  }
                ]
              }
            }

          ]
        }
      )
    }
  }
}
</script>
