<template>
  <el-popover
    ref="popover"
    placement="bottom"
    width="250"
    trigger="click"
    @show="handlerShow"
    @hide="hanlerClose"
  >
    <el-input
      ref="searchInput"
      v-model="filterText"
      placeholder="输入关键字进行查找"
    />
    <el-tree ref="tree" class="tree-class" :data="treeData" :accordion="true" :default-expanded-keys="defaultKeys" :node-key="nodeKey" :props="defaultProps" :filter-node-method="filterNode" @node-click="handleNodeClick">
      <span slot-scope="{ node }">
        <span><i class="el-icon-document" style="margin-right: 5px" />{{ node.label }}</span>
      </span>
    </el-tree>
    <el-input
      slot="reference"
      ref="input"
      v-model="inputValue"
      placeholder="请选择"
      :class="inputClass"
      clearable
      @clear="handleInputClear"
    />
  </el-popover>
</template>

<script>
import { getOrganAuthTree } from '@/api/public'
export default {
  name: 'PermissionTree',
  props: {
    selectObject: {
      type: Object,
      default() {
        return {}
      }
    },
    selectValue: {
      type: String,
      default() {
        return ''
      }
    },
    defaultName: {
      type: String,
      default() {
        return ''
      }
    },
    inputClass: {
      type: String,
      default() {
        return ''
      }
    }
  },

  data() {
    return {
      treeData: [],
      defaultProps: {
        children: 'childList',
        label: 'name'
      },
      nodeKey: 'organCode',
      inputValue: '',
      filterText: '',
      defaultKeys: []
    }
  },
  watch: {
    filterText(val) {
      this.$refs.tree.filter(val)
    },
    selectObject: {
      deep: true,
      handler(val, old) {
        if (val[this.selectValue] === '') this.inputValue = ''
        else if (val[this.defaultName] && val[this.defaultName] !== old[this.defaultName]) {
          this.inputValue = val[this.defaultName]
        }
      }
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      // 设置输入框 只读
      const inputDom = this.$refs.input.$el.children[0]
      inputDom.setAttribute('readonly', 'readonly')
      // 设置初始默认值
      const defaultName = this.defaultName
      if (!this.isSelectChange && this.selectObject[defaultName]) {
        this.inputValue = this.selectObject[defaultName]
      }
    },
    myLeaveFn() {
      this.$refs.popover.doClose()
    },
    handlerShow() {
      this.getTreeData()
      this.$refs.popover.popperElm.addEventListener('mouseleave', this.myLeaveFn)
    },
    getTreeData() {
      const that = this
      getOrganAuthTree({}).then(res => {
        if (res.data.length) {
          this.treeData = res.data
          this.defaultKeys = this.treeData.map(o => {
            return o[that.nodeKey]
          })
        }
      })
    },
    filterNode(value, data) {
      if (!value) return true
      return data.name.indexOf(value) !== -1
    },
    handleNodeClick(item) {
      this.isTreeClick = true
      this.selectObject[this.selectValue] = item[this.nodeKey]
      if (this.defaultName) this.selectObject[this.defaultName] = item.name
      this.inputValue = item.name
      // 获取焦距，去除表单验证无法自动消去
      this.$refs.input.focus()
    },
    handleInputClear() {
      this.selectObject[this.selectValue] = ''
    },
    hanlerClose() {
      this.$emit('tree-click', this.selectObject[this.selectValue])
      this.filterText = ''
      this.$refs.searchInput.blur()
      this.$refs.input.blur()
      this.$refs.popover.popperElm.removeEventListener('mouseleave', this.myLeaveFn)
    }
  }
}
</script>

<style scoped lang="stylus">
/deep/.el-input--medium .el-input__inner{
  height 32px!important
}
.tree-class {
  max-height 350px
  overflow-y auto
  &::-webkit-scrollbar {
    width: 5px;
    height: 5px;
    background-color: rgba(144,147,153,.4);
  }

  &::-webkit-scrollbar-thumb {
    border-radius: 8px;
    background-color: rgba(144,147,153,.6);
  }
}
</style>
