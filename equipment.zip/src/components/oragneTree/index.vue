<template>
  <el-popover
    v-model="popoverShow"
    placement="top"
    width="300"
    trigger="click"
    :disabled="canEdit"
    @show="handlerShow"
  >
    <el-input
      v-model="filterText"
      placeholder="输入关键字进行查找"
    />
    <el-tree ref="tree" class="tree-class" :data="treeData" :default-expanded-keys="defaultKeys" :node-key="nodeKey" :props="defaultProps" :filter-node-method="filterNode" @node-click="handleNodeClick">
      <span slot-scope="{ node }">
        <span><i class="el-icon-document" style="margin-right: 5px" />{{ node.label }}</span>
      </span>
    </el-tree>
    <el-input
      slot="reference"
      ref="input"
      v-model="inputValue"
      placeholder="请选择"
      style="width: 250px"
      clearable
      :disabled="canEdit"
      @clear="handlerClear"
    />
    <!--
      @click="changePopover"
      @focus="popoverShow = true" -->
  </el-popover>
</template>

<script>
import { getUseOrganList } from '@/api/public'
export default {
  name: 'OragneTree',
  props: {
    selectObject: {
      type: Object,
      default() {
        return {}
      }
    },
    isNoEdit: {
      type: String,
      default() {
        return ''
      }
    },
    selectValue: {
      type: String,
      default() {
        return ''
      }
    },
    defaultName: {
      type: String,
      default() {
        return ''
      }
    },
    parentCode: {
      type: String,
      default() {
        return ''
      }
    }
  },

  data() {
    return {
      treeData: [],
      defaultProps: {
        children: 'childList',
        label: 'name'
      },
      nodeKey: 'organCode',
      popoverShow: false,
      inputValue: '',
      canEdit: false,
      filterText: '',
      defaultKeys: []
    }
  },
  watch: {
    filterText(val) {
      this.$refs.tree.filter(val)
    },
    selectObject: {
      deep: true,
      handler(val, old) {
        this.canEdit = val[this.isNoEdit]
        // this.changePopover()
        if (val[this.selectValue] === '') this.inputValue = ''
        else if (val[this.defaultName] && val[this.defaultName] !== old[this.defaultName]) {
          this.inputValue = val[this.defaultName]
        }
      }
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      // 设置输入框 只读
      const inputDom = this.$refs.input.$el.children[0]
      inputDom.setAttribute('readonly', 'readonly')
      // 设置初始默认值
      const defaultName = this.defaultName
      if (!this.isSelectChange && this.selectObject[defaultName]) {
        this.inputValue = this.selectObject[defaultName]
      }
    },
    handlerShow() {
      this.getTreeData()
    },
    changePopover() {
      if (this.canEdit) {
        this.popoverShow = false
      } else {
        this.popoverShow = true
      }
    },
    getTreeData() {
      const that = this
      getUseOrganList({
        organCode: ''
        // organType: '0'
      }).then(res => {
        this.treeData = [res.data]
        this.defaultKeys = this.treeData.map(o => {
          return o[that.nodeKey]
        })
      })
    },
    filterNode(value, data) {
      if (!value) return true
      return data.name.indexOf(value) !== -1
    },
    handleNodeClick(item) {
      this.selectObject[this.selectValue] = item[this.nodeKey]
      if (this.defaultName) this.selectObject[this.defaultName] = item.name
      if (this.parentCode) this.selectObject[this.parentCode] = item.parentCode
      this.inputValue = item.name
      this.popoverShow = false

      if (this.parentCode) {
        this.$emit('sendOrgcode', { organCode: item.organCode, parentCode: item.parentCode })
      } else {
        this.$emit('sendOrgcode', item.organCode)
      }
    },
    handlerClear() {
      this.selectObject[this.selectValue] = ''
      this.selectObject[this.defaultName] = ''
      this.$emit('sendOrgcode', 'clear')
    }
  }
}
</script>

<style scoped lang="stylus">
.tree-class {
  max-height 350px
  overflow-y auto
  &::-webkit-scrollbar {
    width: 5px;
    height: 5px;
    background-color: rgba(144,147,153,.4);
  }

  &::-webkit-scrollbar-thumb {
    border-radius: 8px;
    background-color: rgba(144,147,153,.6);
  }
}
</style>
