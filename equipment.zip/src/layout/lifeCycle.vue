<template>
  <div class="app-wrapper">
    <div class="main-container">
      <div class="header">
        <div class="left" @click="goToIndex">
          <img src="@/assets/icons/icon_22.png" class="header-icon">{{
            navTitle
          }}
        </div>
        <div class="right">
          <div class="userName-container">
            <div class="userName">
              <i class="image-icon account" />{{ useserInfo.userName }}
            </div>
            <div class="logout-box" @click="logout">
              <i class="image-icon logout" />退出
            </div>
          </div>
        </div>
        <div class="center">
          <el-menu
            :router="true"
            :default-active="activeIndex"
            mode="horizontal"
            background-color="transparent"
            text-color="white"
            active-text-color="white"
            @select="handleSelect"
          >
            <template v-for="(item, index) in premissionMenu">
              <el-menu-item
                v-if="!item.children"
                :key="index"
                :route="item.path"
                :index="index + 1 + ''"
              ><i class="image-icon" :class="item.icon" />{{
                item.name
              }}</el-menu-item>
              <el-submenu
                v-else
                :key="index"
                :index="index + 1 + ''"
                popper-class="lifeCycle-submenu"
              >
                <template
                  slot="title"
                ><i class="image-icon" :class="item.icon" />{{
                  item.name
                }}</template>
                <el-menu-item
                  v-for="(child, cIndex) in item.children"
                  :key="cIndex"
                  :route="item.path + child.path"
                  :index="index + 1 + '-' + (cIndex + 1)"
                >{{ child.name }}</el-menu-item>
              </el-submenu>
            </template>
          </el-menu>
        </div>
      </div>
      <tags-view v-if="needTagsView" />
      <app-main />
    </div>
  </div>
</template>

<script>
import { AppMain, TagsView } from './components'
import { mapState, mapGetters } from 'vuex'
import { getUserInfo } from '@/api/public'

const RoleKeys = window.CONFIG.roleKeys
const getMenu = function(menuList, roleCode) {
  const data = []
  menuList.forEach(o => {
    if (o.roleCode === undefined) {
      data.push(o)
    } else {
      if (roleCode[o.roleCode]) {
        let child = []
        if (o.children && o.children.length) {
          child = getMenu(o.children, roleCode)
        }
        if (child.length === 0) delete o.children
        else o.children = child
        data.push(o)
      }
    }
  })
  return data
}
export default {
  name: 'LifeCycleLayout',
  components: {
    AppMain,
    TagsView
  },
  data() {
    return {
      menuList: [
        // { name: '实时监控', path: '/realTimeMonitoring', icon: 'video' },
        { name: '铁骑一张图', path: '/trafficMap', icon: 'mapIcon' },
        { name: '装备管理', path: '/equipmentManage', icon: 'equipment', roleCode: RoleKeys.page1, children: [
          { name: '车辆管理', path: '/car', roleCode: RoleKeys.page2 },
          { name: '骑行装备管理', path: '/interphone', roleCode: RoleKeys.page3 },
          { name: '流程管理', path: '/manage', roleCode: RoleKeys.page4 }
        ] },
        // { name: '流程管理', path: '/process/manage', icon: 'loop' },
        {
          name: '民警考核', path: '/policeAppraisal', icon: 'policeIcon', roleCode: RoleKeys.page5, children: [
            { name: '考核管理', path: '/manage', roleCode: RoleKeys.page6 },
            { name: '可视化考核', path: '/view', roleCode: RoleKeys.page7 },
            { name: '战果认领', path: '/claimResults', roleCode: RoleKeys.page8 },
            { name: '考核统计', path: '/assessStatistics' },
            { name: '月度考核统计', path: '/monthlyAssess' }
          ]
        },
        {
          name: '综合管理', path: '/integratedManage', icon: 'zonghe', roleCode: RoleKeys.page9, children: [
            { name: '装备配置管理', path: '/systemSettings', roleCode: RoleKeys.page14 },
            { name: '维保单位管理', path: '/maintenance', roleCode: RoleKeys.page10 },
            { name: '维保项目管理', path: '/project', roleCode: RoleKeys.page11 },
            { name: '流程配置', path: '/workflowManage', roleCode: RoleKeys.page13 },
            { name: '二维码管理', path: '/qrcode', roleCode: RoleKeys.page12 }
            // { name: '装备属性管理', path: '/attributeManage' }
          ]
        }
      ],
      activeIndex: '1',
      useserInfo: {}
    }
  },
  computed: {
    ...mapState({
      needTagsView: state => state.settings.tagsView
    }),
    ...mapGetters([
      'name',
      'user_userInfo'
    ]),
    navTitle() {
      return window.CONFIG.navTitle
    },
    premissionMenu() {
      let privateCode = []
      if (this.user_userInfo.privateCode) privateCode = this.user_userInfo.privateCode
      const codeObj = {}
      privateCode.forEach(o => {
        codeObj[o] = true
      })
      const data = getMenu(this.menuList, codeObj)
      return data
    }
  },
  watch: {
    '$route': {
      deep: true,
      handler(val) {
        this.setDefaultActive()
      }
    }
  },
  mounted() {
    // this.premissionMenu()
    this.setDefaultActive()
    getUserInfo().then(res => {
      if (res.code === 200) {
        this.useserInfo = res.data
        const roleList = res.data.roleList
        sessionStorage.setItem('userInfo', JSON.stringify(this.useserInfo))
        if (roleList) {
          let roleType = true
          roleList.some(o => {
            if (o.roleId === window.CONFIG.roleId) { // 普通民警
              roleType = false
              return true
            }
          })
          sessionStorage.setItem('roleType', roleType)
        }
      }
    })
  },
  methods: {
    goToIndex() {
      this.$router.push('/')
    },
    /* setDefaultActive() {
      const path = this.$route.path
      let activeIndex = '1'
      if (/equipmentManage\/car/.test(path)) activeIndex = '1-1'
      else if (/equipmentManage\/interphone/.test(path)) activeIndex = '1-2'
      else if (/process\/manage/.test(path) || /process\/apply/.test(path)) activeIndex = '2'
      else if (/policeAppraisal\/manage/.test(path) || /policeAppraisal\/policeDetail/.test(path)) activeIndex = '3-1'
      else if (/policeAppraisal\/view/.test(path)) activeIndex = '3-2'
      else if (/integratedManage\/category/.test(path)) activeIndex = '4-1'
      else if (/integratedManage\/maintenance/.test(path)) activeIndex = '4-2'
      else if (/integratedManage\/project/.test(path)) activeIndex = '4-3'
      else if (/integratedManage\/workflowManage/.test(path) || /integratedManage\/workflowConfig/.test(path)) activeIndex = '4-4'
      else if (/integratedManage\/qrcode/.test(path)) activeIndex = '4-5'
      else if (/integratedManage\/attributeManage/.test(path)) activeIndex = '4-6'
      this.activeIndex = activeIndex
    }, */
    setDefaultActive() {
      const path = this.$route.path
      let activeIndex = '1'
      for (let i = 0; i < this.menuList.length; i++) {
        const item = this.menuList[i]
        if (path.startsWith(item.path)) {
          activeIndex = (i + 1) + ''
          if (item.children) {
            const childrenPath = path.replace(item.path, '')
            for (let j = 0; j < item.children.length; j++) {
              const i2 = item.children[j]
              if (childrenPath.startsWith(i2.path)) {
                activeIndex = (i + 1) + '-' + (j + 1)
                break
              }
            }
          } else {
            break
          }
        }
      }
      this.activeIndex = activeIndex
    },
    handleSelect() { },
    async logout() {
      // await this.$store.dispatch('user/logout')
      // this.$router.push(`/login?redirect=${this.$route.fullPath}`)
      const backUrl = window.CONFIG.UC
      // window.open(backUrl)
      window.location.href = backUrl
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/mixin.scss';

.app-wrapper {
  @include clearfix;
  position: relative;
  height: 100%;
  min-width: 1920px;
  margin: 0 auto;
  background-color: #F4F2F8;
}
</style>
<style lang="stylus" scoped>
#app {
  .main-container {
    margin-left: 0;

    .header {
      $HEIGHT = 60px;
      // background-color: rgba(50, 116, 225, 0.9);
      background-image url('~@/assets/icons/top.png')
      height: $HEIGHT;
      color: white;
      overflow: hidden;

      .left {
        font-size: 26px;
        text-align: right;
        line-height: $HEIGHT;
        box-sizing: border-box;
        padding: 0 18px 0 30px;
        letter-spacing: 8px;
        float: left;
        cursor: pointer;
      }

      .center {
        text-align: center;
        float: right;

        .el-menu {
          border-bottom: none;

          .el-menu-item, .el-submenu {
            width: 160px;
            height: $HEIGHT;
            line-height: $HEIGHT;
            font-size: 16px;
            letter-spacing: 4px;
          }
        }
      }

      .right {
        width: 300px;
        float: right;
        margin-right: 10px;

        .userName-container {
          color: white;
          line-height: 70px;
          font-size: 16px;
          display: flex;
          justify-content: flex-end;
          text-align right

          .userName {
            width: 100px;
            padding-right 12px
          }

          .logout-box {
            width: 100px;
            cursor: pointer;
            padding-right 12px
          }
        }
      }

      .image-icon {
        width: 20px;
        height: 20px;
        background-size: 100% 100%;
        display: inline-block;
        vertical-align: -4px;
        margin-right: 5px;

        &.video {
          background-image: url('~@/assets/icons/icon_09.png');
        }

        &.equipment {
          background-image: url('~@/assets/icons/icon_65.png');
        }

        &.loop {
          background-image: url('~@/assets/icons/icon_67.png');
        }

        &.account {
          background-image: url('~@/assets/icons/icon_17.png');
        }

        &.logout {
          background-image: url('~@/assets/icons/icon_19.png');
        }

        &.zonghe {
          background-image: url('~@/assets/icons/xitong.png');
        }
        &.mapIcon {
          background-image: url('~@/assets/icons/topMap_icon.png');
        }
        &.policeIcon {
          background-image: url('~@/assets/icons/icon_64.png');
        }
      }
    }

    .app-main {
      // height calc(100vh - 106px)
    }

    .el-menu-item {
      background-color: transparent !important;
    }
  }
}
</style>
<style lang="stylus" scoped>
.header-icon {
  display: inline-block;
  width: 40px;
  height: 40px;
  -webkit-user-drag: none;
  vertical-align: -10px;
  margin-right: 10px;
}
</style>
<style lang="stylus">
.main-container {
  .header {
    $HEIGHT = 66px;

    .center {
      .el-submenu .el-submenu__title:hover, .el-menu-item:hover {
        background-color: transparent !important;
        background-image: linear-gradient(to top, rgba(11, 238, 250, 0.3), rgba(11, 238, 250, 0));
      }

      .el-submenu__title {
        height: $HEIGHT;
        line-height: $HEIGHT;

        i {
          color: white;
        }
      }

      .el-menu--horizontal.el-menu {
        >.el-menu-item {
          &.is-active {
            border-bottom: 5px solid #0beefa !important;
            background-image: linear-gradient(to top, rgba(11, 238, 250, 0.3), rgba(11, 238, 250, 0));
          }
        }
      }

      .el-submenu {
        &.is-active {
          background-image: linear-gradient(to top, rgba(11, 238, 250, 0.3), rgba(11, 238, 250, 0));

          .el-submenu__title {
            border-bottom: 5px solid #0beefa !important;
          }
        }
      }
    }
  }

  .tags-view-wrapper {
    padding-left: 15px;
  }
}

.lifeCycle-submenu {
  background-color: #3faaf5 !important;

  .el-menu.el-menu--popup {
    width: 160px;
    min-width: 160px;
    margin: 0;
    padding: 0;

    .el-menu-item {
      height: 40px;
      line-height: 40px;
      text-align: center;
      padding: 0;
      letter-spacing: 5px;

      &:hover {
        background-color: transparent !important;
      }

      &.is-active {
        background-image: linear-gradient(to right, rgba(54, 193, 247, 1), rgba(54, 193, 247, 0.3));
      }
    }
  }
}
</style>
<style lang="stylus">
.el-submenu__title {
  font-size: 16px
}
.main-container .header .center .el-submenu__title{
  height: 60px
  line-height: 60px
}
</style>
