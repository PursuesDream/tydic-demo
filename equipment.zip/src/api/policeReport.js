import request, { request2 } from '@/utils/request'
const bserviceUrl = window.CONFIG.bserviceUrl
// 根据时间段统计总的里程，时长，执法量，接警数
export function getByWeekTotalStat(data) {
  return request({
    url: '/PoliceReportController/getByTimeTotalStat',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
//  图形化统计一次获取数据集合接口
export function getStatPolices(data) {
  return request({
    url: '/PoliceReportController/getChartAllData',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
//  根据时间段，警号，大队，中队查询统计总的里程，时长，执法量，接警数
export function getTotalStat(data) {
  return request({
    url: '/PoliceReportController/getTotalStat',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
//  根据时间段，查询统计支队总的里程，时长，执法量，接警数
export function getTotalOrganStat(data) {
  return request({
    url: 'PoliceReportController/getTotalOrganStat',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}

//  根据大队统计
export function getOrganStat(data) {
  return request({
    url: '/OnePictureController/getOrganStat',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
// 根据
export function getPoliceCurrStat(data) {
  return request({
    url: '/OnePictureController/getPoliceCurrStat',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}

//  根据警员统计
export function getPoliceStat(data) {
  return request({
    url: '/OnePictureController/getPoliceStat',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
// 民警档案 统计
export function getPoliceExecuteSUM(data) {
  return request({
    url: 'PoliceReportController/getPoliceExecuteSUM',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
//  地图点位
export function getDeviceInc(data, options) {
  return request({
    url: '/OnePictureController/getDeviceInc',
    method: 'POST',
    baseURL: bserviceUrl,
    data,
    ...options
  })
}
// 设备历史轨迹
export function getDeviceHis(data) {
  return request({
    url: '/OnePictureController/getDeviceHis',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}

//  接处警记录
export function getIncByPolice(data) {
  return request({
    url: '/PoliceReportController/getIncByPolice',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
// 执勤记录
export function getPoliceExecuteStat(data) {
  return request({
    url: '/PoliceReportController/getPoliceExecuteStat',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
// 执法记录
export function getViolationByPolice(data) {
  return request({
    url: '/PoliceReportController/getViolationByPolice',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
// 获取民警详情
export function getPoliceOrganInfo(data) {
  return request({
    url: '/PoliceReportController/getPoliceOrganInfo',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
//  排行榜
export function getPoliecRanking(data) {
  return request({
    url: '/OnePictureController/getPoliecRanking',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
//  车辆分析
export function getCategoryStat(data) {
  return request({
    url: '/OnePictureController/getCategoryStat',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
// 按支队、大队导出
export function exportOrganStat(params) {
  return request2({
    url: '/PoliceReportController/exportTotalOrganStat',
    method: 'post',
    params,
    baseURL: bserviceUrl
  })
}
// 按警员导出
export function exportPoliceStat(params) {
  return request2({
    url: '/PoliceReportController/exportTotalPoliceStat',
    method: 'post',
    params,
    baseURL: bserviceUrl
  })
}
// 按预警警员统计
export function getAbnormalDevice(data, options) {
  return request({
    url: '/OnePictureController/abnormalDevice',
    method: 'POST',
    data,
    baseURL: bserviceUrl,
    ...options
  })
}
// 预警车辆按支队、大队统计
export function getDutyCountList(data) {
  return request({
    url: '/OnePictureController/getDutyCountList',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
// 预警车辆总和统计
export function getDutyCount(data) {
  return request({
    url: '/OnePictureController/getDutyCount',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}

export function getUnNormalChart(data) {
  return request({
    url: '/OnePictureController/getUnNormalChart',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
