// import request, { request2 } from '@/utils/request'
import request from '@/utils/request'
/**
 * 新增流程配置
 * @param {请求参数} data
 */
export function addFlowInfo(data) {
  return request({
    url: '/flowInfo',
    method: 'post',
    data
  })
}
/**
 * 流程编辑
 * @param {请求参数} data
 */
export function editFlowInfo(data) {
  return request({
    url: '/flowInfo',
    method: 'put',
    data
  })
}
/**
 *查询流程详情
 * @param {请求参数} data
 */
export function getFlowDetail(params) {
  return request({
    url: '/flowInfo/' + params,
    method: 'get'
  })
}
/**
 *流程删除
 * @param {请求参数} data
 */
export function deleteFlow(params) {
  return request({
    url: '/flowInfo/' + params,
    method: 'delete'
  })
}

/**
 *查询流程列表
 * @param {请求参数} data
 */
export function getFlowList(params) {
  return request({
    url: '/flowInfo/list',
    method: 'get',
    params
  })
}

/**
 * 修改流程状态
 * @param {请求参数} data
 */
export function changeFlowState(data) {
  return request({
    url: '/flowInfo/updateState',
    method: 'post',
    data
  })
}

/**
 *查询所有流程分类
 * @param {请求参数} data
 */
export function getTypeList(params) {
  return request({
    url: '/flowSortInfo/queryAll',
    method: 'get',
    params
  })
}
