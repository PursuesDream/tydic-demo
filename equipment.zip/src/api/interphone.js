import request, { request2 } from '@/utils/request'

/**
 * 新增对讲机
 * @param {请求参数} data
 */
export function addInterphone(data) {
  return request({
    url: '/intercom/add',
    method: 'post',
    data
  })
}

/**
 * 修改设备
 * @param {请求参数} data
 */
export function editInterphone(data) {
  return request({
    url: '/intercom/edit',
    method: 'post',
    data
  })
}

/**
 * 删除对讲机
 * @param {请求参数} data
 */
export function deleteIntercomByID(data) {
  return request({
    url: '/intercom/remove',
    method: 'post',
    data
  })
}
/**
 * 分配对讲机
 * @param {请求参数} data
 */
export function adllotInterphone(data) {
  return request({
    url: '/intercom/allocation',
    method: 'post',
    data
  })
}
/**
 *导出对讲机列表
 * @param {请求参数} data
 */
export function exportInterphone(data) {
  return request2({
    url: '/intercom/export',
    method: 'post',
    data
  })
}

/**
 *导入对讲机
 * @param {请求参数} data
 */
export function importInterphone(data) {
  return request({
    url: '/intercom/importIntercomList',
    method: 'post',
    data
  })
}

/** 删除错误文件
 * @param {请求参数} data
 */
export function delErr(data) {
  return request({
    url: '/excel/batchDeleteExcel',
    method: 'post',
    data
  })
}

/**
 * 下载文件错误成功详情
 * @param {Object} data 请求参数
 */
export function downloadImportDetail(data) {
  return request2({
    url: '/excel/dowloadExcel',
    method: 'get',
    params: data
  })
}
/**
 * 请求车辆详情
 * @param {请求参数} data
 */
export function getEqDetail(data) {
  // const { deviceId } = params
  return request({
    url: '/intercom/' + data,
    method: 'get'
  })
}
/**
 *查询对讲机列表
 * @param {请求参数} data
 */
export function getInterphone(params) {
  return request({
    url: '/intercom/list',
    method: 'get',
    params
  })
}
/**
 *查询对讲机详情
 * @param {请求参数} data
 */
export function getInterphoneDetail(params) {
  return request({
    url: '/intercom/' + params,
    method: 'get'
  })
}

/**
 * 模板下载
 * @param {Object} data 请求参数
 */
export function downloadIntercomTemplate(params) {
  return request2({
    url: '/intercom/downloadIntercomTemplate',
    method: 'get',
    params
  })
}

/**
 *查询对讲机使用记录列表
 * @param {请求参数} data
 */
export function getInterphoneUse(params) {
  return request({
    url: '/intercom/recordList',
    method: 'get',
    params
  })
}

/**
 *查询装备使用民警列表
 * @param {请求参数} data
 */
export function getInterphoneUser(params) {
  return request({
    url: 'intercom/getDeviceUseInfo',
    method: 'get',
    params
  })
}
/**
 *停用对讲机
 * @param {请求参数} data
 */
export function stopInterphone(data) {
  return request({
    url: '/intercom/stop?deviceId=' + data,
    method: 'post'
  })
}
/**
 *使用用对讲机
 * @param {请求参数} data
 */
export function useInterphone(data) {
  return request({
    url: '/intercom/used',
    method: 'post',
    data
  })
}
