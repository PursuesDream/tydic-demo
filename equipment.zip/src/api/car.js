import request, { request2 } from '@/utils/request'
const path = '/device'
/**
 * 请求车辆列表
 * @param {请求参数} data
 */
export function getCarList(config) {
  const { params, data } = config
  return request({
    url: path + '/vehicleList',
    method: 'post',
    params,
    data
  })
}

/**
 * 车辆新增或修改
 * @param {请求参数} data
 */
export function updateCar(data) {
  return request({
    url: path + '/insertOrUpdateVehicle',
    method: 'post',
    data
  })
}
/** 删除错误文件
 * @param {请求参数} data
 */
export function delErr(data) {
  return request({
    url: '/excel/batchDeleteExcel',
    method: 'post',
    data
  })
}
/**
 * 修改根据id查询属性/selectCategoryAttrByCategoryCode
 * @param {请求参数} data
 */
export function getCarProperty(data) {
  return request({
    url: path + '/selectVehicleById?deviceId=' + data,
    method: 'post',
    data
  })
}

/**
 *新增根据类型查询属性
 * @param {请求参数} data
 */
export function addCarProperty(data) {
  return request({
    url: path + '/selectCategoryAttrByCategoryCode?categoryCode=' + data,
    method: 'post',
    data
  })
}
// /**
//  * 查询车辆信息使用记录
//  * @param {请求参数} data
//  */
// export function getCarUse(data) {
//   return request({
//     url: '/reportDeviceUsed/vehicleUsedList',
//     method: 'post',
//     data
//   })
// }

/**
 * 批量删除车辆信息
 * @param {请求参数} data
 */
export function deleteCarByID(data) {
  return request({
    url: path + '/deleteVehicleById',
    method: 'post',
    data
  })
}
// 分配车辆接口
/**
 * 分配车辆
 * @param {请求参数} data
 */
export function allotCar(data) {
  return request({
    url: '/deviceUsed/insertVehicleUsed',
    method: 'post',
    data
  })
}
/**
 * 查询车辆使用记录
 * @param {请求参数} data
 */
export function getUseList(config) {
  const { params, data } = config
  return request({
    url: '/deviceRecord/list',
    method: 'post',
    params,
    data
  })
}
/**
 * 停用车辆
 * @param {请求参数} data
 */
export function stopUse(params) {
  const { deviceId, km } = params
  return request({
    url: '/deviceRecord/stop/' + deviceId + '/' + km,
    method: 'get'
  })
}

/**
 * 使用车辆
 * @param {请求参数} data
 */
export function beginUse(params) {
  const { deviceId, userId } = params
  return request({
    url: '/deviceRecord/use/' + deviceId + '/' + userId,
    method: 'get'
  })
}
/**
 * 分配车辆列表查询
 * @param {请求参数} data
 */
export function allotCarList(data) {
  return request({
    url: '/deviceUsed/vehicleUsedList',
    method: 'post',
    data
  })
}

/**
 * 删除车辆分配记录
 * @param {请求参数} data
 */
export function delAllotCar(data) {
  return request({
    url: '/deviceUsed/deleteVehicleUsed?autoId=' + data,
    method: 'post',
    data
  })
}

/**
 * 模板下载
 * @param {Object} data 请求参数
 */
export function downloadVehicleTemplate() {
  return request2({
    url: '/device/downloadVehicleTemplate',
    method: 'get'
  })
}

/**
 * 列表导出
 * @param {Object} data 请求参数
 */
export function downloadVehicleList(data) {
  return request2({
    url: '/device/exportVehicleList',
    method: 'get',
    params: data
  })
}

/**
 * 下载文件错误成功详情
 * @param {Object} data 请求参数
 */
export function downloadImportDetail(data) {
  return request2({
    url: '/excel/dowloadExcel',
    method: 'get',
    params: data
  })
}

/**
 *导入模板
 * @param {请求参数} data
 */
export function importCarList(data) {
  return request({
    url: '/device/importVehicleList',
    method: 'post',
    data
  })
}
