import request, { request2 } from '@/utils/request'

/**
 *设备属性图片新增
 * @param {Object} data 请求参数
 */
export function getAllCategoryList(config) {
  const { params, data } = config
  return request({
    url: '/category/categoryModel',
    method: 'post',
    params,
    data
  })
}
/**
 *属性列表查询
 * @param {Object} data 请求参数
 */
export function getAttributeList(data) {
  return request({
    url: '/attrParam/attrParamList/' + data,
    method: 'post'
  })
}

/**
 *设备属性新增或修改
 * @param {Object} data 请求参数
 */
export function addAttributeList(data) {
  return request({
    url: '/attrParam/attrParamInsertOrUpdate',
    method: 'post',
    data
  })
}

/**
 *设备属性图片删除
 * @param {Object} data 请求参数
 */
export function delAttributeImg(data) {
  return request({
    url: '/attrParam/attrParamDeletePicture',
    method: 'post',
    data
  })
}
/**
 *设备属性图片新增
 * @param {Object} data 请求参数
 */
export function addAttributeImg(config) {
  const { params, data } = config
  return request2({
    url: '/attrParam/attrParamInsertPicture/' + params,
    method: 'post',
    data
  })
}

// 系统设置
/**
 *获取类目详情
 * @param {Object} data 请求参数
 */
export function getCategoryInfo(params) {
  return request({
    url: '/category/getCategoryInfo',
    method: 'get',
    params
  })
}

/**
 *获取类目树
 * @param {Object} data 请求参数
 */
export function getCategoryTree(params) {
  return request({
    url: '/category/getCategoryTree',
    method: 'get',
    params
  })
}

/**
 *类目保存
 * @param {Object} data 请求参数
 */
export function saveCategory(data) {
  return request({
    url: '/category/save',
    method: 'post',
    data
  })
}

/**
 *目录拖拽
 * @param {Object} data 请求参数
 */
export function dragCategory(data) {
  return request({
    url: '/category/drag',
    method: 'post',
    data
  })
}

/**
 *目录删除
 * @param {Object} data 请求参数
 */
export function deleteCategory(data) {
  return request({
    url: '/category/delete',
    method: 'post',
    data
  })
}

/**
 *修改为无效状态
 * @param {Object} data 请求参数
 */
export function changeStateCategory(data) {
  return request({
    url: '/category/updateStates',
    method: 'post',
    data
  })
}
