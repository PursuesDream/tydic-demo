import request, { request2 } from '@/utils/request'
// const mockPath = '/mock' + process.env.VUE_APP_BASE_API
/**
 * 维保项目列表查询
 * @param {Object} data 请求参数
 */
export function getFixList(options) {
  const { params, data } = options
  return request({
    url: '/fixItemconfig/fixItemconfigList',
    method: 'post',
    params,
    data
  })
}
/**
 * 维保项目列表查询
 * @param {Object} data 请求参数
 */
export function getFixItemconfigByFixId(params) {
  return request({
    url: '/fixItemconfig/selectFixItemconfigByFixId',
    method: 'post',
    params
  })
}
/**
 * 维保项目新增或修改
 * @param {Object} data 请求参数
 */
export function updateFixList(data) {
  return request({
    url: '/fixItemconfig/insertOrUpdateFixItemconfig',
    method: 'post',
    data
  })
}
/**
 * 维保项目根据id查询详情
 * @param {Object} data 请求参数
 */
export function getFixDetail(data) {
  return request({
    url: '/fixItemconfig/selectFixItemconfigById',
    method: 'post',
    params: data
  })
}
/**
 * 维保项目删除
 * @param {Object} data 请求参数
 */
export function delFixList(data) {
  return request({
    url: '/fixItemconfig/deleteFixItemconfigByIds',
    method: 'post',
    data
  })
}
/**
 * 维保单位下拉查询
 * @param {Object} data 请求参数
 */
export function selectFixList(data) {
  return request({
    url: '/fixCompany/fixCompanyList',
    method: 'post',
    data
  })
}

/**
 * 模板下载
 * @param {Object} data 请求参数
 */
export function downloadFixItemconfigTemplate() {
  return request2({
    url: '/fixItemconfig/downloadFixItemconfigTemplate',
    method: 'get'
  })
}

/**
 * 列表导出
 * @param {Object} data 请求参数
 */
export function exportProjectList(data) {
  return request2({
    url: '/fixItemconfig/exportFixItemconfigList',
    method: 'get',
    params: data
  })
}
/**
 * 列表导入
 * @param {Object} data 请求参数
 */
export function importProjectList(data) {
  return request({
    url: '/fixItemconfig/importFixItemconfigList',
    method: 'post',
    data
  })
}
