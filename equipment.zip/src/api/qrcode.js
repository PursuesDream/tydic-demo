import request, { request2 } from '@/utils/request'

/* 根据用户数据权限查询支队 */
function getParentCodeList() {
  return request({
    url: '/qrcode/getParentCodeList',
    method: 'get'
  })
}
/*
* 获取二维码列表
* */
function getQrcodeList(data, page) {
  return request({
    url: '/qrcode/qrcodeList?pageNum=' + page + '&pageSize=10',
    method: 'post',
    data
  })
}
/*
* 设置停用
* */
function setStopQrcode(data) {
  return request({
    url: '/qrcode/stopQrcode',
    method: 'post',
    data
  })
}
/*
* 获取装备编号下拉
* */
function getVehicleList(data) {
  return request({
    url: '/device/vehicleList',
    method: 'post',
    data
  })
}
/*
* 生产二维码
* */
function insertQrcode(data) {
  return request({
    url: '/qrcode/insertQrcode',
    method: 'post',
    data
  })
}
/*
* 下载二维码
* */
function downloadQrcode(data) {
  return request2({
    url: '/qrcode/downloadQrcode',
    method: 'post',
    data
  })
}
/*
* 绑定二维码
* */
function bindQrcotde(data) {
  return request({
    url: '/qrcode/bindQrcode',
    method: 'post',
    data
  })
}
/*
* 解除绑定二维码
* */
function unbindQrcode(data) {
  return request({
    url: '/qrcode/unbindQrcode',
    method: 'post',
    data
  })
}
/*
* 启用二维码
* */
function enableQrcode(data) {
  return request({
    url: '/qrcode/enableQrcode',
    method: 'post',
    data
  })
}

export default {
  getParentCodeList,
  getQrcodeList,
  setStopQrcode,
  getVehicleList,
  insertQrcode,
  downloadQrcode,
  bindQrcotde,
  unbindQrcode,
  enableQrcode
}
