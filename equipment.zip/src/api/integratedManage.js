import request from '@/utils/request'
// const publicPath = '/Category'
/**
 * 类目级联查询
 * @param {Object} data 请求参数
 */
export function getCategoryList(data) {
  return request({
    url: '/category/categoryChildList',
    method: 'post',
    params: data
  })
}
/**
 * 类目新增或修改
 * @param {Object} data 请求参数
 */
export function addOrUpdateCategory(data) {
  return request({
    url: '/category/insertOrUpdateCategory',
    method: 'post',
    data
  })
}
/**
 * 类目删除
 * @param {Object} data 请求参数
 */
export function deleteCategory(data) {
  return request({
    url: '/category/deleteCategory',
    method: 'post',
    params: data
  })
}
/**
 * 类目上移下移opType=1
 * @param {Object} options 请求参数
 */
export function changeOrder(options) {
  const { params, data } = options
  return request({
    url: '/category/reOrder',
    method: 'post',
    params,
    data
  })
}
/* 维保单位管理 */
/**
 * 列表查询
 * @param {Object} options 请求参数
 */
export function getfixCompanyList(options) {
  const { params, data } = options
  return request({
    url: '/fixCompany/fixCompanyList',
    method: 'post',
    params,
    data
  })
}

/**
 * 删除
 * @param {Object} data 请求参数
 */
export function deleteFixCompany(data) {
  return request({
    url: '/fixCompany/deleteFixCompanyByIds',
    method: 'post',
    data
  })
}
/**
 * 新增或修改
 * @param {Object} data 请求参数
 */
export function insertOrUpdateFixCompany(data) {
  return request({
    url: '/fixCompany/insertOrUpdateFixCompany',
    method: 'post',
    data
  })
}

/**
 * 根据id查询维保单位列表
 * @param {Object} data 请求参数
 */
export function getfixCompanyByID(data) {
  return request({
    url: '/fixCompany/selectFixCompanyById?comId=' + data,
    method: 'post',
    data
  })
}
// 根据车牌号码查询，返回车辆品牌代码
/**
 * 根据id查询维保单位列表
 * @param {Object} data 请求参数
 */
export function getfixCompanyByVehicleNo(params) {
  return request({
    url: '/category/selectVehicleBrandByVehicleNo',
    method: 'post',
    params
  })
}

// 车牌号查询设备型号代码
/**
 * 根据id查询维保单位列表
 * @param {Object} data 请求参数
 */
export function getCategoryCodeByVehicleNo(params) {
  return request({
    url: '/category/selectCategoryCodeByVehicleNo',
    method: 'post',
    params
  })
}
