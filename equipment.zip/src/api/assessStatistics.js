import request, { request2 } from '@/utils/request'
const bserviceUrl = window.CONFIG.bserviceUrl

function exportAssessData(data) {
  return request2({
    url: '/assess/exportAssessData',
    method: 'post',
    data,
    baseURL: bserviceUrl
  })
}
function getAssessGroupData(data) {
  return request({
    url: '/assess/getAssessGroupData',
    method: 'post',
    data,
    baseURL: bserviceUrl
  })
}
function getPoliceAssessData(data) {
  return request({
    url: '/assess/getPoliceAssessData',
    method: 'post',
    data,
    baseURL: bserviceUrl
  })
}

export default {
  exportAssessData,
  getAssessGroupData,
  getPoliceAssessData
}
