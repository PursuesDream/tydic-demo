/**
 * 公共接口
 */
import request, { request2 } from '@/utils/request'
const publicUrl = window.CONFIG.publicUrl
/**
 * 字典
 */
export function getListDict() {
  return request({
    url: '/dict/listDicts',
    method: 'GET',
    baseURL: publicUrl
  })
}

/**
 * 字典类型
 */
export function getDictType() {
  return request({
    url: '/dict/dictGroup',
    method: 'GET',
    baseURL: publicUrl
  })
}
/**
 * 用户信息详情
 */
export function getUserInfo() {
  return request({
    url: '/user/query/currUser',
    method: 'GET',
    baseURL: publicUrl
  })
}
/**
 * 查询大队接口
 * @param {Object} data 请求参数
 */
export function getOrganList(data) {
  return request({
    url: '/organ/childOrganList?parentCode=' + data,
    method: 'get',
    baseURL: publicUrl,
    data
  })
}
/**
 * 文件上传接口
 * @param {Object} data 请求参数
 */
export function addFileList(data) {
  return request({
    url: '/file/Upload',
    method: 'post',
    baseURL: publicUrl,
    data
  })
}
/**
 * 文件删除接口
 * @param {Object} data 请求参数
 */
export function removeFileList(data) {
  return request({
    url: '/file/deleteFile',
    method: 'post',
    baseURL: publicUrl,
    data
  })
}
/**
 * 请求警员列表
 * @param {Object} params 请求参数
 */
export function getPoliceList(params) {
  return request({
    url: '/user/listUser',
    method: 'get',
    baseURL: publicUrl,
    params
  })
}
/**
 * 文件打包zip下载
 * @param {Object} data 请求参数
 */
export function downLoadAllFIle(data) {
  return request2({
    url: '/file/batchDownLoadFile',
    method: 'post',
    baseURL: publicUrl,
    data
  })
}

/**
 * 文件下载功能
 * @param {Object} data 请求参数
 */
export function downLoadFile(data) {
  return request2({
    url: '/file/download',
    method: 'post',
    baseURL: publicUrl,
    data
  })
}
/**
 * 根据级别类型查询机构
 * @param {Object} params 请求参数
 */
export function organListByParam(params) {
  return request({
    url: '/organ/childOrganListByParam',
    method: 'get',
    baseURL: publicUrl,
    params
  })
}

/**
 * 查询所有有效状态的机构
 * @param {Object} params 请求参数
 */
export function getUseOrganList(params) {
  return request({
    url: '/organ/organTree',
    method: 'get',
    baseURL: publicUrl,
    params
  })
}

/**
 * 查询所有角色查询
 * @param {Object} params 请求参数
 */
export function getRoleList(params) {
  return request({
    url: '/role/queryRoles',
    method: 'get',
    baseURL: publicUrl,
    params
  })
}
/*
* 获取单位
* */
export function getUnit(params) {
  return request({
    url: '/organ/childOrganListByParam',
    method: 'GET',
    params,
    baseURL: publicUrl
  })
}

/**
 * 机构树查询,只查询有数据权限且有效状态的机构
 * @param {Object} params 请求参数
 */
export function getOrganAuthTree(params) {
  return request({
    url: '/organ/organAuthTree',
    method: 'get',
    baseURL: publicUrl,
    params
  })
}
