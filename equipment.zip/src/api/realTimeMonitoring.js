import request from '@/utils/request'
// const mockPath = '/mock' + process.env.VUE_APP_BASE_API
/**
 * 地图打点车辆信息
 * @param {Object} data 请求参数
 */
export function getMapPoint(data) {
  return request({
    url: '/vehicleState/selectVehicleStateList',
    method: 'post',
    data
  })
}
/**
 * 左侧单位车辆菜单树
 * @param {Object} data 请求参数
 */
export function getTreeList(params) {
  return request({
    url: '/vehicleState/selectVehicleMenueList',
    method: 'post',
    params
  })
}

// mock数据模拟
/**
 * 车辆超速信息列表查询
 * @param {Object} data 请求参数
 */
export function getPointList(data) {
  return request({
    url: '/vehicleState/selectVehicleSpeedingList?vehicleNo=' + data,
    method: 'post',
    data
  })
}
/**
 * 车辆超速轨迹回放查询
 * @param {Object} data 请求参数
 */
export function getWarnTrack(data) {
  return request({
    url: '/vehicleStateHis/selectVehicleStateHisList',
    method: 'post',
    data
  })
}

