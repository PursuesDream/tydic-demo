import request from '@/utils/request'

function DevBrandSummary(param) {
  return request({
    url: '/devWall/devBrandSummary?organCode=' + param.organCode,
    method: 'get',
    param
  })
}
function DevCategorySummary(param) {
  return request({
    url: '/devWall/devCategorySummary?organCode=' + param.organCode,
    method: 'get',
    param
  })
}
function DevIncrementSummary(data) {
  return request({
    url: '/devWall/devIncrementSummary',
    method: 'post',
    data
  })
}
function DevFixStatisticSummary(param) {
  return request({
    url: '/devWall/devFixStatisticSummary?organCode=' + param.organCode,
    method: 'get',
    param
  })
}
function DevOpsSummary(param) {
  return request({
    url: '/devWall/devOpsSummary?mileage=' + param.mileage + '&organCode=' + param.organCode,
    method: 'get'
  })
}
function DevFixUsedSummary(data) {
  return request({
    url: '/devWall/devFixUsedSummary',
    method: 'post',
    data
  })
}
function DevStatisticSummary(param) {
  return request({
    url: '/devWall/devStatisticSummary?organCode=' + param.organCode,
    method: 'get'
  })
}

export default {
  DevBrandSummary,
  DevCategorySummary,
  DevIncrementSummary,
  DevFixStatisticSummary,
  DevOpsSummary,
  DevFixUsedSummary,
  DevStatisticSummary
}
