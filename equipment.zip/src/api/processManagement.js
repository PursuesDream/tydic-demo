import request from '@/utils/request'
// const mockPath = '/mock' + process.env.VUE_APP_BASE_API
/**
 * 新增设备维修申请
 * @param {Object} data 请求参数
 */
export function fixApplyList(data) {
  return request({
    url: '/fixApply',
    method: 'post',
    data
  })
}
/**
 * 根据车辆类型查询车牌
 * @param {Object} data 请求参数
 */
export function getCarList(data) {
  return request({
    url: '/deviceUsed/selectVehicleNoByUserId',
    method: 'get',
    params: data
  })
}
/**
 * 查询设备维修申请列表
 * @param {Object} data 请求参数
 */
export function getFixData(data) {
  return request({
    url: '/fixApply/deviceFlowlist',
    method: 'get',
    params: data
  })
}
/**
 * 查询设备维修申请列表
 * @param {Object} data 请求参数
 */
export function getFixAllList(data) {
  return request({
    url: '/fixApply/list',
    method: 'get',
    params: data
  })
}

/**
 * 查询单流程处理记录列表
 * @param {Object} data 请求参数
 */
export function getOperateFlowList(data) {
  return request({
    url: '/formOperateFlow/list',
    method: 'get',
    params: data
  })
}

/**
 * 获取设备维修申请详细信息
 * @param {Object} data 请求参数
 */
export function getFixDetail(data) {
  return request({
    url: '/fixApply/' + data,
    method: 'post',
    data
  })
}

/**
 * 新增单流程处理记录
 * @param {Object} data 请求参数
 */
export function addFixFlow(data) {
  return request({
    url: '/formOperateFlow',
    method: 'post',
    data
  })
}

/**
 * 测试上传功能
 * @param {Object} data 请求参数
 */
export function addFixImg(data) {
  return request({
    url: '/file/Upload',
    method: 'post',
    // baseURL: '/',
    data
  })
}

/**
 * 删除图片
 * @param {Object} data 请求参数
 */
export function delFixImg(data) {
  return request({
    url: '/fixApply/remove',
    method: 'post',
    data
  })
}
