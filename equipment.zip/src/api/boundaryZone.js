import request from '@/utils/request'
const bserviceUrl = window.CONFIG.bserviceUrl

export function getDistrictArea(data) {
  return request({
    url: '/area/queryList',
    method: 'POST',
    data,
    baseURL: bserviceUrl
  })
}
