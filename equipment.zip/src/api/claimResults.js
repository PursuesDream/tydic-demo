import request from '@/utils/request'
/*
* 战果认领列表
* */
function claimList(data) {
  return request({
    url: '/claim/list?pageNum=' + data.pageNum + '&pageSize=' + data.pageSize + '',
    method: 'post',
    data
  })
}

/*
* 设备轨迹列表
* */
function claimTrackList(data) {
  return request({
    url: '/claim/groupClaimRecodesByTime',
    method: 'post',
    data
  })
}

/*
* 设备轨迹列表
* */
function claimDetailTrackList(data) {
  return request({
    url: '/claim/groupClaimRecodesDetailByTime',
    method: 'post',
    data
  })
}

/*
* 战果认领
* */
function claimRecodes(data) {
  return request({
    url: '/claim/claimRecodes',
    method: 'post',
    data
  })
}

/*
* 设备轨迹
* */
function listTrackPoints(data) {
  return request({
    url: '/claim/listTrackPoints',
    method: 'post',
    data
  })
}

export default {
  claimList,
  claimTrackList,
  claimDetailTrackList,
  claimRecodes,
  listTrackPoints
}
