<template>
  <div class="page-container">
    <div id="map" />
    <div class="dateTime">
      <div class="content">
        <span class="time">{{ times.time }}</span>
        <p class="date">
          {{ times.day }}<br>
          {{ times.date }}
        </p>
      </div>
    </div>
    <!-- 勤务概况 -->
    <div v-if="isGeneral">
      <!-- 支队列表-->
      <div v-if="listType === '1'" class="ssjc" style="left: 16px; right: auto">
        <div class="ssjc-title">
          <div v-if="isSearch" style="padding-left: 13px">勤务概况 <i class="el-icon-search" @click="isSearch = false" /> <i class="icon_tab warn_icon" @click="toWarn" /></div>
          <div v-else>
            <i class="el-icon-back" @click="isSearch = true" />
            <el-input
              v-model="policeSearch"
              placeholder="输入民警姓名/警号"
              class="police-search"
              clearable
            >
              <i slot="suffix" class="el-input__icon el-icon-search input-search" @click="searchPolice" />
            </el-input>
            <!-- <i class="el-icon-search input-search" /> -->
          </div>
        </div>
        <div class="ssjc-list">
          <div class="police_detail">
            <dl>
              <dt><span>{{ policeNum }}</span> 人</dt>
              <dd>民警数量</dd>
            </dl>
            <dl>
              <dt><span>{{ onlinePolice }}</span> 人</dt>
              <dd>在线民警</dd>
            </dl>
            <dl v-if="false">
              <dt><span>{{ cavalryNum }}</span> 辆</dt>
              <dd>铁骑数量</dd>
            </dl>
            <dl>
              <dt><span>{{ todayNumCount || 0 }}</span> 辆</dt>
              <dd>今日执勤</dd>
            </dl>
          </div>
          <div
            v-for="(item, index) in organizeList"
            :key="index"
            class="progress-line"
            @click="handleDetachment(item.organCode,'2',item.organShortName)"
          >
            <h3 class="textTile">
              {{ item.organName }}
              <img :src="item.iconUrl" class="title_icon" alt="">
            </h3>
            <div class="textCount">
              <div style="width:50%">民警：<span style="color: #ED1C24">{{ item.oCount }}</span> / {{ item.uCount }}</div>
              <div v-if="false" style="width:50%">铁骑：<span style="color: #ED1C24">{{ item.devCount }}</span> 辆</div>
              <div style="width:50%">铁骑：<span style="color: #ED1C24">{{ item.onlineNum }}</span> / {{ item.devCount }}</div>
            </div>
            <div style="display:flex;width:100%">
              <div style="width:26%;text-align:center">
                <div><span class="progress-num">{{ item.patrolMileageXs }}</span> <span style="font-size: 12px">{{ item.patrolMileageUnit }}</span></div>
                <div class="progress-font">骑巡里程</div>
              </div>
              <div style="width:26%;text-align:center">
                <div><span class="progress-num">{{ item.patrolTimeXs }}</span>  <span style="font-size: 12px">{{ item.patrolTimeUnit }}</span></div>
                <div class="progress-font">骑巡时长</div>
              </div>
              <div style="width:24%;text-align:center">
                <div><span class="progress-num">{{ item.alarmNumber }}</span>  <span style="font-size: 12px">起</span></div>
                <div class="progress-font">接处警数</div>
              </div>
              <div style="width:24%;text-align:center">
                <div><span class="progress-num">{{ item.lawEnNumber }}</span> <span style="font-size: 12px">起</span></div>
                <div class="progress-font">执法量</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 支队勤务 -->
      <div v-if="listType === '2'" class="ssjc" style="left: 16px; right: auto">
        <div class="ssjc-title">
          <div>
            <i class="el-icon-back" @click="handleBack('','1')" />
            <!--（{{ onlineUser }}/{{ countUser }}）-->
            {{ brigadeOrganName }}
          </div>
        </div>
        <div class="ssjc-list">
          <div class="police_detail">
            <dl>
              <dt><span>{{ policeNum }}</span> 人</dt>
              <dd>民警数量</dd>
            </dl>
            <dl>
              <dt><span>{{ onlinePolice }}</span> 人</dt>
              <dd>在线民警</dd>
            </dl>
            <dl v-if="false">
              <dt><span>{{ cavalryNum }}</span> 辆</dt>
              <dd>铁骑数量</dd>
            </dl>
            <dl>
              <dt><span>{{ todayNumCount || 0 }}</span> 辆</dt>
              <dd>今日执勤</dd>
            </dl>
          </div>
          <div
            v-for="(item, index) in organizeList"
            :key="index"
            class="progress-line"
            @click="handlerShowPolice(item)"
          >
            <h3 class="textTile"><img :src="item.iconUrl" class="title_icon" alt="">{{ item.organName }}</h3>
            <div class="textCount">
              <div style="width:50%">民警：<span style="color: #ED1C24">{{ item.oCount }}</span> / {{ item.uCount }}</div>
              <div v-if="false" style="width:50%">铁骑：<span style="color: #ED1C24">{{ item.devCount }}</span> 辆</div>
              <div style="width:50%">铁骑：<span style="color: #ED1C24">{{ item.onlineNum }}</span> / {{ item.devCount }}</div>
            </div>
            <div style="display:flex;width:100%">
              <div style="width:26%;text-align:center">
                <div><span class="progress-num">{{ item.patrolMileageXs }}</span> {{ item.patrolMileageUnit }}</div>
                <div class="progress-font">骑巡里程</div>
              </div>
              <div style="width:26%;text-align:center">
                <div><span class="progress-num">{{ item.patrolTimeXs }}</span> {{ item.patrolTimeUnit }}</div>
                <div class="progress-font">骑巡时长</div>
              </div>
              <div style="width:24%;text-align:center">
                <div><span class="progress-num">{{ item.alarmNumber }}</span> 起</div>
                <div class="progress-font">接处警数</div>
              </div>
              <div style="width:24%;text-align:center">
                <div><span class="progress-num">{{ item.lawEnNumber || 0 }}</span> 起</div>
                <div lass="progress-font">执法量</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 警员列表 -->
      <div v-if="listType === '3'" class="police-container">
        <div class="police-title">
          <div :title="policeTitle">
            {{ policeTitle }}
            <!--  {{ organizeDetail.organName }}({{ onlineUser }}/{{ countUser }})-->
          </div>
          <i class="el-icon-back" @click="handleBack(policeSearch ? '' : brigadeOrganCode,policeSearch ? '1' : '2')" />

        </div>
        <!-- <el-input
          v-model="policeSearch"
          placeholder="输入民警姓名/警号"
          class="police-search"
          clearable
        /> -->
        <div v-loading="policeLoading" class="police-list">
          <div v-if="!policeSearch" class="police_detail">
            <dl>
              <dt><span>{{ policeNum }}</span> 人</dt>
              <dd>民警数量</dd>
            </dl>
            <dl>
              <dt><span>{{ onlinePolice }}</span> 人</dt>
              <dd>在线民警</dd>
            </dl>
            <dl v-if="false">
              <dt><span>{{ cavalryNum }}</span> 辆</dt>
              <dd>铁骑数量</dd>
            </dl>
            <dl>
              <dt><span>{{ todayNumCount }}</span> 辆</dt>
              <dd>今日执勤</dd>
            </dl>
          </div>
          <div
            v-for="(item, idx) in policeList"
            :key="idx"
            class="police-item"
            :class="item.status === 1 ? 'backup' : ''"
            @click="showPoliceDetail(item)"
          >
            <!-- <img :src="item.img" class="avatar"> -->
            <el-image
              fit="fit"
              class="avatar"
              :src="item.img"
            >
              <div slot="error" class="image-slot" />
            </el-image>
            <div class="police-info">
              <div>
                <span
                  style="font-size: 20px; font-weight: bold; margin-right: 10px;color: #3699FF"
                >{{ item.policeName }}</span>&nbsp;{{ item.policeCode }}
              </div>
              <div>
                <!-- <el-tag
                  class="brand"
                  size="mini"
                  :type="idx ? '' : 'warning'"
                  effect="dark"
                >{{ !idx ? '处警中' : '骑巡中' }}</el-tag> -->
                <el-tag
                  v-if="item.useState"
                  class="brand"
                  size="mini"
                  effect="dark"
                >骑巡中</el-tag>
                <span class="plate_num">{{ item.deviceNo }}</span>
              </div>
              <div style="color: #40a9f5">
                <div>
                  <span style="font-size: 18px">{{
                    item.patrolMileage || 0
                  }}</span>&nbsp;KM<br><span style="color: #333">巡逻里程</span>
                </div>
                <div>
                  <span style="font-size: 18px">{{ item.lawEnNumber || 0 }}</span>&nbsp;起<br><span style="color: #333">违法处理</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 车辆预警 -->
    <div v-else>
      <!-- 预警支队列表-->
      <div v-if="warnType === '1'" class="ssjc" style="left: 16px; right: auto">
        <div class="ssjc-title warn-title">
          <div v-if="isWarnSearch" style="padding-left: 13px">车辆预警 <i class="el-icon-search" @click="isWarnSearch = false" /> <i class="icon_tab general_icon" @click="toGeneral" /></div>
          <div v-else>
            <i class="el-icon-back" @click="isWarnSearch = true" />
            <el-input
              v-model="policeWarnSearch"
              placeholder="请输入车牌"
              class="police-search"
              clearable
            >
              <i slot="suffix" class="el-input__icon el-icon-search input-search" @click="searchWarnPolice" />
            </el-input>
            <!-- <i class="el-icon-search input-search" /> -->
          </div>
        </div>
        <div class="ssjc-list">
          <div class="police_detail">
            <dl v-if="false">
              <dt><span>{{ policeWarnNum }}</span> 辆</dt>
              <dd>铁骑数量</dd>
            </dl>
            <dl>
              <dt><span>{{ onlineCarSum }}</span> 辆</dt>
              <dd>正常骑行</dd>
            </dl>
            <dl v-if="false">
              <dt><span>{{ onlineWarnPolice }}</span> 辆</dt>
              <dd>正常骑行</dd>
            </dl>
            <dl>
              <dt class="red-color"><span>{{ cavalryWarnNum }}</span> 辆</dt>
              <dd>异常骑行</dd>
            </dl>
            <dl>
              <dt class="yellow-color"><span>{{ offlineCarSum }}</span> 辆</dt>
              <dd>离线车辆</dd>
            </dl>
          </div>
          <div
            v-for="(item, index) in organizeWarnList"
            :key="index"
            class="progress-line"
            @click="handleWarnDetachment(item.organCode,item.organName)"
          >
            <h3 class="textTile">
              {{ item.organName }}
              <img :src="item.iconUrl" class="title_icon" alt="">
            </h3>
            <div style="display:flex;width:100%">
              <div v-if="false" style="width:33.3%;text-align:center">
                <div><span style="font-size: 20px;color: #3274e1">{{ item.deviceCount }}</span> 辆</div>
                <div>铁骑数量</div>
              </div>
              <div style="width:33.3%;text-align:center">
                <div><span style="font-size: 20px;color: #3274e1">{{ item.normalCount }}</span> 辆</div>
                <div>正常骑行</div>
              </div>
              <div style="width:33.3%;text-align:center">
                <div class="red-color"><span style="font-size: 20px;">{{ item.unNormalCount }}</span> 辆</div>
                <div>异常骑行</div>
              </div>
              <div style="width:33.3%;text-align:center">
                <div><span style="font-size: 20px;color: #3274e1">{{ item.offlineCount }}</span> 辆</div>
                <div>离线车辆</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 预警大队列表 -->
      <div v-if="warnType === '2'" class="ssjc" style="left: 16px; right: auto">
        <div class="ssjc-title warn-title">
          <div>
            <i class="el-icon-back" @click="handleWarnBack('1')" />
            <!--（{{ onlineUser }}/{{ countUser }}）-->
            {{ brigadeWarnOrganName }}
          </div>
        </div>
        <div class="ssjc-list">
          <div class="police_detail">
            <dl v-if="false">
              <dt><span>{{ policeWarnNum }}</span> 辆</dt>
              <dd>铁骑数量</dd>
            </dl>
            <dl>
              <dt><span>{{ onlineCarSum }}</span> 辆</dt>
              <dd>正常骑行</dd>
            </dl>
            <dl v-if="false">
              <dt><span>{{ onlineWarnPolice }}</span> 辆</dt>
              <dd>正常骑行</dd>
            </dl>
            <dl>
              <dt class="red-color"><span>{{ cavalryWarnNum }}</span> 辆</dt>
              <dd>异常骑行</dd>
            </dl>
            <dl>
              <dt class="yellow-color"><span>{{ offlineCarSum }}</span> 辆</dt>
              <dd>离线车辆</dd>
            </dl>
          </div>
          <div
            v-for="(item, index) in organizeWarnList"
            :key="index"
            class="progress-line"
            @click="handlerWarnShowPolice(item)"
          >
            <h3 class="textTile"><img :src="item.iconUrl" class="title_icon" alt="">{{ item.organName }}</h3>
            <div style="display:flex;width:100%">
              <div v-if="false" style="width:33.3%;text-align:center">
                <div><span style="font-size: 20px;color: #3274e1">{{ item.deviceCount }}</span> 辆</div>
                <div>铁骑数量</div>
              </div>
              <div style="width:33.3%;text-align:center">
                <div><span style="font-size: 20px;color: #3274e1">{{ item.normalCount }}</span> 辆</div>
                <div>正常骑行</div>
              </div>
              <div style="width:33.3%;text-align:center">
                <div class="red-color"><span style="font-size: 20px;">{{ item.unNormalCount }}</span> 辆</div>
                <div>异常骑行</div>
              </div>
              <div style="width:33.3%;text-align:center">
                <div><span style="font-size: 20px;color: #3274e1">{{ item.offlineCount }}</span> 辆</div>
                <div>离线车辆</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 预警车辆列表 -->
      <div v-if="warnType === '3'" class="police-container warn-container">
        <div class="police-title warn-title">
          <div :title="warnCarTitle">
            {{ warnCarTitle }}
            <!--  {{ organizeDetail.organName }}({{ onlineUser }}/{{ countUser }})-->
          </div>
          <i class="el-icon-back" @click="handleWarnBack('2')" />
        </div>
        <div v-loading="policeLoading" class="police-list">
          <div v-if="isWarnDetail" class="police_detail">
            <dl v-if="false">
              <dt><span>{{ policeWarnNum }}</span> 辆</dt>
              <dd>铁骑数量</dd>
            </dl>
            <dl>
              <dt><span>{{ onlineCarSum }}</span> 辆</dt>
              <dd>正常骑行</dd>
            </dl>
            <dl v-if="false">
              <dt><span>{{ onlineWarnPolice }}</span> 辆</dt>
              <dd>正常骑行</dd>
            </dl>
            <dl>
              <dt class="red-color"><span>{{ unNormalCarnNum }}</span> 辆</dt>
              <dd>异常骑行</dd>
            </dl>
            <dl>
              <dt class="yellow-color"><span>{{ offlineCarSum }}</span> 辆</dt>
              <dd>离线车辆</dd>
            </dl>
          </div>
          <div
            v-for="(item, idx) in carWarnList"
            :key="idx"
            class="police-item"
            :class="item.status === 1 ? 'backup' : ''"
          >
            <div style="width:100%">
              <div style="width:100%;">
                <span class="deviceNo_box">{{ item.deviceNo }}</span>
              </div>
              <div style="width:100%;" class="abnormal_box">
                异常原因：未扫码骑行
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="oper-btns">
      <transition name="el-zoom-in-bottom">
        <div v-if="isOperBtns" class="oper-all">
          <!-- <div :class="operBtns.isOnline?'oper-active':''" @click="toggleDevice('isOnline')">在线</div> -->
          <div :class="operBtns.isOffline?'oper-active':''" @click="toggleDevice('isOffline')">离线</div>
          <!-- <div :class="operBtns.isWarning?'oper-active':''" @click="toggleDevice('isWarning')">预警</div> -->
          <div :class="operBtns.isDistrict?'oper-active':''" @click="toggleDistrictMap">管界</div>
          <div :class="operBtns.isTrafficLayerMap?'oper-active':''" @click="trafficLayerMap">路况</div>
        </div>
      </transition>
      <div class="oper" @click="isOperBtns=!isOperBtns">
        <img v-if="!isOperBtns" src="../../assets/map/u10181.png" alt="" class="img1">
        <img v-else src="../../assets/map/u10188.png" alt="" class="img2">
      </div>
      <div
        v-if="(listType === '2' || warnType === '2') && operBtns.isDistrict&&isOperBtns"
        class="date-select2"
      >
        <el-radio-group
          v-model="gjRadio"
          style="margin: 8px"
          @change="refreshDistrictMap('2')"
        >
          <el-radio
            :label="0"
            style="color: white; margin-bottom: 8px"
          >行政区域</el-radio>
          <el-radio :label="1" style="color: white">大队管辖</el-radio>
        </el-radio-group>
      </div>
    </div>
    <div v-if="isShowPoliceDetail" class="police-detail">
      <p class="detail_title">
        <span class="title">铁骑详情</span>
        <i class="el-icon-close p-close" @click="handleClosePolice" />
      </p>
      <!-- <img :src="policeDetail.img" class="police-img" alt=""> -->
      <el-image
        fit="fit"
        class="police-img"
        :src="policeDetail.img"
      >
        <div slot="error" class="image-slot" />
      </el-image>
      <!-- <img
        src="https://dss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1606674349,3478859417&fm=26&gp=0.jpg"
        class="police-img"
        alt=""
      > -->
      <div style="margin: 8px 16px 8px 16px;padding-bottom: 35px">
        <div class="police-message">
          <span class="name">{{ policeDetail.policeName }}</span>
          {{ policeDetail.policeCode }}
          <el-tag
            class="brand"
            size="mini"
            effect="dark"
            style="float: right; margin: 4px 0"
          >骑巡中</el-tag>
        </div>
        <div class="police-message">{{ policeDetail.deviceNo }}</div>
        <div class="police-message" :title=" policeDetail.pOrganName + '-' + policeDetail.organName ">
          {{ policeDetail.pOrganName }} - {{ policeDetail.organName }}
        </div>
        <div class="police-message">定位数据时间：{{ policeDetail.lastDate }}</div>
        <div class="police-message">
          定位数据来源：<span v-if="policeDetail.isTBox === '0'">PDA</span><span v-if="policeDetail.isTBox === '1'">TBox</span>
        </div>
        <div class="police-statistics">
          <div>
            <span style="font-size: 22px">{{
              policeDetail.patrolTimeXs
            }}</span>
            {{
              policeDetail.patrolTimeUnit
            }}<br><span style="color: #33333399">今日骑巡时长</span>
          </div>
          <div>
            <span style="font-size: 22px">{{ policeDetail.patrolMileageXs }}</span> {{ policeDetail.patrolMileageUnit }}<br><span style="color: #33333399">今日骑巡里程</span>
          </div>
          <div>
            <span style="font-size: 22px">{{
              policeDetail.lawEnNumber || 0
            }}</span>
            起<br><span style="color: #33333399">今日执法量</span>
          </div>
          <div>
            <span style="font-size: 22px">{{
              policeDetail.alarmNumber || 0
            }}</span>
            起<br><span style="color: #33333399">今日接处警数</span>
          </div>
        </div>

        <el-button
          type="primary"
          plain
          class="ckgj"
          size="mini"
          :disabled="!policeDetail.deviceNo"
          @click="handleShowTrackBox"
        ><i />查看轨迹</el-button>
      </div>
    </div>
    <!-- 轨迹查询 -->
    <div v-if="isShowTrackBox" class="track-search-box">
      <el-date-picker
        v-model="trackTime"
        type="datetimerange"
        range-separator="至"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        value-format="yyyy-MM-dd HH:mm:ss"
        @change="handleTrackTimeChange"
      />
      <el-select v-model="trackSpeed" placeholder="请选择播放时间">
        <el-option
          v-for="item in trackSpeedList"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        />
      </el-select>
      <el-button
        type="primary"
        style="margin-left: 15px"
        size="small"
        @click="trackPlay"
      >播放</el-button>
      <el-button size="small" @click="trackCancel">取消播放</el-button>
      <el-button size="small" @click="trackClose">关闭</el-button>
    </div>
    <!--违法检测-->
    <div v-if="false" class="ssjc">
      <div class="ssjc-title">违法检测</div>
      <div id="ssjc" class="ssjc-list">
        <div
          v-for="item in ssjcList"
          :key="item.time"
          v-animate-height
          class="ssjc-item"
          :class="item.dataType !== 1 ? 'warn' : ''"
        >
          <el-image
            fit="fit"
            :src="item.pic"
            :preview-src-list="bigImageList"
            style="width: 100px; height: 100px"
          >
            <div slot="error" class="image-slot" />
          </el-image>
          <div class="ssjc-info">
            <div>{{ item.carNo }}</div>
            <div>{{ item.findDate }}</div>
            <div>{{ groupInfo.groupName }}</div>
            <div v-if="item.patrolPolice">
              {{ item.patrolPolice.policeName }} | {{ item.cavalryNo }}
            </div>
          </div>
          <div v-if="item.dataType !== 1" class="warn-info">
            {{ item.violatDesc }}
          </div>
        </div>
      </div>
    </div>

    <div v-if="!isShowTrackBox" class="week">
      <div>
        <img src="../../assets/map/icon_04.png" alt="">
        <div class="week_detail">
          <span>{{ weekInfo.patrolTimeXs }}</span>{{ weekInfo.patrolTimeUnit }}<br>骑巡时长
        </div>
      </div>
      <div>
        <img src="../../assets/map/icon_06.png" alt="">
        <div class="week_detail">
          <span>{{ weekInfo.patrolMileageXs }}</span>{{ weekInfo.patrolMileageUnit }}<br>骑巡里程
        </div>
      </div>
      <div class="week_detail">
        <img src="../../assets/map/icon_08.png" alt="">
        <div>
          <span>{{ weekInfo.alarmNumber }}</span>起<br>接处警数
        </div>
      </div>
      <div style="border: none">
        <img src="../../assets/map/icon_10.png" alt="">
        <div>
          <span>{{ weekInfo.lawEnNumber }}</span>起<br>违法处理
        </div>
      </div>
    </div>

    <!-- 选择日周月 -->
    <div class="date-select">
      <div v-for="(item,index) in searchTimeList" :key="index" :class="index === activeTimeIndex ? 'date-active' : ''" @click="handleChangeTime(index)">{{ item.name }}</div>
      <!-- <div :class="isTrafficLayerMap?'date-active':''" @click="trafficLayerMap()">路况</div>
      <div :class="isDistrict?'date-active':''" @click="toggleDistrictMap()">管界</div> -->
    </div>
    <!-- <div v-if="(listType==='2'||warnType==='2')&& isDistrict" class="date-select2">
      <el-radio-group v-model="gjRadio" style="margin:8px" @change="refreshDistrictMap('2')">
        <el-radio :label="0" style="color:white;margin-bottom:8px">行政区域</el-radio>
        <el-radio :label="1" style="color:white">大队管辖</el-radio>
      </el-radio-group>
    </div> -->

    <!-- 排行榜 -->
    <div v-if="!isShowPoliceDetail" class="rank">
      <div class="rank-title">排行榜</div>
      <div class="rank-tabs">
        <div v-for="(item, index) in rankTabList" :key="index" :class="rankActive === index ? 'rank-active' : ''" @click="rankSearch(index, item)">{{ item.name }}</div>
      </div>
      <div style="height: calc(100% - 305px);overflow: auto">
        <div v-for="(item, index) in rankList" :key="index" class="rank-list">
          <div class="rank-header">
            <div
              class="rank-idx"
              :style="index > 2 ? 'background: #707070;' : ''"
            >
              {{ index + 1 }}
            </div>
            <div class="rank-name"> {{ item.userName }}</div>
            <div class="rank-team" :title="item.pOrganName + '-'+ item.organName">{{ item.pOrganName }}-{{ item.organName }}</div>
          </div>
          <el-row class="rank-row">
            <el-col :span="6" style="text-align: center"><span class="progress-num">{{ item.patrolMileageXs }}</span>{{ item.patrolMileageUnit }}</el-col>
            <el-col :span="6" style="text-align: center"><span class="progress-num">{{ item.patrolTimeXs }}</span>{{ item.patrolTimeUnit }}</el-col>
            <el-col :span="6" style="text-align: center"><span class="progress-num">{{ item.alarmNumber | parseToInt }}</span>起</el-col>
            <el-col :span="6" style="text-align: center"><span class="progress-num">{{ item.lawEnNumber | parseToInt }}</span>起</el-col>
          </el-row>
          <el-row class="rank-row">
            <el-col :span="6" style="text-align: center;font-size: 12px">骑巡里程</el-col>
            <el-col :span="6" style="text-align: center;font-size: 12px">骑巡时长</el-col>
            <el-col :span="6" style="text-align: center;font-size: 12px">接处警数</el-col>
            <el-col :span="6" style="text-align: center;font-size: 12px">执法量</el-col>
          </el-row>
        </div>
      </div>
      <!-- <hr style="margin: 3px 8px"> -->
      <div class="rank-pie-card">
        <!-- <div class="rank-title" style="width: 95%; background-color:white; background-image: none; margin: 15px auto 0; color: #3699FF;text-align: center">
          车辆分析：<span>{{ vehicleNum }}</span>辆
        </div> -->
        <!-- <div ref="pie" class="rank-pie" style="" /> -->
        <div class="rank-pie-title">未骑行车辆预警</div>
        <PieChart ref="pie" class="rank-pie" width="300px" height="170px" />
      </div>
    </div>
  </div>
</template>

<script>
import mapUtil from '@/utils/map/mapUtil'
const iconArr = [
  require('../../assets/icons/icon_58.png'),
  require('../../assets/icons/icon_59.png'),
  require('../../assets/icons/icon_60.png'),
  require('../../assets/icons/icon_61.png'),
  require('../../assets/icons/icon_62.png')
]
// const BMap = window.BMap
/* import { getGroup, listCurrentVehicle } from '@/api/patrol'
import { cavalryList } from '@/api/cavalry' */
import {
  getOrganStat,
  getPoliceStat,
  getDeviceInc,
  getPoliceCurrStat,
  getDeviceHis,
  getByWeekTotalStat,
  getPoliecRanking,
  getAbnormalDevice,
  getDutyCountList,
  getDutyCount,
  getUnNormalChart
} from '@/api/policeReport'
import { parseTime, getMonthDays, formatSecond } from '@/utils'
const nowTime = parseTime(new Date(), '{y}-{m}-{d}')
import PieChart from '@/components/Charts/pieChart'
import { CancelToken } from 'axios'
import _ from 'lodash'

export default {
  name: 'TrafficMap',
  filters: {
    parseToInt(val) {
      if (!val) return 0
      return parseInt(val)
    }
  },
  components: {
    PieChart
  },
  data() {
    const newTime = [
      nowTime + ' 00:00:00',
      nowTime + ' 23:59:59'
    ]
    return {
      isSearch: true,
      ssjcList: [],
      currentPoint: 0,
      bigImageList: [],
      groupInfo: {
        groupName: '',
        groupCount: 0,
        onDutyCount: 0,
        backupCount: 0,
        polices: []
      },
      originalPoliceList: [], // 民警列表
      listType: '1', // 1 支队 2 大队 3 民警
      vehicle: {},
      policeSearch: '',
      organizeList: [], // 组织列表
      deviceList: [], // 地图铁骑
      organizeDetail: {},
      policeLoading: false,
      onlineUser: 0,
      countUser: 0,
      maps: null,
      markerClusterer: null,
      policeDetail: {},
      isShowPoliceDetail: false,
      isShowTrackBox: false,
      trackTime: [],
      nowTime: newTime,
      trackSpeed: 1000,
      trackSpeedList: [
        { label: '×1.0倍播放', value: 1000 },
        { label: '×2.0倍播放', value: 2000 },
        { label: '×3.0倍播放', value: 3000 },
        { label: '×4.0倍播放', value: 4000 }
      ],
      trackList: [],
      trackTimer: null,
      timer: new Date(),
      weekInfo: {
        alarmNumber: '0',
        lawEnNumber: '0',
        patrolMileage: '0',
        patrolTime: { text: '秒', time: '0' }
      },
      rankList: [],
      chart: null,
      searchTimeList: [
        { name: '今日', value: 'day' },
        { name: '本周', value: 'week' },
        { name: '本月', value: 'month' }
      ],
      activeTimeIndex: 0,
      rankTabList: [
        { name: '骑巡里程', value: 'patrolMileage' },
        { name: '骑巡时长', value: 'patrolTime' },
        { name: '接处警数', value: 'alarmNumber' },
        { name: '执法量', value: 'lawEnNumber' }
      ],
      rankActive: 0,
      rankActiveVal: 'patrolMileage',
      policeNum: 0,
      onlinePolice: 0,
      cavalryNum: 0,
      todayNumCount: 0,
      brigadeOrganCode: '',
      brigadeOrganName: '',
      squadronOrganCode: '',
      squadronOrganName: '',
      currentListPage: '', // 左侧列表当前类型
      vehicleNum: '',
      curDeviceNo: '',
      curDeviceObj: null,
      beginTime: nowTime, // 开始时间
      endTime: nowTime, // 结束时间
      pageTimer: null,
      isGeneral: true, // 侧栏是否为勤务概览
      warnType: '1',
      isWarnSearch: true,
      policeWarnSearch: '',
      policeWarnNum: 0,
      onlineCarSum: 0,
      offlineCarSum: 0,
      unNormalCarnNum: 0,
      onlineWarnPolice: 0,
      cavalryWarnNum: 0,
      policeWarnList: [],
      organizeWarnList: [],
      brigadeWarnOrganName: '',
      brigadeWarnOrganCode: '',
      squadronWarnOrganCode: '',
      squadronWarnOrganName: '',
      isWarnDetail: true,
      isTrafficLayerMap: false,
      isDistrict: false,
      districtData: null,
      gjRadio: 0,
      isOperBtns: false,
      operBtns: {
        isOnline: true,
        isOffline: false,
        isWarning: true,
        isTrafficLayerMap: false,
        isDistrict: false
      },
      cancelDeviceInc: null, // 勤务概括接口取消
      cancelAbnormalDevice: null // 预警设备接口取消
    }
  },
  computed: {
    policeList() {
      if (this.originalPoliceList.length > 0) {
        const polices = this.originalPoliceList
        const list = polices
        let newArr = []
        const keyValue = this.policeSearch
        if (keyValue) {
          list.forEach(o => {
            // if ((o.policeName + '').includes(keyValue) || (o.policeNo + '').includes(keyValue)) {
            newArr.push(o)
            // }
          })
        } else {
          newArr = polices
        }
        newArr.forEach(item => {
          item.patrolMileage = parseFloat(item.patrolMileage / 1000).toFixed(1)
        })
        return newArr
      }
      return []
    },
    times() {
      const formatTime = parseTime(this.timer, '{y}-{m}-{d} {h}:{i}:{s} {a}') || ''
      const timeArr = formatTime.split(' ')
      const timeObj = {
        time: timeArr[1],
        date: timeArr[0],
        day: `星期${timeArr[2]}`
      }
      return timeObj
    },
    carWarnList() {
      const list = this.policeWarnList.filter(o => {
        return o.flag === 1
      })
      return list || []
    },
    policeTitle() {
      return this.policeSearch || this.squadronOrganName
    },
    warnCarTitle() {
      return this.policeWarnSearch || this.squadronWarnOrganName
    }
  },
  watch: {
    listType(val) {
      this.refreshDistrictMap(val)
    },
    warnType(val) {
      this.refreshDistrictMap(val)
    }
  },
  mounted() {
    // 防止连续聚合
    this.bindMarkerCluster = _.debounce(this.bindMarkerCluster2, 100)

    this.initMap()
    this.initData()
    this.initTimer()
    // this.initChart()
    this.setTimeGetMapData()
  },
  beforeDestroy() {
    if (this.pageTimer) {
      clearInterval(this.pageTimer)
      this.pageTimer = null
    }
  },
  methods: {
    setTimeGetMapData() {
      if (this.pageTimer) {
        clearInterval(this.pageTimer)
        this.pageTimer = null
      }
      // this.refreshData()
      this.pageTimer = setInterval(this.refreshData, window.CONFIG.timer)
    },
    refreshData() {
      const that = this
      const activeTimeIndex = that.activeTimeIndex
      if (activeTimeIndex === 0) { // 今日轮询查询点位信息
        if (this.isGeneral) {
          const type = this.listType === '1' ? '' : this.listType === '2' ? '1' : '2'
          that.getPolicePoints(type)
        } else {
          const type = this.warnType
          if (type === '1') {
            this.toWarn(true)
          } else if (type === '2') {
            this.handleWarnDetachment(this.brigadeWarnOrganCode, this.brigadeWarnOrganName)
          } else if (type === '3') {
            if (this.isWarnSearch) {
              const data = {
                organName: this.squadronWarnOrganName,
                organCode: this.squadronWarnOrganCode
              }
              this.handlerWarnShowPolice(data)
            } else {
              this.searchWarnPolice()
            }
          }
          // that.getDevicePoints(type)
        }
      }
      that.handleChangeTime(activeTimeIndex, false)
    },
    initMap() {
      this.maps = mapUtil.initMap('map')
      // getDistrict().then(res => {
      //   this.districtData = res.data
      // })
      // mapUtil.trafficLayerMap(this.maps)
      // this.maps = new BMap.Map('map')
      // const point = new BMap.Point(116.417804, 39.940296)
      // this.maps.centerAndZoom(point, 13)
      // this.maps.enableScrollWheelZoom() // 启用滚轮放大缩小，默认禁用
      // this.maps.enableContinuousZoom() // 启用地图惯性拖拽，默认禁用
    },
    // 显示路况
    trafficLayerMap() {
      this.operBtns.isTrafficLayerMap = !this.operBtns.isTrafficLayerMap
      mapUtil.trafficLayerMap(this.maps, this.operBtns.isTrafficLayerMap)
    },
    // 显示管界
    toggleDistrictMap() {
      this.operBtns.isDistrict = !this.operBtns.isDistrict
      const type = this.isGeneral ? this.listType : this.warnType
      this.refreshDistrictMap(type)
    },
    toggleDevice(key) {
      this.operBtns[key] = !this.operBtns[key]
      // 有定时器的情况下 才刷新数据。定时器被关了，可能在显示轨迹页面中
      if (this.pageTimer) {
        this.refreshData()
        this.setTimeGetMapData()
      }
    },
    refreshDistrictMap(val) {
      if (this.maps && this.operBtns.isDistrict) {
        if (val === '1') {
          mapUtil.removeMapOverlay(this.maps, '行政区域')
          mapUtil.districtSearch(this.maps, '110000000000', 1)
        } else if (val === '2') {
          const organCode = this.isGeneral ? this.brigadeOrganCode : this.brigadeWarnOrganCode
          mapUtil.removeMapOverlay(this.maps, '行政区域')
          // const key = this.isGeneral ? this.brigadeOrganName : this.brigadeWarnOrganName.replace('支队', '')
          mapUtil.districtSearch(this.maps, organCode, 2, this.gjRadio)
        } else {
          const organCode = this.isGeneral ? this.squadronOrganCode : this.squadronWarnOrganCode
          mapUtil.removeMapOverlay(this.maps, '行政区域')
          mapUtil.districtSearch(this.maps, organCode, 3)
        }
      } else {
        mapUtil.removeMapOverlay(this.maps, '行政区域')
      }
    },
    // initChart(data) {
    //   const divDom = this.$refs.pie
    //   this.chart = echarts.init(divDom)
    //   this.chart.setOption({
    //     tooltip: {
    //       trigger: 'item',
    //       formatter: '{b} : {c}辆'
    //     },
    //     backgroundColor: '#fff',
    //     series: [
    //       {
    //         type: 'pie',
    //         radius: '50%',
    //         center: ['50%', '50%'],
    //         label: {
    //           formatter(params) {
    //             return (params.name ? params.data.name1 + '' + params.data.type : '') + '\n' + params.value + '辆'
    //           }
    //         },
    //         labelLine: {
    //           length: 5,
    //           length2: 15
    //         },
    //         data: data,
    //         emphasis: {
    //           itemStyle: {
    //             shadowBlur: 10,
    //             shadowOffsetX: 0,
    //             shadowColor: 'rgba(0, 0, 0, 0.5)'
    //           }
    //         }
    //       }
    //     ]
    //   }
    //   )
    // },
    initTimer() {
      const that = this
      setInterval(() => {
        that.timer = new Date()
      }, 1000)
    },
    initData() {
      // 初始化organCode
      this.brigadeOrganCode = ''
      // 顶部骑巡、接处警、违法数据
      this.getTimeTota('', '')
      // 排行榜数据
      this.getRanking('', '', 'patrolMileage')
      // 车辆分析数据
      this.getCategoryStat('')

      // 显示勤务概况
      this.toGeneral()
      // this.getDevicePoints('')
    },
    // 改变查询时间
    handleChangeTime(index, isChangeIndex = true) {
      let type = null
      let organizeType = null
      let code = null
      if (this.listType === '1') {
        code = ''
        type = ''
        organizeType = 1
      } else if (this.listType === '2') {
        code = this.brigadeOrganCode
        type = 1
        organizeType = 2
      } else {
        code = this.squadronOrganCode
        type = 2
        if (this.policeSearch) {
          this.searchPolice()
        } else {
          this.getPoliceData(code)
          // this.getorganizeData(this.squadronOrganCode, 3)
        }
      }
      if (isChangeIndex) this.activeTimeIndex = index
      if (type !== 2 && this.isGeneral) this.getorganizeData(code, organizeType)
      this.getTimeTota(code, type)
      this.getRanking(code, type, this.rankActiveVal)
    },
    // 获取左侧支队、大队数据
    getorganizeData(code, type) {
      let beginTime = nowTime
      let endTime = nowTime
      const nowNewTime = new Date()
      this.policeNum = this.policeNum || 0
      this.onlinePolice = this.onlinePolice || 0
      this.cavalryNum = 0
      this.todayNumCount = this.todayNumCount || 0
      if (this.activeTimeIndex === 1) { // 本周
        const Nowdate = nowNewTime.getDay() || 7
        const NowdataTime = nowNewTime.getTime()
        const WeekFirstDay = Nowdate === 1 ? nowNewTime : new Date(NowdataTime - (Nowdate - 1) * 86400000)
        const WeekLastDay = Nowdate === 7 ? nowNewTime : new Date((WeekFirstDay / 1000 + 6 * 86400) * 1000)
        beginTime = parseTime(WeekFirstDay, '{y}-{m}-{d}')
        endTime = parseTime(WeekLastDay, '{y}-{m}-{d}')
      } else if (this.activeTimeIndex === 2) { // 本月
        const nowMonth = nowNewTime.getMonth()
        const nowYear = nowNewTime.getFullYear()
        const monthStartDate = new Date(nowYear, nowMonth, 1)
        const days = getMonthDays(nowMonth)
        const monthEndDate = new Date(nowYear, nowMonth, days)
        beginTime = parseTime(monthStartDate, '{y}-{m}-{d}')
        endTime = parseTime(monthEndDate, '{y}-{m}-{d}')
      }
      // if (type === '2' || type === '3') {
      //   this.brigadeOrganCode = code
      // } else {
      //   this.brigadeOrganCode = ''
      // }
      beginTime = beginTime + ' 00:00:00'
      endTime = endTime + ' 23:59:59'
      const params = {
        beginTime,
        endTime,
        organCode: code,
        qType: type
      }
      let num = 0
      getOrganStat(params).then(res => {
        if (res.code === 200) {
          this.policeNum = res.data.uCount
          this.onlinePolice = res.data.oCount
          this.todayNumCount = res.data.onlineNum
          this.organizeList = res.data.list.map((o, index) => {
            const newItem = { ...o }
            newItem.countUser = o.countUser || 0
            newItem.onlineUser = o.onlineUser || 0
            newItem.percentage = newItem.countUser === 0 ? 0 : (newItem.onlineUser / newItem.countUser) * 100
            newItem.percentage = parseInt(newItem.percentage)
            // newItem.patrolTime = parseFloat(newItem.patrolTime / 60).toFixed(1)
            newItem.patrolTime = formatSecond(newItem.patrolTime)
            newItem.patrolMileage = parseFloat(newItem.patrolMileage / 1000).toFixed(1)
            this.onlineUser += newItem.onlineUser
            this.countUser += newItem.countUser
            this.cavalryNum += o.devCount
            if (num === iconArr.length) {
              num = 0
            }
            newItem.iconUrl = iconArr[num]
            num++
            return newItem
          })
        }
      })
    },
    // 获取预警车辆左侧支队、大队数据
    getDutyList(param = {}) {
      let num = 0
      getDutyCountList(param).then(res => {
        if (res.code === 200) {
          this.onlineCarSum = res.data.normalSum
          this.offlineCarSum = res.data.offlineSum
          this.cavalryWarnNum = res.data.unNormalSum
          this.organizeWarnList = res.data.dutyCountVoList.map((item, index) => {
            const newItem = { ...item }
            if (num === iconArr.length) {
              num = 0
            }
            newItem.iconUrl = iconArr[num]
            num++
            return newItem
          })
        }
      })
    },
    // 点击支队查询数据
    handleDetachment(code, type, name) {
      this.organizeList = []
      this.listType = type
      this.currentListPage = type
      this.brigadeOrganCode = code
      this.brigadeOrganName = name
      this.isShowPoliceDetail = false
      // if (this.markerClusterer) {
      //   this.markerClusterer.clearMarkers()
      //   this.markerClusterer = null
      // }
      mapUtil.clearDataCluster(this.maps)
      this.clearTrack()
      // if (this.trackTimer) {
      //   clearInterval(this.trackTimer)
      //   this.trackTimer = null
      // }
      mapUtil.removeMapOverlay(this.maps, '小车运动')
      this.isShowTrackBox = false
      this.getorganizeData(code, type)
      this.getTimeTota(code, '1')
      this.getRanking(code, '1', this.rankActiveVal)
      this.getCategoryStat('1')
      this.getPolicePoints('1')
    },
    // 点击预警支队查询数据
    handleWarnDetachment(code, name, flag = true) {
      const that = this
      const param = {
        organCode: code
      }
      that.isWarnSearch = true
      that.policeWarnSearch = ''
      that.getDutyList(param)
      that.brigadeWarnOrganName = name
      that.brigadeWarnOrganCode = code
      if (flag) that.warnType = '2'
      that.getDevicePoints('1')
    },
    // 查询警员数据
    searchPolice() {
      const that = this
      let beginTime = nowTime
      let endTime = nowTime
      const nowNewTime = new Date()
      this.listType = '3'
      this.currentListPage = '3'
      if (this.activeTimeIndex === 1) { // 本周
        const Nowdate = nowNewTime.getDay() || 7
        const NowdataTime = nowNewTime.getTime()
        const WeekFirstDay = Nowdate === 1 ? nowNewTime : new Date(NowdataTime - (Nowdate - 1) * 86400000)
        const WeekLastDay = Nowdate === 7 ? nowNewTime : new Date((WeekFirstDay / 1000 + 6 * 86400) * 1000)
        beginTime = parseTime(WeekFirstDay, '{y}-{m}-{d}')
        endTime = parseTime(WeekLastDay, '{y}-{m}-{d}')
      } else if (this.activeTimeIndex === 2) { // 本月
        const nowMonth = nowNewTime.getMonth()
        const nowYear = nowNewTime.getFullYear()
        const monthStartDate = new Date(nowYear, nowMonth, 1)
        const days = getMonthDays(nowMonth)
        const monthEndDate = new Date(nowYear, nowMonth, days)
        beginTime = parseTime(monthStartDate, '{y}-{m}-{d}')
        endTime = parseTime(monthEndDate, '{y}-{m}-{d}')
      }
      const params = {
        beginTime: beginTime + ' 00:00:00',
        endTime: endTime + ' 23:59:59',
        pageNum: 1,
        pageSize: 1000,
        userName: that.policeSearch
      }
      this.policeLoading = true
      getPoliceStat(params).then(res => {
        if (res.code === 200) {
          const data = res.data
          this.originalPoliceList = data.list.rows
        }
        this.policeLoading = false
      }).catch(_ => {
        this.policeLoading = false
      })
    },
    // 获取左侧人员数据
    getPoliceData(code) {
      let beginTime = nowTime
      let endTime = nowTime
      const nowNewTime = new Date()
      if (this.activeTimeIndex === 1) { // 本周
        const Nowdate = nowNewTime.getDay() || 7
        const NowdataTime = nowNewTime.getTime()
        const WeekFirstDay = Nowdate === 1 ? nowNewTime : new Date(NowdataTime - (Nowdate - 1) * 86400000)
        const WeekLastDay = Nowdate === 7 ? nowNewTime : new Date((WeekFirstDay / 1000 + 6 * 86400) * 1000)
        beginTime = parseTime(WeekFirstDay, '{y}-{m}-{d}')
        endTime = parseTime(WeekLastDay, '{y}-{m}-{d}')
      } else if (this.activeTimeIndex === 2) { // 本月
        const nowMonth = nowNewTime.getMonth()
        const nowYear = nowNewTime.getFullYear()
        const monthStartDate = new Date(nowYear, nowMonth, 1)
        const days = getMonthDays(nowMonth)
        const monthEndDate = new Date(nowYear, nowMonth, days)
        beginTime = parseTime(monthStartDate, '{y}-{m}-{d}')
        endTime = parseTime(monthEndDate, '{y}-{m}-{d}')
      }
      beginTime = beginTime + ' 00:00:00'
      endTime = endTime + ' 23:59:59'
      const params = {
        beginTime,
        endTime,
        organCode: code,
        pageNum: 1,
        pageSize: 1000
      }
      this.policeLoading = true
      getPoliceStat(params).then(res => {
        if (res.code === 200) {
          const data = res.data
          this.originalPoliceList = data.list.rows
          const total = data.total
          this.policeNum = total.uCount
          this.onlinePolice = total.oCount
          this.cavalryNum = total.devCount
          this.todayNumCount = total.onlineNum
        }
        this.policeLoading = false
      }).catch(_ => {
        this.policeLoading = false
      })
    },
    // 点击大队查询数据
    handlerShowPolice(organize) {
      this.organizeDetail = { ...organize }
      this.listType = '3'
      this.currentListPage = '3'
      this.isShowPoliceDetail = false
      this.squadronOrganCode = organize.organCode
      this.squadronOrganName = organize.organShortName
      // if (this.markerClusterer) {
      //   this.markerClusterer.clearMarkers()
      //   this.markerClusterer = null
      // }
      mapUtil.clearDataCluster(this.maps)
      this.clearTrack()
      // if (this.trackTimer) {
      //   clearInterval(this.trackTimer)
      //   this.trackTimer = null
      // }
      mapUtil.removeMapOverlay(this.maps, '小车运动')
      this.isShowTrackBox = false
      this.getPoliceData(organize.organCode)
      this.getTimeTota(organize.organCode, '2')
      this.getRanking(organize.organCode, '2', this.rankActiveVal)
      this.getCategoryStat('2')
      this.getPolicePoints('2')
    },
    // 获取预警车辆数据
    getAbnormal(param) {
      const that = this
      getAbnormalDevice(param).then(res => {
        if (res.code === 200) {
          const data = res.data
          that.policeWarnList = data.list
          const total = data.total
          that.onlineCarSum = total.normalSum
          that.unNormalCarnNum = total.unNormalSum
          that.offlineCarSum = total.offlineSum
          // that.policeWarnList = res.data.filter(item => {
          //   switch (item.flag) {
          //     case 0:
          //       return that.operBtns.isOnline
          //     case 1:
          //       return that.operBtns.isWarning
          //     case 2:
          //       return that.operBtns.isOffline
          //     default :
          //       return false
          //   }
          // })
          that.warnType = '3'
        }
      })
    },
    // 点击预警大队查询数据
    handlerWarnShowPolice(organize, flag = true) {
      const that = this
      const param = {
        organCode: organize.organCode,
        qType: '2'
      }
      that.isWarnDetail = true
      that.squadronWarnOrganName = organize.organName
      that.squadronWarnOrganCode = organize.organCode
      if (flag) that.getAbnormal(param)
      getDutyCount({ organCode: organize.organCode }).then(res => {
        if (res.code === 200) {
          this.policeWarnNum = res.data.deviceCount
          this.onlineWarnPolice = res.data.normalCount
          this.cavalryWarnNum = res.data.unNormalCount
        }
      })
      that.getDevicePoints('2')
    },
    // 查询预警车辆数据
    searchWarnPolice() {
      const param = {
        deviceNo: this.policeWarnSearch
      }
      this.isWarnDetail = false
      this.getAbnormal(param)
      this.getDevicePoints('')
    },
    // 点击人员显示详情
    showPoliceDetail(obj) {
      const params = {
        beginTime: nowTime + ' 00:00:00',
        endTime: nowTime + ' 23:59:59',
        policeCode: obj.policeCode,
        pageNum: 1,
        pageSize: 1000
      }
      getPoliceStat(params).then(res => {
        this.isShowPoliceDetail = true
        if (res.code === 200) {
          const list = res.data.list
          const obj = list.rows[0] || {}
          this.policeDetail = { ...obj }
          const patrolTime = this.policeDetail.patrolTime
          let patrolMileage = this.policeDetail.patrolMileage / 1000
          patrolMileage = parseFloat(patrolMileage).toFixed(1)
          this.policeDetail.patrolTime = formatSecond(patrolTime)
          this.policeDetail.patrolMileage = patrolMileage
          this.policeDetail.lastDate = res.data.total.lastDate
          this.curDeviceNo = obj.deviceNo
        }
      })
    },
    handleClosePolice() {
      let type = null
      if (this.listType === '1') {
        type = ''
      } else if (this.listType === '2') {
        type = 1
      } else if (this.listType === '3') {
        type = 2
      }
      this.isShowPoliceDetail = false
      this.isShowTrackBox = false
      this.policeDetail = {}
      this.trackList = []
      /* this.trackTime = [
        nowTime + ' 00:00:00',
        nowTime + ' 23:59:59'
      ] */
      // this.trackTime = []
      this.trackSpeed = 1000
      mapUtil.removeMapOverlay(this.maps, '小车运动')
      this.trackClose()
      // 显示地图全部点位
      this.bindMarkerCluster()
      this.getCategoryStat(type)
    },
    // 获取时长、里程、接警数、违法处理数
    getTimeTota(code, type) {
      let beginTime = nowTime
      let endTime = nowTime
      const nowNewTime = new Date()
      if (this.activeTimeIndex === 1) { // 本周
        const Nowdate = nowNewTime.getDay() || 7
        const NowdataTime = nowNewTime.getTime()
        const WeekFirstDay = Nowdate === 1 ? nowNewTime : new Date(NowdataTime - (Nowdate - 1) * 86400000)
        const WeekLastDay = Nowdate === 7 ? nowNewTime : new Date((WeekFirstDay / 1000 + 6 * 86400) * 1000)
        beginTime = parseTime(WeekFirstDay, '{y}-{m}-{d}')
        endTime = parseTime(WeekLastDay, '{y}-{m}-{d}')
      } else if (this.activeTimeIndex === 2) { // 本月
        const nowMonth = nowNewTime.getMonth()
        const nowYear = nowNewTime.getFullYear()
        const monthStartDate = new Date(nowYear, nowMonth, 1)
        const days = getMonthDays(nowMonth)
        const monthEndDate = new Date(nowYear, nowMonth, days)
        beginTime = parseTime(monthStartDate, '{y}-{m}-{d}')
        endTime = parseTime(monthEndDate, '{y}-{m}-{d}')
      }
      const param = {
        beginTime: beginTime + ' 00:00:00',
        endTime: endTime + ' 23:59:59',
        organCode: code,
        qType: type
      }
      getByWeekTotalStat(param).then(res => {
        if (res.code === 200) {
          this.weekInfo = {
            alarmNumber: res.data[0].alarmNumber,
            lawEnNumber: res.data[0].lawEnNumber,
            patrolMileage: res.data[0].patrolMileage,
            // patrolTime: res.data[0].patrolTime / 60
            patrolTime: formatSecond(res.data[0].patrolTime),
            patrolMileageUnit: res.data[0].patrolMileageUnit,
            patrolMileageXs: res.data[0].patrolMileageXs,
            patrolTimeUnit: res.data[0].patrolTimeUnit,
            patrolTimeXs: res.data[0].patrolTimeXs
          }
          // this.weekInfo.patrolTime = parseFloat(this.weekInfo.patrolTime).toFixed(1)
          this.weekInfo.patrolMileage = parseFloat(this.weekInfo.patrolMileage / 1000).toFixed(1)
        }
      })
    },
    // 获取排行榜数据
    getRanking(code, type, sort) {
      let beginTime = nowTime
      let endTime = nowTime
      const nowNewTime = new Date()
      if (this.activeTimeIndex === 1) { // 本周
        const Nowdate = nowNewTime.getDay() || 7
        const NowdataTime = nowNewTime.getTime()
        const WeekFirstDay = Nowdate === 1 ? nowNewTime : new Date(NowdataTime - (Nowdate - 1) * 86400000)
        const WeekLastDay = Nowdate === 7 ? nowNewTime : new Date((WeekFirstDay / 1000 + 6 * 86400) * 1000)
        beginTime = parseTime(WeekFirstDay, '{y}-{m}-{d}')
        endTime = parseTime(WeekLastDay, '{y}-{m}-{d}')
      } else if (this.activeTimeIndex === 2) { // 本月
        const nowMonth = nowNewTime.getMonth()
        const nowYear = nowNewTime.getFullYear()
        const monthStartDate = new Date(nowYear, nowMonth, 1)
        const days = getMonthDays(nowMonth)
        const monthEndDate = new Date(nowYear, nowMonth, days)
        beginTime = parseTime(monthStartDate, '{y}-{m}-{d}')
        endTime = parseTime(monthEndDate, '{y}-{m}-{d}')
      }
      const param = {
        beginTime: beginTime + ' 00:00:00',
        endTime: endTime + ' 23:59:59',
        organCode: code,
        pageNum: 1,
        pageSize: 10,
        qType: type,
        sort: sort
      }
      getPoliecRanking(param).then(res => {
        if (res.code === 200) {
          if (res.data.rows.length > 0 && res.data.rows.length > 5) {
            res.data.rows.splice(5)
          }
          this.rankList = res.data.rows
          this.rankList.forEach(item => {
            item.patrolMileage = parseFloat(item.patrolMileage / 1000).toFixed(1)
            // item.patrolTime = parseFloat(item.patrolTime / 60).toFixed(1)
            item.patrolTime = formatSecond(item.patrolTime)
          })
        }
      })
    },
    // 人员点位
    getPolicePoints(type) {
      let code = null
      if (type === '1') {
        code = this.brigadeOrganCode
      } else if (type === '2') {
        code = this.squadronOrganCode
      }
      const params = {
        beginTime: nowTime + ' 00:00:00',
        organCode: code || '',
        qType: this.policeSearch ? '' : type
      } // nowTime || '2021-01-11'
      // if (this.markerClusterer) {
      //   this.markerClusterer.clearMarkers()
      //   this.markerClusterer = null
      // }
      mapUtil.clearDataCluster(this.maps)
      const _this = this
      getDeviceInc(params, {
        cancelToken: new CancelToken(c => { _this.cancelDeviceInc = c })
      }).then(res => {
        if (res.code === 200) {
          _this.deviceList = res.data.filter(item => {
            switch (item.flag) {
              case 0:
                return _this.operBtns.isOnline
              case 1:
                return _this.operBtns.isWarning
              case 2:
                return _this.operBtns.isOffline
              default :
                return false
            }
          })
          _this.bindMarkerCluster()
        }
      })
    },
    // 预警地图车辆信息
    getDevicePoints(type) {
      let code = null
      if (type === '1') {
        code = this.brigadeWarnOrganCode
      } else if (type === '2') {
        code = this.squadronWarnOrganCode
      }
      const params = {
        beginTime: nowTime + ' 00:00:00',
        organCode: code || '',
        qType: type,
        deviceNo: this.policeWarnSearch
      }
      // if (this.markerClusterer) {
      //   this.markerClusterer.clearMarkers()
      //   this.markerClusterer = null
      // }
      mapUtil.clearDataCluster(this.maps)
      const that = this
      getAbnormalDevice(params, {
        cancelToken: new CancelToken(c => { that.cancelAbnormalDevice = c })
      }).then(res => {
        if (res.code === 200) {
          const data = res.data.list || []
          // this.onlineCarSum = res.data.sumVo.normalSum
          // this.offlineCarSum = res.data.sumVo.offlineSum
          // this.cavalryWarnNum = res.data.sumVo.unNormalSum
          // this.policeWarnNum = res.data.deviceSum
          // this.onlineWarnPolice = res.data.normalSum
          this.deviceList = data.filter(item => {
            switch (item.flag) {
              case 0:
                return that.operBtns.isOnline
              case 1:
                return that.operBtns.isWarning
              case 2:
                return that.operBtns.isOffline
              default :
                return false
            }
          })
          this.bindMarkerCluster()
        }
      })
    },
    bindMarkerCluster2() {
      this.markerClusterer = mapUtil.markerClustersPoint(this.maps, this.deviceList, data => {
        // console.log(data)
        if (data.flag !== 0) {
          this.curDeviceNo = data.deviceNo
          this.getTrackList(data => {
          // 获取默认时间
            const timeArr = []
            const length = data.length
            data.forEach((o, i) => {
              if (i === 0) timeArr.push(o.timeRaw)
              if (i === (length - 1)) timeArr.push(o.timeRaw)
            })
            this.trackTime = timeArr
            if (data.length) {
              // 异常，离线点击查看轨迹
              this.handleShowTrackBox()
              this.isShowPoliceDetail = false
              this.curDeviceObj = { ...data }
            }
          })
          return false
        }
        // if (data.isUse === '1') return false
        // 点击设备显示人员详情
        const params = {
          deviceNo: data.deviceNo
        }
        getPoliceCurrStat(params).then(res => {
          this.isShowPoliceDetail = true
          if (res.code === 200) {
            let obj = {}
            const data = res.data.list
            if (data && data.length) obj = data[0]
            this.policeDetail = { ...obj }
            // let patrolTime = this.policeDetail.patrolTime / 60
            let patrolMileage = this.policeDetail.patrolMileage / 1000
            // patrolTime = parseFloat(patrolTime).toFixed(1)
            patrolMileage = parseFloat(patrolMileage).toFixed(1)
            this.policeDetail.patrolTime = formatSecond(this.policeDetail.patrolTime)
            this.policeDetail.patrolMileage = patrolMileage
            this.policeDetail.lastDate = res.data.lastDate
            this.curDeviceNo = obj.deviceNo
          }
        })
      })
    },
    handleTrackTimeChange() {
      // this.getTrackList()
    },
    handleShowTrackBox() {
      this.isShowTrackBox = true
      if (this.pageTimer) {
        clearInterval(this.pageTimer)
        this.pageTimer = null
      }
      // if (this.markerClusterer) {
      //   this.markerClusterer.clearMarkers()
      //   this.markerClusterer = null
      // }
      this.getTrackList(data => {
      // 获取默认时间
        const timeArr = []
        const length = data.length
        data.forEach((o, i) => {
          if (i === 0) timeArr.push(o.timeRaw)
          if (i === (length - 1)) timeArr.push(o.timeRaw)
        })
        this.trackTime = timeArr
      })
      mapUtil.clearDataCluster(this.maps)
    },
    // 查看历史轨迹
    getTrackList(cb) {
      const that = this
      let params = {}
      if (that.cancelDeviceInc) {
        that.cancelDeviceInc()
        that.cancelDeviceInc = null
      }
      if (that.cancelAbnormalDevice) {
        that.cancelAbnormalDevice()
        that.cancelAbnormalDevice = null
      }
      if (this.trackTime) {
        params = {
          beginTime: this.trackTime[0],
          endTime: this.trackTime[1],
          deviceNo: this.curDeviceNo
        }
      } else {
        params = {
          beginTime: nowTime + ' 00:00:00',
          endTime: nowTime + ' 23:59:59',
          deviceNo: this.curDeviceNo
        }
      }
      if (this.curDeviceObj) {
        if (this.curDeviceObj.flag === 2) params.qryType = 2
        else if (this.curDeviceObj.flag === 1) params.qryType = 1
      }
      // params.deviceNo = this.policeDetail.deviceNo
      getDeviceHis(params).then(res => {
        if (res.code === 200) {
          const listData = res.data || []
          const pointArr = []
          listData.forEach(o => {
            pointArr.push({
              lng: o.longBaidu,
              lat: o.latBaidu,
              longGaode: o.longGaode,
              latGaode: o.latGaode
            })
          })
          cb && cb(listData)
          this.trackList = pointArr
          if (window.BMap) {
            if (!that.trackTimer) {
              mapUtil.removeMapOverlay(that.maps, '小车运动')
              that.trackTimer = mapUtil.trackAnimation(that.maps, that.trackList, that.trackSpeed, () => {
                that.trackTimer = null
              })
            }
          } else {
            // 高德
            mapUtil.removeMapOverlay(that.maps, '小车运动')
            that.trackTimer = mapUtil.trackAnimation(that.maps, that.trackList, that.trackSpeed)
          }
        }
      })
    },
    // 播放轨迹
    trackPlay() {
      this.getTrackList()
    },
    // 定时器播放轨迹
    clearTrack() {
      if (this.trackTimer) {
        if (typeof this.trackTimer === 'number') {
          clearInterval(this.trackTimer)
        }
        this.trackTimer = null
      }
    },
    // 取消播放
    trackCancel() {
      this.clearTrack()
      mapUtil.removeMapOverlay(this.maps, '小车运动')
    },
    // 关闭
    trackClose() {
      this.clearTrack()
      mapUtil.removeMapOverlay(this.maps, '小车运动')
      this.isShowTrackBox = false
      this.refreshData()
      this.setTimeGetMapData()
      if (this.curDeviceObj) {
        this.isShowPoliceDetail = false
      }
      // this.trackTime = this.nowTime
      this.trackTime = []
      this.curDeviceObj = null
    },
    handleBack(code, type) {
      this.listType = type
      this.organizeDetail = {}
      this.policeSearch = ''
      this.originalPoliceList = []
      this.isSearch = true

      if (type === '2') {
        this.handleDetachment(code, type, this.brigadeOrganName)
      } else {
        this.initData()
      }
      this.clearTrack()
      // if (this.trackTimer) {
      //   clearInterval(this.trackTimer)
      //   this.trackTimer = null
      // }
      mapUtil.removeMapOverlay(this.maps, '小车运动')
      this.isShowTrackBox = false
    },
    // 预警返回按钮
    handleWarnBack(type) {
      this.warnType = this.isWarnSearch ? type : '1'
      if (!this.isWarnSearch) {
        this.isWarnSearch = true
        this.policeWarnSearch = ''
      }
      if (this.warnType === '2') {
        this.getDutyList({ organCode: this.brigadeWarnOrganCode })
        this.getDevicePoints('1')
      } else if (this.warnType === '1') {
        this.getDutyList()
        this.getDevicePoints('')
      }
      this.clearTrack()
      // if (this.trackTimer) {
      //   clearInterval(this.trackTimer)
      //   this.trackTimer = null
      // }
    },
    drawTrack(vehicle) {
      const point = {
        lat: vehicle.latBaidu,
        lng: vehicle.longBaidu
      }
      // 刚开始的一个点
      if (!this.vehicle[vehicle.vehicleId]) {
        this.vehicle[vehicle.vehicleId] = {
          cavalryNo: vehicle.cavalryNo,
          points: [point]
        }
        // mapUtil.movePoint(this.maps, point, point, vehicle, 50)
      } else {
        // 多个数据 取上一个点连接
        const prePoint = this.vehicle[vehicle.vehicleId].points[this.vehicle[vehicle.vehicleId].points.length - 1]
        this.vehicle[vehicle.vehicleId].points.push(point)

        mapUtil.addTrack(this.maps, [prePoint, point], '警车轨迹')
        // mapUtil.movePoint(this.maps, prePoint, point, vehicle, 50)
      }
    },
    // 排行榜切换查询
    rankSearch(index, item) {
      const that = this
      let page = null
      let code = null
      if (this.listType === '1') {
        page = ''
        code = this.brigadeOrganCode
      } else if (this.listType === '2') {
        page = 1
        code = this.brigadeOrganCode
      } else {
        page = 2
        code = this.squadronOrganCode
      }
      that.rankActive = index
      that.rankActiveVal = item.value
      this.getRanking(code, page, item.value)
    },
    // 获取车辆分析数据
    getCategoryStat(type) {
      // const chartData = []
      // const sum = 0
      let code = null
      if (this.listType === '1' || this.listType === '2') {
        code = this.brigadeOrganCode
      } else if (this.listType === '3') {
        code = this.squadronOrganCode
      }
      const param = {
        organCode: code,
        qType: type
      }
      // getCategoryStat(param).then(res => {
      //   if (res.code === 200) {
      //     res.data.forEach(item => {
      //       sum += parseInt(item.count)
      //       chartData.push({
      //         name: item.categoryType + '-' + item.categoryName,
      //         name1: item.categoryType,
      //         type: item.categoryName,
      //         value: item.count
      //       })
      //     })
      //     this.vehicleNum = sum
      //     // this.initChart(chartData)
      //   }
      // })
      getUnNormalChart(param).then(res => {
        if (res.code === 200) {
          // console.info(res)
          this.$nextTick(() => {
            this.$refs.pie.updateChart(res.data)
          })
        }
      })
    },
    // 显示预警车辆
    toWarn(openDetail = false) {
      this.isGeneral = false
      if (this.isShowPoliceDetail) { // 关闭查看民警详情
        // if (!openDetail)
        this.setTimeGetMapData()
        this.isShowPoliceDetail = false
      }
      if (this.isShowTrackBox) { // 关闭当前为查看轨迹播放
        this.clearTrack()
        mapUtil.removeMapOverlay(this.maps, '小车运动')
        this.isShowTrackBox = false
      }
      // 预警设备点位
      this.getDevicePoints('')
      // 预警支队列表
      this.getDutyList()
    },
    // 显示勤务概况
    toGeneral() {
      this.isGeneral = true
      if (this.isShowTrackBox) { // 关闭当前为查看轨迹播放
        this.clearTrack()
        mapUtil.removeMapOverlay(this.maps, '小车运动')
        this.isShowTrackBox = false
        this.setTimeGetMapData()
        if (this.isShowPoliceDetail) {
          this.isShowPoliceDetail = false
        }
      }
      // 人员点位
      this.getPolicePoints('')
      // 区域数据
      this.getorganizeData('', '1')
    }
  }
}
</script>

<style lang="stylus" scoped>
.page-container {
  width: 100%;
  height: calc(100vh - 106px);
  position: relative;
  .red-color  {
    color rgb(255,0,0)!important
  }
  .yellow-color  {
    color rgb(255,127,80)!important
  }
  #map {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 5;
  }
  .progress-num{
    font-size: 16px;
    color: #3274e1;
  }
  .progress-font{
    font-size: 12px
  }
  .police-container {
    width 310px
    position: absolute;
    left: 16px;
    background: rgba(255, 255, 255, 0.5);
    z-index: 10;
    top: 60px;
    box-shadow: 0 0 10px #133791;
  }

  .police-list {
    padding: 4px 10px;
    height: calc(100vh - 230px);
    overflow-y: auto;
    width: 100%;
    .police_detail {
      width 100%
      text-align center
      overflow: hidden;
      dl {
        width 80px
        display inline-block
        background-color white
        margin 10px 5px
        dt{
          width: 100%;
          height 60px
          color #3699FF
          text-align center
          line-height 60px
          span {
            font-size 22px
          }
        }
        dd {
          width 100%
          height 26px
          color white
          background-color #3699FF
          text-align center
          line-height 26px
          margin 0
        }
      }
    }
    .police-item {
      background-color: rgba(255, 255, 255, 0.8);
      display: flex;
      font-size: 16px;
      align-items: center;
      color: #333333;
      // border-top 10px solid #50bcff
      box-shadow: 0 0 4px rgba(0, 0, 0, 0.4);
      margin-bottom: 5px;
      cursor: pointer;

      &.backup {
        border-top-color: #f7931e;
      }

      .police-info {
        padding: 6px 0;
        display: flex;
        flex-direction: column;
        height: 120px;
        justify-content: space-between;

        > div {
          flex: 1;
          display: flex;
          align-items: center;
          margin-bottom 5px
          > div {
            width: 90px;
          }
        }
        .plate_num {
          width 78px
          display inline-block
          font-size 14px
        }
        .brand {
          width: 60px;
          height: 24px;
          line-height: 24px;
          text-align: center;
          font-size: 14px;
          margin-right: 27px;
        }
        .brand.el-tag--dark.el-tag--warning{
          background #FBAF5D
          border-color #FBAF5D
        }
        .brand.el-tag--dark{
          background-color #3CB878
          border-color #3CB878
        }
      }

      .avatar {
        width: 90px;
        height: 95px;
        object-fit: contain;
        margin: 8px;
      }
    }
    .deviceNo_box {
      width 100%
      display block
      font-size 20px
      color #3274E1
      padding 10px 0 0 10px
    }
    .abnormal_box {
      width 100%
      display block
      padding 10px 0 10px 10px
      font-size 14px
      color #666
    }
  }

  .ssjc {
    position: absolute;
    z-index: 15;
    right: 16px;
    top: 60px;
    width: 325px;
    box-shadow: 0 0 10px #133791;
    background-color: rgba(255, 255, 255, 0.5);

    .ssjc-title {
      color: white;
      height: 40px;
      line-height: 40px;
      font-weight: bold;
      font-size: 18px;
      background-color: rgba(54, 153, 255, 0.8)
      overflow hidden
      text-overflow ellipsis
      white-space nowrap
      padding-right 40px
      position relative
      .el-icon-search {
        width 40px
        height 40px
        line-height: 40px;
        float right
        cursor pointer
        text-align center
        background-color #3699FF
        font-size 16px
        &.input-search {
          width: 30px;
          height: 30px;
          background-color: rgba(54, 153, 255, 0.3)
          border-radius: 0px 4px 4px 0px;
        }
      }
      .el-icon-back {
        width 40px
        height 40px
        line-height: 40px;
        float left
        cursor pointer
        text-align center
        background-color #3699FF
        margin-right 10px
      }
      .icon_tab{
        width 40px
        height 40px
        display inline-block
        background-color white
        cursor pointer
        position: absolute;
        right 0
        top 0
      }
      .icon_tab:before{
        content ''
        width 20px
        height 20px
        display inline-block
        background-repeat no-repeat
        background-size contain
        position: absolute;
        left 50%
        top 50%
        transform translate(-50%,-50%)
      }
      .icon_tab.general_icon:before{
        background-image url("../../assets/map/icon_75.png")
      }
      .icon_tab.warn_icon:before{
        width 24px
        height 25px
        background-image url("../../assets/map/icon_76.png")
      }
    }

    .ssjc-title.warn-title {
      background-color rgba(255,0,0,0.4)
      .el-icon-search,.el-icon-back{
        background-color rgba(255,0,0,0.5)
      }
    }
    .ssjc-list {
      overflow-y: auto;
      font-size: 14px;
      color: #333333;
      height: calc(100vh - 230px)
      background: rgba(255, 255, 255, 0.3);
      .police_detail {
        width 100%
        text-align center
        overflow: hidden;
        dl {
          width 90px
          display inline-block
          background-color white
          margin 10px 5px
          dt{
            width: 100%;
            height 60px
            color #3699FF
            text-align center
            line-height 60px
            span {
              font-size 22px
            }
          }
          dd {
            width 100%
            height 26px
            color white
            background-color #3699FF
            text-align center
            line-height 26px
            font-size 14px
            margin 0
          }
        }
      }
    }

    ::-webkit-scrollbar {
      display: none;
    }
  }

  .police-title {
    width: 100%;
    color: rgb(50, 116, 225);
    position: relative;

    > div:first-child {
      color: white;
      background-color: rgba(54,153,255,0.8);
      height: 40px;
      line-height: 40px;
      font-weight: bold;
      font-size: 18px;
      text-shadow: 0 0 5px #133793;
      padding-left 50px
      overflow hidden
      text-overflow ellipsis
      white-space nowrap

    }
    .el-icon-back {
      width 40px
      height 40px
      line-height: 40px;
      float left
      cursor pointer
      text-align center
      background-color #3699FF
      position: absolute;
      color: white;
      left: 0;
      top: 0px;
    }
  }

  .police-container.warn-container{
    .police-title.warn-title > div:first-child {
      background-color rgba(255, 0, 0, 0.4)
    }
    .el-icon-back {
      background-color rgba(255, 0, 0, 0.7)!important
    }
  }
  .police-search {
    width 210px
    margin: 5px 9px 5px 5px
    height 30px
    float left
  }

  .progress-line {
    margin: 10px auto;
    width: 310px;
    position: relative;
    cursor: pointer;
    background: white;
    padding: 10px 0px;
    box-shadow: 0px 0px 5px #908d8d;
    border-radius: 5px;
    .progress-text {
      position: absolute;
      top: 50%;
      left: 10px;
      transform: translateY(-50%);
      z-index: 9;
    }
    .textCount{
      color #000
      display:flex;
      width:100%
      font-size 16px
      margin 10px 10px
    }
    .textTile{
      color #3274e1
      font-size 24px
      margin 0 10px 12px
      padding-left 34px
      position relative
      .title_icon {
        position absolute
        top 0
        left 0
      }
    }
    .progress-count {
      position: absolute;
      top: 50%;
      right: 10px;
      transform: translateY(-50%);
      z-index: 9;
    }
  }

  .police-detail {
    position: absolute;
    z-index: 15;
    right: 16px;
    top: 10px;
    width: 290px;
    box-shadow: 0 0 10px #133791;
    background: rgba(255, 255, 255, 0.5);
    .detail_title {
      width 100%
      height 40px
      line-height 40px
      background-color #549fec
      color white
      font-size 16px
      padding-left 20px
      margin 0
      position: relative;
      .p-close {
        width 40px
        height 40px
        display inline-block
        text-align center
        line-height 40px
        background-color #3699FF
        float: right;
        cursor: pointer;
        font-size: 20px;
      }

    }

    .police-img {
      width: 100%;
      object-fit: contain;
      height: 200px;
    }

    .police-statistics {
      display: flex;
      flex-wrap: wrap;

      > div {
        width: 50%;
        font-size: 12px;
        color: #3274e1;
        padding: 5px 0;
        line-height: 20px;
      }
    }

    .police-message {
      font-size: 15px;
      height: 28px;
      line-height: 28px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;

      .name {
        color: #3274e1;
        font-size: 18px;
      }
    }
    .ckgj{
      width 100%
      height 40px
      border 2px solid #FBAF5D
      text-align center
      line-height 40px
      font-size 14px
      color #FBAF5D
      background-color white
      position: absolute;
      left: 0;
      bottom: 0;
      padding: 0;
      opacity 0.8
      i{
        width 20px
        height 19px
        display inline-block
        background-image url("../../assets/icons/track_icon.png")
        background-repeat no-repeat
        background-size contain
        position: absolute;
        top 50%
        left 35%
        transform translate(-50%,-50%)
      }
    }
  }

  .track-search-box {
    position: absolute;
    top: 10px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 10;
  }

  .week {
    width: 840px;
    height: 70px;
    background-color: rgba(255, 255, 255, 0.8);
    box-shadow: 0 0 3px #133791ab;
    position: absolute;
    top: 10px;
    left: 58%;
    transform: translateX(-50%);
    z-index: 11;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #000;
    font-size 14px

    > div {
      flex: 1;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
      border-right 1px solid #999

      img {
        width: 50px;
        margin-right: 16px;
      }

      span {
        color: #3699ff;
        font-size: 28px;
        margin-right: 6px;
      }
    }
  }

  .dateTime {
    position: absolute;
    left: 16px;
    top: 0;
    width: 307px;
    background-image: url('../../assets/map/time-bg.png');
    z-index: 11;

    .content {
      width: 100%
      height: 50px;
      line-height: 50px;
      text-shadow: 0 0 5px #133793;
      color: white;

      .time {
        position: relative;
        padding: 0 12px;
        float: left;
        font-size: 30px;
        text-align: center;
        font-family: PingFang SC;
        font-weight: 600;
      }

      .date {
        width: 110px;
        float: left;
        margin: 0;
        padding: 5px 0 5px 10px;
        letter-spacing: 0px;
        text-align: left;
        font-size: 16px;
        font-family: PingFang SC;
        font-weight: 400;
        color: #FFFFFF;
        line-height: 20px;
      }
    }
  }

  .date-select {
    position: absolute;
    z-index: 15;
    left: 346px;
    top: 7px;
    width: 220px;
    display: flex;

    >div {
      background-color: rgba(70, 70, 70, 0.8);
      color: white;
      width: 60px;
      height: 34px;
      line-height: 34px;
      text-align: center;
      font-size: 14px;
      cursor: pointer;
      border-right 1px solid #464646
      border-left 1px solid #464646
      box-sizing border-box
    }

    .date-active {
      background-color rgba(54, 153, 255, 0.8)
    }

    >div:first-child {
      border-top-left-radius: 4px;
      border-bottom-left-radius: 4px;
      border none
    }

    >div:last-child {
      border-top-right-radius: 4px;
      border-bottom-right-radius: 4px;
      border none
    }
  }
  .date-select2 {
    position: absolute;
    z-index: 15;
    left: 50px;
    bottom: 86px;
    width: 110px;
    border-radius: 4px;
    background-color: rgba(70, 70, 70, 0.8);
  }
  .rank {
    position: absolute;
    z-index: 15;
    right: 15px;
    top: 50px;
    width: 320px;
    height 93%
    box-shadow: 0 0 10px #133791;
    background: rgba(255, 255, 255, 0.5);
    padding-bottom: 20px;
    .rank-title {
      width 100%
      color: #3274e1;
      font-size: 18px;
      font-weight: 700;
      color white
      height: 33px;
      line-height: 33px;
      text-align center
      background-image url("../../assets/map/title_bg.png")
      background-repeat no-repeat
      background-size 100%
      padding: 0 8px;
    }
    .rank-pie-card{
      color: #3274e1;
      font-size: 18px;
      height: 220px;
      margin: 8px
      border: 1px solid #d2d2d2
      border-radius: 4px;
      box-shadow: 0 0 10px #ccc;
      background: rgba(252, 252, 252,0.8);

        .rank-pie-title {
          text-align center
          border-bottom: 1px solid #d2d2d2
          height: 38px
          line-height: 38px
        }
    }

    .rank-tabs {

      display: flex;
      width: 95%;
      height: 36px;
      line-height: 30px;
      font-size: 16px;
      background: white;
      margin: 10px auto;
      border-radius: 0px 4px 4px 0px;
      border: 1px solid #ccc;

      >div {
        flex: 1;
        text-align: center;
        color: #666;
        padding: 3px 0;
        font-size: 14px;
        cursor: pointer;
      }

      .rank-active {
        background: #3699FF;
        color: white;
      }
    }

    .rank-list {
      width: 95%;
      margin: 5px auto;
      background: white;
      border-radius: 5px;
      box-shadow: 0 0 10px #ccc;
      padding: 15px 5px;
      .rank-header {
        display: flex;
        margin-bottom: 12px;

        .rank-idx {
          width: 22px;
          height: 22px;
          background: #f8932e;
          color: #fff;
          text-align: center;
          line-height: 22px;
          font-size: 16px;
          font-weight: 700;
          margin-right: 5px;
        }

        .rank-name {
          font-weight: 700;
          font-size: 20px;
          color: #3699FF;
          margin-right: 20px;
        }

        .rank-team {
          flex: 1;
          text-align: left;
          color: #333333;
          line-height: 30px;
          font-size: 14px;
          white-space:nowrap; /*文本不换行*/
          text-overflow:ellipsis;/*设置超出部分显示...*/
          -o-text-overflow:ellipsis;
          overflow: hidden;

        }
      }

      .rank-row {
        font-size: 12px;
        margin: 5px 0;
      }
    }

    .rank-pie {
      width: 300px;
      margin: 5px 8px;
    }
  }
}
</style>
<style lang="stylus">
.page-container {
  .progress-line {
    .el-progress-bar__outer {
      border-radius: 0;

      .el-progress-bar__inner {
        border-radius: 0;
      }
    }
  }

  .police-search {
    $fontColor = white
    $fontSize = 14px
    .el-input__inner {
      display block
      background-color rgba(255,255,255,0.2)
      height 30px
      line-height 30px
      padding-right 60px
      border none
      color $fontColor
      &::-webkit-input-placeholder {
        color $fontColor
        font-size $fontSize
      }
      &::-moz-input-placeholder {
        color $fontColor
        font-size $fontSize
      }
      &::-ms-input-placeholder {
        color $fontColor
        font-size $fontSize
      }
    }
    .el-input__suffix {
      right 0
      .el-input__suffix-inner {
        .el-input__icon {
          color $fontColor
          line-height 30px
        }
        .el-input__clear {
          float right
        }
      }
    }
  }
  .ssjc-item {
    overflow: hidden;
    font-size: 13px;
    display: flex;
    align-items: center;
    position: relative;
    height: 120px;
    padding: 10px 8px;
    background: #fefefe;
    box-shadow: 0 2px 8px 0 rgba(19, 55, 145, 0.2);
    background-color: rgba(255, 255, 255, 0.8);

    .el-icon-circle-close {
      color: white;
    }

    >img {
      width: 120px;
      height: 100px;
      margin-right: 8px;
      object-fit: cover;
    }

    .ssjc-info {
      margin-left: 8px;

      > div {
        height: 22px;
        line-height: 22px;
        font-size: 14px;
        color: #000;
      }

      > div:first-child {
        font-size: 20px;
        color: #1a67d3;
        font-weight: bold;
      }
    }

    .warn-info {
      position: absolute;
      left: 0;
      top: 0;
      background: red;
      color: white;
      padding: 2px 4px;
      font-size: 12px;
    }
  }

  .ssjc-item.warn {
    border: 2px solid #fb2f30;
    padding: 8px 6px;

    .ssjc-info {
      margin-top: 8px;

      > div {
        &:first-child {
          color: #ed1c24;
        }
      }
    }
  }

.oper-btns {
    position: absolute;
    left: 350px;
    bottom: 22px;
    z-index: 9;
    .oper-all{
      >div{
        border: 1px solid #1890ff;
        border-radius: 3px;
        width: 40px;
        height: 40px;
        background:  white;
        color:#1890ff;
        text-align center
        line-height 40px
        font-size 14px
        margin-bottom 8px
        cursor: pointer;
      }
      .oper-active{
        color:white;
        background:#1890ff;
      }
    }
    .oper {
      border: 1px solid #1890ff;
      border-radius: 3px;
      width: 40px;
      height: 40px;
      background:  white;
      cursor: pointer;
      .img1 {
        margin: 6px;
        width: 28px;
        height: 28px;
      }
      .img2 {
        margin: 8px;
        width: 24px;
        height: 24px;
      }
    }
  }
  .map-info {
    background-color: rgba(0, 0, 0, 0.5);
    color: white;
    font-size: 14px;
    padding: 3px;
    text-align: center;
    // margin-left 160px
    width: 100px;
    &.map-warning {
      background-color: rgba(214, 0, 0, 0.5);
      > div:first-child {
        background-image: url('~@/assets/map/icon_266.png');
      }

      > div:last-child {
        background-image: url('~@/assets/map/icon_344.png');
      }
    }
    &.map-gray {
      background-color: rgba(128, 128, 128, 0.5);
      > div:first-child {
        background-image: url('~@/assets/map/icon_48.png');
      }

      > div:last-child {
        background-image: url('~@/assets/map/icon_50.png');
      }
    }
    > div:first-child {
      background-image: url('../../assets/map/icon_26.png');
      background-size 100% 100%
      background-repeat no-repeat
      padding-left: 18px;
      margin-bottom: 2px;
      height: 20px;
      line-height: 20px;
    }

    > div:last-child {
      background-image: url('../../assets/map/icon_34.png');
      background-size 100% 100%
      background-repeat no-repeat
      padding-left: 18px;
      height: 20px;
      line-height: 20px;
    }
  }

  .infoBox > img {
    display: none;
  }

  ::-webkit-scrollbar {
    display: none;
  }
}
.imap-label {
  background: transparent;
  border: none;
}
</style>
