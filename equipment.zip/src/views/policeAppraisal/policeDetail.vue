<template>
  <div class="policeDetail-container">
    <div class="policeDetail-box">
      <el-scrollbar class="page-scroll">
        <div class="archive-box">
          <h1 class="archive-title"><span class="icon-box"><i class="png-icon icon-1" /></span><span class="title">概要信息</span>
            <el-date-picker
              v-model="timeRange"
              style="float:right;margin: 5px 20px 0 0;width: 330px"
              type="datetimerange"
              size="mini"
              align="right"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              value-format="yyyy-MM-dd HH:mm:ss"
              @change="hanlderTimeRangeChange"
            />
          </h1>
          <div class="info-container">
            <div class="police-info">
              <el-image
                fit="fit"
                class="dashBox"
                :src="policeDetail.img"
              >
                <div slot="error" class="image-slot" />
              </el-image>
              <div class="police-text">
                <p class="textTitle"><span>{{ policeDetail.userName }}</span> {{ policeCode }}</p>
                <p class="organization-text"><span>所属支队：{{ policeDetail.pOrganName }}</span><span>所属大队：{{ policeDetail.organName }}</span></p>
              </div>
            </div>
            <ul class="count-container">
              <li>
                <p><span>{{ policeDetail.executeCount }}</span>次</p>
                <p>累计执勤次数</p>
              </li>
              <li>
                <p><span>{{ policeDetail.exTime }}</span>{{ policeDetail.exTimeText }}</p>
                <p>累计执勤时长</p>
              </li>
              <li>
                <p><span>{{ policeDetail.pTime }}</span>{{ policeDetail.pTimeText }}</p>
                <p>累计骑巡时长</p>
              </li>
              <li>
                <p><span>{{ policeDetail.patrolMileageXs }}</span>{{ policeDetail.patrolMileageUnit }}</p>
                <p>累计骑巡里程</p>
              </li>
              <li>
                <p><span>{{ policeDetail.alarmNumber || 0 }}</span>起</p>
                <p>累计接处警数</p>
              </li>
              <li>
                <p><span>{{ policeDetail.lawEnNumber || 0 }}</span>起</p>
                <p>累计执法量</p>
              </li>
            </ul>
          </div>
        </div>
        <div class="archive-box">
          <h1 class="archive-title"><span class="icon-box"><i class="png-icon icon-2" /></span><span class="title">执勤记录</span></h1>
          <div class="archive-table">
            <el-table
              :data="dutyTable"
              class="custom-table"
              max-height="480"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <!-- <el-table-column align="center" type="index" label="序号" width="50" /> -->
              <el-table-column width="100" label="序号" align="center">
                <template slot-scope="scope">
                  {{ scope.$index + 1 + dutyTablePagination.pageSize * (dutyTablePagination.curPage - 1) }}
                </template>
              </el-table-column>
              <!-- <el-table-column align="center" prop="currDate" label="日期" /> -->
              <el-table-column align="center" prop="deviceNo" label="执勤车辆" />
              <el-table-column prop="mixtime" align="center" label="开始时间" />
              <el-table-column prop="maxtime" align="center" label="结束时间" />
              <!-- <el-table-column prop="executeCount" align="center" label="执勤次数(次)" /> -->
              <el-table-column align="center" label="执勤时长（小时）">
                <template slot-scope="scope">
                  {{ scope.row.exTime }}
                  <!-- {{ scope.row.exTimeText }} -->
                </template>
              </el-table-column>
              <el-table-column align="center" label="骑巡时长（小时）">
                <template slot-scope="scope">
                  {{ scope.row.pTime }}
                  <!-- {{ scope.row.pTimeText }} -->
                </template>
              </el-table-column>
              <el-table-column align="center" prop="sumPatrolMileage" label="骑巡里程(KM)">
                <template slot-scope="scope">
                  {{ formatMetre(scope.row.sumPatrolMileage) }}
                </template>
              </el-table-column>
              <el-table-column prop="sumAlarmNumber" align="center" label="接处警数(起)" />
              <el-table-column prop="sumLawEnNumber" align="center" label="执法量(起)" />
              <el-table-column align="center" label="轨迹回放">
                <template slot-scope="scope">
                  <i v-if="scope.row.mixtime && scope.row.maxtime" class="address-icon" @click="handleDetail(scope.row, 'isMap')" />
                </template>
              </el-table-column>
            </el-table>
            <el-pagination
              v-if="dutyTablePagination.total"
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="dutyTablePagination.pageSize"
              :total="dutyTablePagination.total"
              :current-page.sync="dutyTablePagination.curPage"
              :page-sizes="pageSizes"
              layout="total, prev, pager, next, sizes,jumper"
              @size-change="(val) => pageSizeChange('isDuty', val)"
              @current-change="(val) => tableCurPageChang('isDuty', val)"
            />
          </div>
        </div>
        <div class="archive-box">
          <h1 class="archive-title"><span class="icon-box"><i class="png-icon icon-3" /></span><span class="title">接处警记录</span></h1>
          <div class="archive-table">
            <el-table
              :data="alarmTable"
              class="custom-table"
              max-height="480"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <!-- <el-table-column type="index" width="50" label="序号" align="center" /> -->
              <el-table-column width="100" label="序号" align="center">
                <template slot-scope="scope">
                  {{ scope.$index + 1 + alarmTablePagination.pageSize * (alarmTablePagination.curPage - 1) }}
                </template>
              </el-table-column>
              <el-table-column align="center" prop="incNo" label="警情编号" />
              <el-table-column align="center" prop="incSubType" label="警情类型" />
              <el-table-column align="center" prop="alarmAddress" label="警情地址" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="content" label="警情信息" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="dispatchTime" label="派警时间" />
              <el-table-column prop="arrivedTime" align="center" label="到达现场时间" />
            </el-table>
            <el-pagination
              v-if="alarmTablePagination.total"
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="alarmTablePagination.pageSize"
              :total="alarmTablePagination.total"
              :current-page.sync="alarmTablePagination.curPage"
              :page-sizes="pageSizes"
              layout="total,prev, pager, next, sizes, jumper"
              @size-change="(val) => pageSizeChange('isAlarm', val)"
              @current-change="(val) => tableCurPageChang('isAlarm', val)"
            />
          </div>
        </div>
        <div class="archive-box">
          <h1 class="archive-title"><span class="icon-box"><i class="png-icon icon-4" /></span><span class="title">执法记录</span></h1>
          <div class="archive-table">
            <el-table
              :data="enforcementTable"
              class="custom-table"
              max-height="480"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <!-- <el-table-column type="index" width="50" label="序号" align="center" /> -->
              <el-table-column width="100" label="序号" align="center">
                <template slot-scope="scope">
                  {{ scope.$index + 1 + enforcementTablePagination.pageSize * (enforcementTablePagination.curPage - 1) }}
                </template>
              </el-table-column>
              <el-table-column align="center" prop="violationCode" label="违法记录编号" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="violationActDesc" label="违法行为" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="carNo" label="车牌号码" :show-overflow-tooltip="true" />
              <el-table-column align="center" label="违法人" :show-overflow-tooltip="true">
                <template>
                  无
                </template>
              </el-table-column>
              <el-table-column align="center" prop="illegalTime" label="违法时间" :show-overflow-tooltip="true" />
              <el-table-column prop="inputTime" align="center" label="录入时间" :show-overflow-tooltip="true" />
            </el-table>
            <el-pagination
              v-if="enforcementTablePagination.total"
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="enforcementTablePagination.pageSize"
              :total="enforcementTablePagination.total"
              :current-page.sync="enforcementTablePagination.curPage"
              :page-sizes="pageSizes"
              layout="total,prev, pager, next, sizes, jumper"
              @size-change="(val) => pageSizeChange('isEnforcement', val)"
              @current-change="(val) => tableCurPageChang('isEnforcement', val)"
            />
          </div>
        </div>
      </el-scrollbar>
    </div>
    <!-- 弹层 -->
    <el-dialog top="80px" width="1222px" custom-class="custom-dialog" :title="detailTitle" :visible.sync="detailDialog" :close-on-click-modal="false" :colse-on-press-escape="false" @close="closeDetail">
      <!-- 轨迹回放 -->
      <div style="margin-bottom: 10px;height:40px">
        <el-col :span="6">
          <i class="fontcolor-r">*&nbsp;</i>播放倍数：
          <el-select v-model="formData.speedSelect" placeholder="">
            <el-option label="正常速度" value="1000" />
            <el-option label="x2倍" value="2000" />
            <el-option label="x3倍" value="3000" />
            <el-option label="x4倍" value="4000" />
          </el-select>
        </el-col>
        <el-col :span="2">
          <el-button type="primary search" size="mini" @click="handleTrack"><i class="image-icon search" />播放</el-button>
        </el-col>
      </div>
      <div v-if="detailDialog" id="policeDetailMap" />
    </el-dialog>
  </div>
</template>

<script>
import { getIncByPolice, getPoliceExecuteStat, getViolationByPolice, getPoliceOrganInfo, getPoliceExecuteSUM } from '@/api/policeReport'
import mapUtil from '@/utils/map/mapUtil'
import { getDeviceHis } from '@/api/policeReport'
import { formatSecond } from '@/utils'
// import { mapState } from 'vuex'
// 因为BMap是挂在window对象上的，防止报错要加上window
// const BMap = window.BMap
const policeDetail = {
  alarmNumber: 0,
  patrolMileage: 0,
  patrolTime: 0,
  lawEnNumber: 0,
  executeCount: 0,
  executeinute: 0
}
export default {
  name: 'PoliceDetail',
  data() {
    return {
      timeRange: [],
      pickerOptions: {
        shortcuts: [
          {
            text: '本周',
            onClick(picker) {
              const Nowdate = new Date().getDay() || 7
              const NowdataTime = new Date().getTime()
              const WeekFirstDay = Nowdate === 1 ? new Date() : new Date(NowdataTime - (Nowdate - 1) * 86400000)
              const WeekLastDay = Nowdate === 7 ? new Date() : new Date((WeekFirstDay / 1000 + 6 * 86400) * 1000)
              picker.$emit('pick', [WeekFirstDay, WeekLastDay])
            }
          },
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近60天',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 60)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近90天',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }]
      },
      formData: {
        beginTime: '',
        endTime: '',
        speedSelect: '1000',
        vehicleNo: ''
      },
      infoData: {},
      detailInfo: {},
      moveSpeed: 200,
      deviceId: '',
      useHistoryPagination: {
        curPage: 1,
        pageSize: 10,
        total: 10
      },
      maps: '',
      policeCode: '',
      detailTitle: '',
      detailDialog: false,
      pageSizes: [5, 10, 15, 20],
      alarmTable: [],
      alarmTablePagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      dutyTable: [],
      dutyTablePagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      enforcementTable: [],
      enforcementTablePagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      insureTable: [],
      insurePagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      outInsureTable: [],
      outInsurePagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      policeDetail: policeDetail
    }
  },
  mounted() {
    // this.initSwiper()

    this.initPage()
  },
  methods: {
    /**
     * 使用记录分页
     */
    pageSizeChange(type, val) {
      const _this = this
      if (type === 'isDuty') {
        _this.dutyTablePagination.pageSize = val
        this.getExecuteStatList()
      } else if (type === 'isAlarm') {
        _this.alarmTablePagination.pageSize = val
        this.getIncList()
      } else if (type === 'isEnforcement') {
        _this.enforcementTablePagination.pageSize = val
        this.getViolationList()
      }
    },
    /**
     * 使用记录分页跳转
     */
    tableCurPageChang(type, val) {
      if (type === 'isDuty') {
        this.dutyTablePagination.curPage = val
        this.getExecuteStatList()
      } else if (type === 'isAlarm') {
        this.alarmTablePagination.curPage = val
        this.getIncList()
      } else if (type === 'isEnforcement') {
        this.enforcementTablePagination.curPage = val
        this.getViolationList()
      }
    },
    initMap() {
      const _this = this
      _this.maps = mapUtil.initMap('policeDetailMap')
      // const BMap = window.BMap
      // _this.maps = new BMap.Map('policeDetailMap')
      // const point = new BMap.Point(116.417804, 39.940296)
      // _this.maps.centerAndZoom(point, 12)
      // const marker = new BMap.Marker(point)
      // marker.disableDragging()
      // _this.maps.enableScrollWheelZoom() // 启用滚轮放大缩小，默认禁用
      // _this.maps.enableContinuousZoom() // 启用地图惯性拖拽，默认禁用
    },
    initPage() {
      const params = this.$route.params
      this.policeCode = params.id
      const timeRange = params.timeRange.split(';')
      this.timeRange = timeRange
      this.getPoliceDetail()
      this.getExecuteStatList()
      this.getIncList()
      this.getViolationList()
      this.getExecuteSum()
    },
    getExecuteSum() {
      const params = {
        beginTime: '',
        endTime: '',
        policeCode: this.policeCode
      }
      if (this.timeRange) {
        params.beginTime = this.timeRange[0] // + ' 00:00:00'
        params.endTime = this.timeRange[1] // + ' 23:59:59'
      }
      getPoliceExecuteSUM(params).then(res => {
        if (res.code === 200) {
          const { sumLawEnNumber, sumAlarmNumber, sumPatrolTime, executeinute, executeCount, sumPatrolMileage } = res.data
          this.policeDetail.alarmNumber = sumAlarmNumber
          this.policeDetail.patrolMileage = sumPatrolMileage
          this.policeDetail.patrolMileageXs = res.data.patrolMileageXs
          this.policeDetail.patrolMileageUnit = res.data.patrolMileageUnit
          this.policeDetail.patrolTime = sumPatrolTime
          this.policeDetail.lawEnNumber = sumLawEnNumber
          this.policeDetail.executeCount = executeCount
          this.policeDetail.executeinute = executeinute
          // const exTimeObj = formatSecond(executeinute, true)
          this.policeDetail.exTime = res.data.executeinuteXs
          this.policeDetail.exTimeText = res.data.executeinuteUnit
          // const pTimeObj = formatSecond(sumPatrolTime, true)
          this.policeDetail.pTime = res.data.patrolTimeXs
          this.policeDetail.pTimeText = res.data.patrolTimeUnit
        }
      })
    },
    getPoliceDetail() {
      const params = {
        policeCode: this.policeCode
      }
      getPoliceOrganInfo(params).then(res => {
        if (res.code === 200 && res.data.rows[0]) {
          this.policeDetail = res.data.rows[0]
          this.policeDetail = { ...this.policeDetail, ...policeDetail }
          const title = '民警档案 — ' + this.policeDetail.userName
          const tempRoute = Object.assign({}, this.$route)
          const route = Object.assign({}, tempRoute, { title })
          this.$store.dispatch('tagsView/updateVisitedView', route)
        }
      })
    },
    hanlderTimeRangeChange() {
      this.getIncList()
      this.getExecuteStatList()
      this.getViolationList()
      this.getExecuteSum()
    },
    getIncList() {
      const params = {
        beginTime: '',
        endTime: '',
        pageNum: this.alarmTablePagination.curPage,
        pageSize: this.alarmTablePagination.pageSize,
        policeCode: this.policeCode
      }
      if (this.timeRange) {
        params.beginTime = this.timeRange[0] // + ' 00:00:00'
        params.endTime = this.timeRange[1] // + ' 23:59:59'
      }
      getIncByPolice(params).then(res => {
        if (res.code === 200) {
          const resData = res.data
          this.alarmTable = resData.rows
          this.alarmTablePagination.total = resData.total
        }
      })
    },
    getExecuteStatList() {
      const params = {
        beginTime: '',
        endTime: '',
        pageNum: this.dutyTablePagination.curPage,
        pageSize: this.dutyTablePagination.pageSize,
        policeCode: this.policeCode
      }
      if (this.timeRange) {
        params.beginTime = this.timeRange[0] // + ' 00:00:00'
        params.endTime = this.timeRange[1] // + ' 23:59:59'
      }
      getPoliceExecuteStat(params).then(res => {
        if (res.code === 200) {
          const resData = res.data
          this.dutyTable = resData.tableDataInfo.rows.map(o => {
            const exTimeObj = formatSecond(o.executeinute, true)
            o.exTime = exTimeObj.time
            o.exTimeText = exTimeObj.text
            const pTimeObj = formatSecond(o.sumPatrolTime, true)
            o.pTime = pTimeObj.time
            o.pTimeText = pTimeObj.text
            return o
          })
          this.dutyTablePagination.total = resData.total
        }
      })
    },
    getViolationList() {
      const params = {
        beginTime: '',
        endTime: '',
        pageNum: this.enforcementTablePagination.curPage,
        pageSize: this.enforcementTablePagination.pageSize,
        policeCode: this.policeCode
      }
      if (this.timeRange) {
        params.beginTime = this.timeRange[0] // + ' 00:00:00'
        params.endTime = this.timeRange[1] // + ' 23:59:59'
      }
      getViolationByPolice(params).then(res => {
        if (res.code === 200) {
          const resData = res.data
          this.enforcementTable = resData.rows
          this.enforcementTablePagination.total = resData.total
        }
      })
    },
    handleDetail(row, type) {
      const obj = { ...row }
      const _this = this
      _this.detailTitle = '铁骑轨迹'
      this.detailDialog = true
      this.formData.vehicleNo = obj.deviceNo
      this.formData.beginTime = obj.mixtime
      this.formData.endTime = obj.maxtime
      _this.$nextTick(_ => {
        _this.initMap()
      })
    },
    closeDetail() {
      const _this = this
      _this.isMap = false
      _this.isFixRecord = false
      _this.isMaintain = false
      _this.isInsurance = false
    },
    /**
     * 地图轨迹回放
     */
    handleTrack() {
      const _this = this
      const layerId = '小车运动'
      mapUtil.removeMapOverlay(_this.maps, layerId)
      const param = {
        beginTime: _this.formData.beginTime,
        endTime: _this.formData.endTime,
        deviceNo: _this.formData.vehicleNo
      }
      /* const param = {
        beginTime: '2021-01-11 10:24:00',
        endTime: '2021-01-11 23:24:00',
        deviceNo: '粤A45680'
      } */
      if (_this.formData.speedSelect !== '') {
        _this.moveSpeed = _this.formData.speedSelect
      }
      getDeviceHis(param).then(res => {
        if (res.code === 200) {
          const pointArr = []
          res.data.forEach(o => {
            pointArr.push({
              lng: o.longBaidu,
              lat: o.latBaidu,
              longGaode: o.longGaode,
              latGaode: o.latGaode
            })
            // pointArr.push(new BMap.Point(item.longBaidu, item.latBaidu))
          })
          mapUtil.trackAnimation(_this.maps, pointArr, _this.moveSpeed)
        }
      }).catch(err => {
        console.log(err)
      })
    },
    formatTime(val, isSecond) {
      let time = val || 0
      time = parseFloat(time)
      let patrolTime = time / 60
      if (isSecond) patrolTime = patrolTime / 60
      patrolTime = parseFloat(patrolTime).toFixed(1)
      return patrolTime
    },
    formatMetre(val) {
      let metre = val || 0
      metre = parseFloat(metre)
      let Mileage = metre / 1000
      Mileage = parseFloat(Mileage).toFixed(1)
      return Mileage
    }
  }
}
</script>

<style lang="stylus" scoped>
.policeDetail-container {
  padding 10px 30px
  overflow auto
  height calc(100vh - 106px)
  // position relative
  .policeDetail-box {
    height 100%
  }
  .tab-button-group {
    position absolute
    z-index 99
    top 50px
    right 10px
    width 120px
    >button {
      display block
      width 100%
      height 40px
      text-align center
      border 1px solid rgb(170,170,170)
      border-radius 5px
      font-size 13px
      color #000
      outline none
      background-color white
      cursor pointer
      margin-bottom 30px
      &:last-child {
        margin-bottom 0
      }
      &.active {
        background-color #169bd5
        color white
        border-color #169bd5
      }
    }
  }
  .archive-box {
    background-color #fff
    border 1px solid #ebebeb
    margin-bottom 20px
    .archive-title {
      height 40px
      border-bottom 1px solid #ebebeb
      margin 0
      font-size 0
      .title {
        line-height 40px
        font-size: 14px;
        font-family: PingFang SC;
        font-weight: 300;
        color: #333333;
        display inline-block
        margin-left 10px
      }
      .icon-box {
        width: 40px;
        height: 40px;
        line-height 40px
        background-color: #3699FF;
        border-radius: 0px 14px 0px 0px;
        float left
        text-align center
        font-size 30px
      }
      .png-icon {
        width 18px
        height 18px
        display inline-block
      }
      .icon-1 {
        background-image url('~@/assets/1.0.0_Icon/1.png')
      }
      .icon-2 {
        background-image url('~@/assets/1.0.0_Icon/2.png')
      }
      .icon-3 {
        background-image url('~@/assets/1.0.0_Icon/3.png')
      }
      .icon-4 {
        background-image url('~@/assets/1.0.0_Icon/4.png')
      }
    }
    .archive-table {
      padding 10px 10px 10px 10px
      max-height 500px
      margin-top:10px
    }
  }
  #policeDetailMap{
    margin-top 10px
    width 1162px
    height 600px
  }
  .info-container {
    width 100%
    overflow hidden
    .police-info {
      float left
      overflow hidden
      .dashBox{
        float left
        border 1px dashed #ebebeb
        margin 20px 23px 14px 20px
        padding 2px 2px
        width 100px
        height 100px
      }
    }
    .police-text {
      float left
      .textTitle {
        color #3699FF
        font-size 25px
        margin-top 39px
        margin-bottom 24px
        span {
          font-size 32px
          margin-right 10px
          font-family "PingFangSC-Medium"
        }
      }
      .organization-text {
        span{
          &:first-child {
            margin-right 30px
          }
        }
      }
    }
    .count-container {
      float right
      overflow hidden
      list-style none
      margin 25px 22px 25px 0
      text-align center
      li {
        float left
        width: 160px;
        height: 80px
        border 1px solid #E0E2E5
        padding-top 18px
        p {
          font-size 16px
          color #555
          line-height 24px
          margin 0
          span {
            font-size 28px
            color #3699FF
            margin-right 5px
          }
        }
      }
    }
  }
  .address-icon {
    width 24px
    height 24px
    display block
    background-image url('~@/assets/icons/icon_48.png')
    margin 0 auto
    cursor pointer
  }
}
</style>
