<template>
  <div class="assess-container">
    <el-form v-model="searchForm" :inline="true">
      <el-form-item class="form_item" label="日期">
        <el-date-picker
          v-model="searchForm.beginTime"
          class="w220"
          style="margin-left: 0;padding-left: 0;"
          type="datetime"
          value-format="yyyy-MM-dd HH:mm:ss"
          placeholder="选择日期时间"
          :picker-options="conditionStartTime"
        />
      </el-form-item>
      <el-form-item class="form_item" label="分组">
        <el-select v-model="searchForm.group" placeholder="请选择">
          <el-option label="第一组" value="1" />
          <el-option label="第二组" value="2" />
          <el-option label="第三组" value="3" />
        </el-select>
      </el-form-item>
      <el-form-item class="form_item" label="所属单位">
        <el-select v-model="searchForm.unit" placeholder="请选择">
          <el-option label="福田大队" value="1" />
          <el-option label="罗湖大队" value="2" />
          <el-option label="南山" value="3" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="success">查询</el-button>
        <el-button type="primary">导出</el-button>
        <el-button type="warning" style="margin-left: 10px">取消</el-button>
      </el-form-item>
    </el-form>
    <div>
      <el-table
        :data="tableData"
        style="width: 100%;"
        :span-method="tableFormat"
      >
        <el-table-column prop="id" label="分组" align="center" width="150" />
        <el-table-column label="单位" align="center">
          <el-table-column label="所属支队" align="center" prop="detachment" />
          <el-table-column label="所属中队" align="center" prop="squadron" />
        </el-table-column>
        <el-table-column label="见警率" align="center" width="800">
          <el-table-column align="center" label="骑警出勤率(%)" />
          <el-table-column align="center" label="骑警出勤得分" />
          <el-table-column align="center" label="干部出勤率(%)" />
          <el-table-column align="center" label="干部出勤得分" />
          <el-table-column align="center" label="车辆使用率(%)" />
          <el-table-column align="center" label="车辆使用得分" />
          <el-table-column align="center" label="人均骑警扫码(次数)" />
          <el-table-column align="center" label="人均骑警扫码得分" />
        </el-table-column>
        <el-table-column label="勤奋度" align="center">
          <el-table-column align="center" label="百警骑巡里程(km)" />
          <el-table-column align="center" label="百警骑巡里程得分" />
          <el-table-column align="center" label="百警骑巡时长(小时)" />
          <el-table-column align="center" label="百警骑巡时长得分" />
        </el-table-column>
        <el-table-column label="管事" align="center">
          <el-table-column align="center" label="铁骑百警执法数" />
          <el-table-column align="center" label="铁骑百警执法得分" />
          <el-table-column align="center" label="铁骑百警接处警数" />
          <el-table-column align="center" label="铁骑百警接处警得分" />
        </el-table-column>
      </el-table>
      <!--<div style="text-align: center;margin-top: 20px">
        <el-pagination
          :current-page="curPage"
          :page-sizes="[100, 200, 300, 400]"
          :page-size="100"
          layout="total, prev, pager, next, sizes, jumper"
          :total="400"
        />
      </div>-->
    </div>
  </div>
</template>

<script>
export default {
  name: 'AssessStatistics',
  data() {
    return {
      searchForm: {
        beginTime: '',
        endTime: '',
        group: '',
        unit: ''
      },
      tableData: [
        {
          id: '第一组',
          detachment: '中心区支队1',
          squadron: '一中队'
        },
        {
          id: '第一组',
          detachment: '中心区支队1',
          squadron: '二中队'
        },
        {
          id: '第一组',
          detachment: '中心区支队1',
          squadron: '三中队'
        },
        {
          id: '第一组',
          detachment: '中心区支队2',
          squadron: '四中队'
        },
        {
          id: '第一组',
          detachment: '中心区支队2',
          squadron: '五中队'
        },
        {
          id: '第一组',
          detachment: '中心区支队2',
          squadron: '六中队'
        },
        {
          id: '第二组',
          detachment: '中心区支队3',
          squadron: '六中队'
        },
        {
          id: '第二组',
          detachment: '中心区支队3',
          squadron: '六中队'
        },
        {
          id: '第二组',
          detachment: '中心区支队3',
          squadron: '六中队'
        },
        {
          id: '第二组',
          detachment: '中心区支队3',
          squadron: '六中队'
        }
      ],
      curPage: 1,
      spanArr: [],
      pos: ''
    }
  },
  computed: {
    conditionStartTime() {
      let endTime = this.searchForm.endTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          endTime = new Date(endTime).getTime()
          if (endTime) {
            if (nowDate > endTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    },
    conditionEndTime() {
      let startTime = this.searchForm.beginTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          startTime = new Date(startTime).getTime()
          if (startTime) {
            if (nowDate < startTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    }
  },
  mounted() {
    // this.getSpanArr(this.tableData)
    this.mergeTableRow(this.tableData, ['detachment', 'id'])
  },
  methods: {
    mergeTableRow(data, merge) {
      if (!merge || merge.length === 0) {
        return data
      }
      merge.forEach((m) => {
        const mList = {}
        data = data.map((v, index) => {
          const rowVal = v[m]
          if (mList[rowVal] && mList[rowVal].newIndex === index) {
            mList[rowVal]['num']++
            mList[rowVal]['newIndex']++
            data[mList[rowVal]['index']][m + '-span'].rowspan++
            v[m + '-span'] = {
              rowspan: 0,
              colspan: 0
            }
          } else {
            mList[rowVal] = { num: 1, index: index, newIndex: index + 1 }
            v[m + '-span'] = {
              rowspan: 1,
              colspan: 1
            }
          }
          return v
        })
      })
    },

    tableFormat({ row, column, rowIndex, columnIndex }) {
      const span = column['property'] + '-span'
      if (row[span]) {
        return row[span]
      }
    }
  }
}
</script>

<style scoped>
  .assess-container {
    height: 85vh;
    border: 1px solid #e6ebf5;
    background-color: #FFFFFF;
    margin: 10px 20px;
    padding: 20px;
  }
  .assess-container .form_item{
    margin-right: 36px;
  }
</style>
