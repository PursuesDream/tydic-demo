<template>
  <div class="view-container">
    <div class="view-title">
      <span class="text"><span class="icon-box"><i class="title-icon" /></span>{{ viewTitle }}<i v-if="showBackButton" class="back-up-icon" @click="handleBack(listType)" /></span>
      <el-date-picker
        v-model="timeRange"
        class="time-range"
        type="datetimerange"
        align="right"
        unlink-panels
        range-separator="至"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        value-format="yyyy-MM-dd HH:mm:ss"
        @change="hadnleDateChange"
      />
      <el-select
        v-if="listType === MJType"
        v-model="searchValue"
        filterable
        remote
        reserve-keyword
        clearable
        placeholder="请输入警号/姓名"
        :remote-method="remoteMethod"
        :loading="searchLoading"
        class="view-input"
        @change="handleSearchChange"
      >
        <el-option
          v-for="item in searchList"
          :key="item.policeCode"
          :label="item.userName"
          :value="item.policeCode"
        />
      </el-select>
    </div>
    <div class="data-box">
      <div class="week">
        <div>
          <img src="../../assets/map/icon_04.png" alt="">
          <div><span>{{ weekInfo.pTime }}</span>{{ weekInfo.pTimeText }}<br>骑巡时长</div>
        </div>
        <div>
          <img src="../../assets/map/icon_06.png" alt="">
          <div><span>{{ formatMetre(weekInfo.patrolMileage) }}</span>Km<br>骑巡里程</div>
        </div>
        <div>
          <img src="../../assets/map/icon_08.png" alt="">
          <div><span>{{ weekInfo.alarmNumber | parseToInt }}</span>起<br>接处警数</div>
        </div>
        <div>
          <img src="../../assets/map/icon_10.png" alt="">
          <div><span>{{ weekInfo.lawEnNumber | parseToInt }}</span>起<br>违法处理</div>
        </div>

      </div>
    </div>

    <el-table
      ref="table"
      v-loading="isLoading"
      v-table-scroll="setTableData"
      class="chart-box"
      :class="listType === MJType? 'isOrganDetail': ''"
      :data="policeList"
      row-key="policeNo"
    >
      <el-table-column
        v-if="listType === ZDType || listType === DDType"
        label=""
        width="350"
      >
        <template slot-scope="scope">
          <div style="cursor:pointer" @click="handlShowOrg(scope.row,listType)">
            <el-row class="user-info">
              <el-col :span="10">
                <div class="organize-box">
                  <i class="table-icon" :class="'icon-' + (scope.$index % 7)" />
                  <div :title="scope.row.organShortName" class="name-box" :style="'background-color:'+colorList[(scope.$index % 7)]">{{ scope.row.organShortName }}</div>
                </div>
              </el-col>
              <el-col :span="14">
                <div style="margin-left: 8px;margin-top: 15px">
                  <p class="bigName" :title="scope.row.organName" :style="'color:'+colorList[(scope.$index % 7)]">{{ scope.row.organName }}</p>
                  <p class="normal-text">{{ scope.row.mjsum }} 位民警</p>
                  <p class="normal-text">累计执勤 <span class="count-text" :style="'color:'+colorList[(scope.$index % 7)]">{{ scope.row.zqsum }} </span>次</p>
                </div>
              </el-col>
            </el-row>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        v-if="listType === MJType"
        width="350"
      >
        <template slot-scope="scope">
          <el-row class="user-info">
            <el-col :span="10">
              <el-image
                fit="fit"
                class="box-img"
                :src="scope.row.img"
              >
                <div slot="error" class="image-slot" />
              </el-image>
            </el-col>
            <el-col :span="14">
              <div style="margin-left: 8px;margin-top: 10px">
                <p class="bigName">{{ scope.row.policeName }}</p>
                <p class="normal-text">警号：{{ scope.row.policeNo }}</p>
                <p class="normal-text">累计执勤 <span class="count-text">{{ scope.row.zqsum }} </span> 次</p>
              </div>
            </el-col>
          </el-row>
        </template>
      </el-table-column>
      <el-table-column label="骑巡时长">
        <template slot-scope="scope">
          <div class="cBox">
            <div class="p">
              <span>{{ scope.row.table0.time }}</span>{{ scope.row.table0.timeText }}
            </div>
            <barChart :id="scope.row.policeNo" :count="scope.row.table0.count" height="85%" width="100%" :chart-data="scope.row.table0" unit="小时" />
          </div>
        </template>
      </el-table-column>
      <el-table-column label="骑巡里程">
        <template slot-scope="scope">
          <div class="cBox">
            <div class="p" v-html="formatMile(scope.row.table1.weeklyTotal)" />
            <barChart :id="scope.row.policeNo" :count="scope.row.table1.count" height="85%" width="100%" :chart-data="scope.row.table1" unit="km" />
          </div>
        </template>
      </el-table-column>
      <el-table-column label="接处警数">
        <template slot-scope="scope">
          <div class="cBox">
            <div class="p"><span>{{ scope.row.table2.weeklyTotal | parseToInt }}</span>起</div>
            <brokenLine :id="scope.row.policeNo" :count="scope.row.table2.count" height="85%" width="100%" :chart-data="scope.row.table2" />
          </div>
        </template>
      </el-table-column>
      <el-table-column label="执法量">
        <template slot-scope="scope">
          <div class="cBox">
            <div class="p"><span>{{ scope.row.table3.weeklyTotal | parseToInt }}</span>起</div>
            <brokenLine :id="scope.row.policeNo" :count="scope.row.table3.count" height="85%" width="100%" :chart-data="scope.row.table3" />
          </div>
        </template>
      </el-table-column>
      <el-table-column label="战力矩阵">
        <template slot-scope="scope">
          <div class="cBox">
            <radarMap :id="scope.row.policeNo" :count="scope.row.radarChartResVo.radarCount" height="100%" width="100%" :chart-data="scope.row.radarChartResVo" />
          </div>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      v-if="listType === MJType"
      style="text-align: center;margin-top:15px;margin-bottom:15px;"
      background
      :page-size="pageSize"
      :total="total"
      :current-page.sync="curPage"
      layout="total,prev, pager, next, jumper"
      @current-change="handleCurPageChange"
    />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import BarChart from '@/components/Charts/barChart'
import brokenLine from '@/components/Charts/polyLine'
import radarMap from '@/components/Charts/radarMap'
import { parseTime, formatSecond } from '@/utils'
import { getByWeekTotalStat, getStatPolices } from '@/api/policeReport'
import { getPoliceList } from '@/api/public'
import Bus from '@/utils/bus'
const defaultIndex = 5 // 区域默认展示数量
const colorList = ['#3699FF', '#39B333', '#FF6633', '#FF9900', '#C6C106', '#04B5B0', '#9966CC']

export default {
  name: 'AppraisalView',
  filters: {
    parseToInt(val) {
      if (!val) return 0
      return parseInt(val)
    }
  },
  components: { BarChart, brokenLine, radarMap },
  data() {
    const getNowWeekTime = () => {
      // const Nowdate = new Date().getDay() || 7
      // const NowdataTime = new Date().getTime()
      // const WeekFirstDay = Nowdate === 1 ? new Date() : new Date(NowdataTime - (Nowdate - 1) * 86400000)
      // const WeekLastDay = Nowdate === 7 ? new Date() : new Date((WeekFirstDay / 1000 + 6 * 86400) * 1000)
      const startDate = new Date()
      startDate.setDate(1)

      const endDate = new Date()
      endDate.setMonth(endDate.getMonth() + 1)
      endDate.setDate(0)

      return [startDate, endDate]
    }

    const defaultTime = getNowWeekTime()
    return {
      colorList: colorList,
      weekInfo: {
        alarmNumber: '0',
        lawEnNumber: '0',
        patrolMileage: '0',
        pTime: '0',
        pTimeText: '秒'
      },
      defaultTime: [parseTime(defaultTime[0], '{y}-{m}-{d} 00:00:00'), parseTime(defaultTime[1], '{y}-{m}-{d} 23:59:59')],
      timeRange: [parseTime(defaultTime[0], '{y}-{m}-{d} 00:00:00'), parseTime(defaultTime[1], '{y}-{m}-{d} 23:59:59')],
      searchValue: '',
      searchList: [],
      searchLoading: false,
      policeList: [],
      viewTitle: '考核报表',
      pageSize: 5,
      total: 0,
      curPage: 1,
      organDetail: {},
      ZDDetail: {}, // 选中的支队
      listType: 1, // 1 支队 2 大队 4 民警
      isLoading: false,
      organIndex: defaultIndex,
      organTable: [],
      ZDType: 1, // 支队
      DDType: 2, // 大队
      MJType: 4, // 民警
      defaultCount: 0, // 促使表格每次更新
      pickerOptions: {
        shortcuts: [
          {
            text: '本周',
            onClick(picker) {
              const timeArr = getNowWeekTime()
              picker.$emit('pick', timeArr)
            }
          },
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近60天',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 60)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近90天',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }]
      },
      showBack: false
    }
  },
  computed: {
    ...mapGetters([
      'showLevelObj'
    ]),
    showBackButton() {
      const level = this.showLevelObj.level
      let status = this.showBack
      switch (level) {
        case 1:
          if (this.listType === 2) status = false
          break
        case 2:
          if (this.listType === 4) status = false
          break
        default:
          if (this.listType === 1) status = false
          break
      }
      return status
    }
  },
  watch: {
  },
  mounted() {
    this.initPage()
    // this.onMessage()
  },
  beforeDestroy() {
    Bus.$off('TYPE_PUSH_STATE_PATROLTIME')
    Bus.$off('TYPE_PUSH_STATE_LAWENNUMBER')
    Bus.$off('TYPE_PUSH_STATE_PATROLMILEAGE')
  },
  methods: {
    initPage() {
      const userData = this.showLevelObj
      let organCode
      /* if (userData['0'] && userData['0'].length === 1) {
        organCode = null
        this.listType = 2
        if (userData['1'] && userData['1'].length === 1) {
          organCode = userData['1'][0].organCode
          this.listType = 4
        } else if (userData['1'] && userData['1'].length > 1) {
          organCode = null
          this.listType = 2
        }
      } else if (userData['0'] && userData['0'].length > 1) {
        organCode = null
        this.listType = 1
      }
      if (!userData[0] && userData['1'] && userData['1'].length === 1) {
        organCode = userData['1'][0].organCode
        this.listType = 4
      } else if (!userData['0'] && userData['1'] && userData['1'].length > 1) {
        organCode = null
        this.listType = 2
      } */
      switch (userData.level) {
        case 1:
          organCode = userData.ZD[0].organCode
          this.listType = 2
          break
        case 2:
          organCode = userData.DD[0].organCode
          this.listType = 4
          break
        default:
          organCode = null
          this.listType = 1
          break
      }
      this.organDetail.organCode = organCode
      this.getWeekData(organCode)
      this.getPoliceData(organCode)
    },
    remoteMethod(query) {
      if (query !== '') {
        this.searchLoading = true
        const params = {
          organCode: this.organDetail.organCode,
          userName: query
        }
        getPoliceList(params).then(res => {
          if (res.code === 200) {
            this.searchList = res.data
          }

          this.searchLoading = false
        }).catch(_ => {
          this.searchLoading = false
        })
      }
    },
    getWeekData(organCode) {
      const params = {
        beginTime: '',
        endTime: '',
        organCode
      }
      if (this.listType === this.MJType) {
        params.qType = '2'
      } else if (this.listType === this.DDType) {
        params.qType = '1'
      } else if (this.listType === this.ZDType) {
        params.qType = ''
      }
      if (this.timeRange) {
        params.beginTime = this.timeRange[0] + ' 00:00:00'
        params.endTime = this.timeRange[1] + ' 23:59:59'
      }
      getByWeekTotalStat(params).then(res => {
        this.formatWeekInfo(res.data[0])
      })
    },
    /* changeOrgErr 改变组织机构错误回调 */
    getPoliceData(organCode, pageNum = 1, changeOrgErr) {
      const params = {
        beginTime: '',
        endTime: '',
        qType: this.listType,
        organCode,
        pageNum,
        pageSize: (this.listType === this.ZDType || this.listType === this.DDType) ? 1000 : this.pageSize
      }
      if (this.timeRange) {
        params.beginTime = this.timeRange[0] + ' 00:00:00'
        params.endTime = this.timeRange[1] + ' 23:59:59'
      }
      if (this.listType === this.MJType) {
        params.policeCode = this.searchValue
      } else if (this.listType === this.DDType) {
        params.pOrganCode = organCode
        delete params.organCode
      }
      this.isLoading = true
      getStatPolices(params).then(res => {
        const resData = res.data
        this.total = resData.total
        const listArr = ['', 'organTable', 'organTable', '', 'policeList']
        this[listArr[this.listType]] = []
        resData.rows.forEach(o => {
          const obj = o
          obj.chartDataResVo.forEach((k, i) => {
            obj['table' + i] = k
            if (i === 0) {
              obj['table' + i].time = (obj['table0'].weeklyTotal / 60).toFixed(1)
              obj['table' + i].timeText = '小时'
            }
            obj['table' + i].count = this.defaultCount
            if (obj['table' + i].xAxis) {
              obj['table' + i].xAxis = obj['table' + i].xAxis.slice(7, 21)
            }
            if (obj['table' + i].yAxis) {
              let yAxis = obj['table' + i].yAxis.slice(7, 21)
              if (i === 1) {
                yAxis = yAxis.map(item => item / 1000)
              }
              if (i === 0) {
                yAxis = yAxis.map(item => (item / 60).toFixed(1))
              }
              obj['table' + i].yAxis = yAxis
            }
          })
          obj.radarChartResVo.count = this.defaultCount
          if (this.listType === this.ZDType || this.listType === this.DDType) obj.policeNo = obj.organCode
          this[listArr[this.listType]].push(obj)
        })
        this.defaultCount++
        if (this.listType === this.ZDType || this.listType === this.DDType) {
          this.policeList = []
          this.organIndex = defaultIndex
          this.organTable.every((o, index) => {
            if (index < defaultIndex) {
              this.policeList.push(o)
              return true
            } else {
              return false
            }
          })
        }
        this.isLoading = false
        this.$refs.table.bodyWrapper.scrollTop = 0
      }).catch(_ => {
        this.isLoading = false
        changeOrgErr && changeOrgErr()
      })
    },
    handlShowOrg(row, listType) {
      if (listType === this.ZDType) {
        this.ZDDetail = { ...row }
        this.listType = this.DDType
      } else if (listType === this.DDType) {
        this.listType = this.MJType
      }
      this.showBack = true
      this.handleShowDetail(row)
    },
    handleShowDetail(row) {
      this.organDetail = { ...row }
      this.viewTitle = row.organName + '-考核报表'
      const that = this
      this.getPoliceData(row.organCode, 1, () => {
        that.handleBack(that.listType)
      })
      this.getWeekData(row.organCode)
    },
    hadnleDateChange() {
      const organCode = this.organDetail.organCode
      this.getPoliceData(organCode, this.curPage)
      this.getWeekData(this.organDetail.organCode)
    },
    handleSearchChange(val) {
      this.curPage = 1
      const organCode = this.organDetail.organCode
      this.getPoliceData(organCode, this.curPage)
    },
    handleBack(listType) {
      let organCode = ''
      let viewTitle = '考核报表'
      if (listType === this.MJType) {
        this.listType = this.DDType
        this.organDetail = { ...this.ZDDetail }
        organCode = this.organDetail.organCode
        if (this.organDetail.organName) {
          viewTitle = this.organDetail.organName + '-' + viewTitle
        }
      } else if (listType === this.DDType) {
        this.listType = this.ZDType
        this.organDetail = {}
      } else if (listType === this.ZDType) {
        this.showBack = false
      }
      this.curPage = 1
      this.searchValue = ''
      this.viewTitle = viewTitle
      this.getPoliceData(organCode)
      this.getWeekData(organCode)
    },
    handleSizeChange(val) {
      this.curPage = 1
      this.pageSize = val
      const organCode = this.organDetail.organCode
      this.getPoliceData(organCode, this.curPage)
    },
    handleCurPageChange(val) {
      const organCode = this.organDetail.organCode
      this.$refs.table.bodyWrapper.scrollTop = 0
      this.getPoliceData(organCode, val)
    },
    setTableData(isBottom) {
      if (isBottom && (this.listType === 1 || this.listType === 2)) {
        const index = this.organIndex
        if (this.organTable.length > this.organIndex) {
          this.policeList.push(this.organTable[index])
          this.organIndex++
        }
      }
    },
    onMessage() {
      // 骑巡时长变更
      Bus.$on('TYPE_PUSH_STATE_PATROLTIME', data => {
        const resData = data
        let patrolTime = parseFloat(resData.weekNumber)
        patrolTime = patrolTime / 60
        this.weekInfo.patrolTime = patrolTime.toFixed(1)
        const policeList = this.policeList
        let count = 0
        let radarCount = 0
        for (let i = 0; i < policeList.length; i++) {
          if (policeList[i].policeNo === resData.policeNo) {
            const chartData = resData.chartDataResVo // 一般图表
            const radarData = resData.radarChartResVo // 雷达
            if (policeList[i].table0.count) {
              count = policeList[i].table0.count
            }
            if (policeList[i].radarChartResVo.radarCount) {
              radarCount = policeList[i].radarChartResVo.radarCount
            }
            count++
            radarCount++
            chartData.count = count
            radarData.radarCount = radarCount
            policeList[i].table0 = chartData
            policeList[i].radarChartResVo = radarData
            break
          }
        }
      })
      // 巡逻里程变更
      Bus.$on('TYPE_PUSH_STATE_PATROLMILEAGE', data => {
        const resData = data
        const patrolMileage = parseFloat(resData.weekNumber)
        this.weekInfo.patrolMileage = patrolMileage.toFixed(1)
        const policeList = this.policeList
        let count = 0
        let radarCount = 0
        for (let i = 0; i < policeList.length; i++) {
          if (policeList[i].policeNo === resData.policeNo) {
            const chartData = resData.chartDataResVo // 一般图表
            const radarData = resData.radarChartResVo // 雷达
            if (policeList[i].table1.count) {
              count = policeList[i].table1.count
            }
            if (policeList[i].radarChartResVo.radarCount) {
              radarCount = policeList[i].radarChartResVo.radarCount
            }
            count++
            radarCount++
            chartData.count = count
            radarData.radarCount = radarCount
            policeList[i].table1 = chartData
            policeList[i].radarChartResVo = radarData
            break
          }
        }
      })
      // 违法处理变更
      Bus.$on('TYPE_PUSH_STATE_LAWENNUMBER', data => {
        const resData = data
        this.weekInfo.lawEnNumber = parseInt(resData.weekNumber)
        const policeList = this.policeList
        let count = 0
        let radarCount = 0
        for (let i = 0; i < policeList.length; i++) {
          if (policeList[i].policeNo === resData.policeNo) {
            const chartData = resData.chartDataResVo // 一般图表
            const radarData = resData.radarChartResVo // 雷达
            if (policeList[i].table3.count) {
              count = policeList[i].table3.count
            }
            if (policeList[i].radarChartResVo.radarCount) {
              radarCount = policeList[i].radarChartResVo.radarCount
            }
            count++
            radarCount++
            chartData.count = count
            radarData.radarCount = radarCount
            policeList[i].table3 = chartData
            policeList[i].radarChartResVo = radarData
            break
          }
        }
      })
    },
    formatTime(str) {
      const timeNum = parseFloat(str) || 0
      let hour = parseInt(timeNum / 60)
      let minute = timeNum % 60
      hour = hour === 0 ? '' : '<span>' + hour + '</span>小时'
      minute = parseFloat(minute).toFixed(1)
      minute = '<span>' + minute + '</span>分钟'
      return hour + minute
    },
    formatMile(str) {
      let mile = str
      mile = this.formatMetre(str)
      mile = '<span>' + mile + '</span>KM'
      return mile
    },
    formatWeekInfo(data) {
      let { patrolTime, patrolMileage, alarmNumber, lawEnNumber } = data
      patrolTime = patrolTime || 0
      patrolMileage = patrolMileage || 0
      alarmNumber = alarmNumber || 0
      lawEnNumber = lawEnNumber || 0
      alarmNumber = parseInt(alarmNumber)
      lawEnNumber = parseInt(lawEnNumber)
      patrolMileage = parseFloat(patrolMileage).toFixed(1)
      this.weekInfo = { patrolMileage, alarmNumber, lawEnNumber }
      const timeObj = formatSecond(patrolTime, true)
      this.weekInfo.pTime = timeObj.time
      this.weekInfo.pTimeText = timeObj.text
    },
    formatMetre(val) {
      let metre = val || 0
      metre = parseFloat(metre)
      let Mileage = metre / 1000
      Mileage = parseFloat(Mileage).toFixed(1)
      return Mileage
    }
  }
}
</script>

<style lang="stylus" scoped>
html, body {
  height 100%
 }
.view-container {
  border 1px solid #DCDFE6
  margin 10px 20px
  background-color #fff
  .view-title {
    border-bottom 1px solid #DCDFE6
    overflow hidden
    box-sizing border-box
    .icon-box {
      width: 40px;
      height: 40px;
      background-color: #3699FF;
      border-radius: 0px 14px 0px 0px;
      float left
      text-align center
      margin-right 10px
    }
    .back-up-icon {
      background-image url('~@/assets/1.0.0_Icon/report/backup.png')
      width 24px
      height 24px
      cursor pointer
      margin-left 15px
      display inline-block
      vertical-align: -8px;
    }
    .text {
      font-size: 14px;
      font-family: PingFang SC;
      color: #333;
      line-height 40px
    }
    .view-input {
      float right
      width 150px
      margin-right 20px
    }
    .time-range {
      float right
      width 400px
    }
  }
  .chart-box{
    width 100%
    // height 680px
    box-shadow: 0 1px 3px 0 rgba(40, 53, 127, .12), 0 0 3px 0 rgba(40, 53, 127, .04);
    .chartMain{
      display flex
      width 99%
      height 100%
      .charts{
        width 22%
        height 100%
        border-left 1px solid rgba(51, 51, 51, 0.6)
      }
      .manMessage{
        width 30%
        border-left none
      }
    }
    .user-info {
      background white
      color #4d4d4d
      font-size 16px

      p {
        margin 0
      }

      .box-img {
        width 120px
        height 116px
        display block
      }

      .bigName {
        width 181px
        font-size 24px
        color #1a67d3
        font-weight bold
        margin-right 4px
        line-height 30px
        margin-bottom 10px
        overflow hidden
        white-space nowrap
        word-break break-all
        text-overflow ellipsis
      }
      .normal-text {
        font-size 16px
        line-height 30px
      }
      .count-text {
        font-size 20px
      }
    }
  }
  #mapBox{
    width 100%
    height 100%
  }
  .title-icon {
    width 16px
    height 16px
    display block
    margin 10px auto
    background-image url('~@/assets/1.0.0_Icon/report/0.png')
  }
  .organize-box {
    margin-left 10px
    padding-top 5px
  }
  .table-icon {
    width 43px
    height 43px
    display block
    margin 0 auto
    &.icon-0 {
      background-image url('~@/assets/1.0.0_Icon/report/1.png')
    }
    &.icon-1 {
      background-image url('~@/assets/1.0.0_Icon/report/2.png')
    }
    &.icon-2 {
      background-image url('~@/assets/1.0.0_Icon/report/3.png')
    }
    &.icon-3 {
      background-image url('~@/assets/1.0.0_Icon/report/4.png')
    }
    &.icon-4 {
      background-image url('~@/assets/1.0.0_Icon/report/5.png')
    }
    &.icon-5 {
      background-image url('~@/assets/1.0.0_Icon/report/6.png')
    }
    &.icon-6 {
      background-image url('~@/assets/1.0.0_Icon/report/7.png')
    }
  }
  .name-box {
    width 120px
    height 50px
    line-height 50px
    text-align center
    font-size: 20px;
    font-family: PingFang SC;
    color: #fff;
    box-sizing border-box
    padding 0 10px
    overflow hidden
    white-space nowrap
    word-break break-all
    text-overflow ellipsis
    margin-top 16px
  }
}
.data-box {
    width 1188px
    padding 10px
    height 110px
    display flex
    margin 0 auto 12px
    box-sizing border-box

  .week {
    width 100%
    height 110px
    display flex
    justify-content center
    align-items center
    color #3fa9f5

    > div {
      flex 1
      display flex
      flex-direction row
      align-items center
      justify-content center

      img{
        width 50px
        margin-right 16px
      }

      span {
        font-size 36px
        margin-right 6px
      }
    }
  }
}
</style>
<style lang="stylus">
.view-container {

  .chart-box {
    .titleList {
      font-size 20px
      color #3274e1
      text-align center
      margin 0px
      margin-top 15px
      margin-bottom 12px
    }
    .el-table__body-wrapper {
      height calc(100vh - 350px)
      overflow-y auto
    }
    &.isOrganDetail {
      .el-table__body-wrapper {
        height calc(100vh - 410px)
        overflow-y auto
      }
    }
  }
  .el-table--medium td {
    padding 0
  }

  .cBox {
    height 150px

    .p {
      color #1a67d3
      font-size 16px
      font-weight bold
      text-align:center;
      span{
        font-size 28px
        margin 0 8px
      }
    }
  }

  .el-table thead tr {
    // height 70px
    th {
      background-color white
      padding 0
      border-top: 1px solid #dfe6ec
    }

    th .cell {
      background url("../../assets/map/111_16.png") no-repeat
      background-size 99% 100%
      text-align center
      height 42px
      line-height 42px
      font-size 16px
      color white
      letter-spacing 2px
      text-shadow 0 0 5px #133793
    }

    th:first-child {
      .cell {
        margin-left 20px
        background-image none
        background-size 93% 100%
      }
    }

    /* th:nth-last-child(2) {
      .cell {
        margin-left 12px
        background url("../../assets/map/111_18.png") no-repeat
        background-size 92% 100%
        text-align center
        height 42px
        line-height 42px
        font-size 16px
        color white
        letter-spacing 2px
        text-shadow 0 0 5px #133793
      }
    } */
  }
  .el-table {
    .user-info {
      padding 10px 6px
    }
    .cell {
      padding-left 3px
      padding-right 3px
    }
    tbody {
      td {
        &:last-child{
          .cBox {
            padding 2px 0!important
            // background-color #fff7eb!important
          }
        }
      }
    }
  }
  .el-table tbody td {
    height 164px
  }
  .el-table tbody tr:nth-child(2n) {
    background-color #f2f2f2
    .user-info {
      background-color #fff
    }

    .cBox {
      background-color #FAFAF9
      padding 15px 6px
    }
  }
  .el-table tbody tr:nth-child(2n+1) {
    .user-info {
      background-color #ebf6fe
    }

    .cBox {
      background-color #ebf6fe
      padding 15px 6px
    }
  }
  .el-table tbody tr {
    td:first-child{
      .user-info {
        background-color #fff!important
      }
    }
  }
}
</style>
