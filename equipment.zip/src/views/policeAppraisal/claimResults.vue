<template>
  <div class="interphone-container">
    <el-card style="margin-top: 20px; height: 85vh">
      <div>
        <div>
          <div class="tydic-box">
            <div class="tydic-input">
              所属支队：
              <el-select
                v-model="formData.ssdd"
                placeholder="请选择"
                clearable
                @change="(val) => getOrgan(val, 'zhongdui')"
              >
                <el-option
                  v-for="(o, index) in daduiList"
                  :key="index"
                  :label="o.name"
                  :value="o.organCode"
                />
              </el-select>
            </div>
            <div class="tydic-input">
              所属大队：
              <el-select
                v-model="formData.sszd"
                placeholder="请选择"
                clearable
              >
                <el-option
                  v-for="(o, index) in zhongduiList"
                  :key="index"
                  :label="o.name"
                  :value="o.organCode"
                />
              </el-select>
            </div>

            <div class="tydic-input">
              姓名：
              <el-input
                v-model="formData.deviceNo"
                clearable
                placeholder="请输入"
              />
            </div>
            <div class="tydic-input" style="margin-left: 56px">
              车牌号码：
              <el-input
                v-model="formData.deviceType"
                clearable
                placeholder="请输入"
              />
            </div>

            <div class="tydic-input" style="float: right">
              <el-button
                type="primary search"
                size="mini"
                @click="onSearch"
              ><i class="image-icon search" />查询</el-button>
              <el-button
                type="primary reset"
                size="mini"
                @click="onReset"
              ><i class="image-icon reset" />重置</el-button>
            </div>
            <div>
              <el-button
                v-permission="'button24'"
                class="m-b-15"
                type="primary color5"
                size="mini"
                @click="claimResults"
              ><i class="image-icon export" />战果认领</el-button>
            </div>
            <div class="table-box">
              <el-table
                v-loading="tableLoading"
                :data="tableData"
                class="custom-table"
                stripe
                border
                max-height="600"
                header-row-class-name="custom-table-header"
              >
                <el-table-column
                  type="index"
                  width="100"
                  label="序号"
                  align="center"
                >
                  <template slot-scope="scope">
                    {{ scope.$index + 1 + pageSize * (curPage - 1) }}
                  </template>
                </el-table-column>
                <el-table-column
                  prop="ddOrgName"
                  align="center"
                  label="所属支队"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="zdOrgName"
                  align="center"
                  label="所属大队"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="policeName"
                  align="center"
                  label="姓名"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="policeNo"
                  align="center"
                  label="警号"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="deviceNo"
                  align="center"
                  label="车牌号码"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="patrolTime"
                  align="center"
                  label="骑巡时长（小时）"
                  :show-overflow-tooltip="true"
                ><!-- timeObj.time = hour
    timeObj.text = '小时' -->
                  <template slot-scope="scope">
                    {{ scope.row.pTime }}
                  </template>
                </el-table-column>
                <el-table-column
                  prop="kilometres"
                  align="center"
                  label="骑巡里程/km"
                  :show-overflow-tooltip="true"
                >
                  <template slot-scope="scope">
                    {{ scope.row.kilometres | kilometres }}
                  </template>
                </el-table-column>
                <el-table-column
                  prop="beginTime"
                  align="center"
                  label="骑巡开始时间"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="endTime"
                  align="center"
                  label="骑巡结束时间"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="calcTime"
                  align="center"
                  label="认领时间"
                  :show-overflow-tooltip="true"
                />
                <el-table-column align="center" label="操作" width="120">
                  <template slot-scope="scope">
                    <el-button
                      v-permission="'button26'"
                      type="text"
                      size="small"
                      @click="goArchives(scope.row)"
                    >详情</el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div style="text-align: center">
            <el-pagination
              ref="pagination"
              style="text-align: center; margin-top: 15px"
              background
              :page-size="pageSize"
              :total="total"
              :current-page.sync="curPage"
              layout="total, prev, pager, next, jumper"
              @size-change="sizerChange"
              @current-change="curPageChange"
            />
          </div>

          <!-- 新增 -->
          <el-dialog
            :title="title"
            :visible.sync="formVisible"
            width="1400px"
            custom-class="custom-dialog addOrEdit"
            :close-on-click-modal="false"
            :colse-on-press-escape="false"
            @close="closeDialog('addDataForm')"
          >
            <el-form
              ref="addDataForm"
              :rules="formRules"
              :model="addDataForm"
              :inline="true"
              label-width="90"
            >
              <el-form-item label="车牌号码:" prop="vehicleNo">
                <el-input
                  v-model="addDataForm.vehicleNo"
                  class="putW"
                  clearable
                  placeholder="请输入"
                  :disabled="!showClaimBtn"
                />
              </el-form-item>
              <el-form-item label="骑巡开始时间:" prop="beginTime">
                <el-date-picker
                  v-model="addDataForm.beginTime"
                  class="w200 claim_time"
                  type="datetime"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  placeholder="开始时间"
                  :picker-options="applyStartTime"
                  :disabled="!showClaimBtn"
                />
              </el-form-item>
              <el-form-item label="骑巡结束时间:" prop="endTime">
                <el-date-picker
                  v-model="addDataForm.endTime"
                  class="w200 claim_time"
                  style="margin-left: 0;padding-left: 0;"
                  type="datetime"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  placeholder="结束时间"
                  :picker-options="applyEndTime"
                  :disabled="!showClaimBtn"
                />
              </el-form-item>
              <el-button v-if="showClaimBtn" type="primary search" @click="searchClaimList('addDataForm')"><i class="image-icon search" />查询</el-button>
              <el-form-item v-if="!hidePoliceNum" label="警号:" :prop="!hidePoliceNum ? 'policeNum' : null" style="margin-left: 10px">
                <el-input
                  v-model="addDataForm.policeNum"
                  class="putW"
                  clearable
                  placeholder="请输入"
                />
              </el-form-item>
              <el-button v-if="!hidePoliceNum" type="primary search w70" @click="queryClaim('addDataForm')">确认</el-button>
              <el-button v-if="!hidePoliceNum" type="primary color7 w70" @click="hidePoliceNum = true">取消</el-button>
              <el-button v-if="hidePoliceNum && showClaimBtn" v-permission="'button25'" type="primary search" @click="claimBtn"><i class="image-icon claim" />认领</el-button>
            </el-form>
            <div class="detail-content">
              <div class="detail-list">
                <div v-if="claimRecord.length > 0">
                  <div class="detail-item detail_title">
                    <p>
                      所属支队：{{ unitName }} {{ policeNo }}
                      骑巡时长：<span class="detail-high">{{ duration }}</span>
                      {{ durationText }}&nbsp;&nbsp;&nbsp;骑巡里程：<span
                        class="detail-high"
                      >{{ mileage }}</span>
                      Km
                    </p>
                  </div>
                  <div v-for="(item,index) in claimRecord" :key="index" class="detail-item" :class="{active: trackActive === index}" @click="curTrack(item,index)">
                    <p>
                      {{ item.begin }} 至 {{ item.end }}
                      骑巡时长：<span class="detail-high">{{ item.pTime }}</span>
                      {{ item.pTimeText }}&nbsp;&nbsp;&nbsp;骑巡里程：<span
                        class="detail-high"
                      >{{ item.kilometres | kilometres }}</span>
                      Km
                    </p>
                  </div>
                  <!--<el-pagination
                    style="text-align: center"
                    small
                    layout="prev, pager, next"
                    :pager-count="5"
                    :total="50"
                  />-->
                </div>
              </div>
              <div class="map-div">
                <div v-if="formVisible" id="map" />
              </div>
              <div v-if="claimRecord.length === 0" class="map-default">暂无数据</div>
            </div>

          </el-dialog>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
import { organListByParam } from '@/api/public'
import http from '@/api/claimResults'
import { mapState } from 'vuex'
import mapUtil from '@/utils/map/mapUtil'
import { formatSecond } from '@/utils'

export default {
  name: 'ClaimResults',
  filters: {
    kilometres(value) {
      return (value / 1000).toFixed(1)
    }
  },
  data() {
    return {
      tableLoading: false,
      formData: {
        orgCode: '',
        vehicleBrand: '',
        qrCodeBindSate: '',
        states: '',
        dutyPoliceUserId: '',
        distributionStates: '',
        deviceNo: '',
        deviceNo2: '',
        deviceType: ''
      },
      curPage: 1,
      pageSize: 10,
      total: 0,
      daduiList: [],
      zhongduiList: [],
      tableData: [],
      formVisible: false,
      addDataForm: {
        vehicleNo: '',
        beginTime: '',
        endTime: '',
        policeNum: ''
      },
      formRules: {
        vehicleNo: [
          { required: true, message: '请输入车牌号码', trigger: 'blur' }
        ],
        beginTime: [
          { required: true, message: '请选择时间', trigger: 'change' }
        ],
        endTime: [
          { required: true, message: '请选择时间', trigger: 'change' }
        ],
        policeNum: [
          { required: true, message: '请输入警号', trigger: 'blur' }
        ]
      },
      title: '',
      hidePoliceNum: false,
      showClaimBtn: false,
      claimRecord: [],
      unitName: '',
      policeNo: '',
      duration: '',
      mileage: '',
      maps: '',
      trackActive: null,
      trackTime: null
    }
  },
  computed: {
    ...mapState({
      mapData: state => state.user.mapData
    }),
    applyStartTime() {
      let endTime = this.addDataForm.endTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          endTime = new Date(endTime).getTime()
          if (endTime) {
            if (nowDate > endTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    },
    applyEndTime() {
      let startTime = this.addDataForm.beginTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          startTime = new Date(startTime).getTime()
          if (startTime) {
            if (nowDate < startTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    }
  },
  mounted() {
    const _this = this
    _this.getOrgan('', 'dadui')
    // _this.getInterphoneList()
    _this.getClaimList()
    // _this.getAllCategory()
    // _this.statusList = _this.mapData.vehicle_use_states
  },
  methods: {
    /*
    * 获取战果列表
    * */
    getClaimList() {
      const that = this
      const param = {
        deviceNo: that.formData.deviceType,
        orgCode: that.formData.sszd ? that.formData.sszd : that.formData.ssdd,
        policeName: that.formData.deviceNo,
        pageNum: that.curPage,
        pageSize: that.pageSize
      }
      that.tableLoading = true
      http.claimList(param).then(res => {
        if (res.code === 200) {
          that.tableData = res.rows.map(o => {
            const tiemObj = formatSecond(o.patrolTime, true)
            o.pTime = tiemObj.time
            o.pTimeText = tiemObj.text
            return o
          })
          that.total = res.total
          that.tableLoading = false
        }
      })
    },
    /**
     * 分页大小
     */
    sizerChange(val) {
      const _this = this
      _this.pageSize = val
      _this.getClaimList()
    },
    /**
     * 页数跳转
     */
    curPageChange(val) {
      const _this = this
      _this.curPage = val
      _this.getClaimList()
    },
    /**
     * 查询大队
     * @param {String} listName 'dadui'  'zhongdui'
     */
    getOrgan(code, listName, isSelectChange = false) {
      this[listName + 'List'] = []
      // this.formData.sszd = ''
      const organizeCode = window.CONFIG.organizeCode
      let orgLevel = organizeCode.first
      if (listName === 'zhongdui' || listName === 'fenpeizhongdui') { orgLevel = organizeCode.second }
      const params = {
        parentCode: code,
        orgLevel: orgLevel
      }
      organListByParam(params).then(res => {
        if (res.code === 200) {
          this[listName + 'List'] = res.data
        }
      })
    },
    /**
     * 详情
     */
    goArchives(row) {
      this.formVisible = true
      this.hidePoliceNum = true
      this.showClaimBtn = false
      this.title = '战果认领详情'
      this.addDataForm.vehicleNo = row.deviceNo
      this.addDataForm.beginTime = row.beginTime
      this.addDataForm.endTime = row.endTime
      this.$nextTick(_ => {
        this.searchDetailClaimList('addDataForm')
        this.maps = mapUtil.initMap('map')
      })
    },
    /**
     * 条件查询
     */
    onSearch() {
      const _this = this
      _this.curPage = 1
      _this.getClaimList()
    },
    /**
     * 重置
     */
    onReset() {
      const _this = this
      _this.formData.sszd = ''
      _this.formData.ssdd = ''
      _this.formData.deviceType = ''
      _this.formData.deviceNo = ''
      _this.formData.deviceNo2 = ''
      _this.formData.vehicleBrand = ''
      _this.formData.states = ''
      _this.formData.distributionStates = ''
      _this.formData.qrCodeBindSate = ''
      _this.formData.dutyPoliceUserId = ''
      _this.zhongduiList = []
      _this.curPage = 1
    },
    // 战果认领
    claimResults() {
      this.formVisible = true
      this.hidePoliceNum = true
      this.showClaimBtn = true
      this.title = '战果认领'
      this.$nextTick(_ => {
        this.maps = mapUtil.initMap('map')
      })
    },
    // 认领
    claimBtn() {
      this.hidePoliceNum = false
    },
    // 确认认领
    queryClaim(formName) {
      const that = this
      const param = {
        begin: that.addDataForm.beginTime,
        deviceNo: that.addDataForm.vehicleNo,
        end: that.addDataForm.endTime,
        policeNo: that.addDataForm.policeNum
      }
      this.searchClaimList('addDataForm')
      setTimeout(() => {
        that.$refs[formName].validate((valid) => {
          if (valid) {
            if (that.claimRecord.length > 0) {
              http.claimRecodes(param).then(res => {
                if (res.code === 200) {
                  that.hidePoliceNum = true
                  that.formVisible = false
                  that.getClaimList()
                }
              })
            } else {
              that.$message.warning('该时间段里无战果记录')
            }
          } else {
            return false
          }
        })
      }, 1000)
    },
    // 查询骑巡记录
    searchClaimList(formName) {
      const that = this
      const param = {
        begin: that.addDataForm.beginTime,
        deviceNo: that.addDataForm.vehicleNo,
        end: that.addDataForm.endTime
      }
      this.$refs[formName].validate((valid) => {
        if (valid) {
          http.claimTrackList(param).then(res => {
            if (res.data && res.data.length > 0) {
              that.claimRecord = res.data
              that.unitName = res.data[0].ddName + '/' + res.data[0].zdName
              that.policeNo = that.addDataForm.vehicleType
              that.duration = ((res.data[0].time) / 3600).toFixed(1)
              that.mileage = (res.data[0].kilometres) / 1000
              that.claimRecord.shift()
            }
          })
        } else {
          return false
        }
      })
    },
    // 查询详情骑巡记录
    searchDetailClaimList(formName) {
      const that = this
      const param = {
        begin: that.addDataForm.beginTime,
        deviceNo: that.addDataForm.vehicleNo,
        end: that.addDataForm.endTime
      }
      this.$refs[formName].validate((valid) => {
        if (valid) {
          http.claimDetailTrackList(param).then(res => {
            if (res.data && res.data.length > 0) {
              that.claimRecord = res.data.map(o => {
                const timeObj = formatSecond(o.time, true)
                o.pTime = timeObj.time
                o.pTimeText = timeObj.text
                return o
              })
              that.unitName = res.data[0].ddName + '/' + res.data[0].zdName
              that.policeNo = that.addDataForm.vehicleType
              that.duration = res.data[0].pTime
              that.durationText = res.data[0].pTimeText
              that.mileage = (res.data[0].kilometres) / 1000
              that.claimRecord.shift()
            }
          })
        } else {
          return false
        }
      })
    },
    // 当前战果轨迹
    curTrack(data, index) {
      const that = this
      const param = {
        begin: data.begin,
        deviceNo: that.addDataForm.vehicleNo,
        end: data.end
      }
      mapUtil.removeMapOverlay(this.maps, '小车运动')
      clearInterval(this.trackTime)
      this.trackTime = null
      that.trackActive = null
      http.listTrackPoints(param).then(res => {
        that.trackActive = index
        if (res.code === 200) {
          const listData = res.data || []
          const pointArr = []
          listData.forEach(o => {
            pointArr.push({
              lng: o.longBaidu,
              lat: o.latBaidu,
              longGaode: o.longGaode,
              latGaode: o.latGaode
            })
          })
          this.trackList = pointArr
          if (window.BMap) {
            if (!that.trackTimer) {
              mapUtil.removeMapOverlay(that.maps, '小车运动')
              that.trackTimer = mapUtil.trackAnimation(that.maps, that.trackList, 2000, () => {
                that.trackTimer = null
              })
            }
          } else {
            // 高德
            mapUtil.removeMapOverlay(that.maps, '小车运动')
            that.trackTimer = mapUtil.trackAnimation(that.maps, that.trackList, 2000)
          }
        }
      })
    },
    // 关闭弹窗
    closeDialog(formName) {
      this.addDataForm = {
        vehicleNo: '',
        beginTime: '',
        endTime: '',
        policeNum: ''
      }
      this.claimRecord = []
      this.$refs[formName].resetFields()
    }
  }
}
</script>

<style lang="stylus" scoped>
.interphone-container {
  .detail-content {
    width 100%
    height 520px

    .detail-list {
      width: 45%;
      height: 520px;
      overflow-y: auto;
      margin-right: 10px;
      float left

      .detail-item {
        width: 99%;
        font-size: 14px;
        padding: 0 15px;
        margin-top 5px
        margin-bottom: 14px;
        border: 1px solid #EBEBEB;
        box-shadow: 0px 3px 4px 0px rgba(47, 49, 49, 0.15);
        position: relative;
        cursor pointer

        .detail-high {
          color: #02A7F0;
          font-size: 16px;
        }
      }
      .detail-item.detail_title:before{
        content: '';
        width 10px
        height 100%
        display block
        background-color #3699FF
        position absolute
        left 0
        top 0
      }
      .detail-item.active{
        border 1px solid #02A7F0
      }
    }

    .map-div{
      width: 730px;
      height: 520px;
      z-index: 5;
      float right
    }
    #map {
      width: 730px;
      height: 520px;
    }
    .map-default {
      color #ccc
      font-size 20px
      text-align center
      position: absolute;
      bottom: 0;
      left: 0;
      background: #fff;
      z-index: 10;
      width: 1400px;
      height: 540px;
      line-height: 540px;
    }
  }

  .el-checkbox.is-bordered.el-checkbox--mini {
    padding: 0px 15px;
    line-height: 28px;

    .el-checkbox__label {
      padding: 0px;
    }
  }

  .tydic-input {
    .el-checkbox.is-bordered.el-checkbox--mini {
      width: 120px !important;
      text-align: center;
    }
  }

  .tydic-box {
    padding: 0px 0 10px;
  }

  .red-active {
    color: red;
  }

  .custom-dialog .el-form-item {
    margin-bottom: 20px;
  }

  .tydic-box .tydic-input~.tydic-input {
    margin-left: 54px;
  }

  padding: 0px 20px;

  .w200 {
    width: 200px;
  }

  .w180 {
    width: 180px;
  }

  .w140 {
    width: 140px;
  }
  .w70 {
    width: 70px
  }
}
/deep/.claim_time.el-date-editor.el-input .el-input__inner {
  padding-right 15px
}
</style>
<style lang="stylus">
.cardBox {
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  background: white;
  height: 90vh;
}

.el-checkbox.is-bordered.el-checkbox--mini .el-checkbox__inner {
  display: none !important;
}

.interphone-container {
  .label-input {
    .el-input {
      width: 200px !important;
    }
  }

  .custom-dialog {
    &.addOrEdit {
      .el-dialog__body {
        padding-right: 20px;
        padding-left: 20px;
      }
    }
  }
}
.putW.el-date-editor--datetimerange.el-input__inner{
  width 350px
}
.putW .el-input__inner, .putW .el-range-input{
  width 130px!important
}
.el-button--primary .image-icon.claim{
  background-image url("../../assets/icons/claim_icon.png")
}
</style>
