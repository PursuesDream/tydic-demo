<template>
  <div class="appraisalManage-container">
    <el-card style="margin-top:20px;height:85vh">
      <div class="tydic-box">
        <div class="tydic-input">
          考核维度：
          <el-radio-group v-model="checkType" style="width:260px">
            <el-radio v-for="(item,index) in checkTypeList" :key="index" :label="item.value" style="margin-right:30px" :disabled="item.disabled">{{ item.name }}</el-radio>
          </el-radio-group>
        </div>
        <div class="tydic-input" style="margin-left:14px">
          考核时段：
          <el-date-picker
            v-model="searchConditon.beginTime"
            class="w220"
            style="margin-left: 0;padding-left: 0;"
            type="datetime"
            value-format="yyyy-MM-dd HH:mm:ss"
            placeholder="选择日期时间"
            :picker-options="conditionStartTime"
          />
          <span style="display: inline-block;margin: 0 10px;">至</span>
          <el-date-picker
            v-model="searchConditon.endTime"
            class="w220"
            style="margin-left: 0;padding-left: 0;"
            type="datetime"
            value-format="yyyy-MM-dd HH:mm:ss"
            placeholder="选择日期时间"
            :picker-options="conditionEndTime"
          />
        </div>
        <div class="tydic-input">
          所属支队：
          <el-select v-model="searchConditon.pOrganCode" class="w220" :disabled="checkType === 1||perm.pOrganCode!==''" clearable @change="handlerZDChange">
            <el-option
              v-for="(o,index) in zhiduiList"
              :key="index"
              :label="o.name"
              :value="o.organCode"
            />
          </el-select>
        </div>
        <div class="tydic-input">
          所属大队：
          <el-select v-model="searchConditon.organCode" class="w220" :disabled="checkType !== 3||perm.organCode!==''" clearable>
            <el-option
              v-for="(o,index) in daduiList"
              :key="index"
              :label="o.name"
              :value="o.organCode"
            />
          </el-select>
        </div>
      </div>
      <div class="tydic-box">
        <div class="tydic-input" style="margin-bottom: 20px">
          民警警号：
          <el-input v-model="searchConditon.policeCode" class="w220" :disabled="checkType !== 3" clearable placeholder="请输入民警名称或警号" />
        </div>
        <div class="tydic-input" style="margin-left:54px">
          <el-button type="primary search" size="mini" @click="handleClickSearch"><i class="image-icon search" />查询</el-button>
          <el-button type="primary reset" size="mini" @click="onReset"><i class="image-icon reset" />重置</el-button>
          <el-button v-permission="'button41'" type="primary export" size="mini" style="background-color: #67c23a;border-color:#67c23a;padding-right: 22px" @click="onDownload"><i class="image-icon export" />导出</el-button>
        </div>
      </div>
      <div class="allCount">
        民警总数：<span class="numText">{{ totalCount.mjsum }}</span>人；累计执行次数<span class="numText">{{ totalCount.zqsum?totalCount.zqsum:totalCount.patrolCount }}</span>次；累计骑巡里程<span class="numText">{{ totalCount.patrolMileageXs }}</span>{{ totalCount.patrolMileageUnit }}；累计骑巡时长<span class="numText">{{ totalCount.patrolTimeXs }}</span>{{ totalCount.patrolTimeUnit }}；接警总数<span class="numText">{{ formatNum(totalCount.alarmNumber) }}</span>起；总执法量<span class="numText">{{ formatNum(totalCount.lawEnNumber) }}</span>起；
      </div>
      <el-table
        :key="checkType"
        v-loading="isLoading"
        width="1350px"
        :data="tableData"
        class="custom-table"
        max-height="500"
        header-row-class-name="custom-table-header"
        border
        stripe
        @sort-change="handleSortChange"
      >
        <el-table-column width="100" label="序号" align="center">
          <template slot-scope="scope">
            {{ scope.$index + 1 + pageSize * (curPage - 1) }}
          </template>
        </el-table-column>
        <el-table-column v-if="checkType === 3" align="center" prop="userName" label="姓名" width="140" />
        <el-table-column v-if="checkType === 3" align="center" prop="policeCode" label="警号" width="140" />
        <!-- <el-table-column v-if="checkType === 3" align="center" prop="pOrganName" label="所属支队" /> -->
        <el-table-column v-if="checkType !== 2" align="center" label="所属机构" width="450">
          <template slot-scope="scope">
            {{ scope.row.pOrganName ? scope.row.pOrganName + ' / '+ scope.row.organName : scope.row.organName }}
          </template>
        </el-table-column>
        <el-table-column v-if="checkType === 2" align="center" label="所属机构" width="450">
          <template slot-scope="scope">
            {{ scope.row.parentName ? scope.row.parentName + ' / '+ scope.row.organName : scope.row.organName }}
          </template>
        </el-table-column>
        <!-- <el-table-column v-if="checkType === 3 || checkType === 2" align="center" prop="organName" label="所属大队" /> -->
        <el-table-column v-if="checkType === 1 || checkType === 2" align="center" prop="mjsum" label="民警数量" />
        <el-table-column v-if="checkType !== 3" align="center" prop="zqsum" label="执勤次数" />
        <el-table-column v-else align="center" prop="patrolCount" label="执勤次数" />
        <el-table-column align="center" label="骑巡时长（小时）" sortable="custom" prop="patrolTime">
          <template slot-scope="scope">
            <!-- {{ formatTime(scope.row.patrolTime) }} -->
            {{ scope.row.formatTime }}
            <!--  {{ scope.row.formatTimeText }} -->
          </template>
        </el-table-column>
        <el-table-column align="center" prop="patrolMileage" label="骑巡里程（KM）" sortable="custom">
          <template slot-scope="scope">
            {{ formatMetre(scope.row.patrolMileage) }}
          </template>
        </el-table-column>
        <el-table-column align="center" prop="alarmNumber" label="接处警数（起）" sortable="custom" />
        <el-table-column align="center" prop="lawEnNumber" label="执法量（起）" sortable="custom" />
        <el-table-column v-if="checkType === 3" align="center" label="操作" width="160">
          <template slot-scope="scope">
            <el-button type="text" style="padding:0" @click="handleShowFile(scope.row)">档案</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        style="text-align: center;margin-top:30px;"
        background
        :page-size="pageSize"
        :total="total"
        :current-page.sync="curPage"
        :page-sizes="pageSizes"
        :hide-on-single-page="true"
        layout="total,prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurPageChange"
      />
    </el-card>
  </div>
</template>

<script>
import { getTotalStat, getTotalOrganStat, exportOrganStat, exportPoliceStat } from '@/api/policeReport'
import { mapGetters } from 'vuex'
import { organListByParam } from '@/api/public'
import { getMonthDays, parseTime, formatSecond } from '@/utils'
function getBeginEndTime() {
  const nowNewTime = new Date()
  const nowMonth = nowNewTime.getMonth()
  const nowYear = nowNewTime.getFullYear()
  const monthStartDate = new Date(nowYear, nowMonth, 1)
  const days = getMonthDays(nowMonth)
  const monthEndDate = new Date(nowYear, nowMonth, days)
  const beginTime = parseTime(monthStartDate, '{y}-{m}-{d}')
  const endTime = parseTime(monthEndDate, '{y}-{m}-{d}')
  return [beginTime, endTime]
}
export default {
  name: 'AppraisalManage',
  data() {
    const nowTimeArr = getBeginEndTime()
    return {
      isLoading: false,
      searchConditon: {
        pOrganCode: '',
        organCode: '',
        policeCode: '',
        beginTime: nowTimeArr[0] + ' 00:00:00',
        endTime: nowTimeArr[1] + ' 23:59:59'
      },
      oldSearchConditon: null,
      zhiduiList: [],
      daduiList: [],
      tableData: [],
      totalCount: {
        alarmNumber: '0',
        lawEnNumber: '0',
        mjsum: '0',
        patrolMileage: '0.0',
        patrolTime: '0.0',
        zqsum: '0',
        formatTime: '0',
        formatTimeText: '秒'
      },
      pageSize: 10,
      total: 0,
      curPage: 1,
      pageSizes: [10, 20, 50],
      checkType: 1,
      checkTypeList: [
        { name: '支队', value: 1, disabled: false },
        { name: '大队', value: 2, disabled: false },
        { name: '民警', value: 3, disabled: false }
      ],
      perm: {
        pOrganCode: '',
        organCode: ''
      }
    }
  },
  computed: {
    ...mapGetters([
      'showLevelObj'
    ]),
    conditionStartTime() {
      let endTime = this.searchConditon.endTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          endTime = new Date(endTime).getTime()
          if (endTime) {
            if (nowDate > endTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    },
    conditionEndTime() {
      let startTime = this.searchConditon.beginTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          startTime = new Date(startTime).getTime()
          if (startTime) {
            if (nowDate < startTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    }
  },
  watch: {
    checkType(val) {
      this.resetSearch()
      this.oldSearchConditon = null
      this.onSearch()
      if (val === 3 && this.perm.pOrganCode) {
        this.getOrgan(3, this.perm.pOrganCode)
      } else if (val !== 1) {
        this.getOrgan()
      }
    }
    /* totalCount(val) {
      this.totalCount = val
    } */
  },
  mounted() {
    this.initPage()
  },
  methods: {
    initPage() {
      this.$nextTick(() => {
        const organLevel = this.showLevelObj
        // const organLevel = { '0': [{ 'organId': 'b49a6014172e4af1beab907acea59a0e', 'name': '东城交通支队', 'organCode': '110100000000', 'parentCode': '110000000000', 'selfCode': '2', 'isLeaf': null, 'firstChecked': false, 'checked': false, 'orgLevel': 0 }], '1': [{ 'organId': '6317e29d1867483ab0b97e5a6218057e', 'name': '和平里大队', 'organCode': '110104000000', 'parentCode': '110100000000', 'selfCode': '11', 'isLeaf': null, 'firstChecked': false, 'checked': false, 'orgLevel': 1 }] }
        // console.info(JSON.stringify(organLevel))
        // 禁用支队和大隊选择
        const disabledZJDD = () => {
          this.checkTypeList[0].disabled = true
          this.checkTypeList[1].disabled = true
          this.checkType = 3
          this.perm.pOrganCode = organLevel.ZD[0].organCode
          this.perm.organCode = organLevel.DD[0].organCode
          this.zhiduiList = organLevel.ZD
          this.daduiList = organLevel.DD
          this.resetSearch()
        }
        // 禁用支队选择
        const disabledZD = () => {
          this.checkTypeList[0].disabled = true
          this.checkType = 2
          this.perm.pOrganCode = organLevel.ZD[0].organCode
          this.zhiduiList = organLevel.ZD
          this.resetSearch()
        }
        switch (organLevel.level) {
          case 1:
            disabledZD()
            break
          case 2:
            disabledZJDD()
            break
          default:
            this.onSearch()
            break
        }
      })
    },
    handleClickSearch() {
      this.curPage = 1
      this.oldSearchConditon = null
      this.onSearch()
    },
    onReset() {
      this.resetSearch()
      const nowTimeArr = getBeginEndTime()
      this.searchConditon.beginTime = nowTimeArr[0] + ' 00:00:00'
      this.searchConditon.endTime = nowTimeArr[1] + ' 23:59:59'
      this.oldSearchConditon = null
      this.onSearch()
    },
    onSearch() {
      let params = {}
      if (this.oldSearchConditon) {
        params = { ...this.oldSearchConditon }
      } else {
        params = {
          ...this.searchConditon
        }
        if (params.beginTime === null) params.beginTime = ''
        if (params.endTime === null) params.endTime = ''
        delete params.name
        if (this.checkType === 1) {
          delete params.pOrganCode
          delete params.policeCode
        } else if (this.checkType === 2) {
          delete params.policeCode
        }
        if (this.checkType !== 3) params.qType = this.checkType
        this.oldSearchConditon = { ...params }
      }
      params.pageNum = this.curPage
      this.pageSize = this.checkType === 1 ? 20 : 10
      params.pageSize = this.pageSize
      this.isLoading = true
      const fnIndex = this.checkType
      const requestFn = ['', getTotalOrganStat, getTotalOrganStat, getTotalStat]
      requestFn[fnIndex](params).then(res => {
        if (res.code === 200) {
          const resData = res.data
          if (resData.rows.length > 0) {
            this.totalCount = resData.rows.pop()
            // const timeObj = formatSecond(this.totalCount.patrolTime, true)
            // this.totalCount.formatTime = this.totalCount.patrolTimeXs
            // this.totalCount.formatTimeText = this.totalCount.patrolTimeUnit
            if (this.checkType === 3) {
              this.totalCount.mjsum = resData.total
            }
          } else {
            this.totalCount = {
              alarmNumber: '0',
              lawEnNumber: '0',
              mjsum: '0',
              patrolMileage: '0.0',
              patrolTime: '0.0',
              zqsum: '0',
              formatTime: '0',
              formatTimeText: '秒'
            }
          }
          this.tableData = resData.rows.map(o => {
            const timeObj = formatSecond(o.patrolTime, true)
            o.formatTime = timeObj.time
            o.formatTimeText = timeObj.text
            return o
          })
          this.total = resData.total
        }
        this.isLoading = false
      }).catch(_ => {
        this.isLoading = false
      })
    },
    handleSortChange(data) {
      this.curPage = 1
      const { prop, order } = data
      const orderBy = order === 'ascending' ? 'ASC' : 'DESC'
      this.oldSearchConditon.orderBy = orderBy
      this.oldSearchConditon.sort = prop
      this.onSearch()
    },
    getOrgan(level = 1, parentCode = '') {
      const organizeCode = window.CONFIG.organizeCode
      let orgLevel = ''
      const params = {
        // orgSubType: 0,
        auth: true,
        parentCode
      }
      if (level === 1) {
        orgLevel = organizeCode.first
      } else if (level === 2 || level === 3) orgLevel = organizeCode.second
      if (parentCode) params.parentCode = parentCode
      params.orgLevel = orgLevel
      organListByParam(params).then(res => {
        if (res.code === 200) {
          if (!parentCode) this.zhiduiList = res.data
          else this.daduiList = res.data
        }
      })
    },
    handleSizeChange(val) {
      this.curPage = 1
      this.pageSize = val
      this.onSearch()
    },
    handleCurPageChange(val) {
      this.curPage = val
      this.onSearch()
    },
    handlerZDChange(val) {
      if (val) {
        const type = this.checkType
        this.searchConditon.organCode = ''
        if (type === 3) this.getOrgan(3, val)
      } else {
        this.searchConditon.organCode = ''
        this.daduiList = []
      }
    },
    resetSearch() {
      this.curPage = 1
      this.searchConditon.pOrganCode = this.perm.pOrganCode
      this.searchConditon.organCode = this.perm.organCode
      this.searchConditon.policeCode = ''
    },
    handleShowFile(row) {
      const timeRange = this.searchConditon.beginTime + ';' + this.searchConditon.endTime
      this.$router.push({
        name: 'PoliceDetail',
        params: {
          id: row.policeCode,
          timeRange
        }
      })
    },
    formatTime(val) {
      let time = val || 0
      time = parseFloat(time)
      let patrolTime = time / 60
      patrolTime = parseFloat(patrolTime).toFixed(1)
      return patrolTime
    },
    formatMetre(val) {
      let metre = val || 0
      metre = parseFloat(metre)
      let Mileage = metre / 1000
      Mileage = parseFloat(Mileage).toFixed(1)
      return Mileage
    },
    formatNum(val) {
      let newNum = val || 0
      newNum = Math.round(val)
      return newNum
    },
    // 按支队、大队导出
    exportOrgan(param) {
      exportOrganStat(param).then(res => {
        const url = window.URL.createObjectURL(new Blob([res]))
        const link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        const fileName = '考核列表.xlsx'
        link.setAttribute('download', fileName)
        document.body.appendChild(link)
        link.click()
      })
    },
    // 按警员导出
    exportPolice(param) {
      exportPoliceStat(param).then(res => {
        const url = window.URL.createObjectURL(new Blob([res]))
        const link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        const fileName = '考核列表.xlsx'
        link.setAttribute('download', fileName)
        document.body.appendChild(link)
        link.click()
      })
    },
    // 导出
    onDownload() {
      const that = this
      /* const param = {
        qType: that.checkType,
        beginTime: that.searchConditon.beginTime,
        endTime: that.searchConditon.endTime,
        organCode: that.searchConditon.pOrganCode,
        pOrganCode: that.searchConditon.organCode,
        policeCode: that.searchConditon.policeCode
      } */
      const param = { ...this.oldSearchConditon }
      const pOrganCode = param.pOrganCode
      const organCode = param.organCode
      param.pOrganCode = pOrganCode
      param.organCode = organCode
      param.checkType = param.checkType || 3
      if (that.checkType === 1 || that.checkType === 2) {
        that.exportOrgan(param)
      } else if (that.checkType === 3) {
        that.exportPolice(param)
      }
    }
  }
}
</script>

<style scoped lang="stylus">
.appraisalManage-container {
  padding 0px 20px 10px
  .tydic-input~.tydic-input {
    margin-left 60px
  }
  .w220 {
    width: 220px;
  }
  .allCount{
    height:60px
    line-height 60px
    background-color #dbf5fd
    margin-bottom 10px
    text-indent 10px
    .numText{
      font-size 18px
      padding:0px 10px
      font-weight:bold
    }
  }
}
</style>
<style lang="stylus">
.appraisalManage-container {
  .custom-table {
    td {
      padding 10px 0
    }
  }
}
</style>
