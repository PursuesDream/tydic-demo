<template>
  <div class="assess-container">
    <el-form v-model="searchForm" :inline="true">
      <el-form-item class="form_item" label="日期">
        <el-date-picker
          v-model="searchForm.beginTime"
          class="w220"
          style="margin-left: 0;padding-left: 0;"
          type="datetime"
          value-format="yyyy-MM-dd HH:mm:ss"
          placeholder="选择日期时间"
          :picker-options="conditionStartTime"
        />
        <span style="display: inline-block;margin: 0 10px;">至</span>
        <el-date-picker
          v-model="searchForm.endTime"
          class="w220"
          style="margin-left: 0;padding-left: 0;"
          type="datetime"
          value-format="yyyy-MM-dd HH:mm:ss"
          placeholder="选择日期时间"
          :picker-options="conditionEndTime"
        />
      </el-form-item>
      <el-form-item class="form_item" label="分组">
        <el-select v-model="searchForm.group" placeholder="请选择">
          <el-option v-for="(item, index) in groupList" :label="item.groupName" :value="item.groupId" :key="index"/>
        </el-select>
      </el-form-item>
      <el-form-item class="form_item" label="所属单位">
        <PermissionTree :select-object="searchForm" :select-value="'orgCode'" :default-name="'name'" input-class="input-class-search" @tree-click="handleTreeClick1" />
      </el-form-item>
      <el-form-item>
        <el-button type="success" @click="searchData">查询</el-button>
        <el-button type="primary" @click="" @click="exportData">导出</el-button>
        <el-button type="warning" style="margin-left: 10px">取消</el-button>
      </el-form-item>
    </el-form>
    <div>
      <el-table
        :data="tableData"
        style="width: 100%;"
        :span-method="tableFormat"
      >
        <el-table-column prop="groupName" label="分组" align="center" />
        <el-table-column label="单位" align="center">
          <el-table-column label="所属支队" align="center" prop="parentOrganName" />
          <el-table-column label="所属中队" align="center" prop="organName" />
        </el-table-column>
        <el-table-column label="见警率" align="center">
          <el-table-column align="center" prop="attendance" label="骑警出勤(人数)" />
          <el-table-column align="center" prop="attendanceRatio" label="骑警出勤率(%)" />
          <el-table-column align="center" prop="leaderAttendance" label="干部出勤(次数)" />
          <el-table-column align="center" prop="avgLeaderAttendance" label="干部出勤率(%)" />
          <el-table-column align="center" prop="useDeviceTotal" label="车辆使用(辆)" />
          <el-table-column align="center" prop="deviceRatio" label="车辆使用率(%)" />
          <el-table-column align="center" prop="qrCodeHundred" label="人均骑警扫码(次数)" />
        </el-table-column>
        <el-table-column label="勤奋度" align="center">
          <el-table-column align="center" prop="kilometresHundred" label="百警骑巡里程(km)" />
          <el-table-column align="center" prop="patrolTimeHundred" label="百警骑巡时长(小时)" />
        </el-table-column>
        <el-table-column label="管事" align="center">
          <el-table-column align="center" prop="lawEnNumber" label="铁骑百警执法数" />
          <el-table-column align="center" prop="alarmNumber" label="铁骑百警接处警数" />
        </el-table-column>
      </el-table>
      <!--<div style="text-align: center;margin-top: 20px">
        <el-pagination
          :current-page="curPage"
          :page-sizes="[100, 200, 300, 400]"
          :page-size="100"
          layout="total, prev, pager, next, sizes, jumper"
          :total="400"
        />
      </div>-->
    </div>
  </div>
</template>

<script>
import PermissionTree from '@/components/permissionTree'
import http from '@/api/assessStatistics'
export default {
  name: 'AssessStatistics',
  data() {
    return {
      searchForm: {
        beginTime: '',
        endTime: '',
        group: '',
        orgCode: '',
        name: ''
      },
      groupList: [],
      tableData: [],
      curPage: 1,
      spanArr: [],
      pos: ''
    }
  },
  components: {
    PermissionTree
  },
  computed: {

    conditionStartTime() {
      let endTime = this.searchForm.endTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          endTime = new Date(endTime).getTime()
          if (endTime) {
            if (nowDate > endTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    },
    conditionEndTime() {
      let startTime = this.searchForm.beginTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          startTime = new Date(startTime).getTime()
          if (startTime) {
            if (nowDate < startTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    }
  },
  created() {
    this.getGroupList()
  },
  mounted() {
    this.searchData()
  },
  methods: {
    // 获取分组列表
    getGroupList () {
      const that = this
      http.getAssessGroupData({ groupName: '' }).then(res => {
        that.groupList = res.data
      })
    },
    // 查询数据
    searchData() {
      const that = this
      const param = {
        beginTime: that.searchForm.beginTime,
        endTime: that.searchForm.endTime,
        groupId: that.searchForm.group,
        organ: that.searchForm.orgCode,
        type: ''
      }
      http.getPoliceAssessData(param).then(res => {
        that.tableData = res.data
        that.mergeTableRow(that.tableData, ['groupName', 'parentOrganName'])
      })
    },
    // 导出数据
    exportData() {
      const that = this
      const params = {
        beginTime: that.searchForm.beginTime,
        endTime: that.searchForm.endTime,
        groupId: that.searchForm.group,
        organ: that.searchForm.orgCode,
        type: ''
      }
      http.exportAssessData(params).then(res => {
        const url = window.URL.createObjectURL(new Blob([res]))
        const link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        const fileName = '考核统计.xlsx'
        link.setAttribute('download', fileName)
        document.body.appendChild(link)
        link.click()
      })
    },
    mergeTableRow(data, merge) {
      if (!merge || merge.length === 0) {
        return data
      }
      merge.forEach((m) => {
        const mList = {}
        data = data.map((v, index) => {
          const rowVal = v[m]
          if (mList[rowVal] && mList[rowVal].newIndex === index) {
            mList[rowVal]['num']++
            mList[rowVal]['newIndex']++
            data[mList[rowVal]['index']][m + '-span'].rowspan++
            v[m + '-span'] = {
              rowspan: 0,
              colspan: 0
            }
          } else {
            mList[rowVal] = { num: 1, index: index, newIndex: index + 1 }
            v[m + '-span'] = {
              rowspan: 1,
              colspan: 1
            }
          }
          return v
        })
      })
    },
    tableFormat({ row, column, rowIndex, columnIndex }) {
      const span = column['property'] + '-span'
      if (row[span]) {
        return row[span]
      }
    },
    /* 查询单位树点击回调事件 */
    handleTreeClick1(data) {

    },
  }
}
</script>

<style scoped>
  .assess-container {
    height: 85vh;
    border: 1px solid #e6ebf5;
    background-color: #FFFFFF;
    margin: 10px 20px;
    padding: 20px;
  }
  .assess-container .form_item{
    margin-right: 36px;
  }
</style>
