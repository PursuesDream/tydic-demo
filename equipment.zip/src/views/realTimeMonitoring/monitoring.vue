<template>
  <div class="monitoring-container">
    <div id="mapBox" />
    <div class="leftBox">
      <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
        <el-tab-pane label="实时定位" name="first">
          <div class="tabsBox" style="padding-left: 0px">
            <div class="search-box">
              <el-input v-model="filterText" placeholder="请输入车牌号码进行匹配" />
              <!-- <el-button class="search-button" size="small" @click="getTreeData">查询</el-button> -->
            </div>
            <el-tree
              ref="myTree"
              v-loading="treeLoading"
              element-loading-text="玩命加载中"
              element-loading-background="rgba(0, 0, 0, 1)"
              :accordion="true"
              class="map-tree"
              node-key="organCode"
              :props="defaultProps"
              :default-expanded-keys="defaultExpandArr"
              :filter-node-method="filterNode"
              :data="treeData"
              @node-click="handleNodeClick"
              @node-expand="getCarByOrg"
            >
              <span slot-scope="{ node, data }" class="custom-tree-node">
                <span>{{ node.label||data.name || '' }}</span>
              </span>
            </el-tree>
          </div>
        </el-tab-pane>
        <el-tab-pane label="轨迹回放" name="second">
          <div class="tabsBox second">
            <el-form>
              <el-form-item>
                <el-col :span="24">
                  <i class="fontcolor-r">*&nbsp;</i>车牌号码
                </el-col>
                <el-col :span="24">
                  <el-input v-model="formData.vehicleNo" placeholder="请输入关键字进行匹配" />
                </el-col>
              </el-form-item>
              <el-form-item>
                <el-col :span="24">
                  <i class="fontcolor-r">*&nbsp;</i>开始时间：
                </el-col>
                <el-col :span="24">
                  <el-date-picker
                    v-model="formData.beginTime"
                    type="datetime"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    placeholder="开始时间"
                  />
                </el-col>
              </el-form-item>
              <el-form-item>
                <el-col :span="24">
                  <i class="fontcolor-r">*&nbsp;</i>结束时间：
                </el-col>
                <el-col :span="24">
                  <el-date-picker
                    v-model="formData.endTime"
                    type="datetime"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    placeholder="结束时间"
                    :picker-options="endTime"
                  />
                </el-col>
              </el-form-item>
              <el-form-item>
                <el-col :span="24">
                  <i class="fontcolor-r">*&nbsp;</i>播放倍数：
                </el-col>
                <el-col :span="24">
                  <el-select v-model="formData.speedSelect" placeholder="">
                    <el-option label="正常速度" value="200" />
                    <el-option label="x2倍" value="100" />
                    <el-option label="x3倍" value="65" />
                    <el-option label="x4倍" value="50" />
                  </el-select>
                </el-col>
              </el-form-item>
              <el-form-item>
                <!-- <div style="text-align: center">
                  <el-button type="primary color1" size="mini" style="margin-left: 5px" @click="onSearch('track')">查询</el-button>
                </div> -->
                <el-button class="search-button" size="small" @click="onSearch('track')">查询</el-button>
              </el-form-item>
            </el-form>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
    <div class="tableBox">
      <div class="showOrHide" title="点击打开预警信息表格" @click="showTable = !showTable"><i :class="showTable ? 'el-icon-d-arrow-right':'el-icon-d-arrow-left'" /></div>
      <!-- <p v-show="showTable" class="tableTitle"><span>预警信息</span></p> -->
      <el-table
        v-show="showTable"
        width="1200px"
        :data="tableData"
        class="map-table"
        max-height="300"
        style="background: #000000b0"
        header-row-class-name="tableHader"
      >
        <el-table-column type="index" width="50" label="序号" align="center" />
        <el-table-column align="center" prop="vehicleNo" label="车牌号" :show-overflow-tooltip="true" />
        <el-table-column align="center" prop="policeCode" label="警号" :show-overflow-tooltip="true" />
        <el-table-column prop="policeName" align="center" label="姓名" :show-overflow-tooltip="true" />
        <el-table-column prop="beginTime" align="center" label="位置时间" :show-overflow-tooltip="true" />
        <el-table-column prop="position" align="center" label="位置" :show-overflow-tooltip="true" />
        <el-table-column prop="speedingType" align="center" label="报警类型" :show-overflow-tooltip="true">
          <template slot-scope="scope">
            {{ scope.row.speedingType===1?'超速': '' }}
          </template>
        </el-table-column>
        <el-table-column prop="speedingContent" align="center" label="报警内容" :show-overflow-tooltip="true" />
        <el-table-column align="center" label="操作">
          <template slot-scope="scope">
            <el-button type="text" @click="handleTrack(scope.row)">轨迹回放</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import mapUtil from '@/utils/map/mapUtil'
import { mapState } from 'vuex'
import { getPointList, getMapPoint, getTreeList, getWarnTrack } from '@/api/realTimeMonitoring'
import { parseTime } from '@/utils'
// 因为BMap是挂在window对象上的，防止报错要加上window
const BMap = window.BMap
// const BMapLib = window.BMapLib
export default {
  name: 'MonitoringPage',
  data() {
    return {
      formData: {
        vehicleNo: '',
        beginTime: '',
        endTime: '',
        speedSelect: '200'
      },
      treeLoading: false,
      activeName: 'first',
      moveSpeed: 200,
      curPage: 1,
      pageTotal: 0,
      pageSize: 10,
      total: 0,
      maps: '',
      pageSizes: [10, 20, 30],
      defaultExpandArr: [],
      showTable: false,
      treeData: [],
      filterText: '',
      defaultProps: {
        children: 'voList',
        label: 'orgName'
      },
      markerClusterer: {},
      daduiList: [
        { name: '龙岗大队', value: '1', isEdit: false },
        { name: '罗湖大队', value: '2', isEdit: false },
        { name: '福田大队', value: '3', isEdit: false }
      ],
      zhongduiList: [
        { name: '一中队', value: '1' },
        { name: '二中队', value: '2' },
        { name: '三中队', value: '3' }
      ],
      tableData: [],
      trackDatas: [],
      pointData: []
    }
  },
  computed: {
    ...mapState({
      mapData: state => state.user.mapData
    }),
    endTime() {
      let startTime = this.formData.beginTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          startTime = new Date(startTime).getTime()
          if (nowDate < startTime) return true
          else return false
        }
      }
    }
  },
  watch: {
    filterText(val) {
      this.$refs.myTree.filter(val)
    }
  },
  mounted() {
    const _this = this
    const BMap = window.BMap
    _this.maps = new BMap.Map('mapBox')
    const point = new BMap.Point(114.07133413302, 22.565826182576)
    // const point2 = new BMap.Point(114.154658527, 22.2878)
    _this.maps.centerAndZoom(point, 13)
    const marker = new BMap.Marker(point)
    marker.disableDragging()
    _this.maps.enableScrollWheelZoom() // 启用滚轮放大缩小，默认禁用
    _this.maps.enableContinuousZoom() // 启用地图惯性拖拽，默认禁用
    // var b = new BMap.Bounds(new BMap.Point(113.67553705232179, 22.44949218084102), new BMap.Point(114.40300549862594, 22.69988171556216)) // 范围 左下角，右上角的点位置
    // try {
    //   BMapLib.AreaRestriction.setBounds(_this.maps, b) // 已map为中心，已b为范围的地图
    // } catch (e) {
    //   // 捕获错误异常
    //   alert(e)
    // }
    _this.formatDate()
    _this.getWarnList('')
    _this.onSearch('')
    _this.getTreeData()
  },
  methods: {
    filterNode(value, data) {
      if (!value) return true
      const name = data.orgName || data.name || ''
      return name.indexOf(value) !== -1
    },
    /**
    *时间格式化
    */
    formatDate() {
      const _this = this
      // 获取格林时间
      var date1 = new Date(new Date(new Date().toLocaleDateString()).getTime())
      const myDate = new Date()
      _this.formData.beginTime = parseTime(date1)
      _this.formData.endTime = parseTime(myDate)
    },
    /**
     * 查询树状结构列表
     */
    getTreeData() {
      const _this = this
      _this.treeData = []
      _this.treeLoading = true
      const param = {
        vehicleNo: _this.filterText
      }
      getTreeList(param).then(res => {
        if (res.code === 200) {
          const listData = res.data
          _this.treeLoading = false
          listData.leaf = listData.voList.length === 0
          _this.treeData.push(listData)
          _this.$nextTick(_this.filterArr())
        }
      })
    },
    /**
     * 获取预警信息列表
     */
    getWarnList(val) {
      const _this = this
      const vehicleNo = val
      _this.tableData = []
      getPointList(vehicleNo).then(res => {
        if (res.code === 200) {
          _this.tableData = res.data.rows
        }
      })
    },
    /**
     * tabs切换
     */
    handleClick(tab, event) {
      const _this = this
      let layerId = ''
      let layerId2 = ''
      _this.showTable = false
      if (tab.index === '0') {
        layerId = '小车运动'
        mapUtil.removeMapOverlay(_this.maps, layerId)
        this.addPoint()
        _this.getWarnList('')
        _this.formData.vehicleNo = ''
        _this.formatDate()
      } else if (tab.index === '1') {
        _this.tableData = []
        this.filterText = ''
        if (window.lastInfoBox) {
          window.lastInfoBox.close()
        }
        this.markerClusterer.clearMarkers()
        layerId = '实时'
        mapUtil.removeMapOverlay(_this.maps, layerId)
        layerId2 = '小车运动'
        mapUtil.removeMapOverlay(_this.maps, layerId2)
      }
    },
    /**
    * 当前点击节点
    */
    handleNodeClick(data) {
      const _this = this
      if (data.longBaidu === null) {
        this.getCarByOrg(data)
      } else {
        if (window.lastInfoBox) {
          window.lastInfoBox.close()
        }
        // mapUtil.addAreaPoint(_this.maps, data, layerId)
        const point = new BMap.Point(data.longBaidu, data.latBaidu)
        // _this.maps.setCenter(point, 15)
        _this.maps.centerAndZoom(point, 19)
        _this.showTable = true
        const vehicleNo = this.filterText || data.name
        getPointList(vehicleNo).then(res => {
          if (res.code === 200) {
            _this.tableData = res.data.rows
          }
        })
        // _this.getWarnList(data.vehicleNo)
      }

      // const layerId = '实时'
      // mapUtil.removeMapOverlay(_this.maps, layerId)
    },
    /**
     * 根据机构查询车辆
     */
    getCarByOrg(val) {
      const _this = this
      const params = {
        orgCode: val.organCode
      }
      getMapPoint(params).then(res => {
        if (res.code === 200) {
          let pointData = []
          const newArr = []
          pointData = res.data
          pointData.map(item => {
            item.voList = []
            item.orgName = item.vehicleNo
            item.organCode = item.vehicleNo
            newArr.push(item)
          })
          newArr.map(item => {
            const datas = _this.$refs.myTree.getNode(item)
            if (datas === null) {
              _this.$refs.myTree.append(item, val)
            }
          })
        }
      })
    },
    /**
    *遍历树节点数据
    */
    filterArr() {
      const _this = this
      const arr = []
      for (let i = 0; i < _this.treeData.length; i++) {
        arr.push(_this.treeData[i].organCode)
      }
      _this.defaultExpandArr = arr
    },
    getRules(message, trigger = 'change') {
      return { required: true, message: message + '不能为空！', trigger }
    },
    /**
    * 地图打点
    */
    addPoint(val) {
      const _this = this
      const layerId = '实时'
      const param = {
        orgCode: '',
        containChild: ''
      }
      mapUtil.removeMapOverlay(_this.maps, layerId)
      if (window.lastInfoBox) {
        window.lastInfoBox.close()
      }
      getMapPoint(param).then(res => {
        if (res.code === 200) {
          _this.pointData = res.data
          const markers = res.data.map(item => {
            return mapUtil.addAreaPoint(_this.maps, item, layerId)
          })
          // 聚合
          this.markerClusterer = mapUtil.markerClustersPoint(_this.maps, markers)
        }
      })
    },
    /**
    * 条件查询
    */
    onSearch(val) {
      const _this = this
      if (val === 'track') {
        if (_this.formData.vehicleNo === '') {
          _this.$message.warning({
            message: '请输入车牌号码!',
            duration: 1500,
            showClose: true

          })
          return false
        }
        _this.handleTrack()
      } else {
        const layerId = '实时'
        mapUtil.removeMapOverlay(_this.maps, layerId)
        _this.addPoint('')
      }
    },
    /**
    * 地图轨迹回放
    */
    handleTrack(val) {
      const _this = this
      let layerId = ''
      layerId = '实时'
      mapUtil.removeMapOverlay(_this.maps, layerId)
      layerId = '小车运动'
      mapUtil.removeMapOverlay(_this.maps, layerId)
      this.markerClusterer.clearMarkers()
      let param = {}
      if (val) {
        param = {
          beginTime: val.beginTime,
          endTime: val.endTime,
          vehicleNo: val.vehicleNo
        }
      } else {
        param = {
          beginTime: _this.formData.beginTime,
          endTime: _this.formData.endTime,
          vehicleNo: _this.formData.vehicleNo
        }
      }
      if (_this.formData.speedSelect !== '') {
        _this.moveSpeed = _this.formData.speedSelect
      }
      getWarnTrack(param).then(res => {
        if (res.code === 200) {
          const pointArr = []
          res.data.forEach(item => {
            pointArr.push(new BMap.Point(item.longBaidu, item.latBaidu))
          })
          mapUtil.trackAnimation(_this.maps, pointArr, _this.moveSpeed)
        }
      }).catch(err => {
        console.log(err)
      })
    },
    /**
    * 重置
    */
    onReset() {
    //   const _this = this
      console.log('这是查询')
    }
  }
}
</script>

<style lang="stylus" scoped>
html, body {
  height 100%
 }
.map-tree {
  margin 0 14px
  height calc(100vh - 220px)
  overflow-y auto
  background-color transparent
  color white
  &::-webkit-scrollbar-track-piece {
    background-color #0b2d3f
  }
  &::-webkit-scrollbar {
    width:4px;
    height:4px;
  }
  &::-webkit-scrollbar-thumb {
    background-color #186e90;
  }
  &::-webkit-scrollbar-thumb:hover {
    background-color #186e90
  }
}
.monitoring-container {
  width 100%
  height 100%
  // position relative
  .fontcolor-r{
    color: red;
  }
  .w200 {
    width 200px
  }
  .w180 {
    width 180px
  }
  .w140 {
    width 140px
  }
  #mapBox{
    width 100%
    height 100%
  }
  .leftBox{
    width 240px
    height 820px
    background-color rgba(0,0,0,0.7)
    position absolute
    left 0px
    top 0px
  }
  /deep/.leftBox .el-tabs--card > .el-tabs__header .el-tabs__item{
    width 120px
    height 32px
    line-height 30px
    border 1px solid #3274e1
    text-align center
    color #fff
  }
  /deep/.leftBox .el-tabs--card > .el-tabs__header .el-tabs__item.is-active{
    background-color #3274e1
    border 0
    height 32px
    line-height 30px
    vertical-align 1px
  }
  .tableBox{
    position absolute
    bottom 10px
    left 50%
    transform translateX(-50%)
    width 1200px;
  }
  .tableTitle{
    background #02a7f0
    color #fff
    height 30px
    width 100%
    line-height 30px
    text-indent 20px
    margin 0px
  }
  .tabsBox{
    // padding-left 15px
    &.second {
      padding 10px 16px 0
      color white
      .el-form-item {
        margin-bottom 5px
      }
      .el-input {
        width 100%
        input {
          background-color rgba(46,49,146,0.5)
          border 1px solid #3274e1
          color white
          height 32px
          line-height 32px
        }
      }
      .el-select{
        width 100%
      }
    }
    .search-button {
      width 100%
      margin-top 16px
      background-color rgba(46,49,146,0.8)
      border-color #3274e1
      color #fff
    }
  }
}
/deep/.el-table--medium td {
  padding 7px 0
}
.showOrHide {
    width 100px
    height 24px
    margin 0 auto
    transform translateX(-50%)
    background-color transparent
    position relative
    background-image url('../../assets/mapIcon/liuxunTab.png')
    background-repeat no-repeat
    background-size 100% 100%
    z-index 9999
    color #2861b7
    cursor pointer
    text-align center
    line-height 30px
    .el-icon-d-arrow-right {
      transform rotate(90deg)
    }
    .el-icon-d-arrow-left {
      transform rotate(90deg)
    }
  }
</style>
<style lang="stylus">
.monitoring-container {
  .leftBox {
    .el-tabs {
      .el-tabs__header {
        border-bottom 0
        margin-bottom 0
      }
      .el-tabs__nav {
        border 0
      }
    }
    .tabsBox {
      &.second {
        .el-input {
          input {
            background-color rgba(46,49,146,0.5)
            border 1px solid #3274e1
            color white
            height 32px
            line-height 32px
          }
        }
      }
    }
    .search-box {
      padding 20px 14px
      .el-input {
        input {
          background-color rgba(46,49,146,0.5)
          border 1px solid #3274e1
          color white
          height 32px
          line-height 32px
        }
      }
    }
    .map-tree {
      .el-tree-node__content:hover {
        background-color transparent
        color #00ffff
      }
      .el-tree-node:focus {
        > .el-tree-node__content {
          background-color transparent
          color #00ffff
        }
      }
    }
    .custom-tree-node {
      font-size 14px
    }
  }
  .map-table {
    &.el-table th.is-leaf {
      border-bottom none
    }
    .el-table__body-wrapper {
      .el-table__body {
        width 1196px!important
      }
      &::-webkit-scrollbar-track-piece {
        background-color #0b2d3f
      }
      &::-webkit-scrollbar {
        width:4px;
        height:4px;
      }
      &::-webkit-scrollbar-thumb {
        background-color #186e90;
      }
      &::-webkit-scrollbar-thumb:hover {
        background-color #186e90
      }
    }
  }
}
</style>
