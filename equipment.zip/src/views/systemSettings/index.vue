<template>
  <div class="EqSetting-container">
    <div class="settingContent">
      <div class="leftBox">
        <el-card style="height:100%">
          <div class="tydic-input">
            <el-input
              v-model="filterText"
              placeholder="请输入"
              clearable
              style="width：250px;margin-right:17px"
            />
            <el-button
              v-permission="'button46'"
              size="small"
              @click="increaseNode"
            >+</el-button>
          </div>
          <div class="treeBox">
            <el-scrollbar style="height:720px">
              <el-tree
                ref="tree"
                :data="treeData"
                :props="defaultProps"
                :default-expanded-keys="[nodeCode]"
                :current-node-key="nodeCode"
                node-key="id"
                :draggable="true"
                :accordion="true"
                :filter-node-method="filterNode"
                :render-content="renderContent"
                :allow-drag="allowDrag"
                @node-drag-end="canPutin"
                @node-click="handleNodeClick"
              />
            </el-scrollbar>
          </div>
        </el-card>
      </div>
      <div class="rightBox">
        <el-card style="height:100%">
          <div>
            <el-button
              v-if="isEdit === false && isInitPage "
              v-permission="'button47'"
              type="primary color-commit"
              size="mini"
              @click="isEdit = true"
            >编辑</el-button>
            <el-button
              v-if="isEdit === false && isInitPage "
              v-permission="'button48'"
              type="primary color-commit"
              size="mini"
              @click="deleteNode"
            >删除</el-button>
            <el-button
              v-if="isEdit || isInitPage === false"
              type="primary color-commit"
              size="mini"
              @click="saveData"
            >保存</el-button>
            <el-button
              v-if="isEdit || isInitPage === false"
              type="primary color-cancel"
              size="mini"
              @click="handleCancel"
            >取消</el-button>
          </div>
          <el-scrollbar style="height:740px">
            <div style="margin-top:10px">
              <el-form ref="nodeForm" :inline="true" class="apply-form" :model="nodeForm" label-width="92px">
                <div class="border-box">
                  <el-form-item label="名称：" prop="categoryName" :rules="getRules('名称')">
                    <el-input v-model="nodeForm.categoryName" placeholder="请输入" :maxlength="50" :disabled="isEdit === false && isInitPage" />
                  </el-form-item>
                  <el-form-item label="是否启用：" prop="states" :rules="getRules('是否启用')" label-width="120px">
                    <el-radio-group v-model="nodeForm.states" :disabled="isEdit === false && isInitPage" @change="changeState">
                      <el-radio v-for="(item,index) in checkTypeList" :key="index" :label="item.value" style="margin-right:30px">{{ item.name }}</el-radio>
                    </el-radio-group>
                  </el-form-item>
                  <el-form-item label="类型：" prop="categoryLevel" :rules="getRules('类型')">
                    <el-select v-model="nodeForm.categoryLevel" clearable :disabled="canCheck || childrenType !== null">
                      <el-option
                        v-for="(o,index) in typeList"
                        :key="index"
                        :label="o.name"
                        :value="o.value"
                      />
                    </el-select>
                  </el-form-item>
                  <el-form-item label="备注信息：" prop="remark" style="margin-right:0px">
                    <el-input v-model="nodeForm.remark" style="width:1338px" placeholder="请输入" :disabled="isEdit === false && isInitPage" :maxlength="2000" type="textarea" show-word-limit :autosize="{minRows: 5,maxRows: 5}" />
                  </el-form-item>
                </div>
                <div v-if="showAttr" class="formBox">
                  <p class="titleP">
                    属性设置
                    <el-button
                      size="small"
                      style="margin-left:89%"
                      :disabled="isEdit === false && isInitPage"
                      @click="addAttr"
                    >添加</el-button>
                  </p>
                  <!-- <el-scrollbar style="height:300px"> -->
                  <el-table :data="nodeForm.categoryAttrList" class="attrTable">
                    <el-table-column
                      label="英文名称"
                      align="center"
                    >
                      <template slot-scope="scope">
                        <el-form-item label="" :prop="'categoryAttrList.'+scope.$index+'.attrEnName'" :rules="getRules('英文名称')">
                          <el-input v-model="scope.row.attrEnName" size="small" :disabled="scope.row.isInit === 1 || isEdit === false && isInitPage" />
                        </el-form-item>
                      </template>
                    </el-table-column>
                    <el-table-column
                      label="属性名称"
                      align="center"
                    >
                      <template slot-scope="scope">
                        <el-form-item label="" :prop="'categoryAttrList.'+scope.$index+'.attrName'" :rules="getRules('属性名称')">
                          <el-input v-model="scope.row.attrName" size="small" :disabled="scope.row.isInit === 1 || isEdit === false && isInitPage" />
                        </el-form-item>
                      </template>
                    </el-table-column>
                    <el-table-column
                      label="属性值"
                      align="center"
                    >
                      <template slot-scope="scope">
                        <el-form-item label="" :prop="'categoryAttrList.'+scope.$index+'.attrValue'" :show-message="scope.row.paramType === 1 ? true : false" :rules="scope.row.paramType === 1 ? rules.attrValue:[{ required: false, message: '请输入属性值！', trigger: 'change' }]">
                          <el-input v-model="scope.row.attrValue" :disabled="scope.row.paramType === 2 || scope.row.isInit === 1 || isEdit === false && isInitPage" size="small" />
                        </el-form-item>
                      </template>
                    </el-table-column>
                    <el-table-column
                      label="参数类型"
                      align="center"
                      width="260"
                    >
                      <template slot-scope="scope">
                        <el-form-item label="" :prop="'categoryAttrList.'+scope.$index+'.paramType'" :rules="getRules('参数类型')">
                          <el-radio-group v-model="scope.row.paramType" @change="(val) =>changeParamType(val,scope.row)">
                            <el-radio v-for="(item,value) in paramTypeList" :key="value" :label="item.value" :disabled="scope.row.isInit === 1 || isEdit === false && isInitPage">{{ item.name }}</el-radio>
                          </el-radio-group>
                        </el-form-item>
                      </template>
                    </el-table-column>
                    <el-table-column
                      label="属性值类型"
                      align="center"
                    >
                      <template slot-scope="scope">
                        <el-form-item label="" :prop="'categoryAttrList.'+scope.$index+'.attrType'" :rules="scope.row.paramType === 2 ? rules.attrType:[{ required: false, message: '请选择属性值类型！', trigger: 'change' }]" :show-message="scope.row.paramType === 2 ? true : false">
                          <el-select
                            v-model="scope.row.attrType"
                            placeholder="请选择"
                            clearable
                            :disabled="scope.row.paramType !== 2 || scope.row.isInit === 1 || isEdit === false && isInitPage"
                            @change="(val) =>changeAttrType(val,scope.row)"
                          >
                            <el-option
                              v-for="(o, index) in attrType"
                              :key="index"
                              :label="o.name"
                              :value="o.value"
                            />
                          </el-select>
                        </el-form-item>
                      </template>
                    </el-table-column>
                    <el-table-column
                      label="字典类型"
                      align="center"
                    >
                      <template slot-scope="scope">
                        <el-form-item label="" :prop="'categoryAttrList.'+scope.$index+'.dictType'" :rules="scope.row.attrType === 4 && scope.row.paramType === 2 ? rules.dictType:[{ required: false, message: '请选择字典类型！', trigger: 'change' }]" :show-message="scope.row.attrType === 4 && scope.row.paramType === 2 ? true : false">
                          <el-select
                            v-model="scope.row.dictType"
                            placeholder="请选择"
                            clearable
                            :disabled="scope.row.attrType === 1 || scope.row.paramType === 1 || scope.row.isInit === 1 || isEdit === false && isInitPage"
                          >
                            <el-option
                              v-for="(o, index) in dictTypeList"
                              :key="index"
                              :label="o.name"
                              :value="o.value"
                            />
                          </el-select>
                        </el-form-item>
                      </template>
                    </el-table-column>
                    <el-table-column
                      label="初始化"
                      align="center"
                      width="90"
                    >
                      <template slot-scope="scope">
                        <el-form-item label="" :prop="'categoryAttrList.'+scope.$index+'.isInit'" :rules="getRules('字典类型')">
                          <el-radio v-model="scope.row.isInit" :label="1" disabled style="padding-left:10px">
                            {{ '' }}
                          </el-radio>
                        </el-form-item>
                      </template>
                    </el-table-column>
                    <el-table-column
                      label="展示顺序"
                      align="center"
                      width="180"
                    >
                      <template slot-scope="scope">
                        <el-form-item label="">
                          <el-button size="small" :disabled="isEdit === false && isInitPage" @click="moveUp(scope.row,scope.$index)">上移</el-button>
                          <el-button size="small" :disabled="isEdit === false && isInitPage" @click="moveDown(scope.row,scope.$index)">下移</el-button>
                        </el-form-item>
                      </template>
                    </el-table-column>
                    <el-table-column
                      label="操作"
                      align="center"
                      width="150"
                    >
                      <template slot-scope="scope">
                        <el-form-item label="">
                          <el-button size="small" :disabled="scope.row.isInit === 1 || isEdit === false && isInitPage" @click="deleteRow(scope.row)">-</el-button>
                          <el-button
                            size="small"
                            :disabled="isEdit === false && isInitPage"
                            @click="increaseRow(scope.row)"
                          >+</el-button>
                        </el-form-item>
                      </template>
                    </el-table-column>
                  </el-table>
                  <!-- </el-scrollbar> -->
                </div>
                <div v-if="showAttr" class="border-box" style="padding:0px 0px 15px 0px">
                  <!-- :http-request="handleChangeAudio" -->
                  <p class="tip" style="text-indent:10px">&nbsp;温馨提示：图片支持上传 .pdf .jpg .png；单个文件大小应 &lt;=50MB；最多上传10个文件；此处上传顺序为装备档案图片的显示顺序</p>
                  <div style="width:250px;text-indent:5px">
                    <el-upload
                      ref="uploadFile"
                      :limit="10"
                      :file-list="imgUrl"
                      accept=".pdf,.jpg,.png"
                      action="aaaa"
                      :auto-upload="false"
                      :on-preview="handlePicPreview"
                      :on-change="handleChangeAudio"
                      :on-remove="handleFileRemove"
                      :on-exceed="handleFileExceed"
                      :before-upload="handleFileProgress"
                    >
                      图片上传：<el-button size="mini" type="primary" :disabled="isEdit === false && isInitPage">点击上传</el-button>
                    </el-upload>
                  </div>
                </div>
                <div v-if="showAttr === false && categoryCode && nodeForm.categoryList.length>0" class="border-box">
                  <p style="text-indent:10px">
                    注：可拖动进行排序，越靠左则表示顺序越靠前
                  </p>
                  <el-form-item label="" prop="categoryList">
                    <vuedraggable v-model="nodeForm.categoryList" class="wrapper" :disabled=" isEdit === false">
                      <transition-group>
                        <el-tag
                          v-for="tag in nodeForm.categoryList"
                          :key="tag.categoryName"
                          size="medium"
                          style="margin-left:10px;cursor:pointer"
                        >
                          {{ tag.categoryName }}
                        </el-tag>
                      </transition-group>
                    </vuedraggable>
                  </el-form-item>
                </div>
              </el-form>
            </div>
          </el-scrollbar>
        </el-card>
      </div>
    </div>
  </div>
</template>
<script>
import vuedraggable from 'vuedraggable'
import { getDictType } from '@/api/public'
import { deepClone } from '@/utils'
import { changeStateCategory, dragCategory, deleteCategory, saveCategory, getCategoryTree, getCategoryInfo } from '@/api/attributeManage'
import checkPermission from '@/utils/permission'
export default {
  name: 'SettingEq',
  components: {
    vuedraggable
  },
  data() {
    return {
      paramTypeList: [
        { name: '通用参数', value: 1 },
        { name: '个性化参数', value: 2 }
      ],
      attrType: [
        { name: '文本', value: 1 },
        { name: '单选', value: 4 }
      ],
      filterText: '',
      treeData: [],
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      nodeForm: {
        categoryName: '',
        states: '',
        remark: '',
        categoryLevel: '',
        categoryList: [],
        categoryAttrList: []
      },
      isAdd: false,
      isEdit: false,
      isInitPage: false,
      canCheck: false,
      childrenType: null,
      showAttr: false,
      imgUrl: [],
      checkTypeList: [
        { name: '启用', value: 1 },
        { name: '停用', value: 0 }
      ],
      typeList: [
        { name: '分类', value: '1' },
        { name: '设备', value: '2' }
      ],
      categoryCode: '',
      categoryLevel: '',
      pLevel: '', // 父节点层级
      dictTypeList: [],
      nodeCode: '',
      categoryState: '',
      rules: {
        attrValue: [
          { required: true, message: '请输入通用属性值！', trigger: 'change' }
        ],
        attrType: [
          { required: true, message: '请选择属性值类型！', trigger: 'change' }
        ],
        dictType: [
          { required: true, message: '请选择字典类型！', trigger: 'change' }
        ]
      }
    }
  },
  // updated() {
  //   console.log(this.nodeForm.categoryList)
  // },
  watch: {
    categoryLevel(val) {
      this.categoryLevel = val
      if (val === '1') {
        // this.isInitPage = false
        this.typeList = [
          { name: '分类', value: '1' },
          { name: '设备', value: '2' }
        ]
      } else {
        // this.isInitPage = true
        this.typeList = [
          { name: '分类', value: '1' },
          { name: '设备', value: '2' },
          { name: '品牌', value: '3' },
          { name: '型号', value: '4' }
        ]
      }
    },
    childrenType(val) {
      this.childrenType = val
    },
    categoryCode(val) {
      this.categoryCode = val
    },
    categoryState(val) {
      this.categoryState = val
    },
    filterText(val) {
      this.$refs.tree.filter(val)
    },
    isInitPage(val) {
      this.isInitPage = val
    },
    isEdit(val) {
      this.isEdit = val
    }
  },
  mounted() {
    const _this = this
    _this.getDictType()
    _this.getCategoryTreeList()
  },
  methods: {
    /**
     * 自定义节点颜色
     */
    renderContent(h, { node, data, store }) {
      return (<span class={data.states === 1 ? 'effective-category' : 'invalid-category'} style='font-size:14px'>{node.label}</span>)
    },
    increaseNode() {
      if (this.categoryLevel === '4') {
        this.$message.warning('当前已是最小层级！')
        return
      }
      if (this.categoryState === 0) {
        this.$message.warning('请选择有效的父节点！')
        return
      }
      this.isAdd = true
      if (this.canCheck === false) {
        return false
      }
      this.isEdit = false
      this.isInitPage = false
      this.nodeForm = {
        categoryName: '',
        states: '',
        remark: '',
        pCode: this.categoryCode,
        categoryLevel: '',
        categoryList: [],
        categoryAttrList: []
      }
      if (this.categoryLevel === '3') {
        this.showAttr = true
        this.nodeForm.categoryLevel = '4'
      } else {
        this.showAttr = false
      }
      if (this.categoryLevel === '2') {
        this.nodeForm.categoryLevel = '3'
      }
      // if (this.categoryLevel === '1' ) {
      //   this.nodeForm.categoryLevel = '2'
      // }
      // 如果父节点是分类，且子节点下还有分类，就只能新增分类
      if ((this.pLevel && this.pLevel === '1') && this.categoryLevel === '1' && (this.childrenType === null && this.categoryLevel !== '2')) {
        this.nodeForm.categoryLevel = '2'
      } else if (this.childrenType === true) { // 否则只能新增设备
        this.nodeForm.categoryLevel = '1'
      }
      // 节点是分类且父节点不是分类且自身未有子节点
      if (this.categoryLevel === '1' && this.pLevel !== '1' && this.childrenType === null) {
        this.canCheck = false
        this.typeList = [
          { name: '分类', value: '1' },
          { name: '设备', value: '2' }
        ]
      } else {
        this.canCheck = true
        this.typeList = [
          { name: '分类', value: '1' },
          { name: '设备', value: '2' },
          { name: '品牌', value: '3' },
          { name: '型号', value: '4' }
        ]
      }
    },
    /**
     * 过滤节点
     */
    filterNode(value, data) {
      if (!value) return true
      return data.label.indexOf(value) !== -1
    },
    /**
     * 删除节点
     */
    deleteNode() {
      const param = {
        categoryCode: this.categoryCode
      }
      this.$confirm('确定删除所选节点吗？', '提示', {
        confirmButtoText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteCategory(param).then(res => {
          if (res.code === 200) {
            this.$message.success({
              message: '操作成功！',
              showClose: true,
              duration: 1500
            })
            this.categoryCode = ''
            this.getCategoryTreeList()
            this.nodeForm = {
              categoryName: '',
              states: '',
              remark: '',
              categoryLevel: '',
              categoryList: [],
              categoryAttrList: []
            }
            this.isAdd = false
            this.isEdit = false
            this.isInitPage = false
            this.canCheck = false
            this.categoryCode = ''
            this.categoryState = ''
            this.childrenType = null
            this.categoryLevel = ''
            this.nodeCode = ''
          }
        })
      }).catch(() => {
        this.$message({
          message: '已取消删除！',
          showClose: true,
          type: 'info'
        })
      })
    },
    /**
     * 取消新增
     */
    handleCancel() {
      if (this.canCheck === false) {
        this.nodeForm = {
          categoryName: '',
          states: '',
          remark: '',
          categoryLevel: '',
          categoryList: [],
          categoryAttrList: []
        }
        this.isAdd = false
        this.isEdit = true
        this.isInitPage = false
        return false
      }
      this.isAdd = false
      this.isEdit = false
      this.isInitPage = true
      const param = {
        id: this.categoryCode,
        level: this.categoryLevel
      }
      this.$refs.nodeForm.resetFields()
      this.getCategoryInfos(param)
    },
    handleNodeClick(data, e) {
      this.isEdit = false
      this.isInitPage = true
      this.canCheck = true
      this.childrenType = null
      this.$refs.nodeForm.resetFields()
      this.getCategoryInfos(data)
      if (e.parent.data.level) {
        this.pLevel = e.parent.data.level
      }
      if (e.parent.level === 0 && data.children.length > 0) {
        this.childrenType = data.children.every(item => {
          if (item.level === '1') {
            return true
          } else if (item.level === '2') {
            return false
          } else {
            return null
          }
        })
      }
    },
    saveData() {
      if (!checkPermission('button46') || !checkPermission('button47')) return false
      this.$refs.nodeForm.validate(valid => {
        if (valid) {
          if (this.nodeForm.categoryAttrList && this.nodeForm.categoryAttrList.length > 0) {
            for (let i = 0; i < this.nodeForm.categoryAttrList.length - 1; i++) {
              for (let j = i + 1; j < this.nodeForm.categoryAttrList.length; j++) {
                if (this.nodeForm.categoryAttrList[i].attrEnName === this.nodeForm.categoryAttrList[j].attrEnName) {
                  this.$message.warning({
                    message: '存在重名属性！',
                    showClose: true,
                    duration: 1500
                  })
                  return false
                }
              }
            }
          }
          let param = deepClone(this.nodeForm)
          param = JSON.stringify(param)
          const data = new FormData()
          if (this.categoryLevel === '4' || this.showAttr) {
            this.imgUrl.forEach(item => {
              data.append('files', item.raw)
            })
          }
          data.append('categoryJson', param)
          saveCategory(data).then(res => {
            if (res.code === 200) {
              this.$message.success({
                message: '操作成功！',
                showClose: true,
                duration: 1500
              })
              this.isEdit = false
              this.isInitPage = true
              this.canCheck = true
              if (this.isAdd === true || this.canCheck === false || !this.isEdit) {
                this.getCategoryTreeList().then(() => {
                  this.$nextTick(_ => {
                    this.nodeCode = res.data.categoryCode
                    this.categoryCode = res.data.categoryCode
                    this.nodeForm.categoryCode = res.data.categoryCode
                    this.categoryLevel = res.data.categoryLevel
                    // this.pLevel = res.data.categoryLevel
                    this.$refs.tree.setCurrentKey(this.nodeCode)
                    const node = this.$refs.tree.getNode(this.nodeCode)
                    const nodeData = this.$refs.tree.getCurrentNode(this.nodeCode)
                    this.handleNodeClick(nodeData, node)
                    this.isAdd = false
                  })
                })
              } else {
                this.getCategoryTreeList().then(() => {
                  this.$nextTick(_ => {
                    this.nodeCode = this.categoryCode
                    this.$refs.tree.setCurrentKey(this.nodeCode)
                  })
                })
              }
            }
          })
        }
      })
    },
    getRules(message, trigger = 'blur') {
      return { required: true, message: message + '不能为空！', trigger }
    },
    handlePicPreview(file) {
      this.pictureUrl = file.url
      this.pictureVisible = true
    },
    /**
     * 获取类目树
     */
    async getCategoryTreeList() {
      const _this = this
      return getCategoryTree({}).then(res => {
        if (res.code === 200) {
          _this.treeData = res.data
        }
      })
    },
    /**
     * 获取类目详情
     */
    getCategoryInfos(val) {
      const _this = this
      _this.categoryCode = val.id
      _this.categoryLevel = val.level
      _this.categoryState = val.states
      if (val.level === '4') {
        _this.showAttr = true
      } else {
        _this.showAttr = false
      }
      const params = {
        categoryCode: val.id
      }
      getCategoryInfo(params).then(res => {
        if (res.code === 200) {
          _this.nodeForm = res.data
          if (this.categoryLevel === '4') {
            const imgUrls = res.data.categoryAttrList.filter(item => {
              return item.attrType === 2
            })
            imgUrls.map(item => {
              item.name = item.attrName
            })
            this.nodeForm.categoryAttrList = res.data.categoryAttrList.filter(item => {
              return item.attrType !== 2
            })
            this.imgUrl = imgUrls
          }
        }
      })
    },
    /**
     * 添加属性
     */
    addAttr() {
      const obj = { attrName: '', paramType: 1, attrValue: '', isInit: 0, attrEnName: '', attrType: '', dictType: '', attrOrder: '', categoryCode: this.categoryCode }
      // if (this.nodeForm.categoryAttrList.length === 0) {
      this.nodeForm.categoryAttrList.push(obj)
      // }
    },
    /**
     * 字典类型
     */
    getDictType() {
      getDictType({}).then(res => {
        if (res.code === 200) {
          const _this = this
          const result = res.data
          for (const key in result) {
            _this.dictTypeList.push({ name: result[key], value: key })
          }
        }
      })
    },
    /**
     * 移除文件
     */
    handleFileRemove(file, fileList) {
      const _this = this
      _this.imgUrl = fileList
    },
    /**
     * 文件变化触发文件转换方法:rules="getRules('通用参数值')"
     */
    handleChangeAudio(files, fileList) {
      this.imgUrl = fileList
    },
    handleFileProgress(file) { // 判断文件大小
      var extName = file.name.substring(file.name.lastIndexOf('.')).toLowerCase()
      var AllUpExt = '.jpg|.png|.pdf|'
      if (AllUpExt.indexOf(extName + '|') === -1) {
        this.$message.error('文件格式不正确!')
        return false
      }
      let size = file.size || 0
      size = size / 1024 / 1024
      if (size > 50) {
        this.$message.warning('文件大小不能超出50MB！')
        return false
      }
    },
    handleFileExceed(file, fileList) {
      this.$message.warning('超出最大上传文件个数！')
    },
    /**
     * 上移
     */
    moveUp(row, flag) {
      if (flag === 0) {
        this.$message.warning({
          message: '不能上移第一位！',
          showClose: true,
          duration: 1500
        })
        return
      }
      const index = this.nodeForm.categoryAttrList.indexOf(row)
      if (index > 0) {
        // 在上一项插入该项
        this.nodeForm.categoryAttrList.splice(index - 1, 0, (this.nodeForm.categoryAttrList[index]))
        // 删除后一项
        this.nodeForm.categoryAttrList.splice(index + 1, 1)
      }
    },
    /**
     * 下移
     */
    moveDown(row, flag) {
      const length = this.nodeForm.categoryAttrList.length - 1
      if (flag === length) {
        this.$message.warning({
          message: '不能下移最后一位！',
          showClose: true,
          duration: 1500
        })
        return
      }
      const index = this.nodeForm.categoryAttrList.indexOf(row)
      if (index === (this.nodeForm.categoryAttrList.length - 1)) {
        return
      }
      // 在下一项插入该项
      this.nodeForm.categoryAttrList.splice(index + 2, 0, (this.nodeForm.categoryAttrList[index]))
      // 删除前一项
      this.nodeForm.categoryAttrList.splice(index, 1)
    },
    /**
     * 删除
     */
    deleteRow(row) {
      const index = this.nodeForm.categoryAttrList.indexOf(row)
      if (this.nodeForm.categoryAttrList.length === 1) {
        this.$message.warning('不能删除最后一个属性')
        return
      }
      this.nodeForm.categoryAttrList.splice(index, 1)
    },
    /**
     * 新增
     */
    increaseRow(row) {
      const index = this.nodeForm.categoryAttrList.indexOf(row)
      this.nodeForm.categoryAttrList.splice(index + 1, 0, { attrName: '', paramType: 1, attrValue: '', isInit: 0, attrEnName: '', attrType: '', dictType: '', attrOrder: '', categoryCode: this.categoryCode })
    },
    /**
     * 节点拖拽放置前判断能否被放置
     */
    canPutin(node, pNode, positon, event) {
      this.childrenType = null
      if (positon !== 'inner') {
        this.$message.warning('同级不能移动前后顺序！')
        this.getCategoryTreeList().then(() => {
          this.$nextTick(_ => {
            this.nodeCode = node.data.categoryCode
            this.categoryLevel = node.data.categoryLevel
            this.categoryState = node.data.states
            this.$refs.tree.setCurrentKey(node.data.id)
          })
        })
        return false
      }
      let canPut = null
      if (pNode.data.level === '1') {
        this.pLevel = pNode.data.level
        canPut = pNode.data.children.every(item => {
          if (item.level === node.data.level) {
            return true
          } else {
            return false
          }
        })
      }
      const param = {
        categoryCode: node.data.id,	// string要拖拽的类目编码
        oldCategoryOrder: node.data.order,	// integer($int64)原顺序
        oldPCode: node.data.pId ? node.data.pId : '',	// string原父类目编码
        pCode: pNode.data.id ? pNode.data.id : ''//	string新父类目编码
      }
      if (node.data.level === '2') {
        if (pNode.data.level !== '1') {
          this.$message.warning('设备只能移动到任意分类下！')
          this.nodeCode = node.data.id
        } else if (canPut === false) {
          this.$message.warning('移动的节点与目标节点的子类类型不一致！')
          this.nodeCode = node.data.id
        } else { // 当前为分类,且子类类型一致
          let result = {}
          dragCategory(param).then(res => {
            if (res.code === 200) {
              result = res.data
              this.nodeCode = result.categoryCode
              this.categoryLevel = result.categoryLevel
              this.categoryState = result.states
              this.categoryCode = result.categoryCode
              const param = {
                id: result.categoryCode,
                states: result.states,
                level: result.categoryLevel
              }
              this.getCategoryInfos(param)
              this.isEdit = false
              this.isInitPage = true
              if (this.pLevel === '1') {
                this.canCheck = true
              }
            }
            return getCategoryTree({})
          }).then(res => {
            if (res.code === 200) {
              this.treeData = res.data
              this.$nextTick(_ => {
                this.$refs.tree.setCurrentKey(this.nodeCode)
              })
            }
          })
        }
      }
      // 过滤掉 当前为分类
      if (!((node.data.level === '1' || node.data.level === '2') && pNode.data.level === '1') || canPut === false) {
        getCategoryTree({}).then(res => {
          if (res.code === 200) {
            this.treeData = res.data
            this.$nextTick(_ => {
              // this.nodeCode = res.data
              this.$refs.tree.setCurrentKey(this.nodeCode)
            })
          }
        })
      }
    },
    /**
     * 判断节点是否可拖拽
     */
    allowDrag(node) {
      if (node.data.level === '4' || node.data.level === '3' || node.data.level === '1') {
        return false
      } else {
        return true
      }
    },
    /**
     * 停用/启用
     */
    changeState(val) {
      if (!this.isEdit) return false
      const states = val === 1 ? 0 : 1
      const param = {
        categoryCode: this.categoryCode,
        states: val
      }
      changeStateCategory(param).then(res => {
        if (res.code === 200) {
          this.$message.success({
            message: '操作成功！',
            showClose: true,
            duration: 1500
          })
          this.nodeForm.states = val
          this.getCategoryTreeList()
        }
      }).catch(_ => {
        this.nodeForm.states = states
      })
    },
    /**
     * 选择参数类型
     */
    changeParamType(val, row) {
      row.paramType = val
      if (val === 2) {
        row.attrValue = ''
      }
      if (val === 1) {
        row.attrType = ''
        row.dictType = ''
      }
    },
    /**
     * 选择属性类型
     */
    changeAttrType(val, row) {
      row.attrType = val
      if (val === 1) {
        row.dictType = ''
      }
    }
  }
}
</script>
<style lang="stylus" scoped>
.EqSetting-container {
  padding: 0px 20px
  height: calc(100vh - 106px);
  .border-box{
    border 1px solid #e5e8ef
    padding-top 24px
    border-radius 4px
    margin-bottom 10px
  }
  /deep/ .el-input.is-disabled .el-input__inner{
      color black
    }
    /deep/ .el-radio__input.is-disabled + span.el-radio__label{
      color: black!important
    }
    .el-button.is-disabled{
      color: black!important
    }
    /deep/ .el-textarea.is-disabled .el-textarea__inner{
      color: black!important
    }
  .titleP{
    background-color: rgba(242, 242, 242, 1)
    padding:10px 0px 10px 10px
    margin: 0px
    text-indent 10px
  }
  .treeBox{
    margin-top 10px
    /deep/ .el-tree-node.is-current > .el-tree-node__content {
      background-color: #c2d6ea !important
    }
    /deep/ .el-scrollbar__wrap{
      overflow-x: auto!important
    }
  }
  .settingContent{
    height:100%;
    .leftBox{
      width 350px
      height 96%
      margin-top 20px
      // border 1px solid black
      background-color: #FFFFFF;
      float: left;
      margin-right 20px
    }
    .rightBox{
      width 1500px
      height 96%
      margin-top 20px
      float: right;
      background-color: #FFFFFF;
      /deep/ .el-scrollbar__wrap{
      overflow-x: auto!important
    }
    }
  }
  .formBox{
    border 1px solid #e5e8ef
    padding-top 24px
    border-radius 4px
    margin-bottom 10px
    .el-table .cell{
      height 38px

    }
    /deep/ .el-scrollbar__wrap{
      overflow-x: auto!important
    }
    .el-form-item {
        margin-bottom 15px
    }
  }
}
</style>
<style>
  .effective-category{
    color:black
  }
  .invalid-category{
   color: #C0C4CC
  }
</style>
