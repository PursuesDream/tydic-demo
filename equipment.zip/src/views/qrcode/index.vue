<template>
  <div class="interphone-container">
    <el-card style="margin-top:20px;height:85vh">
      <div>
        <div>
          <div class="tydic-box">
            <div class="tydic-input">
              所属单位：
              <el-select v-model="formData.ssdd" placeholder="请选择" clearable @change="(val) =>getOrgan(val,'zhongdui')">
                <el-option
                  v-for="(o,index) in brigadeList"
                  :key="index"
                  :label="o.name"
                  :value="o.organCode"
                />
              </el-select>
            </div>
            <!--<div class="tydic-input">
            所属中队：
            <el-select v-model="formData.sszd" placeholder="请选择" clearable>
              <el-option
                v-for="(o,index) in zhongduiList"
                :key="index"
                :label="o.name"
                :value="o.organCode"
              />
            </el-select>
          </div>-->
            <div class="tydic-input">
              装备编号：
              <el-input v-model="formData.deviceNo" placeholder="请输入" />
            </div>
            <div class="tydic-input">
              二维码编号：
              <el-input v-model="formData.qrCode" placeholder="请输入" />
            </div>
            <div class="tydic-input">
              绑定装备类型：
              <el-select v-model="formData.vehicleType">
                <el-option
                  v-for="(o,index) in carType"
                  :key="index"
                  :label="o.categoryName"
                  :value="o.categoryCode"
                />
              </el-select>
            </div>
            <!-- <br> -->
            <div class="tydic-input">
              有效状态：
              <el-radio-group v-model="formData.status1">
                <el-radio :label="2">全部</el-radio>
                <el-radio :label="1">有效</el-radio>
                <el-radio :label="0">无效</el-radio>
              </el-radio-group>
            </div>
            <div class="tydic-input">
              绑定状态：
              <el-radio-group v-model="formData.status2">
                <el-radio :label="2">全部</el-radio>
                <el-radio :label="1">已绑定</el-radio>
                <el-radio :label="0">未绑定</el-radio>
              </el-radio-group>
            </div>
            <div class="tydic-input" style="float:right">
              <el-button type="primary search" size="mini" @click="onSearch"><i class="image-icon search" />查询</el-button>
              <el-button type="primary reset" size="mini" @click="onReset"><i class="image-icon reset" />重置</el-button>
            </div>
            <div style="margin-bottom: 15px;">
              <el-button v-permission="'button35'" type="primary color3" size="mini" @click="handleAdd"><i class="image-icon add" />生成二维码</el-button>
              <el-button v-permission="'button36'" type="primary color6" size="mini" @click="handleStop"><i class="image-icon delete" />停用
              </el-button>
              <el-button v-permission="'button37'" type="primary color7" size="mini" @click="handleStar"><i class="image-icon add" />启用
              </el-button>
              <el-button v-permission="'button38'" type="primary color5" size="mini" @click="relieveAllEq"><i class="image-icon delete" />解绑
              </el-button>
              <!--<el-button type="primary color7" size="mini" @click="onBinding"><i class="image-icon fenpei" />绑定装备
            </el-button>-->
              <el-button v-permission="'button49'" type="primary color4" size="mini" @click="downloadAllCode"><i class="image-icon import" />下载</el-button>
            </div>
            <div class="table-box">
              <el-table
                ref="tableFef"
                v-loading="isLoading"
                :data="tableData"
                class="custom-table"
                stripe
                border
                max-height="580"
                header-row-class-name="custom-table-header"
                @selection-change="handleChange"
              >
                <el-table-column type="selection" width="50" align="center" />
                <el-table-column width="100" label="序号" align="center">
                  <template slot-scope="scope">
                    {{ scope.$index + 1 + pageSize * (curPage - 1) }}
                  </template>
                </el-table-column>
                <el-table-column
                  prop="parentCodeName"
                  align="center"
                  label="所属单位"
                  :show-overflow-tooltip="true"
                />
                <!-- <el-table-column
                  prop="parentOrganName"
                  align="center"
                  label="二维码图片"
                >
                  <template slot-scope="scope">
                    <div @click="handleImg(scope.row)">
                      <el-image
                        style="width: 80px; height: 80px"
                        :src="scope.row.codeUrl"
                        :preview-src-list="srcList"
                      />
                    </div>
                  </template>
                </el-table-column> -->
                <el-table-column
                  align="center"
                  prop="deviceTypeName"
                  label="绑定装备类型"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="deviceNo"
                  align="center"
                  label="装备编号"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="qrCode"
                  align="center"
                  label="二维码编号"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="inTime"
                  align="center"
                  label="生成时间"
                  :show-overflow-tooltip="true"
                />
                <el-table-column align="center" label="绑定状态" :show-overflow-tooltip="true">
                  <template slot-scope="scope">
                    {{ scope.row.deviceNo === null ? '未绑定' : '已绑定' }}
                  </template>
                </el-table-column>
                <el-table-column
                  align="center"
                  label="二维码有效状态"
                  :show-overflow-tooltip="true"
                >
                  <template slot-scope="scope">
                    <span v-if="scope.row.states == 1">有效</span>
                    <span v-else-if="scope.row.states == 0">无效</span>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="操作">
                  <template slot-scope="scope">
                    <el-button
                      v-if="scope.row.isExist === '1'"
                      v-permission="'button40'"
                      type="text"
                      size="small"
                      @click="handleImg(scope.row)"
                    >
                      <span>二维码</span>
                    </el-button>
                    <el-button
                      v-if="scope.row.deviceNo === null"
                      v-permission="'button39'"
                      type="text"
                      size="small"
                      :disabled="scope.row.states == 0 ? true : false"
                      @click="bindingEq(scope.row)"
                    >绑定
                    </el-button>
                    <el-button
                      v-if="scope.row.deviceNo !== null"
                      v-permission="'button38'"
                      type="text"
                      size="small"
                      @click="relieveEq(scope.row)"
                    >
                      <span>解绑</span>
                    </el-button>
                    <el-button
                      v-if="scope.row.states == 0"
                      v-permission="'button37'"
                      type="text"
                      size="small"
                      @click="starRowData(scope.row)"
                    >启用
                    </el-button>
                    <el-button
                      v-if="scope.row.states == 1"
                      v-permission="'button36'"
                      type="text"
                      size="small"
                      @click="stopRowData(scope.row)"
                    >
                      <span style="color:red">停用</span>
                    </el-button>
                    <!-- <div @click="handleImg(scope.row)"> -->
                    <!-- <el-image
                      style="width: 80px; height: 80px;display:none"
                      :src="scope.row.codeUrl"
                      :preview-src-list="srcList"
                    /> -->
                    <!-- </div> -->
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div style="text-align: center">
              <el-pagination
                ref="pagination"
                style="text-align: center;margin-top:15px;"
                background
                :page-size="pageSize"
                :total="total"
                :current-page.sync="curPage"
                layout="total, prev, pager, next, jumper"
                @size-change="sizeChange"
                @current-change="curPageChange"
              />
            </div>
          </div>
          <!-- 查看二维码 -->
          <el-dialog
            title="二维码"
            :visible.sync="arCodeVisible"
            width="400px"
            class="add_dialog"
            custom-class="custom-dialog"
            :close-on-click-modal="false"
            :colse-on-press-escape="false"
          >
            <el-image
              style="width: 100%;"
              :src="qrObj.codeUrl"
            />
            <div style="text-align:center"><el-button type="primary" @click="handleDownQrCodeSingle">下载</el-button></div>
          </el-dialog>
          <!-- 新增 -->
          <el-dialog
            title="生成二维码"
            :visible.sync="formVisible"
            width="940px"
            class="add_dialog"
            custom-class="custom-dialog"
            :close-on-click-modal="false"
            :colse-on-press-escape="false"
            @close="closeAddDialog"
          >
            <el-form v-if="formVisible" ref="addDataForm" :model="addDataForm" :inline="true" label-width="96px">
              <el-form-item label="所属单位:" prop="parentOrganCode" :rules="getRules('所属支队')">
                <el-select
                  v-model="addDataForm.parentOrganCode"
                  placeholder="请选择"
                  clearable
                  @change="(val) =>getOrgan(val,'zhongdui')"
                >
                  <el-option
                    v-for="(o,index) in brigadeList"
                    :key="index"
                    :label="o.name"
                    :value="o.organCode"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="装备类型:" prop="vehicleType" :rules="getRules('装备类型')">
                <el-select v-model="addDataForm.vehicleType">
                  <el-option
                    v-for="(o,index) in carType"
                    :key="index"
                    :label="o.categoryName"
                    :value="o.categoryCode"
                  />
                </el-select>
              </el-form-item>
              <!--<el-form-item label="所属大队:" prop="organCode" :rules="getRules('所属支队')">
              <el-select v-model="addDataForm.organCode" placeholder="请选择" clearable>
                <el-option
                  v-for="(o,index) in zhongduiList"
                  :key="index"
                  :label="o.name"
                  :value="o.organCode"
                />
              </el-select>
            </el-form-item>-->
              <el-form-item label="二维码数量:" class="mr0" prop="codeNum" :rules="getRules('二维码数量')">
                <el-input v-model="addDataForm.codeNum" type="number" />
              </el-form-item>
            <!--<el-form-item label="下载二维码方式:" prop="codeType" :rules="getRules('下载二维码方式','change')">
              <el-radio-group v-model="addDataForm.codeType">
                <el-radio label="1">二维码编码</el-radio>
                <el-radio label="2">二维码编码 + 图片</el-radio>
              </el-radio-group>
            </el-form-item>-->
            </el-form>
            <div style="text-align: center;margin-top:20px">
              <el-button type="primary color-commit" size="mini" @click="affirmDownload('addDataForm')">确认</el-button>
              <el-button type="primary color-cancel" size="mini" @click="formVisible = false">取消</el-button>
            </div>
          </el-dialog>
          <!-- 绑定弹层 -->
          <el-dialog
            width="460px"
            custom-class="custom-dialog"
            center
            title="绑定装备"
            class="bind_dialog"
            :visible.sync="bindingDialog"
            :close-on-click-modal="false"
            :colse-on-press-escape="false"
            @close="closeDialog"
          >
            <el-form ref="uesControl" :model="bindingForm" :inline="true" label-width="100px">
              <!--<el-form-item label="二维码编号:" prop="codeNum" :rules="getRules('二维码编号')">
              <el-input v-model="bindingForm.codeNum" />
            </el-form-item>-->
              <el-form-item label="车牌号码:" prop="deviceId" :rules="getRules('车牌号码')">
                <el-select
                  v-model="bindingForm.deviceId"
                  filterable
                  remote
                  reserve-keyword
                  placeholder="请输入关键词"
                  :remote-method="remoteMethod"
                >
                  <el-option
                    v-for="item in bindList"
                    :key="item.deviceId"
                    :label="item.deviceNo"
                    :value="item.deviceId"
                  />
                </el-select>
              </el-form-item>
              <el-button type="primary color-commit" size="mini" @click="bindData">绑定</el-button>
            </el-form>
          </el-dialog>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
import { getOrganList } from '@/api/public'
import { getCategoryList } from '@/api/integratedManage'
import { mapState } from 'vuex'
import http from '@/api/qrcode'

// import QRcode from '@chenfengyuan/vue-qrcode'
export default {
  // components: {
  //   qrcode: QRcode
  // },
  data() {
    return {
      codeDialog: false,
      codeType: '1',
      isImport: true,
      carType: [],
      useTitle: '',
      bindingForm: {
        codeNum: '',
        deviceId: ''
      },
      checkArr: [],
      statusList: [],
      formData: {
        orgCode: '',
        deviceNo: '',
        vehicleType: '',
        status1: 2,
        status2: 2,
        sszd: '',
        ssdd: '',
        qrCode: ''
      },
      oldFormData: null,
      bindingDialog: false, // 控制使用停用弹窗
      curPage: 1,
      pageSize: 10,
      total: 0,
      daduiList: [],
      zhongduiList: [],
      checkedTimeArr: [],
      tableData: [],
      mjLoading: false,
      formTitle: '',
      formVisible: false,
      addDataForm: {
        parentOrganCode: '',
        vehicleType: '',
        organCode: '',
        codeNum: '',
        codeType: ''
      },
      cavalryData: this.mapData,
      bindList: [],
      curDeviceType: '',
      curQrCode: '',
      brigadeList: [
        { name: '东城区支队', organCode: '01' },
        { name: '西城支队', organCode: '02' },
        { name: '朝阳支队', organCode: '05' },
        { name: '丰台支队', organCode: '06' },
        { name: '石景山支队', organCode: '07' },
        { name: '海淀支队', organCode: '08' },
        { name: '房山支队', organCode: '11' },
        { name: '通州支队', organCode: '12' },
        { name: '昌平支队', organCode: '14' },
        { name: '开发区支队', organCode: '21' },
        { name: '中心区支队', organCode: '25' }
      ],
      qrObj: {},
      arCodeVisible: false,
      isLoading: false
    }
  },
  computed: {
    ...mapState({
      mapData: state => state.user.mapData
    })
  },
  mounted() {
    const _this = this
    _this.getOrgan('110000000000', 'dadui')
    _this.statusList = _this.mapData.vehicle_use_states
    _this.getAllCategory()
    this.getOrganLData()
    _this.getQrcodeList()
  },
  methods: {
    /* 获取所属单位列表 */
    getOrganLData() {
      http.getParentCodeList().then(res => {
        if (res.code === 200) {
          this.brigadeList = res.data || []
        }
      })
    },
    /*
    *  获取二维码列表数据
    * */
    getQrcodeList() {
      const that = this
      let param = {}
      if (this.oldFormData) {
        param = { ...this.oldFormData }
      } else {
        param = {
          parentCode: that.formData.ssdd,
          /* organCode: that.formData.sszd,*/
          deviceNo: that.formData.deviceNo,
          qrCode: that.formData.qrCode,
          deviceType: that.formData.vehicleType,
          state1: that.formData.status1,
          state2: that.formData.status2
        }
        this.oldFormData = { ...param }
      }
      this.isLoading = true
      http.getQrcodeList(param, that.curPage).then(res => {
        that.tableData = res.data.rows
        that.total = res.data.total
        this.isLoading = false
      }).catch(_ => {
        this.isLoading = false
      })
    },
    /*
    * 获取装备编号下拉
    * */
    getVehicleList(param = {}) {
      const that = this
      http.getVehicleList(param).then(res => {
        if (res.code === 200) {
          const data = res.data.rows
          data.forEach(item => {
            if (!item.qrCodeBindSate) {
              that.bindList.push(item)
            }
          })
        }
      })
    },
    /**
     * 查询所有车辆类型
     */
    getAllCategory() {
      const _this = this
      const params = {
        categoryCode: '',
        categoryType: ''
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          _this.carType = res.data
        }
      })
    },
    /**
     * 表格选中数据
     */
    handleChange(val) {
      this.checkArr = val
    },
    getRules(message, trigger = 'blur') {
      return { required: true, message: message + '不能为空！', trigger }
    },
    /**
     * 分页大小
     */
    sizeChange(val) {
      const _this = this
      _this.pageSize = val
    },
    /**
     * 页数跳转
     */
    curPageChange(val) {
      const _this = this
      _this.curPage = val
      _this.getQrcodeList()
    },
    /**
     * 查询大队
     */
    getOrgan(code, listName) {
      this[listName + 'List'] = []
      this.formData.sszd = ''
      if (!code) {
        return
      }
      getOrganList(code).then(res => {
        if (res.code === 200) {
          this[listName + 'List'] = res.data
        }
      })
    },
    /**
     * 确认生成二维码
     */
    affirmDownload(formName) {
      const that = this
      const param = {
        parentCode: that.addDataForm.parentOrganCode,
        deviceType: that.addDataForm.vehicleType,
        count: that.addDataForm.codeNum
      }
      this.$refs[formName].validate((valid) => {
        if (valid) {
          http.insertQrcode(param).then(res => {
            if (res.code === 200) {
              that.getQrcodeList()
              this.formVisible = false
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    /**
     * 关闭生成二维码弹窗
     */
    closeAddDialog() {
      const that = this
      that.$refs.addDataForm.resetFields()
    },
    /**
     * 打开生成二维码弹窗
     */
    handleAdd(row) {
      const _this = this
      _this.formVisible = true
      _this.formTitle = '生成二维码'
    },
    /**
     * 搜索
     */
    onSearch() {
      this.curPage = 1
      this.oldFormData = null
      this.getQrcodeList()
    },
    /**
     * 重置
     */
    onReset() {
      this.formData = {
        orgCode: '',
        deviceNo: '',
        vehicleType: '',
        status1: 2,
        status2: 2,
        sszd: '',
        ssdd: '',
        qrCode: ''
      }
      this.curPage = 1
      this.oldFormData = null
      this.getQrcodeList()
    },
    /*
    * 下载二维码
    * */
    downloadCode(codeArr) {
      // const that = this
      http.downloadQrcode(codeArr).then(res => {
        const url = window.URL.createObjectURL(new Blob([res]))
        const link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        const fileName = '二维码.zip'
        link.setAttribute('download', fileName)
        document.body.appendChild(link)
        link.click()
      })
    },
    /**
     * 下载多个二维码
     */
    downloadAllCode() {
      const that = this
      const param = []
      if (that.checkArr.length > 0) {
        for (let i = 0; i < that.checkArr.length; i++) {
          if (that.checkArr[i].states === 0) {
            that.$message.error('您选中的二维码无效，不能下载')
            return false
          }
          param.push(that.checkArr[i].qrCode)
        }
        that.downloadCode(param)
      } else {
        that.$message.error('请选择要下载的二维码')
      }
      this.$refs.tableFef.clearSelection()
    },
    /*
    * 停用设备
    * */
    stopData(param) {
      const that = this
      that.$confirm('此操作将停用装备, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        http.setStopQrcode(param).then(res => {
          if (res.code === 200) {
            that.getQrcodeList()
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          showClose: true,
          message: '已取消停用'
        })
      })
    },
    /**
     * 停用多个设备
     */
    handleStop(val) {
      const that = this
      const param = []
      if (that.checkArr.length > 0) {
        for (let i = 0; i < that.checkArr.length; i++) {
          if (that.checkArr[i].states === 0) {
            that.$message.error('您选中的二维码无效，不能停用')
            return false
          }
          param.push(that.checkArr[i].qrCode)
        }
        that.stopData(param)
      } else {
        that.$message.error('请勾选需要停用的设备')
      }
    },
    /*
    * 停用当前条数据
    * */
    stopRowData(row) {
      const that = this
      const param = [row.qrCode]
      that.stopData(param)
    },
    /*
    * 启用设备
    * */
    starData(param) {
      const that = this
      http.enableQrcode(param).then(res => {
        if (res.code === 200) {
          that.$message({
            type: 'success',
            showClose: true,
            message: '启用成功!'
          })
          that.getQrcodeList()
        }
      })
    },
    /*
    * 启用多个设备
    * */
    handleStar() {
      const that = this
      const param = []
      if (that.checkArr.length > 0) {
        for (let i = 0; i < that.checkArr.length; i++) {
          if (that.checkArr[i].states === 1) {
            that.$message.error('您选中的二维码包含有效二维码')
            return false
          }
          param.push(that.checkArr[i].qrCode)
        }
        that.starData(param)
      } else {
        that.$message.error('请勾选需要停用的设备')
      }
    },
    /*
    * 启用当前设备
    * */
    starRowData(row) {
      const that = this
      const param = [row.qrCode]
      that.starData(param)
    },
    /**
     * 打开绑定当前条设备弹窗
     */
    bindingEq(val) {
      this.bindingDialog = true
      this.curDeviceType = val.deviceType
      this.curQrCode = val.qrCode
      this.bindingForm.deviceId = ''
    },
    /*
    * 绑定当前设备
    * */
    bindData() {
      const that = this
      const param = {
        deviceId: that.bindingForm.deviceId,
        qrCode: that.curQrCode
      }
      that.$refs.uesControl.validate((valid) => {
        if (valid) {
          http.bindQrcotde(param).then(res => {
            if (res.code === 200) {
              that.bindingDialog = false
              that.$message({
                type: 'success',
                showClose: true,
                message: '绑定成功'
              })
              that.getQrcodeList()
            }
          })
        } else {
          return false
        }
      })
    },
    /*
    * 关闭绑定弹窗
    * */
    closeDialog() {
      const that = this
      that.$refs.uesControl.resetFields()
    },
    /*
    * 解除绑定
    * */
    unbindQrCord(param) {
      const that = this
      that.$confirm('此操作将解绑装备, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        http.unbindQrcode(param).then(res => {
          if (res.code === 200) {
            that.getQrcodeList()
            that.$message({
              type: 'success',
              showClose: true,
              message: '解绑成功!'
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          showClose: true,
          message: '已取消解绑'
        })
      })
    },
    /**
     * 解除当前条绑定
     */
    relieveEq(row) {
      const param = [row.qrCode]
      this.unbindQrCord(param)
    },
    /*
    * 批量解除绑定
    * */
    relieveAllEq() {
      const that = this
      const param = []
      if (that.checkArr.length > 0) {
        for (let i = 0; i < that.checkArr.length; i++) {
          if (that.checkArr[i].deviceNo === null) {
            that.$message.error('您选中的二维码未绑定，请先绑定')
            return false
          }
          if (that.checkArr[i].states === 0) {
            that.$message.error('您选中的二维码无效，不能解绑')
            return false
          }
          param.push(that.checkArr[i].qrCode)
        }
        that.unbindQrCord(param)
      } else {
        that.$message.error('请先勾选需要解绑的二维码')
      }
    },
    /*
    * 模糊查询当前装备编号
    * */
    remoteMethod(query) {
      const that = this
      const param = {
        deviceType: that.curDeviceType,
        deviceNo: query
      }
      that.bindList = []
      that.getVehicleList(param)
    },
    /*
    * 二维码图片放大
    * */
    handleImg(row) {
      this.qrObj = { ...row }
      this.arCodeVisible = true
    },
    /* 单个下载二维码 */
    handleDownQrCodeSingle() {
      const param = [this.qrObj.qrCode]
      this.downloadCode(param)
    }
  }
}
</script>

<style lang="stylus" scoped>
.interphone-container {
  .tydic-box {
    padding 0px 0 10px
  }

  .custom-dialog .el-form-item {
    margin-bottom 20px
  }

  .tydic-box .tydic-input ~ .tydic-input {
    margin-left 54px
  }
  padding 0px 20px

  .w200 {
    width 200px
  }

  .w180 {
    width 180px
  }

  .w140 {
    width 140px
  }
}
.el-image-viewer__close{
  color:white;
}
>>>.custom-dialog .el-dialog__header{
  text-align left
  padding-left 30px
}
>>>.bind_dialog .custom-dialog .el-dialog__body {
    padding 20px 15px
  }
>>>.add_dialog .custom-dialog .el-dialog__body {
  padding 20px 15px
}
</style>
