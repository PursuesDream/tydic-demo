<template>
  <div class="archives-container">
    <div style="height:850px;">
      <el-scrollbar class="page-scroll">
        <div class="archive-box">
          <h1 class="archive-title"><span class="icon-content"><i class=" icon-box baseInfo" /></span>车辆基本信息</h1>
          <div class="basic_info">
            <div class="banner_box">
              <div class="main_img"><img :src="curImg" alt=""></div>
              <div class="thumbnail_box">
                <div class="thumbnail_tab">
                  <div id="thumbnail" class="thumbnail">
                    <span v-for="(item, index) in imgUrls" :key="index" :class="{active: activeNum == index}" @click="imgDetail(item, index)"><img :src="item.path" alt=""></span>
                  </div>
                </div>
                <el-button :disabled="disabledLeft" class="arrow_box arrow_left" @click="arrowLeft"><i class="arrow_left_icon" /></el-button>
                <el-button :disabled="disabledRight" class="arrow_box arrow_right" @click="arrowRight"><i class="arrow_right_icon" /></el-button>
              </div>
            </div>
            <div class="info_box">
              <div class="vehicle_info">
                <span class="title">{{ detailInfo.deviceNo }}</span>
                <!-- <span class="vehicle_case oil">
                  平均耗油：9 L/100km
                </span>
                <span class="vehicle_case maintain">
                  百车维修数：23
                </span> -->
              </div>
              <div ref="vehicle_detail" class="vehicle_detail">
                <ul>
                  <li>
                    <span class="msg_key">所属支队：</span>
                    <span class="msg_value">{{ detailInfo.parentOrganName }}</span>
                  </li>
                  <li>
                    <span class="msg_key">所属大队：</span>
                    <span class="msg_value">{{ detailInfo.organName }}</span>
                  </li>
                  <li>
                    <span class="msg_key">责任民警：</span>
                    <span class="msg_value">{{ detailInfo.dutyPoliceName }}/{{ detailInfo.policeNo }}</span>
                  </li>
                  <li>
                    <span class="msg_key">车辆类型：</span>
                    <span class="msg_value">{{ detailInfo.vehicleTypeName }}</span>
                  </li>
                  <li>
                    <span class="msg_key">车辆品牌：</span>
                    <span class="msg_value">{{ detailInfo.vehicleBrandName }}</span>
                  </li>
                  <li>
                    <span class="msg_key">车辆类型：</span>
                    <span class="msg_value">{{ detailInfo.categoryCodeName }}</span>
                  </li>
                  <li v-for="(item, index) in vehicleMsgList" :key="index">
                    <span class="msg_key" :title="item.attrName">{{ item.attrName }}：</span>
                    <span class="msg_value" :title="item.dictName?item.dictName:item.attrValue">{{ item.dictName?item.dictName:item.attrValue }}</span>
                  </li>
                </ul>
                <!-- <ul>

                </ul> -->
                <div v-if="showBtn" class="get_ct_more">
                  <span style="cursor:pointer" @click="showMoreInfo">
                    <span id="more_bt" class="more_bt"><i :class="showBox ? 'icon-top':'icon-bottom'" /></span>{{ showBox?'收起':'展开' }}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="archive-box">
          <h1 class="archive-title"><span class="icon-content"><i class=" icon-box policeInfo" /></span>使用民警</h1>
          <div class="archive-table">
            <el-table
              :data="accountTable"
              class="custom-table"
              max-height="390"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <!-- <el-table-column type="index" width="50" label="序号" align="center" /> -->
              <el-table-column align="center" type="index" label="序号" width="100" :show-overflow-tooltip="true">
                <template slot-scope="scope">
                  {{ scope.$index + 1 + accountPagination.pageSize * (accountPagination.curPage - 1) }}
                </template>
              </el-table-column>
              <el-table-column align="center" prop="policeName" label="姓名" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="policeNo" label="警号" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="ddOrgName" label="所属支队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="zdOrgName" label="所属大队" :show-overflow-tooltip="true" />
              <!-- <el-table-column align="center" prop="kilometres" label="巡逻里程" :show-overflow-tooltip="true" /> -->
              <el-table-column prop="lastTime" align="center" label="最后一次使用" :show-overflow-tooltip="true" />
              <el-table-column prop="repairCount" align="center" label="维修次数" :show-overflow-tooltip="true" />
              <el-table-column prop="repairAmount" align="center" label="维修金额（元）" :show-overflow-tooltip="true" />
              <el-table-column prop="maintainCount" align="center" label="保养次数" :show-overflow-tooltip="true" />
              <el-table-column prop="maintainAmount" align="center" label="保养金额（元）" :show-overflow-tooltip="true" />
              <el-table-column prop="insuranceCount" align="center" label="出险次数" :show-overflow-tooltip="true" />
            </el-table>
            <el-pagination
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="accountPagination.pageSize"
              :total="accountPagination.total"
              :current-page.sync="accountPagination.curPage"
              :page-sizes="pageSizes"
              layout="prev, pager, next, sizes, jumper"
              @size-change="(val) => historyChange('isAccount', val)"
              @current-change="(val) => historyCurPageChange('isAccount', val)"
            />
          </div>
        </div>
        <div class="archive-box">
          <h1 class="archive-title"><span class="icon-content"><i class=" icon-box usedInfo" /></span>使用记录</h1>
          <div class="archive-table">
            <el-table
              :data="useTable"
              class="custom-table"
              max-height="390"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <el-table-column align="center" type="index" label="序号" width="100" :show-overflow-tooltip="true">
                <template slot-scope="scope">
                  {{ scope.$index + 1 + useHistoryPagination.pageSize * (useHistoryPagination.curPage - 1) }}
                </template>
              </el-table-column>
              <el-table-column align="center" prop="policeName" label="姓名" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="policeNo" label="警号" :show-overflow-tooltip="true" />
              <el-table-column prop="ddOrgName" align="center" label="所属支队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="zdOrgName" label="所属大队" :show-overflow-tooltip="true" />
              <el-table-column prop="beginTime" align="center" label="使用开始时间" :show-overflow-tooltip="true" />
              <el-table-column prop="endTime" align="center" label="使用结束时间" :show-overflow-tooltip="true" />
              <!-- <el-table-column prop="kilometres" align="center" label="里程数" :show-overflow-tooltip="true" /> -->
              <!-- <el-table-column prop="cph" align="center" label="平均时速" :show-overflow-tooltip="true" /> -->
              <!-- <el-table-column align="center" label="轨迹回放">
                <template slot-scope="scope">
                  <i class="mapIcon" @click="handleDetail(scope.row, 'isMap')" />
                </template>
              </el-table-column> -->
            </el-table>
            <el-pagination
              v-if="useHistoryPagination.total"
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="useHistoryPagination.pageSize"
              :total="useHistoryPagination.total"
              :current-page.sync="useHistoryPagination.curPage"
              :page-sizes="[5, 10, 15, 20]"
              layout="total, prev, pager, next,sizes, jumper"
              @size-change="(val) => historyChange('isMap', val)"
              @current-change="(val) => historyCurPageChange('isMap', val)"
            />
          </div>
        </div>
        <div class="archive-box">
          <h1 class="archive-title"><span class="icon-content"><i class=" icon-box fixInfo" /></span>维修记录</h1>
          <div class="archive-table">
            <el-table
              :data="serviceTable"
              class="custom-table"
              max-height="390"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <el-table-column align="center" type="index" label="序号" width="100" :show-overflow-tooltip="true">
                <template slot-scope="scope">
                  {{ scope.$index + 1 + servicePagination.pageSize * (servicePagination.curPage - 1) }}
                </template>
              </el-table-column>
              <el-table-column align="center" prop="applyUserName" label="姓名" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="policeNo" label="警号" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="parentOrgName" label="所属支队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="orgName" label="所属大队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="applyTime" label="维修申请时间" :show-overflow-tooltip="true" />
              <el-table-column align="center" label="维保金额" :show-overflow-tooltip="true">
                <template slot-scope="scope">
                  <span>{{ getAllPay(scope.row.items) }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="fixCompanyName" align="center" label="维保单位" :show-overflow-tooltip="true" />
              <el-table-column prop="fixCompanyTel" align="center" label="维保单位联系电话" :show-overflow-tooltip="true" />
              <!-- <el-table-column align="center" label="详情">
                <template slot-scope="scope">
                  <el-button type="text" @click="handleDetail(scope.row,'isFixRecord')">详情</el-button>
                </template>
              </el-table-column> -->
            </el-table>
            <el-pagination
              v-if="servicePagination.total"
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="servicePagination.pageSize"
              :total="servicePagination.total"
              :current-page.sync="servicePagination.curPage"
              :page-sizes="[5, 10, 15, 20]"
              layout="total,prev, pager, next, sizes, jumper"
              @size-change="(val) => historyChange('isFixRecord', val)"
              @current-change="(val) => historyCurPageChange('isFixRecord', val)"
            />
          </div>
        </div>
        <div class="archive-box">
          <h1 class="archive-title"><span class="icon-content"><i class=" icon-box maintenInfo" /></span>保养记录</h1>
          <div class="archive-table">
            <el-table
              :data="insureTable"
              class="custom-table"
              max-height="390"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <el-table-column align="center" type="index" label="序号" width="100" :show-overflow-tooltip="true">
                <template slot-scope="scope">
                  {{ scope.$index + 1 + insurePagination.pageSize * (insurePagination.curPage - 1) }}
                </template>
              </el-table-column>
              <el-table-column align="center" prop="applyUserName" label="姓名" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="policeNo" label="警号" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="parentOrgName" label="所属支队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="orgName" label="所属大队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="applyTime" label="保养申请时间" :show-overflow-tooltip="true" />
              <el-table-column align="center" label="保养金额" :show-overflow-tooltip="true">
                <template slot-scope="scope">
                  <span>{{ getAllPay(scope.row.items) }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="fixCompanyName" align="center" label="维保单位" :show-overflow-tooltip="true" />
              <el-table-column prop="fixCompanyTel" align="center" label="维保单位联系电话" :show-overflow-tooltip="true" />
              <!-- <el-table-column align="center" label="详情">
                <template slot-scope="scope">
                  <el-button type="text" @click="handleDetail(scope.row,'isMaintain')">详情</el-button>
                </template>
              </el-table-column> -->
            </el-table>
            <el-pagination
              v-if="insurePagination.total"
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="insurePagination.pageSize"
              :total="insurePagination.total"
              :current-page.sync="insurePagination.curPage"
              :page-sizes="[5, 10, 15, 20]"
              layout="total,prev, pager, next, sizes, jumper"
              @size-change="(val) => historyChange('isMaintain', val)"
              @current-change="(val) => historyCurPageChange('isMaintain', val)"
            />
          </div>
        </div>
        <div class="archive-box">
          <h1 class="archive-title"><span class="icon-content"><i class=" icon-box insureInfo" /></span>出险记录</h1>
          <div class="archive-table">
            <el-table
              :data="outInsureTable"
              class="custom-table"
              max-height="390"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <el-table-column align="center" type="index" label="序号" width="100" :show-overflow-tooltip="true">
                <template slot-scope="scope">
                  {{ scope.$index + 1 + outInsurePagination.pageSize * (outInsurePagination.curPage - 1) }}
                </template>
              </el-table-column>
              <el-table-column align="center" prop="applyUserName" label="姓名" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="policeNo" label="警号" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="parentOrgName" label="所属支队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="orgName" label="所属大队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="applyTime" label="出险申请时间" :show-overflow-tooltip="true" />
              <el-table-column prop="fixCompanyName" align="center" label="保险单位" :show-overflow-tooltip="true" />
              <el-table-column prop="insuranceType" align="center" label="出险类型" :show-overflow-tooltip="true">
                <template slot-scope="scope">
                  <span>{{ getInsuranceType(scope.row.insuranceType) }}</span>
                </template>
              </el-table-column>
              <!-- <el-table-column align="center" label="详情">
                <template slot-scope="scope">
                  <el-button type="text" @click="handleDetail(scope.row,'isInsurance')">详情</el-button>
                </template>
              </el-table-column> -->
            </el-table>
            <el-pagination
              v-if="outInsurePagination.total"
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="outInsurePagination.pageSize"
              :total="outInsurePagination.total"
              :current-page.sync="outInsurePagination.curPage"
              :page-sizes="[5, 10, 15, 20]"
              layout="total,prev, pager, next, sizes, jumper"
              @size-change="(val) => historyChange('isInsurance', val)"
              @current-change="(val) => historyCurPageChange('isInsurance', val)"
            />
          </div>
        </div>
      </el-scrollbar>
    </div>
    <!-- 弹层 -->
    <el-dialog :width="dialogWidth" custom-class="custom-dialog" :title="detailTitle" :visible.sync="detailDialog" :close-on-click-modal="false" :colse-on-press-escape="false" @close="closeDetail">
      <!-- 轨迹回放 -->
      <div v-if="isMap" style="height: 650px">
        <div style="margin-bottom: 10px;height:40px">
          <el-col :span="8">
            <i class="fontcolor-r">*&nbsp;</i>开始时间：
            <el-date-picker
              v-model="formData.beginTime"
              type="datetime"
              value-format="yyyy-MM-dd HH:mm:ss"
              placeholder="开始时间"
            />
          </el-col>
          <el-col :span="8">
            <i class="fontcolor-r">*&nbsp;</i>结束时间：
            <el-date-picker
              v-model="formData.endTime"
              type="datetime"
              value-format="yyyy-MM-dd HH:mm:ss"
              placeholder="结束时间"
              :picker-options="endTime"
            />
          </el-col>
          <el-col :span="6">
            <i class="fontcolor-r">*&nbsp;</i>播放倍数：
            <el-select v-model="formData.speedSelect" placeholder="">
              <el-option label="正常速度" value="200" />
              <el-option label="x2倍" value="100" />
              <el-option label="x3倍" value="65" />
              <el-option label="x4倍" value="50" />
            </el-select>
          </el-col>
          <el-col :span="2">
            <el-button type="primary search" size="mini" @click="handleTrack"><i class="image-icon search" />播放</el-button>
          </el-col>
        </div>
        <div id="carDetailMap" />
      </div>
      <!-- 维修记录 -->
      <div v-if="isFixRecord" style="height: 650px">
        <div style="font-size:17px">
          <p>
            流程编号： <span style="color:#3aa8e1">{{ infoData.applyNumber }}</span>
          </p>
          <p>
            <el-col :span="8">
              <span>
                申&nbsp;&nbsp;&nbsp;&nbsp;请&nbsp;&nbsp;&nbsp;&nbsp;人&nbsp;&nbsp;&nbsp;&nbsp;：  {{ infoData.applyUserName }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                所属支队：  {{ infoData.parentOrgName }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                所属大队：  {{ infoData.orgName }}
              </span>
            </el-col>
          </p>
          <p>
            <el-col :span="8">
              <span>
                车牌号码：  {{ infoData.vehicleNo }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                维保单位：  {{ infoData.fixCompanyName }}
              </span>
            </el-col>
          </p>
          <p>
            故障描述：{{ infoData.remarks }}
          </p>
          <div class="imgBox">
            <p>
              维保信息：
            </p>
            <div>
              <el-table
                :data="infoData.items"
                class="info-table"
                max-height="390"
                stripe
                border
                show-summary
                :summary-method="getSummaries"
              >
                <el-table-column type="index" width="50" label="序号" align="center" />
                <el-table-column align="center" label="维修配件" prop="parts">
                  <template slot-scope="scope">
                    {{ scope.row.peijianValue }}
                  </template>
                </el-table-column>
                <el-table-column align="center" prop="itemName" label="维修项目">
                  <template slot-scope="scope">
                    {{ scope.row.weixiuValue }}
                  </template>
                </el-table-column>
                <!-- <el-table-column align="center" label="维修配件" prop="fixName" />
                <el-table-column align="center" label="维修项目" prop="fixName" /> -->
                <el-table-column align="center" label="参考单价（元）" width="120" :precision="2">
                  <template slot-scope="scope">
                    {{ scope.row.shopPrice }}
                  </template>
                </el-table-column>
                <el-table-column align="center" label="实际单价（元）" width="150" prop="price" />
                <el-table-column align="center" label="数量" width="120" prop="num" />
                <el-table-column align="center" label="参考工时费（元/小时）" width="150">
                  <template slot-scope="scope">
                    {{ scope.row.shopHourPrice }}
                  </template>
                </el-table-column>
                <el-table-column prop="hourPrice" align="center" label="实际工时费（元/小时）" width="150" />
                <el-table-column prop="workHour" align="center" label="工时（小时）" width="120" />
                <el-table-column align="center" label="费用（元）" width="130" :show-overflow-tooltip="true" prop="amount">
                  <template slot-scope="scope">
                    {{ getAllCost(scope.row) }}
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div class="imgBox">
            <p>
              附件列表（{{ fileLength }}）：
            </p>
            <div>
              <div>
                <el-button type="text" style="margin-left: 10px;" @click="hanlderDownload('all')">保存全部</el-button>
                <div style="max-height: 130px;overflow-y:auto">
                  <p v-for="(item,index) in infoData.annexs" :key="index">
                    <i class="el-icon-link" />
                    <el-button type="text" @click="hanlderDownload('one',item)">{{ item.name }}</el-button>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 保养记录 -->
      <div v-if="isMaintain" style="height: 500px">
        <div style="font-size:17px">
          <p>
            流程编号： <span style="color:#3aa8e1">{{ infoData.applyNumber }}</span>
          </p>
          <p>
            <el-col :span="8">
              <span>
                申&nbsp;&nbsp;&nbsp;&nbsp;请&nbsp;&nbsp;&nbsp;&nbsp;人&nbsp;&nbsp;&nbsp;&nbsp;： {{ infoData.applyUserName }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                所属支队：  {{ infoData.parentOrgName }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                所属大队： {{ infoData.orgName }}
              </span>
            </el-col>
          </p>
          <p>
            <el-col :span="8">
              <span>
                车牌号码：  {{ infoData.vehicleNo }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                维保单位： {{ infoData.fixCompanyName }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                联系电话：  {{ infoData.applyNumber }}
              </span>
            </el-col>
          </p>
          <p>
            故障描述：{{ infoData.remarks }}
          </p>
          <div class="imgBox">
            <p>
              维保信息：
            </p>
            <div>
              <el-table
                :data="infoData.items"
                class="info-table"
                max-height="480"
                stripe
                border
                show-summary
                :summary-method="getSummaries"
              >
                <el-table-column type="index" width="50" label="序号" align="center" />
                <el-table-column align="center" label="维修配件" prop="parts">
                  <template slot-scope="scope">
                    {{ scope.row.peijianValue }}
                  </template>
                </el-table-column>
                <el-table-column align="center" prop="itemName" label="维修项目">
                  <template slot-scope="scope">
                    {{ scope.row.weixiuValue }}
                  </template>
                </el-table-column>
                <!-- <el-table-column align="center" label="维修配件" prop="fixName" :show-overflow-tooltip="true" />
                <el-table-column align="center" label="维修项目" prop="fixName" :show-overflow-tooltip="true" /> -->
                <el-table-column align="center" label="参考单价（元）" width="120" :show-overflow-tooltip="true">
                  <template slot-scope="scope">
                    {{ scope.row.shopPrice }}
                  </template>
                </el-table-column>
                <el-table-column align="center" label="实际单价（元）" width="150" prop="price" :show-overflow-tooltip="true" />
                <el-table-column align="center" label="数量" width="120" prop="num" :show-overflow-tooltip="true" />
                <el-table-column align="center" label="参考工时费（元/小时）" width="150" :show-overflow-tooltip="true">
                  <template slot-scope="scope">
                    {{ scope.row.shopHourPrice }}
                  </template>
                </el-table-column>
                <el-table-column prop="hourPrice" align="center" label="实际工时费（元/小时）" width="150" />
                <el-table-column prop="workHour" align="center" label="工时（小时）" width="120" />
                <el-table-column align="center" label="费用（元）" width="130" :show-overflow-tooltip="true" prop="amount">
                  <template slot-scope="scope">
                    {{ getAllCost(scope.row) }}
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div class="imgBox">
            <p>
              附件列表（{{ fileLength }}）：：
            </p>
            <div>
              <div>
                <el-button type="text" style="margin-left: 10px;" @click="hanlderDownload('all')">保存全部</el-button>
                <div style="max-height: 130px;overflow-y:auto">
                  <p v-for="(item,index) in infoData.annexs" :key="index">
                    <i class="el-icon-link" />
                    <el-button type="text" @click="hanlderDownload('one',item)">{{ item.name }}</el-button>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 出险记录 -->
      <div v-if="isInsurance" style="height: 350px">
        <div style="font-size:17px">
          <p>
            流程编号： <span style="color:#3aa8e1">{{ infoData.applyNumber }}</span>
          </p>
          <p>
            <el-col :span="8">
              <span>
                申&nbsp;&nbsp;&nbsp;&nbsp;请&nbsp;&nbsp;&nbsp;&nbsp;人&nbsp;&nbsp;&nbsp;&nbsp;：   {{ infoData.applyUserName }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                所属支队：  {{ infoData.parentOrgName }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                所属大队：  {{ infoData.orgName }}
              </span>
            </el-col>
          </p>
          <p>
            <el-col :span="8">
              <span>
                车牌号码：  {{ infoData.vehicleNo }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                保险单位：  {{ infoData.fixCompanyName }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                出险类型：  {{ getInsuranceType(infoData.insuranceType) }}
              </span>
            </el-col>
          </p>
          <p>
            故障描述：{{ infoData.remarks }}
          </p>
          <div>
            <div>
              <span style="font-size:17px">附件列表（{{ fileLength }}）：</span>
              <div>
                <el-button type="text" style="margin-left: 10px;" @click="hanlderDownload('all')">保存全部</el-button>
                <div style="max-height: 130px;overflow-y:auto">
                  <p v-for="(item,index) in infoData.annexs" :key="index">
                    <i class="el-icon-link" />
                    <el-button type="text" @click="hanlderDownload('one',item)">{{ item.name }}</el-button>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getInterphoneUse, getInterphoneUser, getInterphone, getEqDetail } from '@/api/interphone'
import { downLoadFile, downLoadAllFIle } from '@/api/public'
import { getAttributeList } from '@/api/attributeManage'
import { getCategoryList, getCategoryCodeByVehicleNo } from '@/api/integratedManage'
import { getFixItemconfigByFixId, getFixList } from '@/api/fixProject'
import { getFixDetail, getFixData } from '@/api/processManagement'
import mapUtil from '@/utils/map/mapUtil'
import { getWarnTrack } from '@/api/realTimeMonitoring'
import iconM from '@/assets/mapIcon/011.png'
import { mapState } from 'vuex'
import { parseTime } from '@/utils'
// 因为BMap是挂在window对象上的，防止报错要加上window
const BMap = window.BMap
export default {
  name: 'CarArchives',
  data() {
    return {
      formData: {
        beginTime: '',
        endTime: '',
        speedSelect: '200',
        vehicleNo: ''
      },
      showBtn: false,
      imgUrls: [],
      infoData: {},
      detailInfo: {},
      moveSpeed: 200,
      deviceId: '',
      useHistoryPagination: {
        curPage: 1,
        pageSize: 10,
        total: 10
      },
      dialogWidth: '900px',
      maps: '',
      imgUrl: iconM,
      imgArray: [iconM],
      activeTabButton: '01',
      isMap: false,
      isFixRecord: false,
      isMaintain: false,
      isInsurance: false,
      detailTitle: '',
      detailDialog: false,
      pageSizes: [5, 10, 15, 20],
      buttonList: [
        { name: '概要信息', value: '01' },
        { name: '相关用户', value: '02' },
        { name: '使用记录', value: '03' },
        { name: '维修记录', value: '04' },
        { name: '保养记录', value: '05' },
        { name: '出险记录', value: '06' }
      ],
      /* carPictures: [require('@/assets/testImg/Chrysanthemum.jpg'), require('@/assets/testImg/Desert.jpg'), require('@/assets/testImg/Hydrangeas.jpg'), require('@/assets/testImg/Jellyfish.jpg'), require('@/assets/testImg/Koala.jpg'), require('@/assets/testImg/Chrysanthemum.jpg')], */
      carPictures: ['1', '1', '1', '1', '1', '1'],
      selectPic: '',
      swiperOptions: {
        notNextTick: true,
        spaceBetween: 30,
        slidesPerView: 4
      },
      accountTable: [],
      accountPagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      useTable: [],
      useTablePagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      serviceTable: [],
      servicePagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      fixTable: [
        { fixName: '配件1', num: 10, shopPrice: 10, price: 10, shopHourPrice: 10, hourPrice: 10, workHour: 10, amount: 10 }

      ],
      insureTable: [],
      insurePagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      multipleSeletcion: [],
      outInsureTable: [],
      outInsurePagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      showBox: false,
      thumbnailDom: null,
      thumbnailPositon: 0,
      disabledLeft: true,
      disabledRight: false,
      defaultImg: require('../../assets/icons/errorImg.jpg'),
      activeNum: 0,
      curImg: '',
      vehicleMsgList: []
    }
  },
  computed: {
    ...mapState({
      mapData: state => state.user.mapData
    }),
    archiveTitle() {
      const id = this.$route.params && this.$route.params.deviceNo
      const value = id || ''
      return '档案 >>> ' + value
    },
    fileLength() {
      let length = 0
      if (this.infoData.annexs && this.infoData.annexs.length) length = this.infoData.annexs.length
      return length
    },
    endTime() {
      let startTime = this.formData.beginTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          startTime = new Date(startTime).getTime()
          if (nowDate < startTime) return true
          else return false
        }
      }
    }
  },
  mounted() {
    // this.initSwiper()
    this.getAllCategory()
    this.setTagsViewTitle()
    this.formatDate()
  },
  methods: {
    /**
     * 查询所有车辆类型
     */
    getAllCategory() {
      const _this = this
      const params = {
        categoryCode: '',
        categoryType: '1'
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          _this.carType = res.data
        }
      })
    },
    /**
     * 查询属性列表
     */
    getAttributeList() {
      const param = this.detailInfo.categoryCode
      getAttributeList(param).then(res => {
        if (res.code === 200) {
          this.vehicleMsgList = res.data.filter(item => {
            return item.attrType !== 2 && item.paramType !== 2
          })
          getEqDetail(this.deviceId).then(res => {
            if (res.code === 200) {
              res.data.attrList.map(item => {
                item.attrName = item.attrKey
                if (item.dictType) {
                  // item.dictName =
                  this.mapData[item.dictType].every(dict => {
                    if (dict.code === item.attrValue) {
                      item.dictName = dict.name
                      return false
                    } else return true
                  })
                }
              })
              this.vehicleMsgList = this.vehicleMsgList.concat(res.data.attrList)
            }
          })
          this.imgUrls = res.data.filter(item => {
            return item.attrType === 2
          })
          this.imgUrls.map(item => {
            item.name = item.attrName
          })
          this.$nextTick(_ => {
            this.thumbnailDom = document.getElementById('thumbnail')
            if (this.imgUrls.length > 0) {
              this.curImg = this.imgUrls[0].path
            } else {
              this.curImg = this.defaultImg
            }
            if (this.thumbnailDom.offsetWidth < 300) {
              this.disabledLeft = true
              this.disabledRight = true
            }
            this.refreshCount()
          })
        }
      })
    },
    /**
     * 展示更多
     */
    refreshCount() {
      var obj = document.getElementsByClassName('vehicle_detail')
      var show_height = 250// 定义原始显示高度
      // console.log(obj[0].scrollHeight)
      if (obj[0].scrollHeight > show_height) {
        this.showBtn = true
      }
    },
    /**
     * 展示更多按钮
     */
    showMoreInfo() {
      var obj = this.$refs.vehicle_detail
      this.showBox = !this.showBox
      var total_height = obj.scrollHeight// 文章总高度
      var show_height = 250// 定义原始显示高度
      if (this.showBox) {
        obj.style.height = total_height + 'px'
      } else {
        obj.style.height = show_height + 'px'
        this.showBox = false
      }
    },
    /**
     * 计算维保金额
     */
    getAllPay(row) {
      let result = 0
      row.reduce((res, item) => {
        result += item.amount
      }, 0)
      return result.toFixed(2)
    },
    /**
     * 转义车辆类型
     */
    getVehicleBrands(id, listName) {
      let name = ''
      const list = this[listName]
      const ids = id + ''
      for (let i = 0; i < list.length; i++) {
        if (list[i].categoryCode === ids) {
          name = list[i].categoryName
          break
        }
      }
      return name
    },
    /**
     * 出险类型名称转换
     */
    getInsuranceType(id) {
      let name = ''
      const ids = id + ''
      const list = this.mapData.fix_apply_insurance_type
      for (let i = 0; i < list.length; i++) {
        if (list[i].code === ids) {
          name = list[i].name
          break
        }
      }
      return name
    },
    /**
    * 使用民警
    */
    usedUserHistory() {
      const _this = this
      _this.accountTable = []
      const params = {
        deviceId: _this.deviceId,
        pageNum: _this.accountPagination.curPage,
        pageSize: _this.accountPagination.pageSize
      }
      getInterphoneUser(params).then(res => {
        if (res.code === 200) {
          const data = res.data
          _this.accountTable = data.rows
          _this.accountPagination.total = data.total
        }
      })
    },
    /**
    * 使用记录条件查询
    */
    searchHistory() {
      const _this = this
      _this.useTable = []
      const params = {
        deviceId: _this.deviceId,
        usePoliceName: '',
        beginTime: '',
        endTime: '',
        pageNum: _this.useHistoryPagination.curPage,
        pageSize: _this.useHistoryPagination.pageSize
      }
      getInterphoneUse(params).then(res => {
        if (res.code === 200) {
          _this.useTable = res.data.rows
          _this.useHistoryPagination.total = res.data.total
        }
      })
    },
    /**
     * 使用记录分页
     */
    historyChange(type, val) {
      const _this = this
      if (type === 'isMap') {
        _this.useHistoryPagination.pageSize = val
        _this.searchHistory()
      } else if (type === 'isFixRecord') {
        _this.servicePagination.pageSize = val
        _this.getFixApply()
      } else if (type === 'isMaintain') {
        _this.insurePagination.pageSize = val
        _this.getMaintainApply()
      } else if (type === 'isInsurance') {
        _this.outInsurePagination.pageSize = val
        _this.getInsuranceApply()
      } else if (type === 'isAccount') {
        _this.accountPagination.pageSize = val
        _this.usedUserHistory()
      }
    },
    /**
    * 使用记录分页跳转
    */
    historyCurPageChange(type, val) {
      const _this = this
      if (type === 'isMap') {
        _this.useHistoryPagination.curPage = val
        _this.searchHistory()
      } else if (type === 'isFixRecord') {
        _this.servicePagination.curPage = val
        _this.getFixApply()
      } else if (type === 'isMaintain') {
        _this.insurePagination.curPage = val
        _this.getMaintainApply()
      } else if (type === 'isInsurance') {
        _this.outInsurePagination.curPage = val
        _this.getInsuranceApply()
      } else if (type === 'isAccount') {
        _this.accountPagination.curPage = val
        _this.usedUserHistory()
      }
    },
    handleSelectionChange(val) {
      this.multipleSeletcion = val
    },
    getAllCost(row) {
      const count = row.num
      const peijianNow = row.price
      const weixiuNow = row.hourPrice
      const hour = row.workHour
      const amount = count * peijianNow + weixiuNow * hour || 0
      row.amount = amount.toFixed(2)
      return amount.toFixed(2)
    },
    getSummaries(param) {
      const { columns, data } = param
      const sums = []
      columns.forEach((column, index) => {
        if (index === 0) {
          sums[index] = '合计'
          return
        }
        const values = data.map(item => Number(item[column.property]))
        if (column.property === 'amount') {
          sums[index] = values.reduce((prev, curr) => {
            const value = Number(curr)
            if (!isNaN(value)) {
              return prev + curr
            } else {
              return prev
            }
          }, 0)
          sums[index] += '元'
        } else {
          sums[index] = ''
        }
      })
      return sums
    },
    initSwiper() {
      console.log(this.$refs.swiper)
    },
    initMap() {
      const _this = this
      const BMap = window.BMap
      _this.maps = new BMap.Map('carDetailMap')
      const point = new BMap.Point(116.417804, 39.940296)
      // const point2 = new BMap.Point(114.154658527, 22.2878)
      _this.maps.centerAndZoom(point, 12)
      const marker = new BMap.Marker(point)
      marker.disableDragging()
      _this.maps.enableScrollWheelZoom() // 启用滚轮放大缩小，默认禁用
      _this.maps.enableContinuousZoom() // 启用地图惯性拖拽，默认禁用
    },
    setTagsViewTitle() {
      const params = this.$route.params
      // this.detailInfo = JSON.parse(sessionStorage.getItem('detailInfo'))
      this.deviceId = params.id
      const title = '车辆档案'
      const tempRoute = Object.assign({}, this.$route)
      const route = Object.assign({}, tempRoute, { title })
      this.$store.dispatch('tagsView/updateVisitedView', route)
      this.$nextTick(this.searchHistory)
      this.$nextTick(this.getEqDetail)
      this.$nextTick(this.getFixApply)
      this.$nextTick(this.getMaintainApply)
      this.$nextTick(this.getInsuranceApply)
      this.$nextTick(this.usedUserHistory)
    },
    changeTabButton(value) {
      this.activeTabButton = value
    },
    /**
     * 查询设备详情
     */
    getEqDetail() {
      const _this = this
      const param = {
        deviceId: _this.deviceId
      }
      getInterphone(param).then(res => {
        if (res.code === 200) {
          _this.detailInfo = res.data.rows[0]
          this.formData.vehicleNo = this.detailInfo.deviceNo
          this.getAttributeList()
        }
      })
    },
    handleDetail(row, type) {
      const _this = this
      if (type === 'isMap') {
        _this.isMap = true
        _this.detailTitle = '铁骑轨迹'
        _this.dialogWidth = '1180px'
        _this.$nextTick(_ => {
          _this.initMap()
          // _this.$nextTick(_ => {
          //   // const layerId = '小车运动'
          //   // mapUtil.removeMapOverlay(_this.maps, layerId)
          //   _this.handleTrack()
          // })
        })
      } else if (type === 'isFixRecord') {
        _this.isFixRecord = true
        _this.detailTitle = '维修记录详情'
        _this.dialogWidth = '1180px'
        this.getApplyDetail(row.applyId)
      } else if (type === 'isMaintain') {
        _this.isMaintain = true
        _this.detailTitle = '保养记录详情'
        _this.dialogWidth = '1180px'
        this.getApplyDetail(row.applyId)
      } else if (type === 'isInsurance') {
        _this.isInsurance = true
        _this.detailTitle = '出险记录详情'
        _this.dialogWidth = '900px'
        this.getApplyDetail(row.applyId)
      }
      this.detailDialog = true
    },
    /**
    * 查询详情
    */
    getApplyDetail(val) {
      const that = this
      that.infoData = {}
      getFixDetail(val).then(res => {
        res.data.items.forEach(o => {
          o.peijianValue = ''
          o.weixiuValue = ''
        })
        this.infoData = res.data
        // 配件名称列表回显
        getCategoryCodeByVehicleNo({
          vehicleNo: this.infoData.vehicleNo
        }).then(res => { // 根据车牌号查询型号代码
          const categoryCode = res.data || ''
          that.categoryCode = categoryCode
          that.vehicleBrand = that.getVehicleBrands(that.infoData.vehicleType, 'carType')
          const params = {}
          const data = {
            vehicleType: that.infoData.vehicleType,
            vehicleBrand: that.vehicleBrand,
            categoryCode,
            guaranteeType: that.infoData.flowType
          }
          that.peijianList = []
          getFixList({ data, params }).then(res => {
            if (res.code === 200) {
              that.peijianList = res.data.rows || []
              that.infoData.items.forEach(o => {
                that.peijianList.every(pj => {
                  if (pj.fixId === o.fixId) {
                    o.peijianValue = pj.ports
                    return false
                  } else return true
                })
                const data = {
                  fixId: o.fixId
                }
                // 维修项目列表回显
                getFixItemconfigByFixId(data).then(res => {
                  if (res.code === 200) {
                    o.weixiuList = res.data || []
                    o.weixiuList.every(wx => {
                      if (wx.fixItemId === o.fixItemId) {
                        o.weixiuValue = wx.itemName
                        return false
                      } else return true
                    })
                  }
                })
              })
            }
          })
        })
      }).catch(err => {
        console.log(err)
      })
    },
    closeDetail() {
      const _this = this
      _this.isMap = false
      _this.isFixRecord = false
      _this.isMaintain = false
      _this.isInsurance = false
    },
    /**
    *时间格式化
    */
    formatDate() {
      const _this = this
      // 获取格林时间
      var date1 = new Date(new Date(new Date().toLocaleDateString()).getTime())
      const myDate = new Date()
      _this.formData.beginTime = parseTime(date1)
      _this.formData.endTime = parseTime(myDate)
    },
    /**
    * 地图轨迹回放
    */
    handleTrack() {
      const _this = this
      const layerId = '小车运动'
      mapUtil.removeMapOverlay(_this.maps, layerId)
      const param = {
        beginTime: _this.formData.beginTime,
        endTime: _this.formData.endTime,
        vehicleNo: _this.formData.vehicleNo
      }
      if (_this.formData.speedSelect !== '') {
        _this.moveSpeed = _this.formData.speedSelect
      }
      getWarnTrack(param).then(res => {
        if (res.code === 200) {
          const pointArr = []
          res.data.forEach(item => {
            pointArr.push(new BMap.Point(item.longBaidu, item.latBaidu))
          })
          mapUtil.trackAnimation(_this.maps, pointArr, _this.moveSpeed)
        }
      }).catch(err => {
        console.log(err)
      })
    },
    /**
     * 查询设备维修申请列表
     */
    getFixApply() {
      const _this = this
      _this.serviceTable = []
      const param = {
        deviceId: _this.deviceId,
        flowType: 1,
        flowState: '2',
        pageNum: _this.servicePagination.curPage,
        pageSize: _this.servicePagination.pageSize
      }
      getFixData(param).then(res => {
        if (res.code === 200) {
          _this.serviceTable = res.data.rows
          _this.servicePagination.total = res.data.total
        }
      }).catch(err => {
        console.log(err)
      })
    },
    /**
     * 查询设备保养申请列表
     */
    getMaintainApply() {
      const _this = this
      _this.insureTable = []
      const param = {
        deviceId: _this.deviceId,
        flowType: 2,
        flowState: '2',
        pageNum: _this.insurePagination.curPage,
        pageSize: _this.insurePagination.pageSize
      }
      getFixData(param).then(res => {
        if (res.code === 200) {
          _this.insureTable = res.data.rows
          _this.insurePagination.total = res.data.total
        }
      }).catch(err => {
        console.log(err)
        _this.isLoading = false
      })
    },
    /**
     * 查询设备出险申请列表
     */
    getInsuranceApply() {
      const _this = this
      _this.outInsureTable = []
      const param = {
        deviceId: _this.deviceId,
        flowType: 3,
        flowState: '2',
        pageNum: _this.outInsurePagination.curPage,
        pageSize: _this.outInsurePagination.pageSize
      }
      getFixData(param).then(res => {
        if (res.code === 200) {
          _this.outInsureTable = res.data.rows
          _this.outInsurePagination.total = res.data.total
        }
      }).catch(err => {
        console.log(err)
        _this.isLoading = false
      })
    },
    /**
     * 附件下载
     */
    hanlderDownload(flag, obj) {
      if (flag === 'one') {
        downLoadFile({
          fileName: obj.name,
          fileUrl: obj.url
        }).then(res => {
          const url = window.URL.createObjectURL(new Blob([res]))
          const link = document.createElement('a')
          link.style.display = 'none'
          link.href = url
          const fileName = obj.name
          link.setAttribute('download', fileName)
          document.body.appendChild(link)
          link.click()
        })
      } else {
        const names = []
        const urls = []
        this.infoData.annexs.forEach(o => {
          names.push(o.name)
          urls.push(o.url)
        })
        downLoadAllFIle({
          names, urls
        }).then(res => {
          const url = window.URL.createObjectURL(new Blob([res]))
          const link = document.createElement('a')
          link.style.display = 'none'
          link.href = url
          const fileName = '全部文件.zip'
          link.setAttribute('download', fileName)
          document.body.appendChild(link)
          link.click()
        })
      }
    },
    /*
    * 轮播左切换
    * */
    arrowLeft() {
      const that = this
      const domL = that.thumbnailDom.offsetLeft
      if (domL >= 0) {
        that.disabledLeft = true
        return false
      } else {
        that.thumbnailPositon += 75
        that.thumbnailDom.style.left = that.thumbnailPositon + 'px'
        that.disabledRight = false
      }
    },
    /*
    * 轮播右切换
    * */
    arrowRight() {
      const that = this
      const domL = that.thumbnailDom.offsetLeft
      const domW = that.thumbnailDom.offsetWidth
      // const width = this.imgUrls.length * 75
      if (domL + domW <= 370) {
        that.disabledRight = true
        return false
      } else {
        that.thumbnailPositon -= 75
        that.thumbnailDom.style.left = that.thumbnailPositon + 'px'
        that.disabledLeft = false
      }
    },
    /*
    * 显示轮播缩略图详情
    * */
    imgDetail(data, index) {
      this.activeNum = index
      this.curImg = data.path
    }
  }
}
</script>

<style lang="stylus" scoped>
.archives-container {
    padding 10px 30px
    overflow auto
    height 800px
    // position relative

    .icon-content{
      display:inline-block
      vertical-align: middle
      width: 40px;
      height: 40px;
      background: #3699FF;
      border-radius: 0px 14px 0px 0px;
      margin-right:10px
    }
    .icon-box{
      display:inline-block
      vertical-align: middle
      width: 17px;
      height: 18px;
      margin-left: 10px;
      &.baseInfo {
        background-image url('~@/assets/icons/icon_49.png')
      }
      &.policeInfo {
        background-image url('~@/assets/icons/icon_52.png')
        height 13px
      }
      &.usedInfo{
        width: 16px;
        background-image url('~@/assets/icons/icon_51.png')
      }
      &.fixInfo{
        background-image url('~@/assets/icons/icon_54.png')
        width: 16px;
        height: 16px;
      }
      &.maintenInfo{
        width: 13px;
        height: 16px;
        background-image url('~@/assets/icons/icon_66.png')
      }
      &.insureInfo{
        width: 17px;
        height: 18px;
        background-image url('~@/assets/icons/icon_68.png')
      }
    }
    .tab-button-group {
        position absolute
        z-index 99
        top 50px
        right 10px
        width 120px
        >button {
            display block
            width 100%
            height 40px
            text-align center
            border 1px solid rgb(170,170,170)
            border-radius 5px
            font-size 13px
            color #000
            outline none
            background-color white
            cursor pointer
            margin-bottom 30px
            &:last-child {
                margin-bottom 0
            }
            &.active {
                background-color #169bd5
                color white
                border-color #169bd5
            }
        }
    }
    .archive-box {
        border 1px solid #ebebeb
        margin-bottom 20px
        // padding 0px 10px
        box-shadow 0 2px 12px 0 rgba(0, 0, 0, 0.1)
        background white
        .mapIcon{
          width 25px
          height 24px
          cursor pointer
          margin auto
          display block
          background-repeat no-repeat
          background-size contain
          background-image url("../../assets/icons/icon_48.png")
        }
        .archive-title {
            height 40px
            border-bottom 1px solid #ebebeb
            // background-image linear-gradient(-90deg,rgb(255,255,255) 26%,rgb(2,167,240) 99%)
            margin 0
            font-size 18px
            font-weight 650
            line-height 39px
            // padding-left 50px
        }
        .archive-table {
            padding 10px 0px 10px 0px
            max-height 458px
            overflow: hidden;
        }
        .basic_info {
          width 100%
          min-height 330px
          overflow: hidden
          .banner_box {
            width 25%
            height 100%
            float: left;

            .main_img {
              width 230px
              height 230px
              margin 24px auto 0

              img {
                width 100%
                height 100%
              }
            }

            .thumbnail_box {
              width 330px
              height 40px
              padding 0 30px
              margin: 13px auto 0;
              position: relative;

              .thumbnail_tab {
                width 100%
                height 40px
                overflow: hidden;
                position relative

                .thumbnail {
                  height 40px
                  padding 0
                  white-space: nowrap;
                  position absolute
                  left 0
                  top 0

                  span {
                    width 60px
                    height 40px
                    display inline-block
                    text-align: center;
                    border: 1px solid transparent;
                    box-sizing: border-box;
                    cursor pointer
                    &~span {
                      margin-left 10px
                    }
                    img {
                      width 100%
                      height 100%
                    }
                  }

                  span.active {
                    border 1px solid #09dcf1
                  }
                }
              }

              .arrow_box {
                border: none;
                background: transparent;
                line-height: 0;
                padding 0
                position absolute
                top 50%
                transform translateY(-50%)

                i {
                  width 22px
                  height 24px
                  display block
                  background-repeat no-repeat
                  background-size contain
                }

                i.arrow_left_icon {
                  background-image url("../../assets/icons/icon_56.png")
                }

                i.arrow_right_icon {
                  background-image url("../../assets/icons/icon_55.png")
                }
              }

              .arrow_box.arrow_left {
                left 0
              }

              .arrow_box.arrow_right {
                right 0
              }

              .el-button.is-disabled {
                opacity 0.5
              }
            }
          }
          .title {
                font-size 20px
                color #3699FF
                float: left
              }
          .info_box {
            width 75%
            padding: 20px 0 0 20px
            overflow hidden
            float: left
            .vehicle_info {
              width 100%
              height 36px
              line-height 36px

              .vehicle_case {
                margin-left 50px
                float: left
                padding-left 30px
                position: relative;
              }
              .vehicle_case:before {
                content ''
                width 24px
                height 24px
                display block
                background-repeat no-repeat
                background-size contain
                position: absolute;
                left 0
                top 5px
              }
              .vehicle_case.oil:before {
                background-image url("../../assets/icons/icon_50.png")
              }
              .vehicle_case.maintain:before {
                background-image url("../../assets/icons/icon_53.png")
              }
            }
            .vehicle_detail {
              width 100%
              // border: 1px solid rgba(54,153,255,0.3);
              padding:5px 5px
              margin-bottom 5px
              height:250px;        /*初始要显示的高度*/
              overflow:hidden;    /*关键样式：内容会被修剪，并且其余内容是不可见的。*/
              position:relative
              div{
                clear:both;
                min-height:1em;
                white-space:pre-wrap; /*如何处理元素内的空白*/
              }
              .get_ct_more {
                  height:78px;
                  position:absolute;
                  bottom:0px;width:100%;
                  background:linear-gradient(to top,#fff,rgba(255,255,255,0) 70%);
                  margin:0px;
                  margin-right:10px
                  color orange
                  .icon-top {
                    display inline-block
                    transform rotate(180deg)
                    width:16px;
                    height:13px;
                    background-image url('../../assets/icons/icon_47.png')
                  }
                  .icon-bottom {
                    display inline-block
                    width:16px;
                    height:13px;
                    background-image url('../../assets/icons/icon_47.png')
                    transform rotate(360deg)
                  }
              }
              .more_bt {
                  display inline-block
                  cursor pointer
                  width:16px;
                  height:13px;
                  margin-left:43%;
                  margin-bottom:-10px
                  margin-top: 60px;
              }
              ul {
                width 100%
                list-style none
                overflow: hidden;
                padding: 0;
                li {
                  width 25%
                  line-height 36px
                  float: left
                  span {
                    display inline-block
                    font-size 14px
                    overflow: hidden;
                  }
                  span.msg_key {
                    width 35%
                    text-align left
                    text-overflow:ellipsis;
                    white-space: nowrap;
                  }
                  span.msg_value {
                    width 60%
                    overflow: hidden;
                    text-overflow:ellipsis;
                    white-space: nowrap;
                  }
                }
              }
            }
          }
        }
    }
    #carDetailMap{
      margin-top 10px
      width 1162px
      height 600px
    }
    .dashBox{
      display inline-block
      height 115px
      border 1px dashed #ebebeb
      margin-left 10px
      padding 5px 5px
      width 115px
    }
    .info-container {
        // padding-left 340px
        height 200px
        width 100%
        .textTitle {
          color #3274e1
          font-size 25px
          font-weight bold
        }

    }
}
</style>
