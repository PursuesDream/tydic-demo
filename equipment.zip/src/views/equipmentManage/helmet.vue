<template>
  <div class="helmet-container">
    <div>
      <div>
        <!-- <el-card> -->
        <div class="tydic-box">
          <div class="tydic-input">
            所属大队：
            <el-select v-model="formData.ssdd" placeholder="请选择" clearable>
              <el-option
                v-for="(o,index) in daduiList"
                :key="index"
                :label="o.name"
                :value="o.value"
              />
            </el-select>
          </div>
          <div class="tydic-input">
            所属中队：
            <el-select v-model="formData.sszd" placeholder="请选择" clearable>
              <el-option
                v-for="(o,index) in zhongduiList"
                :key="index"
                :label="o.name"
                :value="o.value"
              />
            </el-select>
          </div>
          <div class="tydic-input">
            警号：
            <el-input v-model="formData.cph" placeholder="请输入" />
          </div>
          <div class="tydic-input">
            姓名：
            <el-input v-model="formData.user" placeholder="请输入" />
          </div>
          <div style="text-align: center;margin-bottom: 15px;">
            <el-button type="primary color1" size="mini" @click="onSearch">查询</el-button>
            <el-button type="primary color2" size="mini" @click="onReset">重置</el-button>
            <el-button type="primary color3" size="mini" @click="handleAdd">新增</el-button>
            <el-button type="primary color4" size="mini" @click="onImport">导入</el-button>
            <el-button type="primary color5" size="mini" @click="onOutput">导出</el-button>
          </div>
          <div class="table-box">
            <el-table
              :data="tableData"
              class="custom-table"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <el-table-column type="index" width="50" label="序号" align="center" />
              <el-table-column align="center" prop="ssdd" label="设备编号" />
              <el-table-column align="center" prop="sszd" label="名称" />
              <el-table-column
                prop="carType"
                align="center"
                label="状态"
                :show-overflow-tooltip="true"
              />
              <el-table-column
                prop="cjh"
                align="center"
                label="所属大队"
                :show-overflow-tooltip="true"
              />
              <el-table-column
                prop="cph"
                align="center"
                label="所属中队"
                :show-overflow-tooltip="true"
              />
              <el-table-column
                prop="time"
                align="center"
                label="警号"
                :show-overflow-tooltip="true"
              />
              <el-table-column
                prop="carStaus"
                align="center"
                label="姓名"
                :show-overflow-tooltip="true"
              />
              <el-table-column
                prop="useStaus"
                align="center"
                label="品牌"
                :show-overflow-tooltip="true"
              />
              <el-table-column
                prop="instance"
                align="center"
                label="型号"
                :show-overflow-tooltip="true"
              />
              <el-table-column
                prop="userCode"
                align="center"
                label="材质"
                :show-overflow-tooltip="true"
              />
              <el-table-column
                prop="baoyang"
                align="center"
                label="入库时间"
                :show-overflow-tooltip="true"
              />
              <el-table-column align="center" label="操作">
                <template slot-scope="scope">
                  <el-button
                    type="text"
                    size="small"
                    @click="handleDetail(scope.row)"
                  >详情</el-button>
                  <el-button
                    type="text"
                    size="small"
                    @click="handleEdit(scope.row)"
                  >编辑</el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <!-- @current-change="handleCurrentChange" -->
        <div style="text-align: center">
          <el-pagination
            ref="pagination"
            style="text-align: center;margin-top:15px;"
            background
            :page-size="pageSize"
            :total="total"
            :current-page.sync="curPage"
            :page-sizes="pageSizes"
            layout="prev, pager, next, sizes, jumper"
          />
        </div>
        <el-dialog :title="formTitle" :visible.sync="formVisible" width="1000px" custom-class="custom-dialog" :close-on-click-modal="false" :colse-on-press-escape="false">
          <el-form :ref="addDataForm" :model="addDataForm">
            <el-form-item>
              <el-col :span="8">
                <el-col :span="10" align="right"><i class="fontcolor-r">*&nbsp;</i>设备编号：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.num"
                    type="text"
                    size="mini"
                    placeholder="请输入"
                    width="80px"
                    :disabled="isDetail || isEdit"
                  />
                </el-col>
              </el-col>
              <el-col :span="8">
                <el-col :span="10" align="right"><i class="fontcolor-r">*&nbsp;</i>名称：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.name"
                    type="text"
                    size="mini"
                    placeholder="请输入"
                    :disabled="isDetail"
                    width="80px"
                  />
                </el-col>
              </el-col>
              <el-col :span="8">
                <el-col :span="10" align="right">品牌：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.pinpai"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
            </el-form-item>
            <el-form-item>
              <el-col :span="8">
                <el-col :span="10" align="right">生产厂商：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.changjia"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
              <el-col :span="8">
                <el-col :span="10" align="right">头长：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.touchang"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
              <el-col :span="8">
                <el-col :span="10" align="right">头宽：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.toukuan"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
            </el-form-item>
            <el-form-item>
              <el-col :span="8">
                <el-col :span="10" align="right">头全高：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.headHight"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
              <el-col :span="8">
                <el-col :span="10" align="right">头耳高：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.ergao"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
              <el-col :span="8">
                <el-col :span="10" align="right">两耳外宽：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.erwaikuan"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
            </el-form-item>
            <el-form-item>
              <el-col :span="8">
                <el-col :span="10" align="right">材质：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.caizhi"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
              <el-col :span="8">
                <el-col :span="10" align="right">颜色：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.color"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
              <el-col :span="8">
                <el-col :span="10" align="right">重量：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.weight"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
            </el-form-item>
            <el-form-item>
              <el-col :span="8">
                <el-col :span="10" align="right">出厂日期：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.chuchang"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
              <el-col :span="8">
                <el-col :span="10" align="right">强制报废日期：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.baofei"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
              <el-col :span="8">
                <el-col :span="10" align="right">所属单位：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.ssdw"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
            </el-form-item>
            <el-form-item>
              <el-col :span="8">
                <el-col :span="10" align="right">所有人：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.owner"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
              <el-col :span="8">
                <el-col :span="10" align="right">所有人证件：</el-col>
                <el-col :span="14">
                  <el-input
                    v-model="addDataForm.idCard"
                    type="text"
                    size="mini"
                    :disabled="isDetail"
                    placeholder="请输入"
                    width="80px"
                  />
                </el-col>
              </el-col>
            </el-form-item>
          </el-form>
          <div style="text-align: center">
            <el-button type="primary color1" size="mini">保存</el-button>
            <el-button type="primary color2" size="mini">重置</el-button>
            <el-button type="primary color-cancel" size="mini">取消</el-button>
          </div>
        </el-dialog>
        <!-- </el-card> -->
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'Helmet',
  data() {
    return {
      formData: {
        ssdd: '',
        sszd: '',
        cph: '',
        startTime: '',
        endTime: '',
        user: '',
        carType: '',
        pinpai: '',
        carStaus: '',
        curPage: 1,
        pageSize: 10
      },
      curPage: 1,
      pageTotal: 0,
      pageSize: 10,
      total: 0,
      pageSizes: [10, 20, 30],
      daduiList: [
        { name: '龙岗大队', value: '1' },
        { name: '罗湖大队', value: '2' },
        { name: '福田大队', value: '3' }
      ],
      zhongduiList: [
        { name: '一中队', value: '1' },
        { name: '二中队', value: '2' },
        { name: '三中队', value: '3' }
      ],
      carType: [
        { name: '全部', value: '1' },
        { name: '铁骑', value: '2' },
        { name: '警用车', value: '3' }
      ],
      pinpaiList: [
        { name: '全部', value: '1' },
        { name: '铁骑', value: '2' },
        { name: '警用车', value: '3' }
      ],
      statusList: [
        { name: '全部', value: '1' },
        { name: '铁骑', value: '2' },
        { name: '警用车', value: '3' }
      ],
      checkedTimeArr: [],
      tableData: [
        { ssdd: '罗湖大队', sszd: '横岗中队', carType: '铁骑', cjh: 'CJH543557', cph: '粤B12454', time: '2020/09/08,20:22', carStaus: '已领用', useStaus: '使用中', instance: '120/km', userCode: '100次', baoyang: '10次', fix: '4次', insurance: '2次' },
        { ssdd: '罗湖大队', sszd: '横岗中队', carType: '铁骑', cjh: 'CJH543557', cph: '粤B12454', time: '2020/09/08,20:22', carStaus: '已领用', useStaus: '使用中', instance: '120/km', userCode: '100次', baoyang: '10次', fix: '4次', insurance: '2次' },
        { ssdd: '罗湖大队', sszd: '横岗中队', carType: '铁骑', cjh: 'CJH543557', cph: '粤B12454', time: '2020/09/08,20:22', carStaus: '已领用', useStaus: '使用中', instance: '120/km', userCode: '100次', baoyang: '10次', fix: '4次', insurance: '2次' }
      ],
      formTitle: '',
      formVisible: false,
      isDetail: false, // 控制详情不可编辑
      isEdit: false, // 设备编号不可编辑
      addDataForm: {
        num: '',
        name: '',
        pinpai: '',
        changjia: '',
        touchang: '',
        toukuan: '',
        headHight: '',
        ergao: '',
        erwaikuan: '',
        caizhi: '',
        color: '',
        weight: '',
        chuchang: '',
        baofei: '',
        ssdw: '',
        owner: '',
        idCard: ''
      }
    }
  },
  methods: {
    /**
    * 查看详情
    */
    handleDetail(row) {
      const _this = this
      _this.formVisible = true
      _this.formTitle = '头盔信息详情'
      _this.isDetail = true
    },
    /**
    * 编辑头盔信息
    */
    handleEdit(row) {
      const _this = this
      _this.isDetail = false
      _this.isEdit = true
      _this.formVisible = true
      _this.formTitle = '编辑头盔信息'
    },
    /**
    * 新增头盔信息
    */
    handleAdd(row) {
      const _this = this
      _this.isEdit = false
      _this.isDetail = false
      _this.formVisible = true
      _this.formTitle = '新增头盔信息'
    },
    /**
    * 条件查询
    */
    onSearch() {
      // const _this = this
      console.log('这是查询')
    },
    /**
    * 导入
    */
    onImport() {
      // const _this = this
      console.log('这是查询')
    },
    /**
    * 重置
    */
    onReset() {
      // const _this = this
      console.log('这是查询')
    },
    /**
    * 导出
    */
    onOutput() {
      // const _this = this
      console.log('这是查询')
    }
  }
}
</script>

<style lang="stylus" scoped>
.helmet-container {
  padding 10px 50px
  .w200 {
    width 200px
  }
  .w180 {
    width 180px
  }
  .w140 {
    width 140px
  }
}
</style>
