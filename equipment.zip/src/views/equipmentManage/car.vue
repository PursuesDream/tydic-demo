<template>
  <div class="interphone-container">
    <el-card style="margin-top:20px;height:85vh">
      <div>
        <div>
          <div class="tydic-box">
            <div class="tydic-input">
              所属单位：
              <PermissionTree :select-object="formData" :select-value="'orgCode'" :default-name="'name'" input-class="input-class-search" @tree-click="handleTreeClick1" />
            </div>
            <div class="tydic-input">
              责任民警：
              <el-select
                v-model="formData.dutyPoliceUserId"
                filterable
                remote
                placeholder="请输入民警名称或警号"
                :remote-method="(query)=>{queryMJList(query,'')}"
                clearable
                :loading="mjLoading"
                @change="selectPolice"
              >
                <el-option
                  v-for="item in policeList"
                  :key="item.userId"
                  :label="`${item.userName}（${item.policeCode}）`"
                  :value="item.userId"
                />
              </el-select>
            </div>
            <div class="tydic-input">
              车牌号码：
              <el-input v-model="formData.deviceNo" clearable placeholder="请输入" />
            </div>
            <div class="tydic-input" style="margin-left:56px">
              车辆类型：
              <el-select v-model="formData.deviceType" @change="getLxList">
                <el-option
                  v-for="(o,index) in carType"
                  :key="index"
                  :label="o.categoryName"
                  :value="o.categoryCode"
                />
              </el-select>
            </div>
            <div class="tydic-input" style="margin-left:68px">
              车架号：
              <el-input v-model="formData.deviceNo2" clearable placeholder="请输入" />
            </div>
            <div class="tydic-input" style="margin-left:0px">
              车辆状态：
              <el-checkbox-group v-model="carStates" size="mini" style="margin-left:0px">
                <el-checkbox label="1" border style="margin-right:0px">正常</el-checkbox>
                <el-checkbox label="0" border style="margin-right:0px">报废</el-checkbox>
              </el-checkbox-group>
            </div>
            <div class="tydic-input">
              分配状态：
              <el-checkbox-group v-model="adllotStates" size="mini" style="margin-left:0px">
                <el-checkbox label="1" border style="margin-right:0px">已分配</el-checkbox>
                <el-checkbox label="0" border style="margin-right:0px">未分配</el-checkbox>
              </el-checkbox-group>
            </div>
            <div class="tydic-input" style="margin-left:69px">
              二维码：
              <el-checkbox-group v-model="qrStates" size="mini" style="margin-left:0px">
                <el-checkbox label="1" border style="margin-right:0px">已绑定</el-checkbox>
                <el-checkbox label="0" border style="margin-right:0px">未绑定</el-checkbox>
              </el-checkbox-group>
            </div>
            <div class="tydic-input">
              使用状态：
              <el-checkbox-group v-model="useStates" size="mini" style="margin-left:0px">
                <el-checkbox label="1" border style="margin-right:0px">使用中</el-checkbox>
                <el-checkbox label="0" border style="margin-right:0px">空闲中</el-checkbox>
              </el-checkbox-group>
            </div>
            <div class="tydic-input" style="float:right">
              <el-button type="primary search" size="mini" @click="onSearch"><i class="image-icon search" />查询</el-button>
              <el-button type="primary reset" size="mini" @click="onReset"><i class="image-icon reset" />重置</el-button>
            </div>
            <div>
              <el-button v-permission="'button1'" class="m-b-15" type="primary color3" size="mini" @click="handleAdd"><i class="image-icon add" />新增</el-button>
              <el-button v-permission="'button2'" class="m-b-15" type="primary color6" size="mini" @click="onDel"><i class="image-icon delete" />删除</el-button>
              <el-button v-permission="'button3'" class="m-b-15" type="primary color7" size="mini" @click="onAllot"><i class="image-icon fenpei" />分配</el-button>
              <el-button v-permission="'button4'" class="m-b-15" type="primary color4" size="mini" @click="onImport"><i class="image-icon import" />导入</el-button>
              <el-button v-permission="'button5'" class="m-b-15" type="primary color5" size="mini" @click="onOutput"><i class="image-icon export" />导出</el-button>
            <!-- <el-button type="primary" size="mini" style="background:rgba(24, 144, 255, 1)" @click="downloadCode"><i class="image-icon import" />下载二维码</el-button> -->
            </div>
            <div class="table-box">
              <el-table
                v-loading="tableLoading"
                :data="tableData"
                class="custom-table"
                stripe
                border
                max-height="600"
                header-row-class-name="custom-table-header"
                @selection-change="handleChange"
              >
                <el-table-column type="selection" width="50" align="center" />
                <el-table-column type="index" width="100" label="序号" align="center">
                  <template slot-scope="scope">
                    {{ scope.$index + 1 + pageSize * (curPage - 1) }}
                  </template>
                </el-table-column>
                <!-- <el-table-column
                  prop="parentOrganName"
                  align="center"
                  label="所属支队"
                  :show-overflow-tooltip="true"
                /> -->
                <el-table-column
                  prop="organName"
                  align="center"
                  label="所属单位"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="deviceNo"
                  align="center"
                  label="车牌号码"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="deviceNo2"
                  align="center"
                  label="车架号"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  align="center"
                  label="车辆类型"
                  :show-overflow-tooltip="true"
                >
                  <template slot-scope="scope">
                    <span>{{ getVehicleType(scope.row.vehicleType,'carType') }}</span>
                  </template>
                </el-table-column>
                <el-table-column
                  align="center"
                  label="车辆状态"
                  :show-overflow-tooltip="true"
                >
                  <template slot-scope="scope">
                    <span :class="{'red-active':scope.row.states !== 1}">{{ scope.row.states === 1 ?'正常':'报废' }}</span>
                  </template>
                </el-table-column>
                <el-table-column
                  prop="dutyPoliceName"
                  align="center"
                  label="责任民警"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="useStateName"
                  align="center"
                  label="使用状态"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="usePoliceName"
                  align="center"
                  label="使用人"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  align="center"
                  label="使用记录"
                  :show-overflow-tooltip="true"
                >
                  <template slot-scope="scope">
                    <el-button
                      v-permission="'button6'"
                      type="text"
                      size="small"
                      @click="showUseHistory(scope.row)"
                    >使用记录</el-button>
                  </template>
                </el-table-column>
                <el-table-column
                  prop="inTime"
                  align="center"
                  label="入库时间"
                  :show-overflow-tooltip="true"
                />
                <el-table-column align="center" label="操作">
                  <template slot-scope="scope">
                    <el-button
                      v-permission="'button9'"
                      type="text"
                      size="small"
                      @click="goArchives(scope.row)"
                    >档案</el-button>
                    <el-button
                      v-permission="'button8'"
                      type="text"
                      size="small"
                      @click="handleEditEq(scope.row)"
                    >编辑</el-button>
                    <el-button
                      v-if="scope.row.useStates === '0'"
                      v-permission="'button7'"
                      type="text"
                      size="small"
                      :disabled=" scope.row.states === 0 || scope.row.states === '0'"
                      @click="handleUse(scope.row)"
                    >使用</el-button>
                    <el-button
                      v-if="scope.row.useStates === '1'"
                      v-permission="'button10'"
                      type="text"
                      size="small"
                      @click="handleStop(scope.row)"
                    ><span style="color:red">停用</span></el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div style="text-align: center">
            <el-pagination
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="pageSize"
              :total="total"
              :current-page.sync="curPage"
              layout="total, prev, pager, next, jumper"
              @size-change="sizerChange"
              @current-change="curPageChange"
            />
          </div>
          <!-- 导入 -->
          <el-dialog v-loading="isLoadingUp" element-loading-text="导入中" width="640px" custom-class="custom-dialog addOrEdit" title="导入" :visible.sync="importDialog" :close-on-click-modal="false" :colse-on-press-escape="false" @close="cancelImport">
            <el-form v-if="isImport" ref="importList" :model="importList" style="height:310px" :inline="true" label-width="90px">
              <el-form-item label="车辆类型:" prop="vehicleType" :rules="getRules('车辆类型')">
                <el-select v-model="importList.vehicleType" @change="getLxList">
                  <el-option
                    v-for="(o,index) in carType"
                    :key="index"
                    :label="o.categoryName"
                    :value="o.categoryCode"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="车辆品牌:" prop="vehicleBrand" :rules="getRules('车辆品牌')">
                <el-select v-model="importList.vehicleBrand" @change="getPpList">
                  <el-option
                    v-for="(o,index) in pinpaiList"
                    :key="index"
                    :label="o.categoryName"
                    :value="o.categoryCode"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="车辆型号:" prop="categoryCode" :rules="getRules('车辆型号')" style="width:315px">
                <el-select v-model="importList.categoryCode">
                  <el-option
                    v-for="(o,index) in xinghaoList"
                    :key="index"
                    :label="o.categoryName"
                    :value="o.categoryCode"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="温馨提示:">
                导入前，请先<el-button type="text" @click="downTemplete">下载模板</el-button>并阅读模板内的导入须知
              </el-form-item>
              <el-form-item label="上传文件:">
                <el-upload
                  ref="upload"
                  class="tydic-file-upload"
                  accept=".xls,.xlsx"
                  action=""
                  :limit="1"
                  :http-request="httpRequest"
                  :on-change="fileChange"
                  :file-list="fileList"
                  :data="importList"
                  :auto-upload="false"
                >
                  <el-button slot="trigger" size="small" type="success">选取文件</el-button>
                  <div slot="tip" class="el-upload__tip" style="display: inline-block;margin-left: 20px">只能上传xls、xlsx格式的 excel文件</div>
                </el-upload>
              </el-form-item>
              <el-form-item label="数据重复:">
                <el-radio v-model="importList.filterType" label="2">跳过重复</el-radio><el-radio v-model="importList.filterType" label="1">覆盖</el-radio>
              </el-form-item>
            </el-form>
            <el-form v-else style="height:200px">
              <el-form-item label="">
                <p class="tips">导入提示:{{ responseMsg.msg }}</p>
                <!-- </el-form-item> -->
                <!-- <el-form-item label=""> -->
                <p class="tips">失败数据:<span v-if="responseMsg.fileName" style="color:#1890ff;cursor:pointer" @click="downloadErrfile(1)">{{ responseMsg.fileName }}</span><span v-else style="color:#1890ff;">无</span></p>
                <!-- </el-form-item> -->
                <!-- <el-form-item label=""> -->
                <p class="tips">错误详情:<span v-if="responseMsg.fileName" style="color:#1890ff;cursor:pointer" @click="downloadErrfile(2)">{{ responseMsg.fileName }}</span><span v-else style="color:#1890ff;">无</span></p>
              </el-form-item>
            </el-form>
            <div style="text-align: center;margin-top: 10px;height:35px">
              <el-button v-if="isImport" type="primary color-commit" size="mini" @click="onImportFile">导入</el-button>
              <el-button v-else type="primary color-commit" size="mini" @click="continueImport"> 继续导入</el-button>
              <el-button type="primary color-cancel" size="mini" @click="cancelImport">取消</el-button>
            </div>
          </el-dialog>
          <!-- 使用记录 -->
          <el-dialog width="1610px" custom-class="custom-dialog" :title="useHistoryTitle" :visible.sync="useHistoryDialog" :close-on-click-modal="false" :colse-on-press-escape="false">
            <el-form :inline="true" :model="useHistoryForm" label-width="82px">
              <el-form-item label="使用时间：">
                <el-date-picker
                  v-model="useHistoryForm.startTime"
                  class="w180"
                  size="mini"
                  type="datetime"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  placeholder="开始时间"
                />
                <span style="display: inline-block;margin: 0 10px;">至</span>
                <el-date-picker
                  v-model="useHistoryForm.endTime"
                  class="w180"
                  size="mini"
                  style="margin-left: 0;padding-left: 0;"
                  type="datetime"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  placeholder="结束时间"
                />
              </el-form-item>
              <el-form-item label="姓名：">
                <el-input v-model="useHistoryForm.name" class="w140" placeholder="请输入" size="mini" />
              </el-form-item>
              <span>
                <el-button type="primary search" size="mini" @click="searchHistory"><i class="image-icon search" />查询</el-button>
                <el-button type="primary reset" size="mini" @click="resetHistory"><i class="image-icon reset" />重置</el-button>
              </span>
            </el-form>
            <el-table
              :data="useHistoryTable"
              class="custom-table"
              max-height="520"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <el-table-column align="center" type="index" label="序号" width="50" :show-overflow-tooltip="true">
                <template slot-scope="scope">
                  {{ scope.$index + 1 + useHistoryPagination.pageSize * (useHistoryPagination.curPage - 1) }}
                </template>
              </el-table-column>
              <el-table-column align="center" prop="deviceNo2" label="车架号" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="deviceNo" label="车牌号码" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="policeNo" label="警号" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="policeName" label="姓名" :show-overflow-tooltip="true" />
              <el-table-column prop="ddOrgName" align="center" label="所属支队" :show-overflow-tooltip="true" width="200" />
              <el-table-column align="center" prop="zdOrgName" label="所属大队" :show-overflow-tooltip="true" width="200" />
              <el-table-column prop="beginTime" align="center" label="使用开始时间" :show-overflow-tooltip="true" width="200" />
              <el-table-column prop="endTime" align="center" label="使用结束时间" :show-overflow-tooltip="true" width="200" />
            </el-table>
            <el-pagination
              ref="pagination"
              style="text-align: center;margin-top:30px;"
              background
              :page-size="useHistoryPagination.pageSize"
              :total="useHistoryPagination.total"
              :current-page.sync="useHistoryPagination.curPage"
              :page-sizes="[5, 10, 15, 20]"
              layout="total, prev, pager, next, jumper"
              @size-change="historyChange"
              @current-change="historyCurPageChange"
            />
          </el-dialog>
          <!-- 新增 -->
          <el-dialog :title="formTitle" :visible.sync="formVisible" width="640px" custom-class="custom-dialog addOrEdit" :close-on-click-modal="false" :colse-on-press-escape="false">
            <el-form v-if="formVisible" ref="addDataForm" :model="addDataForm" :inline="true" label-width="90px">
              <el-form-item label="车辆类型:" prop="vehicleType" :rules="getRules('车辆类型')">
                <el-select v-model="addDataForm.vehicleType" @change="getLxList">
                  <el-option
                    v-for="(o,index) in carType"
                    :key="index"
                    :label="o.categoryName"
                    :value="o.categoryCode"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="车辆品牌:" prop="vehicleBrand" :rules="getRules('车辆品牌')">
                <el-select v-model="addDataForm.vehicleBrand" @change="getPpList">
                  <el-option
                    v-for="(o,index) in pinpaiList"
                    :key="index"
                    :label="o.categoryName"
                    :value="o.categoryCode"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="车辆型号:" prop="categoryCode" :rules="getRules('车辆型号')">
                <el-select v-model="addDataForm.categoryCode" @change="getAttributeList">
                  <el-option
                    v-for="(o,index) in xinghaoList"
                    :key="index"
                    :label="o.categoryName"
                    :value="o.categoryCode"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="车架号:" prop="intercomNos2" :rules="getRules('车架号')">
                <el-input v-model="addDataForm.intercomNos2" clearable maxlength="50" size="mini" type="text" placeholder="请输入" style="width:200px" />
              </el-form-item>
              <el-form-item label="车牌号码:" prop="intercomNos">
                <el-input v-model="addDataForm.intercomNos" maxlength="50" size="mini" type="text" placeholder="请输入" style="width:200px" />
              </el-form-item>
              <el-form-item label="所属单位:" prop="organCode" :rules="getRules('所属单位')">
                <PermissionTree :select-object="addDataForm" :select-value="'organCode'" :default-name="'organName'" input-class="input-class-add" @tree-click="handleTreeClick2" />
                <!-- <el-select v-model="addDataForm.parentOrganCode" clearable @change="(val) =>getAddOrganList(val,'addZd')">
                  <el-option
                    v-for="(o,index) in addDdList"
                    :key="index"
                    :label="o.name"
                    :value="o.organCode"
                  />
                </el-select> -->
              </el-form-item>
              <!-- <el-form-item label="所属大队:" prop="organCode">
                <el-select
                  v-model="addDataForm.organCode"
                  clearable
                  @change="handleAddChangeDD"
                >
                  <el-option
                    v-for="(o,index) in addZdList"
                    :key="index"
                    :label="o.name"
                    :value="o.organCode"
                  />
                </el-select>
              </el-form-item> -->
              <!-- :remote-method="(query)=>{queryAddMJ(query,addDataForm.organCode)}" -->
              <el-form-item label="责任民警:" prop="dutyPolice">
                <el-select
                  v-model="addDataForm.dutyPolice"
                  filterable
                  remote
                  placeholder="请输入民警名称或警号"
                  clearable
                  :loading="mjLoading"
                >
                  <el-option
                    v-for="item in addPoliceList"
                    :key="item.userId"
                    :label="`${item.userName}（${item.policeCode}）`"
                    :value="item.userId"
                  />
                </el-select>
              </el-form-item>
              <el-form-item v-for="(item, index) in addDataForm.attrList" :key="index" :label="item.attrName+':'" :prop="'attrList.'+index+'.attrValue'" :rules="item.attrType === 4 ? rules.attrValue:[{ required: false, message: '请选择！', trigger: 'change' }]" :show-message="item.attrType === 4 ? true : false">
                <!-- 文本 -->
                <el-input v-if="item.attrType === 1" v-model="item.attrValue" maxlength="50" size="mini" type="text" placeholder="请输入" style="width:200px" />
                <!-- 单选 -->
                <el-radio-group v-if="item.attrType === 4" v-model="item.attrValue" style="width:200px">
                  <el-radio v-for="(obj,code) in mapData[item.dictType]" :key="code" :label="obj.code">{{ obj.name }}</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-form>
            <div style="text-align: center;margin-top:20px">
              <el-button type="primary color-commit" size="mini" @click="addIntercom">保存</el-button>
              <el-button type="primary color-cancel" size="mini" @click="cancelAddIntercom">取消</el-button>
            </div>
          </el-dialog>
          <!-- 停用,使用弹层 -->
          <el-dialog width="340px" custom-class="custom-dialog addOrEdit" :title="useTitle" :visible.sync="useDialog" :close-on-click-modal="false" :colse-on-press-escape="false" @close="handleCloseUse">
            <el-form v-if="useDialog" ref="uesControl" label-width="90px" :model="uesControl" style="height:60px">
              <el-form-item label="民警/辅警:" :rules="getRules('民警/辅警')" prop="userId">
                <el-select
                  v-model="uesControl.userId"
                  filterable
                  remote
                  placeholder="请输入民警名称或警号"
                  :remote-method="queryUseMJ"
                  clearable
                  :loading="mjLoading"
                  @change="selectUsePolice"
                >
                  <el-option
                    v-for="item in usePolice"
                    :key="item.userId"
                    :label="`${item.userName}（${item.policeCode}）`"
                    :value="item.userId"
                  />
                </el-select>
              </el-form-item>
            </el-form>
            <div style="text-align: center;margin-top: 10px;">
              <el-button type="primary color-commit" size="mini" @click="comfirmChange">确定</el-button>
              <el-button type="primary color-cancel" size="mini" @click="cancelChange">取消</el-button>
            </div>
          </el-dialog>
          <!-- 分配 -->
          <el-dialog width="340px" custom-class="custom-dialog addOrEdit" title="分配" :visible.sync="allotDialog" :close-on-click-modal="false" :colse-on-press-escape="false" @close="handleDialogClose">
            <el-form ref="addMessage" :model="addMessage" label-width="100px">
              <el-form-item v-if="allotDialog" label="所属支队：" :rules="getRules('所属单位')" prop="sszd">
                <PermissionTree :select-object="addMessage" :select-value="'sszd'" :default-name="'organName'" input-class="input-class-add" @tree-click="handleTreeClick3" />
                <!-- <el-select v-model="addMessage.ssdd" clearable @change="(val) =>getOrgan(val,'fenpeizhongdui', true)">
                  <el-option
                    v-for="(o,index) in daduiList"
                    :key="index"
                    :label="o.name"
                    :value="o.organCode"
                  />
                </el-select> -->
              </el-form-item>
              <!-- <el-form-item label="所属大队：">
                <el-select v-model="addMessage.sszd" clearable @change="handleAdlloChangeDD">
                  <el-option
                    v-for="(o,index) in fenpeizhongduiList"
                    :key="index"
                    :label="o.name"
                    :value="o.organCode"
                  />
                </el-select>
              </el-form-item> -->
              <el-form-item label="责任民警：">
                <el-select
                  v-model.trim="addMessage.dutyPoliceUserId"
                  filterable
                  remote
                  placeholder="请输入民警名称或警号"
                  clearable
                  :loading="mjLoading"
                  :remote-method="handleSearchPolice"
                  @change="selectAdllotPolice"
                >
                  <el-option
                    v-for="item in adllotPolice"
                    :key="item.userId"
                    :label="`${item.userName}（${item.policeCode}）`"
                    :value="item.userId"
                  />
                </el-select>
              </el-form-item>
            </el-form>
            <div style="text-align: center;margin-top: 10px;">
              <el-button type="primary color-commit" size="mini" @click="saveAllot">保存</el-button>
              <el-button type="primary color-cancel" size="mini" @click="cancelAdllot">取消</el-button>
            </div>
          </el-dialog>
        <!-- </el-card> -->
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
import { getPoliceList, organListByParam } from '@/api/public'
import { getCategoryList } from '@/api/integratedManage'
import { getAttributeList } from '@/api/attributeManage'
import { getEqDetail, delErr, editInterphone, downloadImportDetail, importInterphone, downloadIntercomTemplate, adllotInterphone, getInterphoneUse, stopInterphone, useInterphone, exportInterphone, getInterphone, addInterphone, deleteIntercomByID } from '@/api/interphone'
import { mapState, mapGetters } from 'vuex'
import PermissionTree from '@/components/permissionTree'
import { deepClone } from '@/utils'
export default {
  name: 'Car',
  components: {
    PermissionTree
  },
  data() {
    return {
      testNameddd: '我的',
      codeDialog: false,
      tableLoading: false,
      codeType: '1',
      isImport: true,
      carType: [],
      useTitle: '',
      uesControl: {
        userId: '',
        deviceId: ''
      },
      checkArr: [],
      addMessage: {
        deviceIds: '',
        sszd: '',
        ssdd: '',
        orgCode: '',
        organName: '',
        dutyPoliceUserId: ''
      },
      statusList: [],
      importList: {
        file: '',
        filterType: '2',
        vehicleBrand: '',
        vehicleType: '',
        categoryCode: ''
      },
      fenpeizhongduiList: [],
      formData: {
        orgCode: '',
        name: '',
        vehicleBrand: '',
        useStates: '',
        qrCodeBindSate: '',
        states: '',
        dutyPoliceUserId: '',
        distributionStates: '',
        deviceNo: '',
        deviceNo2: '',
        deviceType: ''
      },
      oldFormData: null,
      useStates: [],
      adllotStates: [],
      qrStates: [],
      carStates: [],
      useDialog: false, // 控制使用停用弹窗
      useHistoryTable: [],
      useHistoryTitle: '',
      curPage: 1,
      pageSize: 10,
      total: 0,
      daduiList: [],
      fileList: [],
      zhongduiList: [],
      checkedTimeArr: [],
      tableData: [],
      useHistoryPagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      mjLoading: false,
      policeList: [],
      useHistoryDialog: false,
      formTitle: '',
      formVisible: false,
      isDetail: false, // 控制详情不可编辑
      isEdit: false, // 设备编号不可编辑
      useHistoryForm: {
        deviceId: '',
        name: '',
        startTime: '',
        endTime: ''
      },
      addDataForm: {
        vehicleType: '',
        intercomNos: '',
        organName: '',
        intercomNos2: '',
        dutyPolice: '',
        vehicleBrand: '',
        categoryCode: '',
        parentOrganCode: '',
        organCode: '',
        attrList: []
      },
      pinpaiList: [],
      xinghaoList: [],
      cavalryData: this.mapData,
      allotDialog: false,
      adllotPolice: [],
      usePolice: [],
      isLoadingUp: false, // 正在导入中
      importDialog: false, // 控制导入弹层
      responseMsg: {},
      addPoliceList: [],
      addZdList: [],
      addDdList: [],
      rules: {
        attrValue: [
          { required: true, message: '请选择！', trigger: 'change' }
        ]
      }
    }
  },
  computed: {
    ...mapState({
      mapData: state => state.user.mapData
    }),
    ...mapGetters([
      'user_userInfo'
    ])
  },
  mounted() {
    const _this = this
    _this.getOrgan('', 'dadui')
    _this.getAddOrganList('', 'addDd')
    _this.getInterphoneList()
    _this.getAllCategory()
    _this.statusList = _this.mapData.vehicle_use_states
  },
  methods: {
    /* 查询单位树点击回调事件 */
    handleTreeClick1(data) {
      if (data !== this.formData.orgCode) {
        this.formData.dutyPoliceUserId = ''
        this.policeList = []
      }
      this.queryMJList('', data)
    },
    /* 新增单位树点击回调事件 */
    handleTreeClick2(data) {
      if (data !== this.addDataForm.organCode) {
        this.addDataForm.dutyPolice = ''
        this.addDataForm.addPoliceList = []
      }
      this.queryAddMJ('', data)
    },
    /* 分配单位树点击回调事件 */
    handleTreeClick3(data) {
      if (data !== this.addMessage.organCode) {
        this.addMessage.dutyPoliceUserId = ''
        this.addMessage.adllotPolice = []
      }
      this.queryAdllotMJ('', data)
    },
    /**
     * 模板下载
     */
    downTemplete() {
      const _this = this
      if (!this.importList.categoryCode) {
        _this.$message({
          message: '请选择车辆型号！',
          showClose: true,
          type: 'warning'
        })
        return false
      }
      const param = {
        categoryCode: this.importList.categoryCode,
        categoryType: '1'
      }
      downloadIntercomTemplate(param).then(res => {
        const url = window.URL.createObjectURL(new Blob([res]))
        const link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        let xHName = ''
        let pPName = ''
        let typeName = ''
        this.carType.every(item => {
          if (this.importList.vehicleType === item.categoryCode) {
            typeName = item.categoryName
            return false
          } else return true
        })
        this.pinpaiList.every(item => {
          if (this.importList.vehicleBrand === item.categoryCode) {
            pPName = item.categoryName
            return false
          } else return true
        })
        this.xinghaoList.every(item => {
          if (this.importList.categoryCode === item.categoryCode) {
            xHName = item.categoryName
            return false
          } else return true
        })
        const fileName = typeName + pPName + xHName + '模板.xls'
        link.setAttribute('download', fileName)
        document.body.appendChild(link)
        link.click()
      })
    },
    getRules(message, trigger = 'blur') {
      return { required: true, message: message + '不能为空！', trigger }
    },
    /**
     * 查询属性列表
     */
    getAttributeList(val) {
      const _this = this
      getAttributeList(val).then(res => {
        if (res.code === 200) {
          let result = []
          result = res.data.filter(item => {
            return item.paramType === 2
          })
          result.map(item => {
            item.attrKey = item.attrEnName
            // delete item.attrEnName
          })
          if (this.isEdit) {
            result.map(item => {
              item.deviceId = _this.addDataForm.deviceIds
            })
          }
          this.addDataForm.attrList = result
          // console.log(this.addDataForm.attrList)
        }
      })
    },
    /**
     * 查询对讲机列表
     */
    getInterphoneList() {
      const _this = this
      _this.tableLoading = true
      _this.tableData = []
      let param = {}
      if (this.oldFormData) {
        param = { ...this.oldFormData }
      } else {
        param = {
          deviceNo: _this.formData.deviceNo, // 对讲机号
          deviceNo2: _this.formData.deviceNo2, // 对讲机号
          categoryType: '1',
          deviceType: _this.formData.deviceType, // 对讲机号
          vehicleBrand: _this.formData.vehicleBrand, // 对讲机号
          orgCode: _this.formData.orgCode, // 单位编码
          dutyPoliceUserId: _this.formData.dutyPoliceUserId, // 责任民警
          states: _this.getStates(_this.carStates), // "报废状态: 0报废、1正常、其他=全部 "
          distributionStates: _this.getStates(_this.adllotStates), // "分配状态 0未分配、1已分配，其他=全部",
          useStates: _this.getStates(_this.useStates), // "使用状态 0空闲、1使用中、其他=全部"，
          qrCodeBindSate: _this.getStates(_this.qrStates)// "二维码绑定状态 0未绑定、1已绑定、其他=全部"
        }
        this.oldFormData = { ...param }
      }
      param.pageNum = _this.curPage
      param.pageSize = _this.pageSize
      getInterphone(param).then(res => {
        if (res.code === 200) {
          _this.tableData = res.data.rows
          _this.total = res.data.total
          _this.tableLoading = false
        }
      })
    },
    getStates(array, name) {
      if (array.length === 2) {
        return '3'
      } else if (array.length === 0) {
        return ''
      } else {
        return array[0]
      }
    },
    /**
    * 分页大小
    */
    sizerChange(val) {
      const _this = this
      _this.pageSize = val
      _this.getInterphoneList()
    },
    /**
    * 页数跳转
    */
    curPageChange(val) {
      const _this = this
      _this.curPage = val
      _this.getInterphoneList()
    },
    /**
     * 所选民警加入表格
     */
    selectPolice(val) {
      // const arr = []
      if (!val) {
        return
      }
      this.formData.dutyPoliceUserId = val
    },
    // 添加设备 选中大队
    handleAddChangeDD(val) {
      this.addDataForm.dutyPolice = ''
      let code = this.addDataForm.parentOrganCode
      if (val) code = val
      this.queryAddMJ('', code)
    },
    // 分配 选中大队
    handleAdlloChangeDD(val) {
      let code = this.addMessage.ssdd
      if (val) code = val
      this.queryAdllotMJ('', code)
    },
    /**
     * 选择使用民警
     */
    selectUsePolice(val) {
      this.uesControl.userId = val
    },
    /**
     * 请求民警列表
     */
    queryUseMJ(query, val) {
      // this.usePolice = []
      // this.uesControl.useId = ''
      const param = {
        organCode: '',
        auth: true,
        userName: query
      }
      this.mjLoading = true
      getPoliceList(param).then(res => {
        this.usePolice = res.data
        this.mjLoading = false
      })
    },
    handleCloseUse() {
      this.cancelChange()
    },
    /**
     * 对讲机新增
     */
    addIntercom() {
      const _this = this
      let submitFun = ''
      if (this.isEdit) {
        submitFun = editInterphone
      } else {
        submitFun = addInterphone
      }
      const param = deepClone(_this.addDataForm)
      // console.log(this.addDataForm)
      this.$refs.addDataForm.validate(valid => {
        if (valid) {
          submitFun(param).then(res => {
            if (res.code === 200) {
              _this.$message({
                message: '操作成功！',
                showClose: true,
                type: 'success'
              })
              this.formVisible = false
              this.getInterphoneList()
            }
          })
        }
      })
    },
    /**
     * 取消新增
     */
    cancelAddIntercom() {
      this.formVisible = false
      this.addDataForm.vehicleType = ''
      this.addDataForm.intercomNos = ''
      this.addDataForm.intercomNos2 = ''
      this.addDataForm.dutyPolice = ''
      this.addDataForm.vehicleBrand = ''
      this.addDataForm.categoryCode = ''
      this.addDataForm.parentOrganCode = ''
      this.addDataForm.organCode = ''
      this.addDataForm.organName = ''
      this.addDataForm.attrList = []
      this.pinpaiList = []
      this.xinghaoList = []
      this.addZdList = []
      this.addPoliceList = []
    },
    /**
    * 表格选中数据
    */
    handleChange(val) {
      const _this = this
      _this.checkArr = val
      // console.log(this.checkArr[0])
    },
    /**
   * 查询大队
   * @param {String} listName 'dadui'  'zhongdui'
   */
    getOrgan(code, listName, isSelectChange = false) {
      this[listName + 'List'] = []
      this.formData.sszd = ''
      const organizeCode = window.CONFIG.organizeCode
      let orgLevel = organizeCode.first
      if (listName === 'zhongdui' || listName === 'fenpeizhongdui') orgLevel = organizeCode.second
      if (listName === 'fenpeizhongdui') {
        this.adllotPolice = []
        this.fenpeizhongduiList = []
        if (isSelectChange) {
          this.addMessage.sszd = ''
          this.addMessage.dutyPoliceUserId = ''
          this.queryAdllotMJ('', code)
        } else {
          const orgCode = this.addMessage.sszd || this.addMessage.ssdd
          this.queryAdllotMJ('', orgCode, false)
        }
      }
      const params = {
        // orgSubType: 0,
        parentCode: code,
        orgLevel: orgLevel
      }
      organListByParam(params).then(res => {
        if (res.code === 200) {
          this[listName + 'List'] = res.data
        }
      })
    },
    /**
   * 新增查询大队
   * @param {String} listName 'addDd'  'addZd'
   */
    getAddOrganList(code, listName) {
      this[listName + 'List'] = []
      if (this.isEdit) {
        this.addDataForm.organCode = ''
        this.addDataForm.dutyPolice = ''
      }
      const organizeCode = window.CONFIG.organizeCode
      let orgLevel = organizeCode.first
      if (listName === 'addZd') {
        orgLevel = organizeCode.second
        this.addDataForm.organCode = ''
        this.addDataForm.dutyPolice = ''
        this.queryAddMJ('', code)
      }
      const params = {
        // orgSubType: 0,
        parentCode: code,
        orgLevel: orgLevel
      }
      organListByParam(params).then(res => {
        if (res.code === 200) {
          this[listName + 'List'] = res.data
        }
      })
    },
    /**
     * 请求分配责任民警列表
     */
    queryAdllotMJ(query, val) {
      this.adllotPolice = []
      // if (isNoSelectChange) {
      //   this.addMessage.dutyPoliceUserId = ''
      // }
      const param = {
        organCode: val || this.user_userInfo.organCode,
        userName: query
      }
      this.mjLoading = true
      getPoliceList(param).then(res => {
        this.adllotPolice = res.data
        this.mjLoading = false
      })
    },
    /**
     * 分配责任民警
     */
    selectAdllotPolice(val) {
      if (!val) {
        return
      }
      this.adllotPolice.map(item => {
        if (item.userId === val) {
          this.addMessage.sszd = item.organCode
          this.addMessage.organName = item.organName
        }
      })
    },
    handleSearchPolice(val) {
      if (val !== '') {
        const organCode = this.addMessage.sszd || this.addMessage.ssdd
        this.queryAdllotMJ(val, organCode, false)
      }
    },
    /**
     * 请求民警列表
     */
    queryMJList(query, val) {
      this.policeList = []
      this.formData.dutyPoliceUserId = ''
      const organCode = val || this.formData.orgCode || this.user_userInfo.organCode
      const param = {
        organCode,
        userName: query
      }
      this.mjLoading = true
      getPoliceList(param).then(res => {
        this.policeList = res.data
        this.mjLoading = false
      })
    },
    /**
     * 请求新增民警列表
     */
    queryAddMJ(query, val) {
      this.addPoliceList = []
      const organCode = val || this.user_userInfo.organCode
      const param = {
        organCode,
        userName: query
      }
      this.mjLoading = true
      getPoliceList(param).then(res => {
        this.addPoliceList = res.data
        this.mjLoading = false
      })
    },
    handleDialogResetAdllot() {
      this.$refs.addMessage.resetFields()
      this.cancelAdllot()
    },
    handleDialogClose() {
      this.handleDialogResetAdllot()
    },
    /**
     * 取消分配弹出
     */
    cancelAdllot() {
      const _this = this
      _this.addMessage.ssdd = ''
      _this.addMessage.sszd = ''
      _this.addMessage.organName = ''
      _this.addMessage.dutyPoliceUserId = ''
      _this.adllotPolice = []
      this.fenpeizhongduiList = []
      _this.allotDialog = false
    },
    /**
     * 分配保存
     */
    saveAllot() {
      const _this = this
      const arr3 = []
      const arr2 = []
      if (_this.addMessage.sszd !== '' || _this.addMessage.dutyPoliceUserId !== '') {
        arr2.push(this.addMessage.police)
        _this.checkArr.map(item => {
          arr3.push(item.deviceId)
        })
        const str = arr3.toString()
        const param = {
          deviceIds: str,
          organCode: _this.addMessage.sszd,
          dutyPolice: this.addMessage.dutyPoliceUserId
        }
        adllotInterphone(param).then(res => {
          if (res.code === 200) {
            _this.$message({
              message: '分配成功！',
              showClose: true,
              type: 'success'
            })
            _this.fenpeizhongduiList = []
            _this.getInterphoneList()
            _this.allotDialog = false
          }
        }).catch(err => {
          console.log(err)
        })
      } else {
        _this.$message({
          message: '请选择需要分配的单位或者责任民警！',
          showClose: true,
          type: 'warning'

        })
        return
      }
    },
    /**
     * 查询所有车辆类型
     */
    getAllCategory() {
      const _this = this
      const params = {
        categoryCode: '',
        categoryType: '1'
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          _this.carType = res.data
        }
      })
    },
    getVehicleType(id, listName) {
      let name = ''
      const list = this[listName]
      for (let i = 0; i < list.length; i++) {
        if (list[i].categoryCode === id) {
          name = list[i].categoryName
          break
        }
      }
      return name
    },
    /**
     * 根据车辆类型查询车辆品牌
     */
    getLxList(val, id) {
      const _this = this
      const params = {
        categoryCode: val,
        categoryType: '1'
      }
      // if (_this.isEdit) {
      _this.addDataForm.vehicleBrand = ''
      _this.addDataForm.categoryCode = ''
      _this.xinghaoList = []
      this.pinpaiList = []
      this.addDataForm.attrList = []
      // }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          _this.pinpaiList = res.data
        }
      })
    },
    /**
     * 根据车辆品牌查询车辆型号
     */
    getPpList(val) {
      const _this = this
      const params = {
        categoryCode: val,
        categoryType: '1'
      }
      // if (_this.isEdit) {
      _this.addDataForm.categoryCode = ''
      _this.xinghaoList = []
      this.addDataForm.attrList = []
      // }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          _this.xinghaoList = res.data
        }
      })
    },
    /**
    * 使用记录条件查询
    */
    searchHistory() {
      const _this = this
      _this.useHistoryTable = []
      const params = {
        deviceId: _this.useHistoryForm.deviceId,
        usePoliceName: _this.useHistoryForm.name,
        beginTime: _this.useHistoryForm.startTime,
        endTime: _this.useHistoryForm.endTime,
        pageNum: _this.useHistoryPagination.curPage,
        pageSize: _this.useHistoryPagination.pageSize
      }
      getInterphoneUse(params).then(res => {
        if (res.code === 200) {
          _this.useHistoryTable = res.data.rows
          _this.useHistoryPagination.total = res.data.total
        }
      })
    },
    /**
    * 使用记录重置条件查询
    */
    resetHistory() {
      const _this = this
      _this.useHistoryForm.name = ''
      _this.useHistoryForm.startTime = ''
      _this.useHistoryForm.endTime = ''
      _this.useHistoryPagination.pageSize = 10
      _this.useHistoryPagination.curPage = 1
      _this.searchHistory()
    },
    /**
     * 打开使用记录弹层
     */
    showUseHistory(row) {
      const _this = this
      _this.useHistoryDialog = true
      _this.useHistoryTitle = '使用记录'
      _this.useHistoryForm.deviceId = row.deviceId
      _this.searchHistory()
    },

    /**
     * 使用记录分页
     */
    historyChange(val) {
      const _this = this
      _this.useHistoryPagination.pageSize = val
      _this.searchHistory()
    },
    /**
    * 使用记录分页跳转
    */
    historyCurPageChange(val) {
      const _this = this
      _this.useHistoryPagination.curPage = val
      _this.searchHistory()
    },
    /**
    * 使用
    */
    handleUse(row) {
      const _this = this
      _this.useTitle = '使用'
      _this.useState = true
      _this.uesControl.deviceId = row.deviceId
      // _this.uesControl.userId = ''
      // _this.usePolice = []
      _this.useDialog = true
    },
    /**
    * 停用
    */
    handleStop(row) {
      const _this = this
      _this.useTitle = '停用'
      _this.$confirm('确定停用该车辆吗？', '提示', {
        confirmButtoText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        const deviceId = row.deviceId
        stopInterphone(deviceId).then(res => {
          if (res.code === 200) {
            _this.$message({
              message: '操作成功！',
              showClose: true,
              type: 'success'
            })
            _this.getInterphoneList()
          }
        }).catch(err => {
          console.log(err)
        })
      }).catch(() => {
        _this.$message({
          message: '已取消操作！',
          showClose: true,
          type: 'info'
        })
      })
    },
    /**
     * 确定启用
     */
    comfirmChange() {
      const _this = this
      const param = {
        deviceId: _this.uesControl.deviceId,
        usePolice: _this.uesControl.userId
      }
      this.$refs.uesControl.validate(valid => {
        if (valid) {
          useInterphone(param).then(res => {
            if (res.code === 200) {
              _this.$message({
                message: '操作成功！',
                showClose: true,
                type: 'success'
              })
            }
            _this.getInterphoneList()
            _this.useDialog = false
          })
        }
      })
    },
    /**
     * 下载二维码
     */
    downloadCode() {
      this.codeDialog = true
    },
    /**
     * 取消使用
     */
    cancelChange() {
      const _this = this
      _this.usePolice = []
      _this.uesControl.deviceId = ''
      _this.uesControl.userId = ''
      _this.useDialog = false
    },
    /**
     * 跳转档案页面
     */
    goArchives(row) {
      // const obj = JSON.stringify(row)
      // sessionStorage.setItem('detailInfo', obj) // 存储装备信息
      this.$router.push({
        name: 'CarArchives',
        params: {
          id: row.deviceId
        }
      })
      // this.$router.push({ path: `/process/info/read/${row.applyNumber}`, query: { id: row.applyId, applyNumber: row.applyNumber, status: 'read' }})
      // this.$router.push({ path: `/equipmentManage/archives/${row.deviceId}`, query: { paramData: row }})
    },
    /**
    * 新增装备信息
    */
    handleAdd(row) {
      const _this = this
      _this.isEdit = false
      _this.isDetail = false
      _this.addDataForm.vehicleType = ''
      _this.addDataForm.intercomNos = ''
      _this.addDataForm.intercomNos2 = ''
      _this.addDataForm.dutyPolice = ''
      _this.addDataForm.vehicleBrand = ''
      _this.addDataForm.categoryCode = ''
      _this.addDataForm.parentOrganCode = ''
      _this.addDataForm.organCode = ''
      _this.addDataForm.organName = ''
      this.addDataForm.attrList = []
      _this.pinpaiList = []
      _this.xinghaoList = []
      _this.addZdList = []
      _this.addPoliceList = []
      _this.formVisible = true
      _this.formTitle = '新增车辆'
    },
    /**
    * 编辑装备信息
    */
    handleEditEq(row) {
      const _this = this
      _this.isEdit = true
      _this.addDataForm.vehicleType = row.vehicleType
      _this.addDataForm.intercomNos = row.deviceNo
      _this.addDataForm.intercomNos2 = row.deviceNo2
      _this.addDataForm.dutyPolice = row.dutyPoliceUserId
      _this.addDataForm.vehicleBrand = row.vehicleBrand
      _this.addDataForm.categoryCode = row.categoryCode
      _this.addDataForm.organName = row.organName
      _this.addDataForm.organCode = row.orgCode
      this.addDataForm.deviceIds = row.deviceId
      const parentCode = row.parentCode ? row.parentCode : ''
      this.getEqDetail(row.deviceId)
      if (parentCode) {
        const params = {
          // orgSubType: 0,
          parentCode,
          orgLevel: window.CONFIG.organizeCode.second
        }
        organListByParam(params).then(res => {
          if (res.code === 200) {
            this.addZdList = res.data
          }
        })
      }
      getCategoryList({ categoryCode: row.vehicleType, categoryType: '1' }).then(res => {
        if (res.code === 200) {
          _this.pinpaiList = res.data
        }
      })
      getCategoryList({ categoryCode: row.vehicleBrand, categoryType: '1' }).then(res => {
        if (res.code === 200) {
          _this.xinghaoList = res.data
        }
      })
      const orgCode = row.orgCode || row.parentCode || ''
      _this.queryAddMJ('', orgCode)
      _this.formVisible = true
      _this.formTitle = '编辑车辆'
    },
    /**
     * 查询车辆详情
     */
    getEqDetail(val) {
      this.addDataForm.attrList = []
      getEqDetail(val).then(res => {
        if (res.code === 200) {
          res.data.attrList.map(item => {
            item.deviceId = val
          })
          this.addDataForm.attrList = res.data.attrList
        }
      })
    },
    /**
    * 条件查询
    */
    onSearch() {
      const _this = this
      this.oldFormData = null
      _this.curPage = 1
      _this.getInterphoneList()
    },
    /**
    * 导入
    */
    onImport() {
      const _this = this
      _this.importDialog = true
      _this.isImport = true
      _this.importList.categoryCode = ''
      _this.importList.vehicleBrand = ''
      _this.importList.vehicleType = ''
      _this.xinghaoList = []
      _this.pinpaiList = []
    },
    /**
     * 取消导入
     */
    cancelImport() {
      const _this = this
      _this.importDialog = false
      _this.isImport = true
      _this.fileList = []
      _this.xinghaoList = []
      _this.pinpaiList = []
      _this.importList = {
        file: '',
        filterType: '2',
        vehicleBrand: '',
        vehicleType: '',
        categoryCode: ''
      }
      if (_this.responseMsg.failedPath) {
        const param = {
          path: [this.responseMsg.failedPath, this.responseMsg.errorPath]
        }
        delErr(param).then(res => {
          console.log(res)
        })
      }
    },
    /**
     * 文件变化监听
     */
    fileChange(file, fileList) {
      const _this = this
      _this.fileList = fileList
    },
    /**
     *表单提交的回调
     */
    httpRequest(param) {
      const _this = this
      const fileObj = param.file // 相当于input里取得的files
      const fd = new FormData()// FormData 对象
      fd.append('file', fileObj)// 文件对象
      fd.append('repeatType', _this.importList.filterType)
      fd.append('categoryCode', _this.importList.categoryCode)
      fd.append('categoryType', '1')
      this.isLoadingUp = true
      importInterphone(fd).then(res => {
        _this.isLoadingUp = false
        if (res.code === 200) {
          _this.isImport = false
          _this.responseMsg = res.data
          let type = ''
          if (_this.responseMsg.errorPath) {
            type = 'error'
          } else {
            type = 'success'
          }
          _this.$message({
            type: type,
            message: _this.responseMsg.msg,
            duration: 2000
          })
          _this.getInterphoneList()
        }
      }).catch(_ => {
        this.isLoadingUp = false
      })
    },
    /**
    * 导入文件
    */
    onImportFile() {
      const _this = this
      this.$refs.importList.validate(valid => {
        if (valid) {
          if (_this.fileList.length === 0) {
            this.$message.warning({
              message: '请添加文件!',
              showClose: true
            })
            return
          }
          _this.$refs.upload.submit()
        }
      })
    },
    /**
     * 下载错误文件
     */
    downloadErrfile(val) {
      const _this = this
      let params = {}
      if (val === 1) {
        params = {
          path: _this.responseMsg.failedPath
        }
      } else if (val === 2) {
        params = {
          path: _this.responseMsg.errorPath
        }
      }
      downloadImportDetail(params).then(res => {
        const url = window.URL.createObjectURL(new Blob([res]))
        const link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        const fileName = '车辆导入详情.xlsx'
        link.setAttribute('download', fileName)
        document.body.appendChild(link)
        link.click()
      })
    },
    /**
    * 继续导入文件
    *
    */
    continueImport() {
      const _this = this
      _this.isImport = true
      const param = {
        paths: [this.responseMsg.failedPath, this.responseMsg.errorPath]
      }
      delErr(param).then(res => {
        // console.log(res)
        this.fileList = []
      })
    },
    /**
    * 重置
    */
    onReset() {
      const _this = this
      _this.formData.orgCode = ''
      _this.formData.name = ''
      // _this.formData.ssdd = ''
      _this.formData.deviceType = ''
      _this.formData.deviceNo = ''
      _this.formData.deviceNo2 = ''
      _this.formData.vehicleBrand = ''
      _this.formData.useStates = ''
      _this.formData.states = ''
      _this.formData.distributionStates = ''
      _this.formData.qrCodeBindSate = ''
      _this.formData.dutyPoliceUserId = ''
      _this.useStates = []
      _this.adllotStates = []
      _this.qrStates = []
      _this.carStates = []
      _this.policeList = []
      _this.pinpaiList = []
      _this.zhongduiList = []
      _this.curPage = 1
      _this.oldFormData = null
      _this.getInterphoneList()
    },
    /**
     * 删除
     */
    onDel() {
      const _this = this
      const deviceIds = []
      if (_this.checkArr.length === 0) {
        _this.$message({
          message: '请选择需要删除的车辆！',
          showClose: true,
          type: 'warning'
        })
        return
      }
      let hasUse = false
      _this.checkArr.every(item => {
        if (item.useStates === '1') {
          hasUse = true
          return false
        } else {
          deviceIds.push(item.deviceId)
          return true
        }
      })
      if (hasUse) {
        this.$message.warning({
          message: '不能删除正在使用中的车辆!',
          duration: 1500,
          showClose: true

        })
        return false
      }
      _this.$confirm('确定删除所选车辆吗？', '提示', {
        confirmButtoText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteIntercomByID(deviceIds).then(res => {
          if (res.code === 200) {
            _this.$message({
              message: '删除成功！',
              showClose: true,
              type: 'success'
            })
            _this.getInterphoneList()
          }
        }).catch(err => {
          console.log(err)
        })
      }).catch(() => {
        _this.$message({
          message: '已取消删除！',
          showClose: true,
          type: 'info'
        })
      })
    },
    /**
    * 分配
    */
    onAllot() {
      if (this.checkArr.length === 0) {
        this.$message({
          message: '请选择需要分配的车辆！',
          showClose: true,
          type: 'warning'
        })
        return
      }
      this.allotDialog = true
      if (this.checkArr.length === 1) {
        const checkObj = this.checkArr[0]
        // let listName = ''
        let code = ''
        if (checkObj.dutyPoliceUserId) this.addMessage.dutyPoliceUserId = checkObj.dutyPoliceUserId
        if (checkObj.orgCode) {
          code = checkObj.orgCode
          this.addMessage.organName = checkObj.organName
          this.addMessage.sszd = checkObj.orgCode
        }
        this.queryAdllotMJ('', code)
        // listName = 'fenpeizhongdui'
        // this.getOrgan(code, listName)
      } else {
        this.addMessage.sszd = ''
        this.addMessage.dutyPoliceUserId = ''
        this.addMessage.organName = ''
        this.fenpeizhongduiList = []
        this.adllotPolice = []
      }
    },
    /**
    * 导出
    */
    onOutput() {
      const _this = this
      /* const params = {
        deviceNo: _this.formData.deviceNo, // 对讲机号
        deviceNo2: _this.formData.deviceNo2, // 对讲机号
        categoryType: '1',
        vehicleType: _this.formData.vehicleType, // 对讲机号
        vehicleBrand: _this.formData.vehicleBrand, // 对讲机号
        orgCode: _this.formData.sszd ? _this.formData.sszd : _this.formData.ssdd, // 所属单位
        dutyPoliceUserId: _this.formData.dutyPoliceUserId, // 责任民警
        states: _this.getStates(_this.carStates), // "报废状态: 0报废、1正常、其他=全部 "
        distributionStates: _this.getStates(_this.adllotStates), // "分配状态 0未分配、1已分配，其他=全部",
        useStates: _this.getStates(_this.useStates), // "使用状态 0空闲、1使用中、其他=全部"，
        qrCodeBindSate: _this.getStates(_this.qrStates)// "二维码绑定状态 0未绑定、1已绑定、其他=全部"
      } */
      const params = { ..._this.oldFormData }
      exportInterphone(params).then(res => {
        const url = window.URL.createObjectURL(new Blob([res]))
        const link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        const fileName = '车辆列表.xlsx'
        link.setAttribute('download', fileName)
        document.body.appendChild(link)
        link.click()
      })
    }
  }
}
</script>

<style lang="stylus" scoped>
.interphone-container {
  .el-checkbox.is-bordered.el-checkbox--mini{
    padding:0px 15px
    line-height 28px
    .el-checkbox__label{
      padding 0px
    }
  }
  .tydic-input{
    .el-checkbox.is-bordered.el-checkbox--mini{
      width 120px!important
      text-align center
    }
  }
  .tydic-box {
    padding 0px 0 10px
  }
  .red-active{
    color red
  }
  .custom-dialog .el-form-item{
    margin-bottom 20px
  }
  .tydic-box .tydic-input~.tydic-input{
    margin-left 54px
  }
  padding 0px 20px
  .w200 {
    width 200px
  }
  .w180 {
    width 180px
  }
  .w140 {
    width 140px
  }
}
</style>
<style lang="stylus">
.input-class-add {
  width:200px;
}
.input-class-search {
  width:250px;
}
.cardBox{
  box-shadow 0 2px 12px 0 rgba(0, 0, 0, 0.1)
  background white
  height:90vh
}
 .el-checkbox.is-bordered.el-checkbox--mini .el-checkbox__inner{
    display none!important
  }
.interphone-container {
  .label-input {
    .el-input {
      width 200px!important
    }
  }
  .custom-dialog {
    &.addOrEdit {
      .el-dialog__body {
        padding-right 20px
        padding-left 20px
      }
    }
    // &.usedDialog{
    //   padding-right 30px
    //   padding-left 27px
    // }
  }
}
</style>
