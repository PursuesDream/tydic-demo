<template>
  <div class="archives-container">
    <div style="height:850px;">
      <el-scrollbar class="page-scroll">
        <div class="archive-box">
          <h1 class="archive-title"><i class="el-icon-notebook-2" style="color:#3aa8e1;margin-right:10px" />概要信息</h1>
          <div class="info-container">
            <p class="textTitle">
              {{ detailInfo.deviceNo }}
            </p>
            <el-col :span="6">
              <p>
                所属支队：{{ detailInfo.parentOrganName }}
              </p>
              <p>
                责任民警：{{ detailInfo.dutyPoliceName }} / {{ detailInfo.policeNo }}
              </p>
            </el-col>
            <el-col :span="6">
              <p>
                所属大队：{{ detailInfo.organName }}
              </p>
              <p>
                入库时间：{{ detailInfo.inTime }}
              </p>
            </el-col>
            <el-col :span="6">
              <p>
                品牌：{{ detailInfo.vehicleBrandName }}
              </p>
            </el-col>
            <el-col :span="6">
              <p>
                型号：{{ detailInfo.categoryCodeName }}
              </p>
            </el-col>
          </div>
        </div>
        <div class="archive-box">
          <h1 class="archive-title"><i class="el-icon-notebook-2" style="color:#3aa8e1;margin-right:10px" />使用民警</h1>
          <div class="archive-table">
            <el-table
              :data="accountTable"
              class="custom-table"
              max-height="350"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <el-table-column type="index" width="50" label="序号" align="center" />
              <el-table-column align="center" prop="policeName" label="姓名" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="policeNo" label="警号" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="ddOrgName" label="所属支队队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="zdOrgName" label="所属大队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="kilometres" label="巡逻里程" :show-overflow-tooltip="true" />
              <el-table-column prop="lastTime" align="center" label="最后一次使用" :show-overflow-tooltip="true" />
              <el-table-column prop="repairCount" align="center" label="维修次数" :show-overflow-tooltip="true" />
              <el-table-column prop="repairAmount" align="center" label="维修金额" :show-overflow-tooltip="true" />
              <el-table-column prop="maintainCount" align="center" label="保养次数" :show-overflow-tooltip="true" />
              <el-table-column prop="maintainAmount" align="center" label="保养金额" :show-overflow-tooltip="true" />
              <el-table-column prop="insuranceCount" align="center" label="出险次数" :show-overflow-tooltip="true" />
            </el-table>
            <!-- <el-pagination
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="accountPagination.pageSize"
              :total="accountPagination.total"
              :current-page.sync="accountPagination.curPage"
              :page-sizes="pageSizes"
              layout="prev, pager, next, sizes, jumper"
              @size-change="(val) => historyChange('isAccount', val)"
              @current-change="(val) => historyCurPageChange('isAccount', val)"
            /> -->
          </div>
        </div>
        <div class="archive-box">
          <h1 class="archive-title"><i class="el-icon-notebook-2" style="color:#3aa8e1;margin-right:10px" />使用记录</h1>
          <div class="archive-table">
            <el-table
              :data="useTable"
              class="custom-table"
              max-height="350"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <el-table-column align="center" type="index" label="序号" width="50" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="policeNo" label="警号" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="policeName" label="姓名" :show-overflow-tooltip="true" />
              <el-table-column prop="ddOrgName" align="center" label="所属支队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="zdOrgName" label="所属大队" :show-overflow-tooltip="true" />
              <el-table-column prop="beginTime" align="center" label="使用开始时间" :show-overflow-tooltip="true" />
              <el-table-column prop="endTime" align="center" label="使用结束时间" :show-overflow-tooltip="true" />
              <el-table-column prop="kilometres" align="center" label="里程数" :show-overflow-tooltip="true" />
              <!-- <el-table-column prop="cph" align="center" label="平均时速" :show-overflow-tooltip="true" /> -->
              <el-table-column align="center" label="轨迹回放">
                <template slot-scope="scope">
                  <el-button type="text" @click="handleDetail(scope.row, 'isMap')">口</el-button>
                </template>
              </el-table-column>
            </el-table>
            <el-pagination
              ref="pagination"
              style="text-align: center;margin-top:30px;"
              background
              :page-size="useHistoryPagination.pageSize"
              :total="useHistoryPagination.total"
              :current-page.sync="useHistoryPagination.curPage"
              :page-sizes="[5, 10, 15, 20]"
              layout="total, prev, pager, next, jumper"
              @size-change="(val) => historyChange('isMap', val)"
              @current-change="(val) => historyCurPageChange('isMap', val)"
            />
          </div>
        </div>
        <div class="archive-box">
          <h1 class="archive-title"><i class="el-icon-notebook-2" style="color:#3aa8e1;margin-right:10px" />维修记录</h1>
          <div class="archive-table">
            <el-table
              :data="serviceTable"
              class="custom-table"
              max-height="350"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <el-table-column type="index" width="50" label="序号" align="center" />
              <el-table-column align="center" prop="applyUserName" label="姓名" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="ssdd" label="警号" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="parentOrgName" label="所属支队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="orgName" label="所属大队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="applyTime" label="维修申请时间" :show-overflow-tooltip="true" />
              <el-table-column align="center" label="维保金额" :show-overflow-tooltip="true">
                <template slot-scope="scope">
                  <span>{{ getAllPay(scope.row.items) }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="fixCompanyName" align="center" label="维保单位" :show-overflow-tooltip="true" />
              <el-table-column prop="cjh" align="center" label="维保单位联系电话" :show-overflow-tooltip="true" />
              <el-table-column align="center" label="详情">
                <template slot-scope="scope">
                  <el-button type="text" @click="handleDetail(scope.row,'isFixRecord')">详情</el-button>
                </template>
              </el-table-column>
            </el-table>
            <el-pagination
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="servicePagination.pageSize"
              :total="servicePagination.total"
              :current-page.sync="servicePagination.curPage"
              :page-sizes="[5, 10, 15, 20]"
              layout="prev, pager, next, sizes, jumper"
              @size-change="(val) => historyChange('isFixRecord', val)"
              @current-change="(val) => historyCurPageChange('isFixRecord', val)"
            />
          </div>
        </div>
        <div class="archive-box">
          <h1 class="archive-title"><i class="el-icon-notebook-2" style="color:#3aa8e1;margin-right:10px" />保养记录</h1>
          <div class="archive-table">
            <el-table
              :data="insureTable"
              class="custom-table"
              max-height="350"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <el-table-column type="index" width="50" label="序号" align="center" />
              <el-table-column align="center" prop="applyUserName" label="姓名" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="ssdd" label="警号" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="parentOrgName" label="所属支队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="orgName" label="所属大队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="applyTime" label="维修申请时间" :show-overflow-tooltip="true" />
              <el-table-column align="center" label="维保金额" :show-overflow-tooltip="true">
                <template slot-scope="scope">
                  <span>{{ getAllPay(scope.row.items) }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="fixCompanyName" align="center" label="维保单位" :show-overflow-tooltip="true" />
              <el-table-column prop="cjh" align="center" label="维保单位联系电话" :show-overflow-tooltip="true" />
              <el-table-column align="center" label="详情">
                <template slot-scope="scope">
                  <el-button type="text" @click="handleDetail(scope.row,'isMaintain')">详情</el-button>
                </template>
              </el-table-column>
            </el-table>
            <el-pagination
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="insurePagination.pageSize"
              :total="insurePagination.total"
              :current-page.sync="insurePagination.curPage"
              :page-sizes="[5, 10, 15, 20]"
              layout="prev, pager, next, sizes, jumper"
              @size-change="(val) => historyChange('isMaintain', val)"
              @current-change="(val) => historyCurPageChange('isMaintain', val)"
            />
          </div>
        </div>
        <div class="archive-box">
          <h1 class="archive-title"><i class="el-icon-notebook-2" style="color:#3aa8e1;margin-right:10px" />出险记录</h1>
          <div class="archive-table">
            <el-table
              :data="outInsureTable"
              class="custom-table"
              max-height="350"
              stripe
              border
              header-row-class-name="custom-table-header"
            >
              <el-table-column type="index" width="50" label="序号" align="center" />
              <el-table-column align="center" prop="applyUserName" label="姓名" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="ssdd" label="警号" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="parentOrgName" label="所属支队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="orgName" label="所属大队" :show-overflow-tooltip="true" />
              <el-table-column align="center" prop="applyTime" label="出险申请时间" :show-overflow-tooltip="true" />
              <el-table-column prop="fixCompanyName" align="center" label="保险单位" :show-overflow-tooltip="true" />
              <el-table-column prop="insuranceType" align="center" label="索赔类型" :show-overflow-tooltip="true" />
              <el-table-column align="center" label="详情">
                <template slot-scope="scope">
                  <el-button type="text" @click="handleDetail(scope.row,'isInsurance')">详情</el-button>
                </template>
              </el-table-column>
            </el-table>
            <el-pagination
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="outInsurePagination.pageSize"
              :total="outInsurePagination.total"
              :current-page.sync="outInsurePagination.curPage"
              :page-sizes="[5, 10, 15, 20]"
              layout="prev, pager, next, sizes, jumper"
              @size-change="(val) => historyChange('isInsurance', val)"
              @current-change="(val) => historyCurPageChange('isInsurance', val)"
            />
          </div>
        </div>
      </el-scrollbar>
    </div>
    <!-- 弹层 -->
    <el-dialog :width="dialogWidth" custom-class="custom-dialog" :title="detailTitle" :visible.sync="detailDialog" :close-on-click-modal="false" :colse-on-press-escape="false" @close="closeDetail">
      <!-- 轨迹回放 -->
      <div v-if="isMap" style="height: 650px">
        <div style="margin-bottom: 10px;height:40px">
          <el-col :span="8">
            <i class="fontcolor-r">*&nbsp;</i>开始时间：
            <el-date-picker
              v-model="formData.beginTime"
              type="datetime"
              value-format="yyyy-MM-dd HH:mm:ss"
              placeholder="开始时间"
            />
          </el-col>
          <el-col :span="8">
            <i class="fontcolor-r">*&nbsp;</i>结束时间：
            <el-date-picker
              v-model="formData.endTime"
              type="datetime"
              value-format="yyyy-MM-dd HH:mm:ss"
              placeholder="结束时间"
              :picker-options="endTime"
            />
          </el-col>
          <el-col :span="6">
            <i class="fontcolor-r">*&nbsp;</i>播放倍数：
            <el-select v-model="formData.speedSelect" placeholder="">
              <el-option label="正常速度" value="200" />
              <el-option label="x2倍" value="100" />
              <el-option label="x3倍" value="65" />
              <el-option label="x4倍" value="50" />
            </el-select>
          </el-col>
          <el-col :span="2">
            <el-button type="primary search" size="mini" @click="handleTrack"><i class="image-icon search" />播放</el-button>
          </el-col>
        </div>
        <div id="detailMap" />
      </div>
      <!-- 维修记录 -->
      <div v-if="isFixRecord" style="height: 650px">
        <div style="font-size:17px">
          <p>
            流程编号： <span style="color:#3aa8e1">{{ infoData.applyNumber }}</span>
          </p>
          <p>
            <el-col :span="8">
              <span>
                申&nbsp;&nbsp;&nbsp;&nbsp;请&nbsp;&nbsp;&nbsp;&nbsp;人&nbsp;&nbsp;&nbsp;&nbsp;：  {{ infoData.applyUserName }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                所属大队：  {{ infoData.parentOrgName }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                所属中队：  {{ infoData.orgName }}
              </span>
            </el-col>
          </p>
          <p>
            <el-col :span="8">
              <span>
                车牌号码：  {{ infoData.vehicleNo }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                维保单位：  {{ infoData.fixCompanyName }}
              </span>
            </el-col>
          </p>
          <p>
            故障描述：{{ infoData.remarks }}
          </p>
          <div class="imgBox">
            <p>
              维保信息：
            </p>
            <div>
              <el-table
                :data="infoData.items"
                class="info-table"
                max-height="320"
                stripe
                border
                show-summary
                :summary-method="getSummaries"
              >
                <el-table-column type="index" width="50" label="序号" align="center" />
                <el-table-column align="center" label="维修配件" prop="fixName" />
                <el-table-column align="center" label="维修项目" prop="fixName" />
                <el-table-column align="center" label="参考单价（元）" width="120" :precision="2">
                  <template slot-scope="scope">
                    <!-- <el-input-number v-model="scope.row.shopPrice" class="w-full" type="number" :controls="false" :precision="2" placeholder="请输入" /> -->
                    {{ scope.row.shopPrice }}
                  </template>
                </el-table-column>
                <el-table-column align="center" label="实际单价（元）" width="150" prop="price" />
                <el-table-column align="center" label="数量" width="120" prop="num" />
                <el-table-column align="center" label="参考工时费（元）" width="150">
                  <template slot-scope="scope">
                    <!-- <el-input-number v-model="scope.row.hourPrice" class="w-full" :controls="false" :precision="2" placeholder="请输入" /> -->
                    {{ scope.row.shopHourPrice }}
                  </template>
                </el-table-column>
                <el-table-column prop="hourPrice" align="center" label="实际工时费（元）" width="150" />
                <el-table-column prop="workHour" align="center" label="工时（小时）" width="120" />
                <el-table-column align="center" label="费用（元）" width="130" :show-overflow-tooltip="true" prop="amount">
                  <template slot-scope="scope">
                    {{ getAllCost(scope.row) }}
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div class="imgBox">
            <p>
              附件列表（{{ fileLength }}）：
            </p>
            <div>
              <div>
                <el-button type="text" style="margin-left: 10px;" @click="hanlderDownload('all')">保存全部</el-button>
                <div style="max-height: 130px;overflow-y:auto">
                  <p v-for="(item,index) in infoData.annexs" :key="index">
                    <i class="el-icon-link" />
                    <el-button type="text" @click="hanlderDownload('one',item)">{{ item.name }}</el-button>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 保养记录 -->
      <div v-if="isMaintain" style="height: 500px">
        <div style="font-size:17px">
          <p>
            流程编号： <span style="color:#3aa8e1">{{ infoData.applyNumber }}</span>
          </p>
          <p>
            <span>
              申&nbsp;&nbsp;&nbsp;&nbsp;请&nbsp;&nbsp;&nbsp;&nbsp;人&nbsp;&nbsp;&nbsp;&nbsp;： {{ infoData.applyUserName }}
            </span>
            <span>
              所属支队：  {{ infoData.parentOrgName }}
            </span>
            <span>
              所属大队： {{ infoData.orgName }}
            </span>
          </p>
          <p>
            <span>
              车牌号码：  {{ infoData.vehicleNo }}
            </span>
            <span>
              维保单位： {{ infoData.fixCompanyName }}
            </span>
            <span>
              联系电话：  {{ infoData.applyNumber }}
            </span>
          </p>
          <p>
            故障描述：{{ infoData.remarks }}
          </p>
          <div class="imgBox">
            <p>
              维保信息：
            </p>
            <div>
              <el-table
                :data="infoData.items"
                class="info-table"
                max-height="320"
                stripe
                border
                show-summary
                :summary-method="getSummaries"
              >
                <el-table-column type="index" width="50" label="序号" align="center" />
                <el-table-column align="center" label="维修配件" prop="fixName" :show-overflow-tooltip="true" />
                <el-table-column align="center" label="维修项目" prop="fixName" :show-overflow-tooltip="true" />
                <el-table-column align="center" label="参考单价（元）" width="120" :show-overflow-tooltip="true">
                  <template slot-scope="scope">
                    <!-- <el-input-number v-model="scope.row.shopPrice" class="w-full" type="number" :controls="false" :precision="2" placeholder="请输入" /> -->
                    {{ scope.row.shopPrice }}
                  </template>
                </el-table-column>
                <el-table-column align="center" label="实际单价（元）" width="150" prop="price" :show-overflow-tooltip="true" />
                <el-table-column align="center" label="数量" width="120" prop="num" :show-overflow-tooltip="true" />
                <el-table-column align="center" label="参考工时费（元）" width="150" :show-overflow-tooltip="true">
                  <template slot-scope="scope">
                    <!-- <el-input-number v-model="scope.row.hourPrice" class="w-full" :controls="false" :precision="2" placeholder="请输入" /> -->
                    {{ scope.row.shopHourPrice }}
                  </template>
                </el-table-column>
                <el-table-column prop="hourPrice" align="center" label="实际工时费（元）" width="150" />
                <el-table-column prop="workHour" align="center" label="工时（小时）" width="120" />
                <el-table-column align="center" label="费用（元）" width="130" :show-overflow-tooltip="true" prop="amount">
                  <template slot-scope="scope">
                    {{ getAllCost(scope.row) }}
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div class="imgBox">
            <p>
              附件列表（{{ fileLength }}）：：
            </p>
            <div>
              <div>
                <el-button type="text" style="margin-left: 10px;" @click="hanlderDownload('all')">保存全部</el-button>
                <div style="max-height: 130px;overflow-y:auto">
                  <p v-for="(item,index) in infoData.annexs" :key="index">
                    <i class="el-icon-link" />
                    <el-button type="text" @click="hanlderDownload('one',item)">{{ item.name }}</el-button>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 出险记录 -->
      <div v-if="isInsurance" style="height: 350px">
        <div style="font-size:17px">
          <p>
            流程编号： <span style="color:#3aa8e1">{{ infoData.applyNumber }}</span>
          </p>
          <p>
            <el-col :span="8">
              <span>
                申&nbsp;&nbsp;&nbsp;&nbsp;请&nbsp;&nbsp;&nbsp;&nbsp;人&nbsp;&nbsp;&nbsp;&nbsp;：   {{ infoData.applyUserName }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                所属支队：  {{ infoData.parentOrgName }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                所属大队：  {{ infoData.orgName }}
              </span>
            </el-col>
          </p>
          <p>
            <el-col :span="8">
              <span>
                车牌号码：  {{ infoData.vehicleNo }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                保险单位：  {{ infoData.fixCompanyName }}
              </span>
            </el-col>
            <el-col :span="8">
              <span>
                索赔类型：  {{ getInsuranceType(infoData.insuranceType) }}
              </span>
            </el-col>
          </p>
          <p>
            故障描述：{{ infoData.remarks }}
          </p>
          <div>
            <div>
              <span style="font-size:17px">附件列表（{{ fileLength }}）：</span>
              <div>
                <el-button type="text" style="margin-left: 10px;" @click="hanlderDownload('all')">保存全部</el-button>
                <div style="max-height: 130px;overflow-y:auto">
                  <p v-for="(item,index) in infoData.annexs" :key="index">
                    <i class="el-icon-link" />
                    <el-button type="text" @click="hanlderDownload('one',item)">{{ item.name }}</el-button>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getInterphoneUse, getInterphoneUser } from '@/api/interphone'
import { downLoadFile, downLoadAllFIle } from '@/api/public'
import { getFixData, getFixDetail } from '@/api/processManagement'
import mapUtil from '@/utils/map/mapUtil'
import { getWarnTrack } from '@/api/realTimeMonitoring'
import iconM from '@/assets/mapIcon/011.png'
import { mapState } from 'vuex'
import { parseTime } from '@/utils'
// 因为BMap是挂在window对象上的，防止报错要加上window
const BMap = window.BMap
export default {
  name: 'Archives',
  data() {
    return {
      formData: {
        beginTime: '',
        endTime: '',
        speedSelect: '200',
        vehicleNo: ''
      },
      infoData: {},
      detailInfo: {},
      moveSpeed: 200,
      deviceId: '',
      useHistoryPagination: {
        curPage: 1,
        pageSize: 10,
        total: 10
      },
      dialogWidth: '900px',
      maps: '',
      imgUrl: iconM,
      imgArray: [iconM],
      activeTabButton: '01',
      isMap: false,
      isFixRecord: false,
      isMaintain: false,
      isInsurance: false,
      detailTitle: '',
      detailDialog: false,
      pageSizes: [5, 10, 15, 20],
      buttonList: [
        { name: '概要信息', value: '01' },
        { name: '相关用户', value: '02' },
        { name: '使用记录', value: '03' },
        { name: '维修记录', value: '04' },
        { name: '保养记录', value: '05' },
        { name: '出险记录', value: '06' }
      ],
      /* carPictures: [require('@/assets/testImg/Chrysanthemum.jpg'), require('@/assets/testImg/Desert.jpg'), require('@/assets/testImg/Hydrangeas.jpg'), require('@/assets/testImg/Jellyfish.jpg'), require('@/assets/testImg/Koala.jpg'), require('@/assets/testImg/Chrysanthemum.jpg')], */
      carPictures: ['1', '1', '1', '1', '1', '1'],
      selectPic: '',
      swiperOptions: {
        notNextTick: true,
        spaceBetween: 30,
        slidesPerView: 4
      },
      accountTable: [],
      accountPagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      useTable: [],
      useTablePagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      serviceTable: [],
      servicePagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      fixTable: [
        { fixName: '配件1', num: 10, shopPrice: 10, price: 10, shopHourPrice: 10, hourPrice: 10, workHour: 10, amount: 10 }

      ],
      insureTable: [],
      insurePagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      },
      multipleSeletcion: [],
      outInsureTable: [],
      outInsurePagination: {
        curPage: 1,
        pageSize: 10,
        total: 0
      }
    }
  },
  computed: {
    ...mapState({
      mapData: state => state.user.mapData
    }),
    archiveTitle() {
      const id = this.$route.params && this.$route.params.deviceNo
      console.log(this.$route.params)
      const value = id || ''
      return '档案 >>> ' + value
    },
    fileLength() {
      let length = 0
      if (this.infoData.annexs && this.infoData.annexs.length) length = this.infoData.annexs.length
      return length
    },
    endTime() {
      let startTime = this.formData.beginTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          startTime = new Date(startTime).getTime()
          if (nowDate < startTime) return true
          else return false
        }
      }
    }
  },
  mounted() {
    // this.initSwiper()

    this.setTagsViewTitle()
    this.formatDate()
  },
  methods: {
    /**
     * 计算维保金额
     */
    getAllPay(row) {
      let result = 0
      row.reduce((res, item) => {
        result += item.amount
      }, 0)
      return result.toFixed(2)
    },
    /**
     * 出险类型名称转换
     */
    getInsuranceType(id) {
      let name = ''
      const list = this.mapData.fix_apply_insurance_type
      for (let i = 0; i < list.length; i++) {
        if (list[i].code === id) {
          name = list[i].name
          break
        }
      }
      return name
    },
    /**
    * 使用民警
    */
    usedUserHistory() {
      const _this = this
      _this.accountTable = []
      const params = {
        deviceId: _this.deviceId
      }
      // pageNum: _this.accountPagination.curPage,
      // pageSize: _this.accountPagination.pageSize
      getInterphoneUser(params).then(res => {
        if (res.code === 200) {
          _this.accountTable = res.rows
          _this.accountPagination.total = res.total
        }
      })
    },
    /**
    * 使用记录条件查询
    */
    searchHistory() {
      const _this = this
      _this.useTable = []
      const params = {
        deviceId: _this.deviceId,
        usePoliceName: '',
        beginTime: '',
        endTime: '',
        pageNum: _this.useHistoryPagination.curPage,
        pageSize: _this.useHistoryPagination.pageSize
      }
      getInterphoneUse(params).then(res => {
        if (res.code === 200) {
          _this.useTable = res.data.rows
          _this.useHistoryPagination.total = res.data.total
        }
      })
    },
    /**
     * 使用记录分页
     */
    historyChange(type, val) {
      const _this = this
      if (type === 'isMap') {
        _this.useHistoryPagination.pageSize = val
        _this.searchHistory()
      } else if (type === 'isFixRecord') {
        _this.servicePagination.pageSize = val
        _this.getFixApply()
      } else if (type === 'isMaintain') {
        _this.insurePagination.pageSize = val
        _this.getMaintainApply()
      } else if (type === 'isInsurance') {
        _this.outInsurePagination.pageSize = val
        _this.getInsuranceApply()
      } else if (type === 'isAccount') {
        _this.accountPagination.pageSize = val
        _this.usedUserHistory()
      }
    },
    /**
    * 使用记录分页跳转
    */
    historyCurPageChange(type, val) {
      const _this = this
      if (type === 'isMap') {
        _this.useHistoryPagination.curPage = val
        _this.searchHistory()
      } else if (type === 'isFixRecord') {
        _this.servicePagination.curPage = val
        _this.getFixApply()
      } else if (type === 'isMaintain') {
        _this.insurePagination.curPage = val
        _this.getMaintainApply()
      } else if (type === 'isInsurance') {
        _this.outInsurePagination.curPage = val
        _this.getInsuranceApply()
      } else if (type === 'isAccount') {
        _this.accountPagination.curPage = val
        _this.usedUserHistory()
      }
    },
    handleSelectionChange(val) {
      this.multipleSeletcion = val
    },
    getAllCost(row) {
      const count = row.num
      const peijianNow = row.price
      const weixiuNow = row.hourPrice
      const hour = row.workHour
      const amount = count * peijianNow + weixiuNow * hour || 0
      row.amount = amount.toFixed(2)
      return amount.toFixed(2)
    },
    getSummaries(param) {
      const { columns, data } = param
      const sums = []
      columns.forEach((column, index) => {
        if (index === 0) {
          sums[index] = '合计'
          return
        }
        const values = data.map(item => Number(item[column.property]))
        if (column.property === 'amount') {
          sums[index] = values.reduce((prev, curr) => {
            const value = Number(curr)
            if (!isNaN(value)) {
              return prev + curr
            } else {
              return prev
            }
          }, 0)
          sums[index] += '元'
        } else {
          sums[index] = ''
        }
      })
      return sums
    },
    initSwiper() {
      console.log(this.$refs.swiper)
    },
    initMap() {
      const _this = this
      const BMap = window.BMap
      _this.maps = new BMap.Map('detailMap')
      const point = new BMap.Point(116.417804, 39.940296)
      // const point2 = new BMap.Point(114.154658527, 22.2878)
      _this.maps.centerAndZoom(point, 12)
      const marker = new BMap.Marker(point)
      marker.disableDragging()
      _this.maps.enableScrollWheelZoom() // 启用滚轮放大缩小，默认禁用
      _this.maps.enableContinuousZoom() // 启用地图惯性拖拽，默认禁用
    },
    setTagsViewTitle() {
      const params = this.$route.params
      this.detailInfo = JSON.parse(sessionStorage.getItem('detailInfo'))
      this.deviceId = params.id
      this.formData.vehicleNo = this.detailInfo.deviceNo
      const title = '装备档案'
      const tempRoute = Object.assign({}, this.$route)
      const route = Object.assign({}, tempRoute, { title })
      this.$store.dispatch('tagsView/updateVisitedView', route)
      this.$nextTick(this.searchHistory)
      this.$nextTick(this.getFixApply)
      this.$nextTick(this.getMaintainApply)
      this.$nextTick(this.getInsuranceApply)
      this.$nextTick(this.usedUserHistory)
    },
    changeTabButton(value) {
      this.activeTabButton = value
    },
    handleDetail(row, type) {
      const _this = this
      if (type === 'isMap') {
        _this.isMap = true
        _this.detailTitle = '铁骑轨迹'
        _this.dialogWidth = '1180px'
        _this.$nextTick(_ => {
          _this.initMap()
          // _this.$nextTick(_ => {
          //   // const layerId = '小车运动'
          //   // mapUtil.removeMapOverlay(_this.maps, layerId)
          //   _this.handleTrack()
          // })
        })
      } else if (type === 'isFixRecord') {
        _this.isFixRecord = true
        _this.detailTitle = '维修记录详情'
        _this.dialogWidth = '1180px'
        this.getApplyDetail(row.applyId)
      } else if (type === 'isMaintain') {
        _this.isMaintain = true
        _this.detailTitle = '保养记录详情'
        _this.dialogWidth = '1180px'
        this.getApplyDetail(row.applyId)
      } else if (type === 'isInsurance') {
        _this.isInsurance = true
        _this.detailTitle = '出险记录详情'
        _this.dialogWidth = '900px'
        this.getApplyDetail(row.applyId)
      }
      this.detailDialog = true
    },
    /**
    * 查询详情
    */
    getApplyDetail(val) {
      const that = this
      that.infoData = {}
      getFixDetail(val).then(res => {
        const obj = res.data
        obj.items.forEach(o => {
          o.weixiuList = []
        })
        that.infoData = obj
      }).catch(err => {
        console.log(err)
      })
    },
    closeDetail() {
      const _this = this
      _this.isMap = false
      _this.isFixRecord = false
      _this.isMaintain = false
      _this.isInsurance = false
    },
    /**
    *时间格式化
    */
    formatDate() {
      const _this = this
      // 获取格林时间
      var date1 = new Date(new Date(new Date().toLocaleDateString()).getTime())
      const myDate = new Date()
      _this.formData.beginTime = parseTime(date1)
      _this.formData.endTime = parseTime(myDate)
    },
    /**
    * 地图轨迹回放
    */
    handleTrack() {
      const _this = this
      const layerId = '小车运动'
      mapUtil.removeMapOverlay(_this.maps, layerId)
      const param = {
        beginTime: _this.formData.beginTime,
        endTime: _this.formData.endTime,
        vehicleNo: _this.formData.vehicleNo
      }
      if (_this.formData.speedSelect !== '') {
        _this.moveSpeed = _this.formData.speedSelect
      }
      getWarnTrack(param).then(res => {
        if (res.code === 200) {
          const pointArr = []
          res.data.forEach(item => {
            pointArr.push(new BMap.Point(item.longBaidu, item.latBaidu))
          })
          mapUtil.trackAnimation(_this.maps, pointArr, _this.moveSpeed)
        }
      }).catch(err => {
        console.log(err)
      })
    },
    /**
     * 查询设备维修申请列表
     */
    getFixApply() {
      const _this = this
      _this.serviceTable = []
      const param = {
        deviceId: _this.deviceId,
        flowType: 1,
        pageNum: _this.servicePagination.curPage,
        pageSize: _this.servicePagination.pageSize
      }
      getFixData(param).then(res => {
        if (res.code === 200) {
          _this.serviceTable = res.data.rows
          _this.servicePagination.total = res.data.total
        }
      }).catch(err => {
        console.log(err)
      })
    },
    /**
     * 查询设备保养申请列表
     */
    getMaintainApply() {
      const _this = this
      _this.insureTable = []
      const param = {
        deviceId: _this.deviceId,
        flowType: 2,
        pageNum: _this.insurePagination.curPage,
        pageSize: _this.insurePagination.pageSize
      }
      getFixData(param).then(res => {
        if (res.code === 200) {
          _this.insureTable = res.data.rows
          _this.insurePagination.total = res.data.total
        }
      }).catch(err => {
        console.log(err)
        _this.isLoading = false
      })
    },
    /**
     * 查询设备出险申请列表
     */
    getInsuranceApply() {
      const _this = this
      _this.outInsureTable = []
      const param = {
        deviceId: _this.deviceId,
        flowType: 3,
        pageNum: _this.outInsurePagination.curPage,
        pageSize: _this.outInsurePagination.pageSize
      }
      getFixData(param).then(res => {
        if (res.code === 200) {
          _this.outInsureTable = res.data.rows
          _this.outInsurePagination.total = res.data.total
        }
      }).catch(err => {
        console.log(err)
        _this.isLoading = false
      })
    },
    /**
     * 附件下载
     */
    hanlderDownload(flag, obj) {
      if (flag === 'one') {
        downLoadFile({
          fileName: obj.name,
          fileUrl: obj.url
        }).then(res => {
          const url = window.URL.createObjectURL(new Blob([res]))
          const link = document.createElement('a')
          link.style.display = 'none'
          link.href = url
          const fileName = obj.name
          link.setAttribute('download', fileName)
          document.body.appendChild(link)
          link.click()
        })
      } else {
        const names = []
        const urls = []
        this.infoData.annexs.forEach(o => {
          names.push(o.name)
          urls.push(o.url)
        })
        downLoadAllFIle({
          names, urls
        }).then(res => {
          const url = window.URL.createObjectURL(new Blob([res]))
          const link = document.createElement('a')
          link.style.display = 'none'
          link.href = url
          const fileName = '全部文件.zip'
          link.setAttribute('download', fileName)
          document.body.appendChild(link)
          link.click()
        })
      }
    }
  }
}
</script>

<style lang="stylus" scoped>
.archives-container {
    padding 10px 20px
    overflow auto
    height 800px
    // position relative
    .tab-button-group {
        position absolute
        z-index 99
        top 50px
        right 10px
        width 120px
        >button {
            display block
            width 100%
            height 40px
            text-align center
            border 1px solid rgb(170,170,170)
            border-radius 5px
            font-size 13px
            color #000
            outline none
            background-color white
            cursor pointer
            margin-bottom 30px
            &:last-child {
                margin-bottom 0
            }
            &.active {
                background-color #169bd5
                color white
                border-color #169bd5
            }
        }
    }
    .archive-box {
        border 1px solid #ebebeb
        margin-bottom 20px
        padding 0px 10px
        .archive-title {
            height 46px
            border-bottom 1px solid #ebebeb
            // background-image linear-gradient(-90deg,rgb(255,255,255) 26%,rgb(2,167,240) 99%)
            margin 0
            font-size 18px
            font-weight 650
            line-height 46px
            padding-left 50px
        }
        .archive-table {
            padding 10px 10px 10px 10px
            height 435px
        }
    }
    #detailMap{
      margin-top 10px
      width 1162px
      height 600px
    }
    .dashBox{
      display inline-block
      height 115px
      border 1px dashed #ebebeb
      margin-left 10px
      padding 5px 5px
      width 115px
    }
    .info-container {
        // padding-left 340px
        height 200px
        width 100%
        .textTitle {
          color #3274e1
          font-size 25px
          font-weight bold
        }

    }
}
</style>
