<template>
  <div class="manage-container">
    <el-card style="margin-top:20px;height:85vh">
      <div class="tydic-box">
        <div class="tydic-input">
          <span style="margin-left:0px">申请时间：</span>
          <el-date-picker
            v-model="searchConditon.beginTime"
            class="w220"
            type="datetime"
            value-format="yyyy-MM-dd HH:mm:ss"
            placeholder="开始时间"
            :picker-options="applyStartTime"
          />
          <span style="display: inline-block;margin: 0 10px;">至</span>
          <el-date-picker
            v-model="searchConditon.endTime"
            class="w220"
            style="margin-left: 0;padding-left: 0;"
            type="datetime"
            value-format="yyyy-MM-dd HH:mm:ss"
            placeholder="结束时间"
            :picker-options="applyEndTime"
          />
        </div>
        <!-- <div class="tydic-input">
        所属支队：
        <el-select v-model="searchConditon.parentOrgCode" clearable @change="(val) =>getOrgan(val,'zhongdui')">
          <el-option
            v-for="(o,index) in daduiList"
            :key="index"
            :label="o.name"
            :value="o.organCode"
          />
        </el-select>
      </div>
      <div class="tydic-input">
        所属大队：
        <el-select v-model="searchConditon.orgCode" clearable>
          <el-option
            v-for="(o,index) in zhongduiList"
            :key="index"
            :label="o.name"
            :value="o.organCode"
          />
        </el-select>
      </div> -->
        <div class="tydic-input">
          申请编号：
          <el-input v-model="searchConditon.applyNumber" placeholder="请输入" :maxlength="50" />
        </div>
        <div class="tydic-input">
          <span style="margin-left:14px">
            申请人：
          </span>
          <el-input v-model="searchConditon.flowUserName" placeholder="请输入" :maxlength="50" />
        </div>
        <div class="tydic-input">
          流程类型：
          <el-select v-model="searchConditon.flowType" clearable>
            <el-option
              v-for="(o,index) in processTypeList"
              :key="index"
              :label="o.name"
              :value="o.code"
            />
          </el-select>
        </div>
        <div>
          <div class="tydic-input">
            <span style="margin-left:0px">结束时间：</span>
            <el-date-picker
              v-model="searchConditon.overBeginTime"
              class="w220"
              type="datetime"
              value-format="yyyy-MM-dd HH:mm:ss"
              placeholder="开始时间"
              :picker-options="liuchengStartTime"
            />
            <span style="display: inline-block;margin: 0 10px;">至</span>
            <el-date-picker
              v-model="searchConditon.overEndTime"
              class="w220"
              style="margin-left: 0;padding-left: 0;"
              type="datetime"
              value-format="yyyy-MM-dd HH:mm:ss"
              placeholder="结束时间"
              :picker-options="liuchengEndTime"
            />
          </div>

          <div class="tydic-input">
            流程状态：
            <el-select v-model="searchConditon.flowState" clearable>
              <el-option
                v-for="(o,index) in fixStatusList"
                :key="index"
                :label="o.name"
                :value="o.code"
              />
            </el-select>
          </div>
          <div class="tydic-input" style="float:right">
            <el-button type="primary search" size="mini" @click="onSearch"><i class="image-icon search" />查询</el-button>
            <el-button type="primary reset" size="mini" @click="handleReset"><i class="image-icon reset" />重置</el-button>
          </div>
        </div>
      </div>
      <div class="button-group">
        <el-button v-if="roleType !== 'true'" v-permission="'button21'" type="primary color-default" size="mini" @click="handleApply">申请流程</el-button>
      <!-- <el-button type="default color-default" size="mini" @click="handleInvalid">申请作废</el-button>
      <el-button type="default color-default" size="mini" @click="handleApproval">审批</el-button> -->
      </div>
      <div class="table-container">
        <div class="tabs-group">
          <div v-for="(item,index) in tableTabs" :key="index" class="tab" :class="activeTab === item.value ? 'active': ''" @click="handeChangeTab(item.value)">{{ item.name }}</div>
        </div>
        <el-table
          v-loading="isLoading"
          width="1350px"
          :data="tableData"
          class="custom-table"
          max-height="600"
          stripe
          border
          header-row-class-name="custom-table-header"
        >
          <el-table-column width="100" label="序号" align="center">
            <template slot-scope="scope">
              {{ scope.$index + 1 + searchConditon.pageSize * (searchConditon.pageNum - 1) }}
            </template>
          </el-table-column>
          <el-table-column align="center" label="流程编号" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <el-button type="text" @click="handleOpenInfo(scope.row)">{{ scope.row.applyNumber }}</el-button>
            </template>
          </el-table-column>
          <!-- <el-table-column align="center" prop="parentOrgName" label="所属支队" :show-overflow-tooltip="true" />
        <el-table-column align="center" prop="orgName" label="所属大队" :show-overflow-tooltip="true" /> -->
          <el-table-column prop="applyUserName" align="center" label="申请人" width="100" :show-overflow-tooltip="true" />
          <el-table-column prop="applyTime" align="center" label="申请时间" width="200" :show-overflow-tooltip="true" />
          <el-table-column prop="flowType" align="center" label="流程类型" width="100" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              {{ getVehicleBrand(scope.row.flowType,'processTypeList') }}
            </template>
          </el-table-column>
          <el-table-column prop="overTime" align="center" label="结束时间" width="200" :show-overflow-tooltip="true" />
          <el-table-column prop="flowState" align="center" label="流程状态" width="100" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              {{ getVehicleBrand(scope.row.flowState,'fixStatusList') }}
            </template>
          </el-table-column>
          <el-table-column align="center" prop="parentOrgName" label="所属机构" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              {{ (scope.row.parentOrgName || '') + ' / ' + (scope.row.orgName || '') }}
            </template>
          </el-table-column>
          <el-table-column align="center" label="操作" width="100">
            <template slot-scope="scope">
              <!-- <el-button type="text" @click="handleApproval(scope.row)">审批</el-button> -->
              <!-- <el-button type="text" @click="handleBack(scope.row)">回退</el-button>
          <el-button type="text" @click="handleInvalid(scope.row)">作废</el-button>
          <el-button type="text" @click="handleEdit(scope.row)">编辑</el-button> -->
              <el-button v-if="scope.row.approve === '1'" v-permission="'button51'" type="text" @click="handleApproval(scope.row)">审批</el-button>
              <el-button v-if="scope.row.back === '1'" v-permission="'button22'" type="text" @click="handleBack(scope.row)">回退</el-button>
              <el-button v-if="scope.row.invalid === '1'" v-permission="'button23'" type="text" @click="handleInvalid(scope.row)">作废</el-button>
              <el-button v-if="scope.row.edit === '1'" v-permission="'button50'" type="text" @click="handleEdit(scope.row)">编辑</el-button>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          ref="pagination"
          style="text-align: center;margin-top:30px;"
          background
          :page-size="searchConditon.pageSize"
          :total="searchConditon.total"
          :current-page.sync="searchConditon.pageNum"
          :page-sizes="pageSizes"
          layout="total, prev, pager, next, jumper"
          @current-change="handlePageChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script>
import { getFixAllList } from '@/api/processManagement'
import { mapState } from 'vuex'
import { organListByParam } from '@/api/public'
export default {
  name: 'ProcessManage',
  data() {
    return {
      isLoading: false,
      roleType: null,
      searchConditon: {
        applyUserId: '', // 当前用户
        beginTime: '', // 申请结束时间
        endTime: '', // 申请结束时间
        flowType: '', // 流程类型 1-维修 2-保养 3-出险 4-报废
        flowUserId: '', // 流程申请人
        orgCode: '', // 所属中队组织机构名称
        overBeginTime: '', // 流程结束开始时间
        overEndTime: '', // 流程结束结束时间
        parentOrgCode: '', // 所属大队组织机构
        queryType: '0', //	查询类型 0-所有流程 1-我的审批 2-我的申请'
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      oldSearchConditon: null,
      daduiList: [],
      zhongduiList: [],
      processTypeList: [],
      tableData: [],
      fixStatusList: [],
      pageSizes: [5, 10, 15, 20],
      tableTabs: [
        { name: '所有流程', value: '0' },
        { name: '我的审批', value: '1' },
        { name: '我的申请', value: '2' }
      ], // 0-所有流程 1-我的审批 2-我的申请
      activeTab: '0'
    }
  },
  computed: {
    ...mapState({
      mapData: state => state.user.mapData
    }),
    liuchengStartTime() {
      let endTime = this.searchConditon.overEndTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          endTime = new Date(endTime).getTime()
          if (endTime) {
            if (nowDate > endTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    },
    liuchengEndTime() {
      let startTime = this.searchConditon.overBeginTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          startTime = new Date(startTime).getTime()
          if (startTime) {
            if (nowDate < startTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    },
    applyStartTime() {
      let endTime = this.searchConditon.endTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          endTime = new Date(endTime).getTime()
          if (endTime) {
            if (nowDate > endTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    },
    applyEndTime() {
      let startTime = this.searchConditon.beginTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          startTime = new Date(startTime).getTime()
          if (startTime) {
            if (nowDate < startTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    }
  },
  watch: {
    // 如果路由有变化，会再次执行请求列表的方法
    $route(to, from) {
      if (from.path === '/process/manage') {
        return
      }
      this.getFixApply()
    }
  },
  mounted() {
    const _this = this
    _this.roleType = sessionStorage.getItem('roleType')
    _this.getFixApply()
    _this.getOrgan('', 'dadui')
    _this.processTypeList = _this.mapData.fix_apply_type
    _this.fixStatusList = _this.mapData.fix_apply_stauts
  },
  methods: {
    handleApply() {
      this.$router.push('/process/apply/')
    },
    handleOpenInfo(row) {
      // this.$router.push({ path: `/process/info/read/${row.applyNumber}`, query: { id: row.applyId, applyNumber: row.applyNumber, status: 'read' }})
      this.$router.push({ path: `/process/info/read/${row.applyId}/${row.applyNumber}` })
    },
    handeChangeTab(value) { // 切换流程
      this.activeTab = value
      this.searchConditon.queryType = value
      this.searchConditon.pageNum = 1
      this.getFixApply()
      this.tableData = []
    },
    /**
    * 条件查询
    */
    onSearch() {
      const _this = this
      this.oldSearchConditon = null
      _this.searchConditon.pageNum = 1
      _this.getFixApply()
    },
    /**
     * 查询设备维修申请列表
     */
    getFixApply() {
      const _this = this
      _this.isLoading = true
      let param = {}
      if (this.oldSearchConditon) {
        param = { ... _this.oldSearchConditon }
      } else {
        param = { ... _this.searchConditon }
        _this.oldSearchConditon = param
        delete _this.oldSearchConditon.pageNum
        delete _this.oldSearchConditon.pageSize
        delete _this.oldSearchConditon.queryType
      }
      param.pageNum = _this.searchConditon.pageNum
      param.pageSize = _this.searchConditon.pageSize
      param.queryType = _this.searchConditon.queryType
      getFixAllList(param).then(res => {
        if (res.code === 200) {
          _this.isLoading = false
          _this.tableData = res.data.rows
          _this.searchConditon.total = res.data.total
        }
      }).catch(err => {
        console.log(err)
        _this.isLoading = false
      })
    },
    handleInvalid(row) {
      this.$router.push({ path: `/process/info/invalid/${row.applyId}/${row.applyNumber}` })
    },
    handleApproval(row) {
      this.$router.push({ path: `/process/info/approval/${row.applyId}/${row.applyNumber}` })
    },
    handleBack(row) {
      this.$router.push({ path: `/process/info/back/${row.applyId}/${row.applyNumber}` })
    },
    handleEdit(row) {
      this.$router.push({ path: `/process/apply/${row.applyId}/${row.applyNumber}` })
    },
    /**
     * 分页
     */
    handlePageChange(val) {
      // this.searchConditon.curPage = val
      this.getFixApply()
    },
    /**
   * 查询大队
   * @param {String} listName 'dadui'  'zhongdui'
   */
    getOrgan(code, listName) {
      this[listName + 'List'] = []
      const organizeCode = window.CONFIG.organizeCode
      let orgLevel = organizeCode.first
      if (listName === 'zhongdui') orgLevel = organizeCode.second
      const params = {
        // orgSubType: 0,
        parentCode: code,
        orgLevel: orgLevel
      }
      organListByParam(params).then(res => {
        if (res.code === 200) {
          this[listName + 'List'] = res.data
        }
      })
    },
    /**
     * 重置
     */
    handleReset() {
      this.searchConditon = {
        applyUserId: '', // 当前用户
        beginTime: '', // 申请结束时间
        endTime: '', // 申请结束时间
        flowType: '', // 流程类型 1-维修 2-保养 3-出险 4-报废
        flowUserId: '', // 流程申请人
        orgCode: '', // 所属中队组织机构名称
        overBeginTime: '', // 流程结束开始时间
        overEndTime: '', // 流程结束结束时间
        parentOrgCode: '', // 所属大队组织机构
        queryType: '0', //	查询类型 0-所有流程 1-我的审批 2-我的申请'
        pageNum: 1,
        pageSize: 10,
        total: 0
      }
      this.oldSearchConditon = null
      this.zhongduiList = []
      this.getFixApply()
    },
    /**
    * 转义维保类型
    */
    getVehicleBrand(id, listName) {
      let name = ''
      const list = this[listName]
      if (this[listName]) {
        const ids = id + ''
        for (let i = 0; i < list.length; i++) {
          if (list[i].code === ids) {
            name = list[i].name
            break
          }
        }
        return name
      }
    }
  }
}
</script>

<style lang="stylus" scoped>
.manage-container {
  // width 1920px
  position relative
  padding 0 20px
  .w200 {
    width: 200px;
  }
  .w220 {
    width: 220px;
  }
  .tydic-box {
    padding 0px 0 0px
    .tydic-input {
      &~.tydic-input {
        margin-left 102px
      }
    }
  }
}
.button-group {
  // margin-bottom 10px
}
.table-container {
  position relative
  margin-top 20px
}
.tabs-group {
  position absolute
  right 0
  top -30px
  z-index 99
  .tab {
    cursor pointer
    display inline-block
    width 100px
    height 30px
    line-height 31px
    box-sizing border-box
    border 1px solid #f2f2f2
    background-color white
    text-align center
    color #333
    font-size 13px
    &.active {
      background-color #02a7f0
      color white
    }
  }
}
</style>
