<template>
  <div class="info-container">
    <div class="info-content">
      <div class="content-title"><i class="el-icon-notebook-2" />基本信息</div>
      <div class="content-box">
        <el-row>
          <el-col :span="6">流程编号：<el-link type="primary" :underline="false">{{ infoData.applyNumber }}</el-link></el-col>
          <el-col :span="6">申请人：{{ infoData.applyUserName }}</el-col>
          <el-col :span="6">所属支队：{{ infoData.parentOrgName }}</el-col>
          <el-col :span="6">所属大队：{{ infoData.orgName }}</el-col>
        </el-row>
        <el-row>
          <el-col :span="6">车牌号码：{{ infoData.vehicleNo }}</el-col>
          <el-col :span="6">车辆类型：{{ getVehicleBrands(infoData.vehicleType,'carType') }}</el-col>
          <el-col :span="6">流程类型：{{ getVehicleBrand(infoData.flowType,'typeList') }}</el-col>
          <el-col v-if="infoData.flowType === '1' || infoData.flowType === '2'" :span="6">维保单位：{{ infoData.fixCompanyName }}</el-col>
          <el-col v-if="infoData.flowType === '3'" :span="6">出险类型：{{ getVehicleBrand(infoData.insuranceType,'chuxianTypeList') }}</el-col>
        </el-row>
        <el-row>
          <el-col :span="24" class="reason-text">
            <span style="position:absolute;top:0;left:0;">故障描述：</span>
            <p>{{ infoData.remarks }}</p>
          </el-col>
        </el-row>
        <el-row v-if="infoData.flowType === '1' || infoData.flowType === '2'">
          <el-col :span="24">
            维修信息：
            <el-table
              :data="infoData.items"
              class="info-table"
              max-height="320"
              stripe
              border
              show-summary
              :summary-method="getSummaries"
            >
              <el-table-column type="index" width="50" label="序号" align="center" />
              <el-table-column align="center" label="配件名称" prop="parts">
                <template slot-scope="scope">
                  {{ scope.row.peijianValue }}
                </template>
              </el-table-column>
              <el-table-column align="center" prop="itemName" label="维修项目">
                <template slot-scope="scope">
                  {{ scope.row.weixiuValue }}
                </template>
              </el-table-column>
              <el-table-column align="center" label="参考单价（元）" width="120">
                <template slot-scope="scope">
                  {{ scope.row.shopPrice }}
                </template>
              </el-table-column>
              <el-table-column align="center" label="实际单价（元）" width="150">
                <template slot-scope="scope">
                  {{ scope.row.price }}
                </template>
              </el-table-column>
              <el-table-column align="center" label="数量" width="120">
                <template slot-scope="scope">
                  {{ scope.row.num }}
                </template>
              </el-table-column>
              <el-table-column align="center" label="参考工时费（元/小时）" width="180">
                <template slot-scope="scope">
                  {{ scope.row.shopHourPrice }}
                </template>
              </el-table-column>
              <el-table-column prop="shopPrice" align="center" label="实际工时费（元/小时）" width="180">
                <template slot-scope="scope">
                  {{ scope.row.hourPrice }}
                </template>
              </el-table-column>
              <el-table-column prop="workHour" align="center" label="工时（小时）" width="120">
                <template slot-scope="scope">
                  {{ scope.row.workHour }}
                </template>
              </el-table-column>
              <el-table-column prop="amount" align="center" label="费用（元）" width="130" :show-overflow-tooltip="true">
                <!-- <template slot-scope="scope">
                  {{ getAllCost(scope.row) }}
                </template> -->
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24" class="reason-text">
            <span style="position:absolute;top:0;left:0;">附件（{{ fileLength }}）：</span>
            <div>
              <el-button type="text" style="margin-left: 10px;" @click="hanlderDownload('all')">保存全部</el-button>
              <div style="max-height: 130px;overflow-y:auto">
                <p v-for="(item,index) in infoData.annexs" :key="index">
                  <i class="el-icon-link" />
                  <el-button type="text" @click="hanlderDownload('one',item)">{{ item.name }}</el-button>
                </p>
              </div>
            </div>
          </el-col>
        </el-row>
      </div>
    </div>
    <div class="info-content" style="margin-bottom: 20px;">
      <div class="content-title"><i class="el-icon-notebook-2" />流转信息</div>
      <div class="content-box">
        <div class="history-group">
          <p v-for="(item,index) in infoData.process" :key="index" class="history">{{ item }}</p>
        </div>
        <template v-if="pageStatus !=='read'">
          <p>
            <span class="required">处理结论：</span>
            <el-radio-group v-model="resultRadio">
              <el-radio v-for="(item,index) in radioGroup" :key="index" :label="item.value">{{ item.label }}</el-radio>
            </el-radio-group>
          </p>
          <p>
            <!-- <span :class="isRequired ? 'required': ''">处理意见：</span> -->
            <span>处理意见：</span>
            <el-input v-model="resultText" style="margin-top:10px;width: 800px;display:block;" resize="none" type="textarea" placeholder="请输入" maxlength="100" show-word-limit :autosize="{minRows: 5,maxRows: 5}" />
          </p>
          <div v-if="isRead" style="text-align:right">
            <el-button type="primary color3" size="mini" @click="hanleSubmit">提交</el-button>
            <el-button type="primary color2" size="mini" @click="hanleReset">重置</el-button>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
import { getFixDetail, addFixFlow } from '@/api/processManagement'
import { getCategoryList, getCategoryCodeByVehicleNo } from '@/api/integratedManage'
import { getFixItemconfigByFixId, getFixList } from '@/api/fixProject'
import { downLoadFile, downLoadAllFIle } from '@/api/public'
import { mapState } from 'vuex'
export default {
  name: 'ProcessInfo',
  data() {
    return {
      infoTableData: [
        {
          peijianValue: 800,
          peijianNow: 700,
          count: 2,
          weixiuValue: 500,
          weixiuNow: 600,
          hour: 1.5,
          allCost: '',
          ID: 0 }
      ],
      carType: [],
      typeList: [],
      peijianList: [],
      weixiuList: [],
      historyList: [],
      pageStatus: 'approval',
      resultRadio: '',
      resultText: '',
      isRead: true,
      infoData: {},
      categoryCode: '',
      vehicleBrand: '',
      chuxianTypeList: []
    }
  },
  computed: {
    ...mapState({
      mapData: state => state.user.mapData
    }),
    fileLength() {
      let length = 0
      if (this.infoData.annexs && this.infoData.annexs.length) length = this.infoData.annexs.length
      return length
    },
    radioGroup() {
      let arr = []
      const status = this.pageStatus
      switch (status) {
        case 'approval':
          arr = [
            { label: '同意', value: 0 },
            { label: '不同意', value: 1 },
            { label: '作废', value: 2 }
          ]
          break
        case 'back': {
          arr = [
            { label: '回退', value: -1 }
          ]
          break
        }
        case 'invalid':
          arr = [
            { label: '作废', value: 2 }
          ]
          break
        default:
          arr = []
          break
      }
      return arr
    },
    isRequired() {
      let status = false
      const nowPageStaus = this.pageStatus
      if (nowPageStaus !== 'approval' && nowPageStaus !== 'read') status = true
      else if (nowPageStaus === 'approval') {
        if (this.resultRadio !== '' && this.resultRadio !== 1) status = true
      }
      return status
    }
  },
  watch: {
    radioGroup(val) {
      if (val.length) {
        this.resultRadio = val[0].value
      }
    }
  },
  mounted() {
    this.setTagsViewTitle()
    this.getAllCategory()
    this.carType = this.mapData.fix_apply_vehicle_type
    this.typeList = this.mapData.fix_apply_type
    this.chuxianTypeList = this.mapData.fix_apply_insurance_type
  },
  methods: {
    hanleSubmit() {
      const _this = this
      if (_this.resultRadio === '') {
        _this.$message.warning({
          message: '请选择一种处理结论！',
          showClose: true
        })
        return false
      }
      // if (_this.isRequired && _this.resultText === '') {
      //   _this.$message.warning({
      //     message: '请填写处理意见！',
      //     showClose: true
      //   })
      //   return false
      // }
      const param = {
        applyId: _this.infoData.applyId,
        stauts: _this.resultRadio,
        remarks: _this.resultText
      }
      addFixFlow(param).then(res => {
        if (res.code === 200) {
          _this.$message.success({
            message: '操作成功!',
            showClose: true
          })
        }
        const view = this.$route
        this.$store.dispatch('tagsView/delView', view).then(({ visitedViews }) => {
          this.$router.push({ name: 'ProcessManage' })
        })
        // this.$router.push('/process/manage')
      })
    },
    hanleReset() {
      this.resultRadio = ''
      this.resultText = ''
    },
    setTagsViewTitle() {
      const params = this.$route.params
      let title = ''
      if (params.status === 'read') {
        title = '流程详情'
        this.isRead = false
      } else {
        title = '流程处理'
      }
      this.pageStatus = params.status
      const tempRoute = Object.assign({}, this.$route)
      const route = Object.assign({}, tempRoute, { title })
      this.$store.dispatch('tagsView/updateVisitedView', route)
      this.$nextTick(this.getApplyDetail(params.id))
    },
    /**
    * 查询详情
    */
    getApplyDetail(val) {
      const that = this
      getFixDetail(val).then(res => {
        res.data.items.forEach(o => {
          o.peijianValue = ''
          o.weixiuValue = ''
        })
        this.infoData = res.data
        // 配件名称列表回显
        getCategoryCodeByVehicleNo({
          vehicleNo: this.infoData.vehicleNo
        }).then(res => { // 根据车牌号查询型号代码
          const categoryCode = res.data || ''
          that.categoryCode = categoryCode
          that.vehicleBrand = that.getVehicleBrands(that.infoData.vehicleType, 'carType')
          const params = {}
          const data = {
            vehicleType: that.infoData.vehicleType,
            vehicleBrand: that.vehicleBrand,
            categoryCode,
            guaranteeType: that.infoData.flowType
          }
          that.peijianList = []
          getFixList({ data, params }).then(res => {
            if (res.code === 200) {
              that.peijianList = res.data.rows || []
              that.infoData.items.forEach(o => {
                that.peijianList.every(pj => {
                  if (pj.fixId === o.fixId) {
                    o.peijianValue = pj.ports
                    return false
                  } else return true
                })
                const data = {
                  fixId: o.fixId
                }
                // 维修项目列表回显
                getFixItemconfigByFixId(data).then(res => {
                  if (res.code === 200) {
                    o.weixiuList = res.data || []
                    o.weixiuList.every(wx => {
                      if (wx.fixItemId === o.fixItemId) {
                        o.weixiuValue = wx.itemName
                        return false
                      } else return true
                    })
                  }
                })
              })
            }
          })
        })
      }).catch(err => {
        console.log(err)
      })
    },
    handleAddInfo() {
      if (this.infoTableData.length > 9) return false
      let ID = 0
      if (this.infoTableData.length > 0) {
        ID = this.infoTableData[this.infoTableData.length - 1].ID + 1
      }
      const obj = {
        peijianValue: '',
        peijianNow: '',
        count: '',
        weixiuValue: '',
        weixiuNow: '',
        hour: '',
        allCost: '',
        ID
      }
      this.infoTableData.push(obj)
    },
    /**
     * 转义类型
     */
    getVehicleBrand(id, listName) {
      let name = ''
      const list = this[listName]
      const ids = id + ''
      for (let i = 0; i < list.length; i++) {
        if (list[i].code === ids) {
          name = list[i].name
          break
        }
      }
      return name
    },
    /**
     * 转义车辆类型
     */
    getVehicleBrands(id, listName) {
      let name = ''
      const list = this[listName]
      const ids = id + ''
      for (let i = 0; i < list.length; i++) {
        if (list[i].categoryCode === ids) {
          name = list[i].categoryName
          break
        }
      }
      return name
    },
    /**
     * 查询所有车辆类型
     */
    getAllCategory() {
      const _this = this
      const params = {
        categoryCode: '',
        categoryType: '1'
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          _this.carType = res.data
        }
      })
    },
    getAllCost(row) {
      const count = row.num // 数量
      const peijianNow = row.price // 实际单价
      const weixiuNow = row.hourPrice // 实际工时费
      const hour = row.workHour // 工时
      const allCost = count * peijianNow + weixiuNow * hour || 0
      row.allCost = allCost.toFixed(2)
      return allCost.toFixed(2)
    },
    getSummaries(param) {
      const { columns, data } = param
      const sums = []
      columns.forEach((column, index) => {
        if (index === 0) {
          sums[index] = '合计'
          return
        }
        const values = data.map(item => Number(item[column.property]))
        if (column.property === 'amount') {
          sums[index] = values.reduce((prev, curr) => {
            const value = Number(curr)
            if (!isNaN(value)) {
              return prev + curr
            } else {
              return prev
            }
          }, 0)
          sums[index] += '元'
        } else {
          sums[index] = ''
        }
      })
      return sums
    },
    getSelectName(value, listName) {
      const list = this[listName] || []
      let name = ''
      for (let i = 0; i < list.length; i++) {
        if (list[i].value === value) {
          name = list[i].name
          break
        }
      }
      return name
    },
    hanlderDownload(flag, obj) {
      if (flag === 'one') {
        downLoadFile({
          fileName: obj.name,
          fileUrl: obj.url
        }).then(res => {
          const url = window.URL.createObjectURL(new Blob([res]))
          const link = document.createElement('a')
          link.style.display = 'none'
          link.href = url
          const fileName = obj.name
          link.setAttribute('download', fileName)
          document.body.appendChild(link)
          link.click()
        })
      } else {
        const names = []
        const urls = []
        this.infoData.annexs.forEach(o => {
          names.push(o.name)
          urls.push(o.url)
        })
        downLoadAllFIle({
          names, urls
        }).then(res => {
          const url = window.URL.createObjectURL(new Blob([res]))
          const link = document.createElement('a')
          link.style.display = 'none'
          link.href = url
          const fileName = '全部文件.zip'
          link.setAttribute('download', fileName)
          document.body.appendChild(link)
          link.click()
        })
      }
    }
  }
}
</script>

<style lang="stylus" scoped>
.info-container {
    padding 0 30px
    .content-title {
      i {
        color #1296da
        margin-right 10px
      }
      font-weight bold
      margin 20px 0 10px
    }
    .content-box {
      background-color white
      box-shadow 5px 5px 5px rgba(0,0,0,0.35)
      border 1px solid rgb(242,242,242)
      padding 20px
      .el-row {
        margin-bottom 5px
        .el-col {
          line-height 30px
        }
        .reason-text {
          position relative
          padding-left 80px
          p {
            overflow-y auto
            max-height 180px
            margin 0
          }
        }
      }
      .history-group {
        overflow-y auto
        max-height 120px
        .history {
          margin 0
          line-height 28px
        }
      }
    }
}
.required {
  &::before {
    content: "*";
    color: #ff4949;
    margin-right: 4px;
  }
}
.w-full {
    width 100%
}
</style>
