<template>
  <div class="apply-container">
    <el-card style="margin-top:20px;height:85vh">
      <div style="margin-bottom: 15px;">
        <el-button type="primary color3" size="mini" @click="submitForm">提交</el-button>
        <el-button type="primary color1" size="mini" @click="handleSave">保存</el-button>
        <el-button type="primary color2" size="mini" @click="handleReset">重置</el-button>
        <el-button type="primary color-cancel" size="mini" @click="handleCancel">取消</el-button>
      </div>
      <el-form ref="applyForm" :inline="true" class="apply-form" :model="infoData" label-width="95px">
        <el-form-item label="车辆类型：" prop="vehicleType" :rules="getRules('车辆类型')">
          <el-select v-model="infoData.vehicleType" class="w200" clearable @change="getCarByCarType">
            <el-option
              v-for="(o,index) in carType"
              :key="index"
              :label="o.categoryName"
              :value="o.categoryCode"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="流程类型：" prop="flowType" :rules="getRules('流程类型')">
          <el-select v-model="infoData.flowType" class="w200" @change="handleChangeFlowType">
            <el-option
              v-for="(o,index) in typeList"
              :key="index"
              :label="o.name"
              :value="o.code"
            />
          </el-select>
        </el-form-item>
        <el-form-item v-if="infoData.vehicleType" key="1" label="车牌号码：" prop="vehicleNo" :rules="getRules('车牌号码')">
          <el-select v-model="infoData.vehicleNo" class="w200" clearable @change="getFixCompany">
            <el-option
              v-for="(o,index) in carNumList"
              :key="index"
              :label="o.vehicleNo"
              :value="o.vehicleNo"
            />
          </el-select>
        <!-- <el-input v-model="infoData.vehicleNo" class="w200" placeholder="请输入" /> -->
        </el-form-item>
        <el-form-item v-if="isweibao" key="2" label="维保单位：" style="margin: 0" prop="fixCompany" :rules="getRules('维保单位')">
          <el-select v-model="infoData.fixCompany" class="w200" clearable @change="handleChangeFixCompany">
            <el-option
              v-for="(o,index) in danweiList"
              :key="index"
              :label="o.comName"
              :value="o.comId"
            />
          </el-select>
        </el-form-item>
        <el-form-item v-if="ischuxian" key="3" label="保险单位：" style="margin: 0" prop="fixCompanyName" :rules="getRules('保险单位')">
          <el-input v-model="infoData.fixCompanyName" class="w200" placeholder="请输入" />
        </el-form-item>
        <el-form-item v-if="ischuxian" key="4" label="出险类型：" prop="insuranceType" :rules="getRules('类型')">
          <el-select v-model="infoData.insuranceType" class="w200" clearable>
            <el-option
              v-for="(o,index) in chuxianTypeList"
              :key="index"
              :label="o.name"
              :value="o.code"
            />
          </el-select>
        </el-form-item>
        <!-- <el-form-item v-if="isbaofei" key="5" label="设备编号：" prop="vehicleNo" :rules="getRules('设备编号','blur')" style="display:block;">
        <el-input v-model="infoData.vehicleNo" resize="none" class="w1040" type="textarea" placeholder="注：多个设备编号以英文状态下的逗号“,”隔开" maxlength="2000" show-word-limit :autosize="{minRows: 5,maxRows: 5}" />
      </el-form-item> -->
        <el-form-item v-if="infoData.flowType" key="6" label="描述：" prop="remarks" :rules="getRules('描述','blur')" style="display:block;">
          <el-input v-model="infoData.remarks" resize="none" style="width: 1515px" type="textarea" placeholder="请输入" maxlength="2000" show-word-limit :autosize="{minRows: 5,maxRows: 5}" />
        </el-form-item>
        <el-form-item v-if="isweibao" label="维保信息：" class="required info_table">
          <div class="button-group">
            <el-button type="default color-default" size="mini" @click="handleAddInfo">增加</el-button>
            <el-button type="default color-default" size="mini" @click="handleRemoveInfo">删除</el-button>
          </div>
          <el-table
            :data="infoData.items"
            class="info-table"
            max-height="320"
            stripe
            border
            show-summary
            :summary-method="getSummaries"
            @selection-change="handleSelectionChange"
          >
            <el-table-column type="selection" width="80" align="center" />
            <el-table-column type="index" width="50" label="序号" align="center" />
            <el-table-column align="center" label="配件名称">
              <template slot-scope="scope">
                <el-form-item class="rule-group" :prop="'items.'+scope.$index+'.fixId'" :rules="getRules('配件名称')">
                  <el-select v-model="scope.row.fixId" clearable @change="getFixItem(scope.row)">
                    <el-option
                      v-for="(o,index) in peijianList"
                      :key="index"
                      :label="o.ports"
                      :value="o.fixId"
                    />
                  </el-select>
                </el-form-item>
              </template>
            </el-table-column>
            <el-table-column align="center" label="维保项目">
              <template slot-scope="scope">
                <el-form-item class="rule-group" :prop="'items.'+scope.$index+'.fixItemId'" :rules="getRules('维修项目')">
                  <el-select v-model="scope.row.fixItemId" clearable filterable allow-create @change="(val) => getPrice(val, scope.row)">
                    <el-option
                      v-for="(o,index) in scope.row.weixiuList"
                      :key="index"
                      :label="o.itemName"
                      :value="o.fixItemId"
                    />
                  </el-select>
                </el-form-item>
              </template>
            </el-table-column>
            <el-table-column align="center" label="参考单价（元）" width="120" :precision="2">
              <template slot-scope="scope">
                <el-form-item class="rule-group" :prop="'items.'+scope.$index+'.shopPrice'" :rules="numberRules('参考单价')">
                  <el-input-number v-model="scope.row.shopPrice" class="w-full" type="number" :controls="false" :precision="2" placeholder="请输入" />
                  <!-- {{ scope.row.shopPrice }} -->
                </el-form-item>
              </template>
            </el-table-column>
            <el-table-column align="center" label="实际单价（元）" width="150" prop="price">
              <template slot-scope="scope">
                <el-form-item class="rule-group" :prop="'items.'+scope.$index+'.price'" :rules="numberRules('实际单价')">
                  <el-input-number v-model="scope.row.price" class="w-full" type="number" :controls="false" :precision="2" placeholder="请输入" @change="(val) =>changeAllCost(val,scope.row)" />
                </el-form-item>
              </template>
            </el-table-column>
            <el-table-column align="center" label="数量" width="120" prop="num">
              <template slot-scope="scope">
                <el-form-item class="rule-group" :prop="'items.'+scope.$index+'.num'" :rules="numberRules('数量')">
                  <el-input-number v-model="scope.row.num" class="w-full" :controls="false" :precision="0" placeholder="请输入" />
                </el-form-item>
              </template>
            </el-table-column>
            <el-table-column align="center" label="参考工时费（元/小时）" width="180">
              <template slot-scope="scope">
                <el-form-item class="rule-group" :prop="'items.'+scope.$index+'.shopHourPrice'" :rules="numberRules('参考工时费')">
                  <el-input-number v-model="scope.row.shopHourPrice" class="w-full" :controls="false" :precision="2" placeholder="请输入" />
                  <!-- {{ scope.row.shopHourPrice }} -->
                </el-form-item>
              </template>
            </el-table-column>
            <el-table-column prop="hourPrice" align="center" label="实际工时费（元/小时）" width="180">
              <template slot-scope="scope">
                <el-form-item class="rule-group" :prop="'items.'+scope.$index+'.hourPrice'" :rules="numberRules('实际工时费')">
                  <el-input-number v-model="scope.row.hourPrice" class="w-full" :controls="false" :precision="2" placeholder="请输入" />
                </el-form-item>
              </template>
            </el-table-column>
            <el-table-column prop="workHour" align="center" label="工时（小时）" width="120">
              <template slot-scope="scope">
                <el-form-item class="rule-group" :prop="'items.'+scope.$index+'.workHour'" :rules="numberRules('工时')">
                  <el-input-number v-model="scope.row.workHour" class="w-full" :controls="false" :precision="2" placeholder="请输入" />
                </el-form-item>
              </template>
            </el-table-column>
            <el-table-column align="center" label="费用（元）" width="130" :show-overflow-tooltip="true" prop="amount">
              <template slot-scope="scope">
                {{ getAllCost(scope.row) }}
              </template>
            </el-table-column>
          </el-table>
        </el-form-item>
        <el-form-item v-if="infoData.flowType" label="温馨提示：">
          <p class="tip">（1）文件支持.rar .zip .doc .docx .pdf .jpg .png；单个文件大小应&lt;=100MB;最少上传1个文件，最多上传20个文件；</p>
          <p v-if="isweibao" class="tip">（2）请按照要求上传维修、保养现场照片以及费用清单相关照片</p>
          <p v-if="ischuxian" class="tip">（2）单方事故需要准备的理赔资料有修车发票、行驶证、驾驶证、原件照片及复印件、索赔申请书、身份证、银行账号。如果涉及到人员伤亡，则还需要准备住院病历，门诊病历，住院发票，用药清单及伤者的身份证等材料；</p>
          <p v-if="ischuxian" class="tip">（3）双方事故需要准备的理赔资料有修车发票、行驶证、驾驶证、原件照片及复印件、索赔申请书、身份证、银行账号、交通事故责任认定书。如果涉及到人员伤亡，需要准备的资料和单方事故相同；</p>
          <p v-if="ischuxian" class="tip">（4）如果涉及到第三方财产理赔，那么除了需要准备上诉资料以外，还需要准备第三方财产损失明细及相关部门的证明；</p>
        </el-form-item>
        <el-form-item v-if="infoData.flowType" label="文件上传：" class="file-label required">
          <el-upload
            ref="uploadFile"
            :limit="20"
            :file-list="infoData.annexs"
            accept=".rar,.zip,.doc,.docx,.pdf,.jpg,.jpeg,.png,.RAR,.ZIP,.DOC,.DOCX,.PDF,.JPG,.JPEG,.PNG"
            action="aaaa"
            :on-preview="handlePicPreview"
            :on-remove="handleFileRemove"
            :on-exceed="handleFileExceed"
            :before-upload="handleFileProgress"
            :http-request="handleChangeAudio"
          >
            <el-button size="mini" type="primary">点击上传</el-button>
          </el-upload>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import { getFixDetail, fixApplyList, getCarList } from '@/api/processManagement'
import { addFileList, removeFileList } from '@/api/public'
import { deepClone } from '@/utils'
import { getCategoryList, getfixCompanyByVehicleNo, getCategoryCodeByVehicleNo } from '@/api/integratedManage'
import { selectFixList, getFixList, getFixItemconfigByFixId } from '@/api/fixProject'
import { mapState } from 'vuex'
export default {
  name: 'ProcessApply',
  data() {
    return {
      infoData: {
        parentOrgCode: '',
        orgCode: '',
        deviceId: '',
        applyId: '',
        flowType: '',
        vehicleNo: '',
        vehicleType: '',
        fixCompany: '',
        remarks: '',
        insuranceType: '',
        items: [],
        annexs: []
      },
      vehicleBrand: '', // 车辆品牌，用于过滤查询车辆
      param: {},
      infoTableData: [],
      applyForm: {},
      multipleSeletcion: [],
      pictureVisible: false,
      pictureUrl: '', // 放大图片地址
      errorFlieList: [], // 故障图片
      costFlieList: [], // 费用清单
      typeList: [],
      danweiList: [],
      daduiList: [],
      zhongduiList: [],
      carNumList: [],
      carType: [],
      peijianList: [],
      chuxianTypeList: [],
      categoryCode: ''
    }
  },
  computed: {
    ...mapState({
      mapData: state => state.user.mapData
    }),
    isweibao: {
      get() {
        return this.infoData.flowType === '1' || this.infoData.flowType === '2'
      },
      set() {}
    },
    ischuxian() {
      return this.infoData.flowType === '3'
    },
    isbaofei() {
      return this.infoData.flowType === '4'
    }
  },
  mounted() {
    const _this = this
    this.setTagsViewTitle()
    _this.getAllCategory()
    _this.chuxianTypeList = _this.mapData.fix_apply_insurance_type
    _this.typeList = _this.mapData.fix_apply_type || []
    // if (_this.typeList.length) _this.infoData.flowType = _this.typeList[0].code
  },
  methods: {
    /**
     * 查询所有车辆类型
     */
    getAllCategory() {
      const _this = this
      const params = {
        categoryCode: '',
        categoryType: '1'
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          _this.carType = res.data
        }
      })
    },
    submitForm() {
      this.$refs.applyForm.validate(valid => {
        if (valid) {
          this.infoData.flowState = 0
          const param = deepClone(this.infoData)
          if (this.infoData.items.length === 0 && this.isweibao) {
            this.$message.warning({
              message: '维保项目信息不能为空!',
              showClose: true
            })
            return
          }
          if (this.infoData.annexs.length === 0) {
            this.$message.warning({
              message: '请添加附件!',
              showClose: true
            })
            return
          }
          param.items.every(item => {
            if (item.fixItemId === item.itemName) {
              item.fixItemId = ''
              return false
            } else return true
          })
          // console.log(param.items)
          fixApplyList(param).then(res => {
            if (res.code === 200) {
              this.$message.success({
                message: '操作成功!',
                showClose: true
              })
              // this.$router.push('/process/manage')
              // this.handleReset()
              const view = this.$route
              this.$store.dispatch('tagsView/delView', view).then(({ visitedViews }) => {
                this.$router.push({ name: 'ProcessManage' })
              })
            }
          })
        }
      })
    },
    handleSave() {
      this.$refs.applyForm.validate(valid => {
        if (valid) {
          if (this.infoData.items.length === 0 && this.isweibao) {
            this.$message.warning({
              message: '维保项目信息不能为空!',
              showClose: true
            })
            return
          }
          if (this.infoData.annexs.length === 0) {
            this.$message.warning({
              message: '请添加附件!',
              showClose: true
            })
            return
          }
          this.infoData.flowState = -1
          const param = deepClone(this.infoData)
          param.items.forEach(o => {
            delete o.weixiuList
          })
          fixApplyList(param).then(res => {
            if (res.code === 200) {
              this.$message.success({
                message: '操作成功!',
                showClose: true
              })
              // this.$router.push('/process/manage')
              // this.handleReset()
              const view = this.$route
              this.$store.dispatch('tagsView/delView', view).then(({ visitedViews }) => {
                this.$router.push({ name: 'ProcessManage' })
              })
            }
          })
        }
      })
    },
    handleReset() {
      this.$refs.applyForm.resetFields()
      this.$refs.uploadFile.clearFiles()
      this.infoData.items = [{
        parts: '',
        itemName: '',
        price: '',
        shopPrice: '',
        shopHourPrice: '',
        num: '',
        hourPrice: '',
        workHour: '',
        amount: ''
      }]
      this.infoData.annexs = []
      this.vehicleBrand = ''
      this.categoryCode = ''
    },
    handleCancel() {
      const view = this.$route
      this.$store.dispatch('tagsView/delView', view).then(({ visitedViews }) => {
        this.$router.push({ name: 'ProcessManage' })
      })
    },
    setTagsViewTitle() {
      const params = this.$route.params
      if (!params.id) return false
      const title = '编辑' + params.applyNumber
      const tempRoute = Object.assign({}, this.$route)
      const route = Object.assign({}, tempRoute, { title })
      this.$store.dispatch('tagsView/updateVisitedView', route)
      this.$nextTick(this.getApplyDetail(params.id))
    },
    /**
    * 查询详情
    */
    getApplyDetail(val) {
      const that = this
      getFixDetail(val).then(res => {
        const obj = res.data
        obj.items.forEach(o => {
          o.weixiuList = []
        })
        this.infoData = obj
        if (this.infoData.flowType === '1' || this.infoData.flowType === '2') {
          this.isweibao = true
          this.danweiList = []
          const param = {
            vehicleType: this.infoData.vehicleType
          }
          // 车牌号码回显
          getCarList(param).then(res => {
            if (res.code === 200) {
              this.carNumList = res.data
            }
          })
          // 维保单位列表回显
          selectFixList(param).then(res => {
            if (res.code === 200) {
              this.danweiList = res.data.rows
            }
          })
          // 配件名称列表回显
          getCategoryCodeByVehicleNo({
            vehicleNo: this.infoData.vehicleNo
          }).then(res => { // 根据车牌号查询型号代码
            const categoryCode = res.data || ''
            that.categoryCode = categoryCode
            that.getFixLists(categoryCode)
          })
          // 维修项目列表回显
          that.infoData.items.forEach(o => {
            const data = {
              fixId: o.fixId
            }
            getFixItemconfigByFixId(data).then(res => {
              if (res.code === 200) {
                o.weixiuList = res.data
              }
            })
          })
        }
      }).catch(err => {
        console.log(err)
      })
    },
    /**
     * 查询车牌号码
     */
    getCarByCarType(val) {
      const param = {
        vehicleType: val
      }
      this.handleChangeFlowType()
      if (!val) return false
      getCarList(param).then(res => {
        if (res.code === 200) {
          this.carNumList = res.data
        }
      }).catch(err => {
        console.log(err)
      })
    },
    /**
     * 流程类型变更
     */
    handleChangeFlowType(val) {
      this.infoData.vehicleNo = ''
      this.infoData.fixCompany = ''
      this.danweiList = []
      this.peijianList = []
      this.infoData.items = []
      this.vehicleBrand = ''
      this.categoryCode = ''
    },
    // 维保单位变更
    handleChangeFixCompany() {},
    /**
     * 查询维保单位列表
     */
    getFixCompany(val) {
      const that = this
      this.danweiList = []
      this.infoData.fixCompany = ''
      this.peijianList = []
      this.infoData.items = []
      const param = {
        vehicleNo: this.infoData.vehicleNo
      }
      that.carNumList.map(item => {
        if (item.vehicleNo === val) {
          that.infoData.deviceId = item.deviceId
        }
      })
      if (!this.infoData.vehicleNo) return false
      // 根据车牌号查询车辆品牌
      getfixCompanyByVehicleNo(param).then(res => {
        const vehicleBrand = res.data || ''
        that.vehicleBrand = vehicleBrand
        const data = {
          vehicleType: this.infoData.vehicleType,
          vehicleBrand
        }
        selectFixList(data).then(res => { // 根据车辆品牌查询维保单位
          if (res.code === 200) {
            this.danweiList = res.data.rows
          }
        }).catch(err => {
          console.log(err)
        })
        getCategoryCodeByVehicleNo(param).then(res => { // 根据车牌号查询型号代码
          const categoryCode = res.data || ''
          that.categoryCode = categoryCode
          that.getFixLists(categoryCode)
        }).catch(err => {
          console.log(err)
        })
      }).catch(err => {
        console.log(err)
      })
    },
    /**
     * 获取维修项目列表
     */
    getFixItem(row) {
      const val = row.fixId
      row.weixiuList = []
      row.fixItemId = ''
      if (!val) return false
      const data = {
        fixId: val
      }
      getFixItemconfigByFixId(data).then(res => {
        if (res.code === 200) {
          row.weixiuList = res.data
        }
      })
    },
    /**
     * 获取配件列表
     */
    getFixLists(categoryCode) {
      const that = this
      const params = {}
      const data = {
        vehicleType: that.infoData.vehicleType,
        vehicleBrand: that.vehicleBrand,
        categoryCode,
        guaranteeType: that.infoData.flowType
      }
      that.peijianList = []
      getFixList({ data, params }).then(res => {
        if (res.code === 200) {
          that.peijianList = res.data.rows
        }
      })
    },
    handleAddInfo() {
      if (this.infoData.items.length > 19) return false
      let ID = 0
      if (this.infoData.items.length > 0) {
        ID = this.infoData.items[this.infoData.items.length - 1].ID + 1
      }
      const obj = {
        fixId: '',
        fixItemId: '',
        itemName: '',
        price: 0.00,
        shopPrice: 0,
        shopHourPrice: 0,
        num: '',
        hourPrice: 0.00,
        workHour: '',
        amount: '',
        weixiuList: [],
        ID
      }
      this.infoData.items.push(obj)
    },
    /**
     * 获取参考单价或参考工时费
     */
    getPrice(vals, row) {
      const val = row.fixItemId
      let obj = {}
      row.weixiuList.every(pj => {
        if (pj.fixItemId === val) {
          obj = pj
          row.itemName = pj.itemName
          return false
        } else {
          row.itemName = vals
          return true
        }
      })
      // row.weixiuList.map(item => {
      //   if (item.fixItemId === val) {
      //     obj = item
      //     row.itemName = item.itemName
      //     console.log('1')
      //     console.log(item.fixItemId, val)
      //   } else if (item.fixItemId !== val) {
      //     row.itemName = vals
      //     console.log('2')
      //     console.log(item.fixItemId, val)
      //   }
      // })
      row.shopPrice = obj.price
      row.shopHourPrice = obj.hourPrice
    },
    handleRemoveInfo() {
      const that = this
      if (that.multipleSeletcion.length === 0) {
        this.$message.warning('请选择要删除的项目！')
        return false
      }
      if (this.infoData.items.length === 1 || this.infoData.items.length === that.multipleSeletcion.length) {
        this.$message.warning('一定要保留一个！')
        return false
      }
      that.multipleSeletcion.forEach(o => {
        that.infoData.items.forEach((k, index) => {
          if (o.ID === k.ID) that.infoData.items.splice(index, 1)
        })
      })
    },
    handleSelectionChange(val) {
      this.multipleSeletcion = val
    },
    /**
     * 移除文件
     */
    handleFileRemove(file, fileList) {
      if (!file.url) return false
      const param = {
        fileUrl: file.url
      }
      removeFileList(param).then(res => {
        console.log(res)
      })
      const _this = this
      _this.infoData.annexs = fileList
    },
    handleFileExceed(file, fileList) {
      this.$message.warning('超出最大上传文件个数！')
    },
    handleFileProgress(file) { // 判断文件大小
      var extName = file.name.substring(file.name.lastIndexOf('.')).toLowerCase()
      var AllUpExt = '.rar|.zip|.doc|.docx|.pdf|.jpg|.jpeg|.png|.RAR|.ZIP|.DOC|.DOCX|.PDF|.JPG|.JPEG|.PNG|'
      if (AllUpExt.indexOf(extName + '|') === -1) {
        this.$message.error('文件格式不正确!')
        return false
      }
      let size = file.size || 0
      size = size / 1024 / 1024
      if (size > 100) {
        this.$message.warning('文件大小不能超出100MB！')
        return false
      }
      // const files = file.file
      // const formParam = new FormData()
      // formParam.append('file', files)
      // addFileList(formParam).then(res => {
      //   if (res.code === 200) {
      //     this.infoData.annexs.push(res.data)
      //   }
      // })
    },
    handlePicPreview(file) {
      this.pictureUrl = file.url
      this.pictureVisible = true
    },
    /**
     * 文件变化触发文件转换方法
     */
    handleChangeAudio(params) {
      const file = params.file
      const formParam = new FormData()
      formParam.append('file', file)
      addFileList(formParam).then(res => {
        if (res.code === 200) {
          this.infoData.annexs.push(res.data)
        }
      })
    },
    getAllCost(row) {
      const count = row.num
      const peijianNow = row.price
      const weixiuNow = row.hourPrice
      const hour = row.workHour
      const amount = count * peijianNow + weixiuNow * hour || 0
      row.amount = amount.toFixed(2)
      return amount.toFixed(2)
    },
    getSummaries(param) {
      const { columns, data } = param
      const sums = []
      columns.forEach((column, index) => {
        if (index === 0) {
          sums[index] = '合计'
          return
        }
        const values = data.map(item => Number(item[column.property]))
        if (column.property === 'amount') {
          sums[index] = values.reduce((prev, curr) => {
            const value = Number(curr)
            if (!isNaN(value)) {
              return prev + curr
            } else {
              return prev
            }
          }, 0)
          sums[index] += '元'
        } else {
          sums[index] = ''
        }
      })
      return sums
    },
    getRules(message, trigger = 'change') {
      return { required: true, message: message + '不能为空！', trigger }
    },
    numberRules(message) {
      const validatePass = (rule, value, callback) => {
        if (value === '' || value === undefined) {
          callback(new Error(message + '不能为空！'))
        } if (parseFloat(value) <= 0) {
          callback(new Error(message + '值大于0'))
        } else {
          callback()
        }
      }
      return { required: true, validator: validatePass, trigger: 'blur' }
    },
    changeAllCost(val, row) {
      this.getAllCost(row)
    }
  }
}
</script>

<style lang="stylus" scoped>
.apply-container {
    padding 0px 20px
}
.apply-form {
    width 100%
    .w200 {
        width 300px
    }
    .w1040 {
        width 1040px
    }
    .info-table {
        width 100%
    }
    .button-group {
        text-align right
    }
}
.tip {
  margin 0
  line-height 36px
}
.w-full {
    width 100%
}
.rule-group {
  padding 20px 0
}
</style>
<style lang="stylus">
.apply-container {
    .apply-form {
        .w1040 {
            .el-input__count {
                right 20px
            }
        }
        .required {
            .el-form-item__label {
                &::before {
                    content: "*";
                    color: #ff4949;
                    margin-right: 4px;
                }
            }
        }
        .file-label {
            display block
        }
        .info-table {
          tbody {
            td {
              /*padding 0*/
            }
          }
        }
    }
    .infoTable {
      tbody {
        td {
          padding 0
        }
      }
    }
}

.apply-container .el-upload-list__item .el-icon-close-tip {
  display none !important
}
.info_table{
  width 88%
}
.info_table .el-form-item__content {
  width 93.7%!important
}
</style>
