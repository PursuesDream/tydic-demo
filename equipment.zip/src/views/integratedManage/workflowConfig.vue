<template>
  <div class="WorkflowConfig-container">
    <el-form ref="editableTabs" :inline="true" class="apply-form" :model="editableTabs" label-width="120px">
      <el-card style="margin-top:5px;padding:0px">
        <div class="baseInfoBox">
          <p class="textTitle">
            <span class="icon-content"><i class=" icon-box baseInfo" /></span>基本信息
          </p>
        </div>
        <div class="textBox">
          <el-form-item label="流程名称：" prop="flowName" :rules="getRules('流程名称')">
            <el-input v-model="editableTabs.flowName" placeholder="请输入" :maxlength="50" />
          </el-form-item>
          <el-form-item label=" 流程类型：" prop="sortId" :rules="getRules('流程类型')">
            <el-select v-model="editableTabs.sortId" clearable>
              <el-option
                v-for="(o,index) in applyTypeList"
                :key="index"
                :label="o.sortName"
                :value="o.sortId"
              />
            </el-select>
          </el-form-item>
          <el-form-item label=" 在用状态：" prop="useState" :rules="getRules('在用状态')">
            <el-select v-model="editableTabs.useState" clearable>
              <el-option
                v-for="(o,index) in statusList"
                :key="index"
                :label="o.name"
                :value="o.code"
              />
            </el-select>
          </el-form-item>
          <el-form-item label=" 流程说明：" prop="remark" :rules="getRules('流程说明')">
            <el-input v-model="editableTabs.remark" style="width:1725px" placeholder="请输入" :maxlength="2000" type="textarea" show-word-limit :autosize="{minRows: 5,maxRows: 5}" />
          </el-form-item>
        </div>
      </el-card>
      <el-card style="margin-top:5px">
        <div class="baseInfoBox">
          <p class="textTitle">
            <span class="icon-content"><i class=" icon-box nodeInfo" /></span>流程配置<el-button type="primary color3" size="mini" style="margin-left:5px" @click="handleAddNode"><i class="image-icon add" />新增</el-button>
          </p>
        </div>
        <div style="height:400px;margin-top:10px;margin-left:38px">
          <el-scrollbar style="height:100%">
            <el-form-item label="">
              <div style="width:1810px">
                <div class="tabBox">
                  <div v-for="(node,flag) in editableTabs.items" :key="flag" style="margin-bottom:15px">
                    <table width="100%" border="1" cellspacing="0" cellpadding="0" class="nodeTable">
                      <tr height="40">
                        <td style="width:200px;background-color:#EBF5FF;text-align:center"><span>节点名称</span></td>
                        <td colspan="2" style="background-color:#EBF5FF;text-align:center"><span>节点</span></td>
                        <td style="width:200px;background-color:#EBF5FF;text-align:center"><span>操作</span></td>
                      </tr>
                      <tr>
                        <td height="255" rowspan="4" style="width:200px;text-align:center"><span>节点{{ flag+ 1 }}</span></td>
                        <td style="width: 200px">
                          <p class="nodeRequired">节点名称</p>
                        </td>
                        <td>
                          <div style="height:48px;padding-left: 10px;">
                            <el-form-item label="" :prop="'items.'+flag+'.procesName'" :rules="getRules('节点名称')">
                              <span style="margin-left:3px">
                                <el-input v-model="node.procesName" placeholder="请输入节点名称" :maxlength="50" style="width:1420px">
                                  <i slot="prefix" class="el-icon-edit el-input__icon" />
                                </el-input>
                              </span>
                            </el-form-item>
                          </div>
                        </td>
                        <td rowspan="4">
                          <p style="text-align:center">
                            <el-button type="text" size="mini" @click="handleDeleteNode(flag)">删除</el-button>
                          </p>
                        </td>
                      </tr>
                      <tr>
                        <td width="110">
                          <p class="nodeRequired">节点类型</p>
                        </td>
                        <td>
                          <div style="height:48px;padding-left: 10px;">
                            <el-form-item label="" :prop="'items.'+flag+'.type'" :rules="getRules('节点类型')">
                              <div>
                                <span>
                                  <el-radio-group v-model="node.type" @change="(val) =>{changeNodeType(val,flag)}">
                                    <el-radio v-for="(obj,code) in typeList" :key="code" :label="obj.code" :disabled="code===1 && flag === 0 || code===0 && flag !== 0 ">{{ obj.name }}</el-radio>
                                  </el-radio-group>
                                </span>
                              </div>
                            </el-form-item>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td width="110" rowspan="2">
                          <p class="nodeRequired">节点操作人</p>
                        </td>
                        <td>
                          <div style="height:48px;float:left;border-right: 1px solid #ccc;padding:5px 5px 0 10px;">
                            <el-form-item label="" :prop="'items.'+flag+'.procesType'" :rules="getRules('节点操作人')">
                              <div>
                                <el-radio-group v-model="node.procesType" @change="(val) =>{changeProcesType(flag)}">
                                  <el-radio v-for="(obj,code) in procesTypeList" :key="code" :label="obj.code">{{ obj.name }}</el-radio>
                                </el-radio-group>
                                <!-- <el-radio v-model="node.procesType" label="0">按角色</el-radio>
                                <el-radio v-model="node.procesType" label="1">按用户</el-radio> -->
                              </div>
                            </el-form-item>
                          </div>
                          <div style="margin-left:10px; float: left;padding: 5px 0 0 10px">
                            <el-form-item label="" :prop="'items.'+flag+'.oragnObj.flowDept'" :rules="getRules('所属机构')">
                              <span class="required">所属机构：</span>
                              <OragnTree :select-object="node.oragnObj" :select-value="'flowDept'" :is-no-edit="'isNoEdit'" :default-name="'flowDeptName'" @sendOrgcode="code =>{ sendOrgcode(code, flag) }" />
                            </el-form-item>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td style="line-height:0px;height:120px;padding:0">
                          <div style="margin-left:10px;">
                            <div>
                              <div v-if="node.procesType === '0'" style="" class="content100">
                                <el-form-item label="" :prop="'items.'+flag+'.procesPriv'" :rules="getRules('角色')">
                                  <!-- <el-scrollbar style="height:100%"> -->
                                  <el-radio-group v-model="node.procesPriv">
                                    <el-radio v-for="(obj,code) in node.roleList" :key="code" :label="obj.roleId">{{ obj.roleName }}</el-radio>
                                  </el-radio-group>
                                  <!-- </el-scrollbar> -->
                                </el-form-item>
                              </div>
                              <div v-if="node.procesType === '1'" style="" class="content100">
                                <el-form-item :prop="'items.'+flag+'.procesUsr'" label="" :rules="getRules('用户')">
                                  <!-- <el-scrollbar style="height:100%"> -->
                                  <el-checkbox-group v-model="node.procesUsr">
                                    <el-checkbox v-for="(obj,code) in node.useList" :key="code" :label="obj.userId">{{ obj.userName }}</el-checkbox>
                                  </el-checkbox-group>
                                  <!-- </el-scrollbar> -->
                                </el-form-item>
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>

                    </table>
                  </div>
                </div>
              </div>
            </el-form-item>
          </el-scrollbar>
        </div>
      </el-card>
    </el-form>
    <div style="float:right;margin: 10px 0px">
      <el-button type="primary color3" size="mini" @click="submitForm">提交</el-button>
      <el-button type="primary color2" size="mini" @click="handleReset">重置</el-button>
      <el-button type="primary color-cancel" size="mini" @click="handleCancel">取消</el-button>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { getFlowDetail, getTypeList, addFlowInfo, editFlowInfo } from '@/api/flowConfig'
import { getUseOrganList, getPoliceList, getRoleList } from '@/api/public'
import OragnTree from '@/components/oragneTree'
import { deepClone } from '@/utils'
export default {
  name: 'WorkflowConfig',
  components: {
    OragnTree
  },
  data() {
    return {
      applyConfigForm: {
        flowName: '',
        sortId: '',
        useState: '',
        remark: ''
      },
      checkList: [],
      radio: '',
      changeRadio: '',
      editableTabsValue: '1',
      editableTabs: {
        flowName: '',
        sortId: '',
        useState: '',
        remark: '',
        items: [
          {
            procesName: '',
            procesType: '',
            procesUsr: [], // 用户
            procesDept: '',
            oragnObj: {
              flowDept: '',
              flowDeptName: '',
              isNoEdit: false
            },
            type: '0',
            procesPriv: '', // 角色
            roleList: [],
            useList: []
          }
        ]
      },
      procesTypeList: [
        { name: '按角色', code: '0' },
        { name: '按用户', code: '1' }
      ],
      typeList: [
        { name: '发起', code: '0' },
        { name: '审批', code: '1' }
      ],
      organNodeIndex: 0,
      isInfoEdit: false,
      useArr: [],
      tabIndex: 1,
      orgCode: '',
      statusList: [],
      applyTypeList: [],
      titleValue: '',
      userOrg: {
        flowDept: '',
        flowDeptName: ''
      }
    }
  },
  computed: {
    ...mapState({
      mapData: state => state.user.mapData
    })
  },
  watch: {
    orgCode(val) {
      if (val) {
        const param = {
          organCode: val
        }
        this.editableTabs.items[this.organNodeIndex].procesDept = val
        getPoliceList(param).then(res => {
          if (res.code === 200) {
            this.editableTabs.items[this.organNodeIndex].useList = res.data
          }
        })
        getRoleList(param).then(res => {
          if (res.code === 200) {
            this.editableTabs.items[this.organNodeIndex].roleList = res.data
          }
        })
      }
    }
  },
  mounted() {
    this.statusList = this.mapData.flow_use_state || []
    // this.getOrganList()
    const userObj = JSON.parse(sessionStorage.getItem('userInfo'))
    this.userOrg.flowDept = userObj.organCode
    this.userOrg.flowDeptName = userObj.organName
    this.getApplyTypeList()
    this.setTagsViewTitle()
  },
  methods: {
    setTagsViewTitle() {
      const id = this.$route && this.$route.params.id
      if (!id) {
        this.changeNodeType('0', 0)
        return false
      }
      // const title = '流程配置编辑 - ' + this.$route.params.id
      const title = '流程配置编辑'
      this.isInfoEdit = true
      const tempRoute = Object.assign({}, this.$route)
      const route = Object.assign({}, tempRoute, { title })
      this.$store.dispatch('tagsView/updateVisitedView', route)
      this.$nextTick(_ => {
        this.getApplyDetail(id)
      })
    },
    getRules(message, trigger = 'change') {
      return { required: true, message: message + '不能为空！', trigger }
    },
    /**
     * 查询所有流程分类
     */
    getApplyTypeList() {
      getTypeList({}).then(res => {
        if (res.code === 200) {
          this.applyTypeList = res.rows
        }
      })
    },
    /**
     * 查询有效状态的机构
     */
    getOrganList() {
      const param = {
        organCode: '-1'
      }
      getUseOrganList(param).then(res => {
        if (res.code === 200) {
          console.log(res)
        }
      })
    },
    /**
     * 流程节点类型
     */
    changeNodeType(val, index) {
      this.organNodeIndex = index
      if (val === '0') {
        this.changeRadio = index
        const oragnObj = {
          flowDept: this.userOrg.flowDept,
          flowDeptName: this.userOrg.flowDeptName,
          isNoEdit: true
        }
        this.editableTabs.items[index].oragnObj = oragnObj
        this.organNodeIndex = index
        this.orgCode = this.userOrg.flowDept
      } else if (val === '1') {
        this.changeRadio = ''
        const oragnObj = {
          flowDept: '',
          flowDeptName: '',
          isNoEdit: false
        }
        this.editableTabs.items[index].oragnObj = oragnObj
      }
    },
    changeProcesType(index) {
      const organCode = this.editableTabs.items[index].oragnObj.flowDept
      if (!organCode) return false
      const param = {
        organCode
      }
      this.editableTabs.items[index].procesDept = organCode
      getPoliceList(param).then(res => {
        if (res.code === 200) {
          this.editableTabs.items[index].useList = res.data
        }
      })
      getRoleList(param).then(res => {
        if (res.code === 200) {
          this.editableTabs.items[index].roleList = res.data
        }
      })
      this.editableTabs.items[index].procesPriv = ''
      this.editableTabs.items[index].procesUsr = []
    },
    /**
     *选择所属机构
     */
    sendOrgcode(data, index) {
      if (data && data !== 'clear') {
        console.log(data)
        this.orgCode = data
        this.organNodeIndex = index
      } else if (data === 'clear') {
        this.changeProcesType(index)
        this.orgCode = ''
        this.editableTabs.items[index].roleList = []
        this.editableTabs.items[index].useList = []
      }
    },
    /**
     * 查询流程详情
     */
    getApplyDetail(val) {
      const _this = this
      getFlowDetail(val).then(res => {
        const result = res.data
        result.items.map((item, index) => {
          item.roleList = []
          item.useList = []
          item.oragnObj = {
            flowDept: item.procesDept,
            isNoEdit: false,
            flowDeptName: item.procesDeptName
          }
          if (item.type === '0') {
            item.oragnObj.isNoEdit = true
            this.changeRadio = index
          } else {
            item.oragnObj.isNoEdit = false
          }
          const param = {
            organCode: item.procesDept
          }
          if (item.procesType === '0') { // 按角色
            getRoleList(param).then(res => {
              if (res.code === 200) {
                item.roleList = res.data
              }
            })
          } else if (item.procesType === '1') {
            item.procesUsr = item.procesUsr.split(',')
            getPoliceList(param).then(res => {
              if (res.code === 200) {
                item.useList = res.data
              }
            })
          }
        })
        _this.editableTabs = result
      }).catch(err => {
        console.log(err)
      })
    },
    /**
     * 保存流程
     */
    submitForm() {
      this.$refs.editableTabs.validate(valid => {
        if (valid) {
          let submitFun = ''
          if (this.isInfoEdit) {
            submitFun = editFlowInfo
          } else {
            submitFun = addFlowInfo
          }
          const param = deepClone(this.editableTabs)
          let hasType0 = false // 是否含有发起类型
          param.items.forEach(item => {
            delete item.roleList
            delete item.useList
            item.procesUsr = item.procesUsr.toString()
            item.flowDept = item.oragnObj.flowDept
            item.flowDeptName = item.oragnObj.flowDeptName
            delete item.oragnObj
            if (item.type === '0') hasType0 = true
          })
          if (!hasType0) {
            this.$message.warning({
              message: '节点类型必须有一个为发起！',
              showClose: true
            })
            return false
          }
          submitFun(param).then(res => {
            if (res.code === 200) {
              if (res.code === 200) {
                this.$message.success({
                  message: '操作成功!',
                  showClose: true
                })
                const view = this.$route
                this.$store.dispatch('tagsView/delView', view).then(({ visitedViews }) => {
                  this.$router.push({ name: 'WorkflowManage' })
                })
              }
            }
          })
        }
      })
    },
    /**
     * 流程重置
     */
    handleReset() {
      this.editableTabs = {
        flowName: '',
        sortId: '',
        useState: '',
        remark: '',
        items: [
          {
            procesName: '',
            procesType: '',
            procesUsr: [], // 用户
            type: '1',
            oragnObj: {
              flowDept: '',
              flowDeptName: '',
              isNoEdit: false
            },
            procesDept: '',
            procesPriv: '', // 角色
            roleList: [],
            useList: []
          }
        ]
      }
      this.$refs.editableTabs.resetFields()
    },
    /**
     * 取消操作
     */
    handleCancel() {
      const view = this.$route
      this.$store.dispatch('tagsView/delView', view).then(({ visitedViews }) => {
        this.$router.push({ name: 'WorkflowManage' })
      })
    },
    /**
     * 新增节点
     */
    handleAddNode() {
      const obj = {
        procesName: '',
        procesType: '',
        sortId: '',
        procesUsr: [],
        procesDept: '',
        oragnObj: {
          isNoEdit: false,
          flowDept: '',
          flowDeptName: ''
        },
        type: '1',
        procesPriv: '',
        roleList: [],
        useList: []
      }
      this.editableTabs.items.push(obj)
    },
    /**
     * 删除节点
     */
    handleDeleteNode(index) {
      if (this.editableTabs.items.length === 1) {
        this.$message.warning('只剩一个不能删除！')
        return false
      }
      this.editableTabs.items.splice(index, 1)
    },
    /**
     * 编辑节点名称保存
     */
    changeName(item, index) {
      const editName = this.titleValue
      this.titleValue = ''
      this.editableTabs[index].name = editName
      this.editableTabs[index].isEdit = false
      this.editableTabsValue = this.editableTabs[index].name
    },
    /**
     *编辑tab
     */
    handleEdit(value, index) {
      this.editableTabs[index].isEdit = true
      this.titleValue = value.name
      console.log(value)
    },
    handleTabsEdit(targetName, action) {
      if (action === 'add') {
        const newTabName = ++this.tabIndex + ''
        const obj = {
          title: '1',
          name: '分组' + newTabName,
          nodeCode: 'new',
          isEdit: false,
          nodeList: [
            {
              nodeName: '',
              nodeType: '',
              nodeAction: [],
              nodeUser: '',
              orgcode: '',
              role: []
            }
          ]
        }
        this.editableTabs.push(obj)
        this.editableTabsValue = '分组' + newTabName
      }
      if (action === 'remove') {
        const tabs = this.editableTabs
        let activeName = this.editableTabsValue
        if (activeName === targetName) {
          tabs.forEach((tab, index) => {
            if (tab.name === targetName) {
              const nextTab = tabs[index + 1] || tabs[index - 1]
              if (nextTab) {
                activeName = nextTab.name
              }
            }
          })
        }
        this.editableTabsValue = activeName
        this.editableTabs = tabs.filter(tab => tab.name !== targetName)
      }
    }
  }
}
</script>

<style lang="stylus" scoped>
/deep/ .el-radio__inner{
  border: 1px solid black!important
}
/deep/.el-checkbox__inner{
  border: 1px solid black!important
}
.el-radio__input.is-disabled + span.el-radio__label{
  color: black!important
}
.WorkflowConfig-container {
  padding 0 20px
  .textTitle {
    // color #3274e1
    // font-size 25px
    // font-weight bold
    margin-top 0px
    border-bottom 1px solid #ebebeb
  }
  .nodeTable{
    border: 1px solid #E1E1E1
    tr{
      border: 1px solid #E1E1E1
    }
    td{
      border: 1px solid #E1E1E1
    }
  }
  .icon-content{
      display:inline-block
      vertical-align: middle
      width: 40px;
      line-height: 40px;
      height: 40px;
      background: #3699FF;
      border-radius: 0px 14px 0px 0px;
      margin-right:10px
    }
    .icon-box{
      display:inline-block
      vertical-align: middle
      width: 17px;
      height: 18px;
      margin-left: 10px;
      &.baseInfo {
        background-image url('~@/assets/icons/icon_49.png')
      }
       &.nodeInfo {
          width: 20px;
        background-image url('~@/assets/icons/applyIcon.png')
      }
    }
  .input-class-2 {
    width 250px
  }
  .baseInfoBox{
    margin-bottom 10px
  }
   /deep/ .el-scrollbar__wrap{
      overflow-x: auto!important
    }
    /deep/ .el-card__body{
      padding:0px
    }
  .tydic-box {
    padding 30px 0 10px
  }
  .w200 {
    width 200px
  }
  .w180 {
    width 180px
  }
  .w140 {
    width 140px
  }
  .w-full {
    width 100%
  }
  .nodeRequired{
    text-align center
    &::before {
        content: "*";
        color: #ff4949;
        margin-right: 4px;
    }
  }
}
</style>
<style lang="stylus">
.WorkflowConfig-container {
  .content100 {
    .el-form-item,.el-form-item__content,.el-form-item__error {
      width 100%
    }
  }
}

</style>

