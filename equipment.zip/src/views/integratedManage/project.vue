<template>
  <div class="project-container">
    <el-card style="margin-top:20px;height:85vh">
      <div>
        <div>
          <!-- <el-card> -->
          <div class="tydic-box">
            <div class="tydic-input">
              车辆类型：
              <el-select v-model="formData.vehicleType" placeholder="请选择" clearable @change="(val) =>getLxList(val,1)">
                <el-option
                  v-for="(o,index) in carType"
                  :key="index"
                  :label="o.categoryName"
                  :value="o.categoryCode"
                />
              </el-select>
            </div>
            <div class="tydic-input">
              车辆品牌：
              <el-select v-model="formData.vehicleBrand" placeholder="请选择" clearable @change="(val) =>getPpList(val,1)">
                <el-option
                  v-for="(o,index) in pinpaiList"
                  :key="index"
                  :label="o.categoryName"
                  :value="o.categoryCode"
                />
              </el-select>
            </div>
            <div class="tydic-input">
              维保类型：
              <el-select v-model="formData.guaranteeType" placeholder="请选择" clearable>
                <el-option
                  v-for="(o,index) in wbList"
                  :key="index"
                  :label="o.name"
                  :value="o.code"
                />
              </el-select>
            </div>
            <div class="tydic-input">
              配件名称：
              <el-input v-model="formData.ports" placeholder="请输入" />
            </div>
            <div class="tydic-input" style="float:right">
              <el-button type="primary search" size="mini" @click="onSearch"><i class="image-icon search" />查询</el-button>
              <el-button type="primary reset" size="mini" @click="onReset"><i class="image-icon reset" />重置</el-button>
            </div>
            <div>
              <el-button v-permission="'button30'" class="m-b-15" type="primary color3" size="mini" @click="handleAdd"><i class="image-icon add" />新增</el-button>
              <el-button v-permission="'button31'" class="m-b-15" type="primary color6" size="mini" @click="onDel('all')"><i class="image-icon delete" />删除</el-button>
              <el-button v-permission="'button33'" class="m-b-15" type="primary color4" size="mini" @click="onImport"><i class="image-icon import" />导入</el-button>
              <el-button v-permission="'button34'" class="m-b-15" type="primary color5" size="mini" @click="onOutput"><i class="image-icon export" />导出</el-button>
            </div>
            <div v-loading="isLoading" class="table-box">
              <el-table
                :data="tableData"
                class="custom-table"
                stripe
                border
                header-row-class-name="custom-table-header"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="55" />
                <el-table-column align="center" type="index" label="序号" width="100" :show-overflow-tooltip="true">
                  <template slot-scope="scope">
                    {{ scope.$index + 1 + pageSize * (curPage - 1) }}
                  </template>
                </el-table-column>
                <el-table-column
                  prop="ports"
                  align="center"
                  label="配件名称"
                  :show-overflow-tooltip="true"
                />
                <el-table-column align="center" prop="vehicleType" label="车辆类型" />
                <el-table-column align="center" prop="vehicleBrand" label="车辆品牌" />
                <el-table-column
                  prop="categoryCodeName"
                  align="center"
                  label="车辆型号"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="guaranteeExpire"
                  align="center"
                  label="保修期限"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  align="center"
                  label="维保类型"
                  :show-overflow-tooltip="true"
                >
                  <template slot-scope="scope">
                    {{ getVehicleBrand(scope.row.guaranteeType,'wbList') }}
                  </template>
                </el-table-column>
                <el-table-column align="center" label="操作">
                  <template slot-scope="scope">
                    <el-button
                      v-permission="'button32'"
                      type="text"
                      size="small"
                      @click="handleEdit(scope.row)"
                    >编辑</el-button>
                    <el-button
                      v-permission="'button31'"
                      type="text"
                      size="small"
                      @click="onDel(scope.row.fixId)"
                    >删除</el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <!-- @current-change="handleCurrentChange" -->
          <div style="text-align: center">
            <el-pagination
              ref="pagination"
              style="text-align: center;margin-top:30px;"
              background
              :page-size="pageSize"
              :total="total"
              :current-page.sync="curPage"
              :page-sizes="[5, 10, 20, 30]"
              layout="total, prev, pager, next, jumper"
              @size-change="sizerChange"
              @current-change="curPageChange"
            />
          </div>
          <!-- 新增编辑弹框 -->
          <el-dialog :title="formTitle" :visible.sync="formVisible" width="735px" custom-class="custom-dialog" :close-on-click-modal="false" :colse-on-press-escape="false" @close="handleDialogClose">
            <el-form ref="addDataForm" :model="addDataForm" :inline="true" label-width="92px">
              <el-form-item label="车辆类型：" prop="vehicleType" :rules="getRules('车辆类型','change')">
                <el-select v-model="addDataForm.vehicleType" clearable size="mini" placeholder="请选择" class="w240" @change="(val) =>getLxList(val,2)">
                  <el-option
                    v-for="(o,index) in carType"
                    :key="index"
                    :label="o.categoryName"
                    :value="o.categoryCode"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="车辆品牌：" class="mr0" prop="vehicleBrand" :rules="getRules('车辆品牌','change')">
                <el-select v-model="addDataForm.vehicleBrand" placeholder="请选择" size="mini" class="w240" clearable @change="(val) =>getPpList(val,2)">
                  <el-option
                    v-for="(o,index) in pinpaiList2"
                    :key="index"
                    :label="o.categoryName"
                    :value="o.categoryCode"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="型号选择：" prop="categoryCode" :rules="getRules('型号选择','change')">
                <el-select v-model="addDataForm.categoryCode" placeholder="请选择" size="mini" class="w240" clearable>
                  <el-option
                    v-for="(o,index) in xhList2"
                    :key="index"
                    :label="o.categoryName"
                    :value="o.categoryCode"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="维保类型：" class="mr0" prop="guaranteeType" :rules="getRules('维保类型','change')">
                <el-select v-model="addDataForm.guaranteeType" placeholder="请选择" size="mini" class="w240" clearable>
                  <el-option
                    v-for="(o,index) in wbList"
                    :key="index"
                    :label="o.name"
                    :value="o.code"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="配件名称：" prop="ports" :rules="getRules('配件名称')">
                <el-input v-model="addDataForm.ports" maxlength="50" size="mini" type="text" placeholder="请输入" class="w240" />
              </el-form-item>
              <el-form-item label="保修期限：" class="mr0" prop="guaranteeExpire" :rules="getRules('保修期限')">
                <el-input v-model="addDataForm.guaranteeExpire" maxlength="50" size="mini" placeholder="请输入" class="w240" />
              </el-form-item>

              <div style="width: 99%">
                <div class="button-group">
                  <el-button type="primary color3" size="mini" @click="handleAddInfo"><i class="image-icon add" />添加</el-button>
                </div>
                <el-table
                  :data="addDataForm.itemList"
                  class="info-table"
                  max-height="200"
                  stripe
                  border
                >
                  <el-table-column type="index" width="50" label="序号" align="center" />
                  <el-table-column align="center" prop="itemName" label="项目名称">
                    <template slot-scope="scope">
                      <el-form-item class="rule-group" :prop="'itemList.'+scope.$index+'.itemName'" :rules="getRules('项目名称')">
                        <el-input
                          v-model="scope.row.itemName"
                          maxlength="50"
                          show-word-limit
                          clearable
                          class="w-full"
                          placeholder="请输入"
                        />
                      </el-form-item>
                    </template>
                  </el-table-column>
                  <el-table-column align="center" label="参考单价（元）" width="160">
                    <template slot-scope="scope">
                      <el-form-item class="rule-group" :prop="'itemList.'+scope.$index+'.price'" :rules="numberRules('参考单价')">
                        <el-input-number
                          v-model="scope.row.price"
                          class="w-full"
                          type="number"
                          :controls="false"
                          :precision="2"
                          clearable
                          placeholder="请输入"
                        />
                      </el-form-item>
                    </template>
                  </el-table-column>
                  <el-table-column align="center" label="参考工时费（元/小时）" width="160">
                    <template slot-scope="scope">
                      <el-form-item class="rule-group" :prop="'itemList.'+scope.$index+'.hourPrice'" :rules="numberRules('参考工时费')">
                        <el-input-number v-model="scope.row.hourPrice" class="w-full" type="number" :controls="false" :precision="2" placeholder="请输入" />
                      </el-form-item>
                    </template>
                  </el-table-column>
                  <el-table-column align="center" label="操作" width="80" :show-overflow-tooltip="true" prop="amount">
                    <template slot-scope="scope">
                      <el-button type="text" size="mini" @click="handleRemoveInfo(scope.row,scope.$index)">删除</el-button>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
            </el-form>
            <div style="text-align: center;margin-top:10px">
              <el-button type="primary color1" size="mini" @click="handleDialogSubmit">保存</el-button>
              <el-button type="primary color2" size="mini" @click="handleDialogReset">重置</el-button>
              <el-button type="primary color-cancel" size="mini" @click="cancelAdd">取消</el-button>
            </div>
          </el-dialog>
          <!-- 导入 -->
          <el-dialog v-loading="isLoadingUp" element-loading-text="导入中" width="500px" custom-class="custom-dialog" title="导入" :visible.sync="importDialog" :close-on-click-modal="false" :colse-on-press-escape="false" @close="cancelImport">
            <el-form v-if="isImport">
              <el-form-item label="">
                导入前，请先<el-button type="text" @click="downTemplete">下载模板</el-button>并阅读模板内的导入须知
              </el-form-item>
              <el-form-item label="上传文件：">
                <el-upload
                  ref="upload"
                  class="tydic-file-upload"
                  accept=".xls,.xlsx"
                  action=""
                  :limit="1"
                  :http-request="httpRequest"
                  :on-change="fileChange"
                  :file-list="fileList"
                  :auto-upload="false"
                >
                  <el-button slot="trigger" size="small" type="success">选取文件</el-button>
                  <div slot="tip" class="el-upload__tip" style="display: inline-block;margin-left: 20px">只能上传xls、xlsx格式的 excel文件</div>
                </el-upload>
              </el-form-item>
              <el-form-item label="上传文件：">
                支持.xls，.xlsx文件格式
              </el-form-item>
            </el-form>
            <el-form v-else>
              <el-form-item label="">
                <p class="tips">导入提示：{{ responseMsg.msg }}</p>
              </el-form-item>
              <el-form-item label="">
                <p class="tips">失败数据：<span v-if="responseMsg.fileName" style="color:#1890ff;cursor:pointer" @click="downloadErrfile(1)">{{ responseMsg.fileName }}</span><span v-else style="color:#1890ff;">无</span></p>
              </el-form-item>
              <el-form-item label="">
                <p class="tips">错误详情：<span v-if="responseMsg.fileName" style="color:#1890ff;cursor:pointer" @click="downloadErrfile(2)">{{ responseMsg.fileName }}</span><span v-else style="color:#1890ff;">无</span></p>
              </el-form-item>
            </el-form>
            <div style="text-align: center;margin-top: 10px;">
              <el-button v-if="isImport" type="primary color-commit" size="mini" @click="onImportFile">导入</el-button>
              <el-button v-else type="primary color-commit" size="mini" @click="continueImport"> 继续导入</el-button>
              <el-button type="primary color-cancel" size="mini" @click="cancelImport">取消</el-button>
            </div>
          </el-dialog>
        <!-- </el-card> -->
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { importProjectList, exportProjectList, getFixList, delFixList, updateFixList, selectFixList, getFixDetail, downloadFixItemconfigTemplate } from '@/api/fixProject'
import { getCategoryList } from '@/api/integratedManage'
import { delErr, downloadImportDetail } from '@/api/car'
import { deepClone } from '@/utils'
// import axios from 'axios'
const emptyForm = {
  vehicleType: '',
  vehicleBrand: '',
  categoryCode: '',
  guaranteeType: '',
  ports: '',
  guaranteeExpire: '',
  itemList: [
    { itemName: '', price: '', hourPrice: '' }
  ]
}
export default {
  name: 'Project',
  data() {
    return {
      isLoading: false,
      responseMsg: {},
      isImport: true,
      carType: [],
      pinpaiList: [],
      pinpaiList2: [],
      xhList: [],
      isEditForm: false,
      xhList2: [],
      showCarName: false,
      showCarNum: false,
      formData: {
        vehicleType: '',
        vehicleBrand: '',
        guaranteeType: '',
        ports: ''
      },
      oldFormData: null,
      wbList: [],
      multipleSelection: [],
      curPage: 1,
      pageSize: 10,
      total: 0,
      pageSizes: [5, 10, 20, 30],
      daduiList: [
        { name: '龙岗大队', value: '1' },
        { name: '罗湖大队', value: '2' },
        { name: '福田大队', value: '3' }
      ],
      dwList: [],
      statusList: [
        { name: '全部', value: '1' },
        { name: '铁骑', value: '2' },
        { name: '警用车', value: '3' }
      ],
      checkedTimeArr: [],
      tableData: [],
      fileList: [],
      formTitle: '',
      formVisible: false,
      importDialog: false,
      addDataForm: {
        vehicleType: '',
        vehicleBrand: '',
        categoryCode: '',
        guaranteeType: '',
        ports: '',
        guaranteeExpire: '',
        itemList: [
          { itemName: '', price: '', hourPrice: '' }
        ]
      },
      isLoadingUp: false // 正在导入中
    }
  },
  computed: {
    ...mapState({
      mapData: state => state.user.mapData
    })
  },
  mounted() {
    const _this = this
    _this.getFixLists()
    _this.getAllCategory()
    _this.wbList = _this.mapData.guarantee_type
  },
  methods: {
    /**
     * 查询所有车辆类型
     */
    getAllCategory() {
      const _this = this
      const params = {
        categoryCode: '',
        categoryType: '1'
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          _this.carType = res.data
        }
      })
    },
    /**
     * 根据车辆类型查询车辆品牌
     */
    getLxList(val, id, cb) {
      const _this = this
      const params = {
        categoryCode: val,
        categoryType: '1'
      }
      if (!val) {
        if (id === 1) {
          _this.pinpaiList = []
          _this.xhList = []
          _this.formData.vehicleBrand = ''
        } else if (id === 2) {
          _this.pinpaiList2 = []
          _this.xhList2 = []
          _this.dwList = []
          _this.addDataForm.vehicleBrand = ''
          this.addDataForm.categoryCode = ''
        }
        return
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          if (id === 1) {
            this.pinpaiList = []
            _this.formData.vehicleBrand = ''
            _this.pinpaiList = res.data
          } else if (id === 2) {
            this.pinpaiList2 = []
            _this.xhList2 = []
            _this.dwList = []
            _this.pinpaiList2 = res.data
            if (_this.showCarName) {
              _this.showCarName = false
            } else {
              this.addDataForm.vehicleBrand = ''
              this.addDataForm.categoryCode = ''
            }
          }
          if (cb) cb()
        }
      })
    },
    /**
     * 根据车辆品牌查询车辆型号
     */
    getPpList(val, id) {
      const _this = this
      const params = {
        categoryCode: val,
        categoryType: '1'
      }
      if (!val) {
        if (id === 2) {
          _this.xhList2 = []
          _this.dwList = []
          this.addDataForm.categoryCode = ''
        }
        return
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          if (id === 1) {
            _this.xhList = res.data
          } else if (id === 2) {
            _this.xhList2 = []
            _this.xhList2 = res.data
            _this.propertyList()
            if (_this.showCarNum) {
              _this.showCarNum = false
            } else {
              this.addDataForm.categoryCode = ''
            }
          }
        }
      })
    },
    /**
    * 条件查询
    */
    onSearch() {
      const _this = this
      this.oldFormData = null
      _this.curPage = 1
      _this.getFixLists()
    },
    /**
     * 获取维保项目列表
     */
    getFixLists() {
      const _this = this
      let data = {}
      if (this.oldFormData) {
        data = { ...this.oldFormData }
      } else {
        data = { ...this.formData }
        this.oldFormData = { ...data }
      }
      const params = {
        pageSize: _this.pageSize,
        pageNum: _this.curPage
      }
      _this.isLoading = true
      getFixList({ data, params }).then(res => {
        if (res.code === 200) {
          _this.isLoading = false
          _this.tableData = res.data.rows
          _this.total = res.data.total
        }
      }).catch(_ => {
        _this.isLoading = false
      })
    },
    /**
     * 新增修改时根据车辆类型、车辆品牌过滤出价值维保单位
     */
    propertyList() {
      const _this = this
      const params = {
        vehicleType: _this.addDataForm.vehicleType,
        vehicleBrand: _this.addDataForm.vehicleBrand
      }
      selectFixList(params).then(res => {
        if (res.code === 200) {
          _this.dwList = res.data.rows
        }
      })
    },
    // 必须是数字且小数位数最多2位
    is2Num(num) {
      var reg = /^(-?\d+)(\.\d{1,2})?$/
      if (reg.test(num)) {
        return true
      } else {
        return false
      }
    },
    /**
     * 获取表格选中数据
     */
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    /**
    * 查看详情
    */
    handleDetail(row) {
      const _this = this
      _this.formVisible = true
      _this.formTitle = '维保项目信息详情'
    },
    handleDialogReset() {
      this.addDataForm = deepClone(emptyForm)
      this.$refs.addDataForm.resetFields()
      this.xhList2 = []
      this.pinpaiList2 = []
    },
    cancelAdd() {
      this.formVisible = false
      this.handleDialogReset()
    },
    handleDialogClose() {
      this.handleDialogReset()
    },
    getRules(message, trigger = 'blur') {
      return { required: true, message: message + '不能为空！', trigger }
    },
    /**
    * 新增维保项目信息
    */
    handleAdd() {
      const _this = this
      _this.isEditForm = false
      _this.formVisible = true
      _this.formTitle = '新增维保项目信息'
      _this.addDataForm = {
        vehicleType: '', /** 车辆类型 */
        vehicleBrand: '', /** 车辆品牌 */
        categoryCode: '', /** 设备型号类目（规则###+###+###） */
        guaranteeExpire: '', /** 保修期限(月) */
        guaranteeType: '', /** 维保类型 */
        ports: '', /** 配件名称 */
        itemList: [{ itemName: '', price: '', hourPrice: '' }]
      }
    },
    /**
     * 转义维保类型
     */
    getVehicleBrand(id, listName) {
      let name = ''
      const list = this[listName]
      const ids = id + ''
      for (let i = 0; i < list.length; i++) {
        if (list[i].code === ids) {
          name = list[i].name
          break
        }
      }
      return name
    },
    /**
    * 编辑维保项目信息
    */
    handleEdit(row) {
      console.log(row)
      const _this = this
      _this.isEditForm = true
      _this.showCarNum = true
      _this.showCarName = true
      const param = {
        fixId: row.fixId
      }
      getFixDetail(param).then(res => {
        const obj = deepClone(res.data)
        this.addDataForm = obj
        this.addDataForm.guaranteeType = this.addDataForm.guaranteeType + '' // 因为返回的维保类型与字典定义的code类型不一致，所以这此处强转型
        _this.getLxList(obj.vehicleType, 2, () => {
          _this.formVisible = true
          _this.formTitle = '编辑维保项目信息'
        })
        _this.getPpList(obj.vehicleBrand, 2)
        // _this.propertyList()
      })
    },
    // 添加项目列
    handleAddInfo() {
      const list = this.addDataForm.itemList
      if (list.length > 19) return false
      const obj = {
        itemName: '',
        price: '',
        hourPrice: ''
      }
      this.addDataForm.itemList.push(obj)
    },
    // 删除项目列
    handleRemoveInfo(row, index) {
      if (this.addDataForm.itemList.length === 1) {
        return false
      }
      this.addDataForm.itemList.splice(index, 1)
    },
    /**
    *编辑保存维保项目信息
    */
    handleDialogSubmit() {
      const data = deepClone(this.addDataForm)
      console.log(data)
      this.$refs.addDataForm.validate(valid => {
        if (valid) {
          updateFixList(data).then(res => {
            if (res.code === 200) {
              this.$message.success({
                message: `${this.formTitle}成功！`,
                showClose: true,
                duration: 1500
              })
              this.formVisible = false
              this.getFixLists()
            }
          })
        }
      })
    },
    /**
     * 新增保存
     */
    handleAddSubmit(form) {
      const _this = this
      this.$refs.editForm.validate(valid => {
        if (valid) {
          updateFixList(form).then(res => {
            if (res.code === 200) {
              _this.$message({
                message: `${this.formTitle}成功！`,
                showClose: true,
                type: 'success'
              })
              _this.getFixLists()
              _this.formVisible = false
            }
          }).catch(err => {
            console.log(err)
          })
        }
      })
    },
    /**
    * 导入importDialog = false
    */
    onImport() {
      const _this = this
      _this.importDialog = true
      _this.isImport = true
    },
    /**
    * 导入文件
    */
    onImportFile() {
      const _this = this
      if (_this.fileList.length === 0) {
        this.$message.warning({
          message: '请添加文件!',
          showClose: true
        })
        return
      }
      _this.$refs.upload.submit()
    },
    /**
     * 取消导入
     */
    cancelImport() {
      const _this = this
      _this.importDialog = false
      _this.isImport = true
      _this.fileList = []
      if (_this.responseMsg.failedPath) {
        const param = {
          path: [this.responseMsg.failedPath, this.responseMsg.errorPath]
        }
        delErr(param).then(res => {
          _this.responseMsg = {}
        })
      }
    },
    /**
    * 继续导入文件
    *
    */
    continueImport() {
      const _this = this
      _this.isImport = true
      const param = {
        paths: [this.responseMsg.failedPath, this.responseMsg.errorPath]
      }
      delErr(param).then(res => {
        _this.responseMsg = {}
      })
    },
    /**
     * 导入重置
     */
    onResetFile() {
      const _this = this
      _this.fileList = []
    },
    /**
    * 重置
    */
    onReset() {
      const _this = this
      _this.formData = {
        vehicleType: '', // "车辆类型",
        vehicleBrand: '', // "车辆品牌",
        guaranteeType: '', // "维保类型",
        ports: '' // "配件名称"
      }
      _this.pinpaiList = []
      _this.pageSize = 10
      _this.curPage = 1
      _this.oldFormData = null
      _this.getFixLists()
    },
    /**
    * 导出
    */
    onOutput() {
      const _this = this
      /* const params = {
        vehicleType: _this.formData.vehicleType,
        vehicleBrand: _this.formData.vehicleBrand,
        guaranteeType: _this.formData.guaranteeType,
        ports: _this.formData.ports
      } */
      const params = { ..._this.oldFormData }
      exportProjectList(params).then(res => {
        const url = window.URL.createObjectURL(new Blob([res]))
        const link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        const fileName = '维保项目列表.xlsx'
        link.setAttribute('download', fileName)
        document.body.appendChild(link)
        link.click()
      })
    },
    /**
     * 下载错误文件
     */
    downloadErrfile(val) {
      const _this = this
      let params = {}
      // const url = window.CONFIG.downloadUrl + '/Excel/dowloadExcel?path=' + escape(_this.responseMsg.failedPath)
      // window.location.href = url
      if (val === 1) {
        params = {
          path: _this.responseMsg.failedPath
        }
      } else if (val === 2) {
        params = {
          path: _this.responseMsg.errorPath
        }
      }
      downloadImportDetail(params).then(res => {
        const url = window.URL.createObjectURL(new Blob([res]))
        const link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        const fileName = '维保项目导入详情.xlsx'
        link.setAttribute('download', fileName)
        document.body.appendChild(link)
        link.click()
      })
    },
    /**
     * 下载错误详情文件
     */
    downloadErrDetail() {
      const _this = this
      const url = window.CONFIG.downloadUrl + '/Excel/dowloadExcel?path=' + escape(_this.responseMsg.errorPath)
      window.location.href = url
    },
    /**
    * 分页大小
    */
    sizerChange(val) {
      const _this = this
      _this.pageSize = val
      _this.getFixLists()
    },
    /**
    * 页数跳转
    */
    curPageChange(val) {
      const _this = this
      _this.curPage = val
      _this.getFixLists()
    },
    /**
     * 模板下载
     */
    downTemplete() {
      downloadFixItemconfigTemplate().then(res => {
        const url = window.URL.createObjectURL(new Blob([res]))
        const link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        const fileName = '模板.xlsx'
        link.setAttribute('download', fileName)
        document.body.appendChild(link)
        link.click()
      })
      /* const queryUrl = window.CONFIG.downloadUrl + '/FixItemconfig/downloadFixItemconfigTemplate'
      window.location.href = queryUrl */
    },
    /**
     *表单提交的回调
     */
    httpRequest(param) {
      const _this = this
      const fileObj = param.file // 相当于input里取得的files
      const fd = new FormData()// FormData 对象
      fd.append('file', fileObj)// 文件对象
      this.isLoadingUp = true
      importProjectList(fd).then(res => {
        _this.isLoadingUp = false
        if (res.code === 200) {
          // _this.submitForm() //提交表单
          _this.isImport = false
          _this.responseMsg = res.data
          _this.$message.success({
            message: _this.responseMsg.msg,
            duration: 2000
          })
          _this.getFixLists()
        }
      }).catch(_ => {
        this.isLoadingUp = false
      })
    },
    /**
     * 文件变化监听
     */
    fileChange(file, fileList) {
      const _this = this
      _this.fileList = fileList
    },
    /**
     * 删除
     */
    onDel(id) {
      const _this = this
      let fixId = []
      if (id === 'all') {
        if (this.multipleSelection.length === 0) {
          this.$message.warning({
            message: '请勾选需要删除的内容！',
            showClose: true,
            duration: 1500
          })
          return false
        } else {
          fixId = this.multipleSelection.map(o => {
            return o.fixId
          })
        }
      } else {
        fixId = [id]
      }
      console.log(fixId)
      _this.$confirm('确定删除所选维保项目吗？', '提示', {
        confirmButtoText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        delFixList(fixId).then(res => {
          if (res.code === 200) {
            this.$message.success({
              message: '删除成功！',
              showClose: true,
              duration: 1500
            })
            this.getFixLists()
          }
        })
      }).catch(() => {
        _this.$message({
          message: '已取消删除！',
          showClose: true,
          type: 'info'
        })
      })
    },
    numberRules(message) {
      const validatePass = (rule, value, callback) => {
        if (value === '' || value === undefined) {
          callback(new Error(message + '不能为空！'))
        } if (parseFloat(value) <= 0) {
          callback(new Error(message + '值大于0'))
        } if (parseFloat(value) > 9999999999.99) {
          callback(new Error('输入1~10位>0的数字'))
        } else {
          callback()
        }
      }
      return { required: true, validator: validatePass, trigger: 'blur' }
    }
  }
}
</script>

<style lang="stylus" scoped>
.project-container {
  padding 0 20px
  .tydic-box {
    padding 0px 0 10px
  }
  .tydic-box .tydic-input~.tydic-input{
    margin-left 80px
  }
  .w240 {
    width 240px
  }
  .w180 {
    width 180px
  }
  .w140 {
    width 140px
  }
  .w-full {
    width 100%
  }
}
</style>
<style lang="stylus" scoped>
.project-container {
  .info-table {
      width 100%
  }
  .rule-group {
    width 100%
    padding 20px 0
  }
  .button-group {
      text-align right
      margin-bottom 10px
  }
}
</style>
<style lang="stylus">
.project-container {
  .el-form-item--medium .el-form-item__label {
    margin-bottom 11px
  }
  .info-table {
    tbody {
      td {
        padding 0
        .el-form-item {
          margin 0
          .el-input__count {
            display none
          }
          .el-form-item__content {
            width 100%
          }
        }
      }
    }
  }
}
</style>
