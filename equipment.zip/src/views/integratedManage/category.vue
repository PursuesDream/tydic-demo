<template>
  <div class="category-container">
    <div style="width:100%">
      <div style="width:100%;margin-top:20px">
        <el-col :span="8">
          <el-card class="box-card">
            <div slot="header">
              <span>类型</span>
            </div>
            <div>
              <div class="search-input">
                <el-input v-model.trim="carTypeFilterValue" placeholder="请输入关键字进行匹配" />
                <el-button type="primary color2" size="mini" tyle="margin-left: 10px;" @click="onReset('carType')">重置</el-button>
              </div>
              <div style="height: 600px;margin-top:10px">
                <el-scrollbar style="height:100%">
                  <!-- <div style="height:2000px"> -->
                  <template v-for="(item,index) in carTypeList">
                    <div v-if="item.isShow" :key="item.categoryCode" class="search-input">
                      <el-input v-show="item.isEdit" :ref="'carTypeInput'+index" v-model.trim="item.categoryName" maxlength="20" />
                      <div v-show="!item.isEdit" :class="[{'active':item.categoryCode === carTypeActive.categoryCode},'nomal']" @click="handleChange('carType',item.categoryCode,index,item.categoryType)">{{ item.categoryName }}</div>
                      <!-- <div style="float: right">
                        <el-button v-if="item.isEdit == true" type="text" size="medium" style="margin-left: 15px" @click="handleComfirm('carType',item.categoryCode,index)">确认</el-button>
                        <el-button v-if="!item.isEdit" type="text" size="medium" style="margin-left: 15px" @click="handleEdit('carType',item.categoryCode,index)">编辑</el-button>
                        <el-button v-if="item.isEdit == true" type="text" size="medium" style="margin-left: 15px" @click="handleCancel('carType',item.categoryCode,index)">取消</el-button>
                        <el-button v-if="item.categoryCode !== 'new'" type="text" size="medium" style="margin-left: 15px" @click="handleDelete('carType',item.categoryCode,index)">删除</el-button>
                      </div> -->
                    </div>
                  </template>
                  <!-- </div> -->
                </el-scrollbar>
              </div>
              <div style="text-align: center;margin-top:30px">
                <!-- <el-button type="primary color1" size="mini" @click="handleAdd('carType')">添加</el-button> -->
              </div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card v-loading="isCarName" class="box-card">
            <div slot="header" class="clearfix">
              <span>品牌</span>
            </div>
            <div>
              <div class="search-input">
                <el-input v-model.trim="carNameFilterValue" placeholder="请输入关键字进行匹配" />
                <el-button type="primary color2" size="mini" style="margin-left: 10px;" @click="onReset('carName')">重置</el-button>
              </div>
              <div style="height: 600px;margin-top:10px">
                <el-scrollbar style="height: 100%">
                  <div style="height:700px">
                    <template v-for="(item,index) in carNameList">
                      <div v-if="item.isShow" :key="item.categoryCode" class="search-input">
                        <el-input v-show="item.isEdit" :ref="'carNameInput'+index" v-model.trim="item.categoryName" maxlength="20" />
                        <div v-show="!item.isEdit" :class="[{'active':item.categoryCode === carNameActive.categoryCode},'nomal']" @click="handleChange('carName',item.categoryCode,index,item.categoryType)">{{ item.categoryName }}</div>
                        <div style="float: right">
                          <el-button v-if="item.isEdit == true" type="text" size="medium" style="margin-left: 15px" @click="handleComfirm('carName',item.categoryCode,index)">确认</el-button>
                          <el-button v-if="!item.isEdit" type="text" size="medium" style="margin-left: 15px" @click="handleEdit('carName',item.categoryCode,index)">编辑</el-button>
                          <el-button v-if="!item.isEdit" type="text" size="medium" style="margin-left: 15px" @click="moveUp('carName',item.categoryOrder,index,item.pCode)">上移</el-button>
                          <el-button v-if="!item.isEdit" type="text" size="medium" style="margin-left: 15px" @click="moveDown('carName',item.categoryOrder,index,item.pCode)">下移</el-button>
                          <el-button v-if="item.isEdit == true" type="text" size="medium" style="margin-left: 15px" @click="handleCancel('carName',item.categoryCode,index)">取消</el-button>
                          <el-button v-if="item.categoryCode !== 'new'" type="text" size="medium" style="margin-left: 15px" @click="handleDelete('carName',item.categoryCode,index)">删除</el-button>
                        </div>
                      </div>
                    </template>
                  </div>
                </el-scrollbar>
              </div>
              <div v-if="carTypeActive.categoryCode" style="text-align: center;margin-top:30px">
                <el-button type="primary color1" size="mini" @click="handleAdd('carName')">添加</el-button>
              </div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card v-loading="isCarNum" class="box-card">
            <div slot="header" class="clearfix">
              <span>型号</span>
            </div>
            <div>
              <div class="search-input">
                <el-input v-model="carNumFilterValue" placeholder="请输入关键字进行匹配" />
                <el-button type="primary color2" size="mini" tyle="margin-left: 10px;" @click="onReset('carNum')">重置</el-button>
              </div>
              <div style="height: 600px;margin-top:10px">
                <el-scrollbar style="height: 100%">
                  <div style="height:700px">
                    <template v-for="(item,index) in carNumList">
                      <div v-if="item.isShow" :key="item.categoryCode" class="search-input">
                        <el-input v-show="item.isEdit" :ref="'carNumInput'+index" v-model="item.categoryName" maxlength="20" />
                        <div v-show="!item.isEdit" :class="[{'active':item.categoryCode === carNumActive.categoryCode},'nomal']" @click="handleChange('carNum',item.categoryCode,index,item.categoryType)">{{ item.categoryName }}</div>
                        <div style="float: right">
                          <el-button v-if="item.isEdit == true" type="text" size="medium" style="margin-left: 15px" @click="handleComfirm('carNum',item.categoryCode,index)">确认</el-button>
                          <el-button v-if="!item.isEdit" type="text" size="medium" style="margin-left: 15px" @click="handleEdit('carNum',item.categoryCode,index)">编辑</el-button>
                          <el-button v-if="!item.isEdit" type="text" size="medium" style="margin-left: 15px" @click="moveUp('carNum',item.categoryOrder,index,item.pCode)">上移</el-button>
                          <el-button v-if="!item.isEdit" type="text" size="medium" style="margin-left: 15px" @click="moveDown('carNum',item.categoryOrder,index,item.pCode)">下移</el-button>
                          <el-button v-if="item.isEdit == true" type="text" size="medium" style="margin-left: 15px" @click="handleCancel('carNum',item.categoryCode,index)">取消</el-button>
                          <el-button v-if="item.categoryCode !== 'new'" type="text" size="medium" style="margin-left: 15px" @click="handleDelete('carNum',item.categoryCode,index)">删除</el-button>
                        </div>
                      </div>
                    </template>
                  </div>
                </el-scrollbar>
              </div>
              <div v-if="carNameActive.categoryCode" style="text-align: center;margin-top:30px">
                <el-button type="primary color1" size="mini" @click="handleAdd('carNum')">添加</el-button>
              </div>
            </div>
          </el-card>
        </el-col>
      </div>
    </div>
  </div>
</template>

<script>
import { getCategoryList, addOrUpdateCategory, deleteCategory, changeOrder } from '@/api/integratedManage'
import { deepClone } from '@/utils'
export default {
  name: 'Category',
  data() {
    return {
      isAddStatus: false,
      isCarName: false,
      isCarNum: false,
      carTypeData: [],
      carTypeActive: {},
      carTypeFilterValue: '',
      carNameData: [],
      carNameActive: {},
      carNameFilterValue: '',
      carNumData: [],
      carNumActive: {},
      carNumFilterValue: '',
      editName: {},
      lastEditName: '',
      parentType: ''
    }
  },
  computed: {
    carTypeList() {
      const that = this
      return that.carTypeData.map(o => {
        o.isShow = (that.carTypeFilterValue !== '' && o.categoryName.toUpperCase().includes(that.carTypeFilterValue.toUpperCase())) || that.carTypeFilterValue === ''
        return o
      })
    },
    carNameList() {
      const that = this
      return that.carNameData.filter(o => {
        // if (that.carNameFilterValue !== '') {
        //   return o.categoryName.toUpperCase().includes(that.carNameFilterValue.toUpperCase())
        // } else {
        //   return true
        // }
        o.isShow = (that.carNameFilterValue !== '' && o.categoryName.toUpperCase().includes(that.carNameFilterValue.toUpperCase())) || that.carNameFilterValue === ''
        return o
      })
    },
    carNumList() {
      const that = this
      return that.carNumData.filter(o => {
        // if (that.carNumFilterValue !== '') {
        //   return o.categoryName.toUpperCase().includes(that.carNumFilterValue.toUpperCase())
        // } else {
        //   return true
        // }
        o.isShow = (that.carNumFilterValue !== '' && o.categoryName.toUpperCase().includes(that.carNumFilterValue.toUpperCase())) || that.carNumFilterValue === ''
        return o
      })
    }
  },
  watch: {
    parentType(val) {
      this.parentType = val
    }
  },
  mounted() {
    this.getCategoryData('carType')
  },
  methods: {
    /**
     * 上移
     */
    moveUp(name, order, index, code) {
      console.log(name, order, index)
      if (index === 0) {
        this.$message.warning({
          message: '不能上移第一位！',
          duration: 1500
        })
        return
      }
      const data = {
        pCode: code,
        categoryOrder: order
      }
      const params = {
        opType: '1'
      }
      changeOrder({ data, params }).then(res => {
        if (res.code === 200) {
          const message = '操作成功！'
          this.$message.success({
            message,
            duration: 1500
          })
          // this.isAddStatus = false
          let categoryCode = ''
          let activeLoading = ''
          // 判断当前级别
          if (name === 'carName') {
            categoryCode = this.carTypeActive.categoryCode
            activeLoading = 'isCarName'
          } else if (name === 'carNum') {
            activeLoading = 'isCarNum'
            categoryCode = this.carNameActive.categoryCode
          }
          this.getCategoryData(name, categoryCode, activeLoading)
        }
      })
    },
    /**
     * 下移
     */
    moveDown(name, order, index, code) {
      console.log(name, code, order)
      console.log(name, order, index)
      const arrLength = this[name + 'List'].length - 1
      if (index === arrLength) {
        this.$message.warning({
          message: '不能下移最后一位！',
          duration: 1500
        })
        return
      }
      const data = {
        pCode: code,
        categoryOrder: order
      }
      const params = {
        opType: '2'
      }
      changeOrder({ data, params }).then(res => {
        if (res.code === 200) {
          const message = '操作成功！'
          this.$message.success({
            message,
            duration: 1500
          })
          // this.isAddStatus = false
          let categoryCode = ''
          let activeLoading = ''
          // 判断当前级别
          if (name === 'carName') {
            categoryCode = this.carTypeActive.categoryCode
            activeLoading = 'isCarName'
          } else if (name === 'carNum') {
            activeLoading = 'isCarNum'
            categoryCode = this.carNameActive.categoryCode
          }
          this.getCategoryData(name, categoryCode, activeLoading)
        }
      })
    },
    getCategoryData(name, code = '', loadingName = '', type = '') {
      const params = {
        categoryCode: code,
        categoryType: this.parentType
      }
      if (loadingName !== '') {
        this.loadingName = true
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          const data = res.data
          this[name + 'Data'] = data.map(o => {
            o.isEdit = false
            o.isShow = true
            return o
          })
          if (this[name + 'Active'].categoryCode === 'new') {
            const index = this[name + 'Data'].length - 1
            this[name + 'Active'] = this[name + 'Data'][index]
          }
          if (loadingName === '') return
          this[loadingName] = false
        }
        this.editName = {}
      })
    },
    // 选中当前内容
    handleChange(name, code, index, type) {
      // 当前状态为添加时，必须完成添加状态
      if (this.checkIsAddStatus()) return false
      if (this[name + 'Active'].isEdit !== undefined) this[name + 'Active'].isEdit = false
      if (this.lastEditName && this.lastEditName === name && this[name + 'Active'].categoryCode === this[name + 'Data'][index].categoryCode) {
        if (this.editName.categoryName) this[name + 'Active'].categoryName = this.editName.categoryName
      }
      const that = this
      this.$nextTick(() => {
        that[name + 'Active'] = this[name + 'Data'][index]
        const categoryCode = that[name + 'Active'].categoryCode
        let activeLoading = ''
        if (name === 'carType') {
          activeLoading = 'isCarName'
          this.carNameData = []
          this.carNameActive = {}
          this.carNameFilterValue = ''
          this.carNumData = []
          this.carNumActive = {}
          this.carNumFilterValue = ''
          this.parentType = type
          this.getCategoryData('carName', categoryCode, activeLoading)
        } else if (name === 'carName') {
          activeLoading = 'isCarNum'
          this.carNumData = []
          this.carNumActive = {}
          this.carNumFilterValue = ''
          this.getCategoryData('carNum', categoryCode, activeLoading)
        }
      })
    },
    // 提交修改、添加
    handleComfirm(name, code, index) {
      const item = this[name + 'Active']
      if (item.categoryName === '') {
        this.$message.warning({
          message: '请输入名称！',
          duration: 1500
        })
        return
      }
      const params = {
        pCode: item.pCode,
        categoryName: item.categoryName,
        categoryType: this.parentType
      }
      // 新增时没有 categoryCode
      if (!this.isAddStatus) {
        params.categoryCode = item.categoryCode
      }
      // 类目第一级车辆类型pCode为空
      if (name === 'carType') {
        params.pCode = ''
      }
      addOrUpdateCategory(params).then(res => {
        if (res.code === 200) {
          const message = this.isAddStatus ? '新增成功！' : '修改成功！'
          this.$message.success({
            message,
            duration: 1500
          })
          this.isAddStatus = false
          let categoryCode = ''
          let activeLoading = ''
          console.log(this.isAddStatus)
          // 判断当前级别
          if (name === 'carName') {
            categoryCode = this.carTypeActive.categoryCode
            activeLoading = 'isCarName'
          } else if (name === 'carNum') {
            activeLoading = 'isCarNum'
            categoryCode = this.carNameActive.categoryCode
          }
          this.getCategoryData(name, categoryCode, activeLoading)
        }
      })
    },
    handleEdit(name, code, index) {
      // 当前状态为添加时，必须完成添加状态
      if (this.checkIsAddStatus()) return false
      if (this.lastEditName) {
        this[this.lastEditName + 'Active'].isEdit = false
        this.editName.categoryName = this[name + 'Active'].categoryName
        this[this.lastEditName + 'Active'].categoryName = this.editName.categoryName
      }
      this.lastEditName = name
      // 取消先前处于编辑状态
      // if (this[name + 'Active'].isEdit !== undefined) {
      //   this[name + 'Active'].isEdit = false
      // }
      this[name + 'Data'][index].isEdit = true
      const obj = deepClone(this[name + 'Data'][index])
      this.editName = obj
      this[name + 'Active'] = this[name + 'Data'][index]
      const that = this
      // 编辑状态默认焦距选中
      this.$nextTick(() => {
        that.$refs[name + 'Input' + index][0].focus()
      })
    },
    handleCancel(name, code, index) {
      if (this.isAddStatus) {
        this[name + 'Active'] = {}
        this[name + 'Data'].pop()
        this.isAddStatus = false
      } else {
        this[name + 'Data'][index].categoryName = this.editName.categoryName // 取消编辑时，应将输入框原来的值还原
        this[name + 'Data'][index].isEdit = false
      }
      this.lastEditName = null
    },
    handleDelete(name, code, index) {
      const _this = this
      // 当前状态为添加时，必须完成添加状态
      if (this.checkIsAddStatus()) return false
      _this.$confirm('确定删除吗？', '提示', {
        confirmButtoText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        const categoryCode = this[name + 'Data'][index].categoryCode
        const categoryType = this.parentType
        deleteCategory({ categoryCode, categoryType }).then(res => {
          if (res.code === 200 && res.data !== -1) {
            this.$message.success({
              message: '删除成功！',
              duration: 1500
            })
            let categoryCode = ''
            let activeLoading = ''
            // 判断当前级别
            if (name === 'carName') {
              activeLoading = 'isCarName'
              _this.carNumData = []
              _this.carNameData.splice(index, 1)
              categoryCode = this.carTypeActive.categoryCode
            } else if (name === 'carNum') {
              activeLoading = 'isCarNum'
              _this.carNumData.splice(index, 1)
              categoryCode = this.carNameActive.categoryCode
            } else if (name === 'carType') {
              _this.carNameData = []
              _this.carNumData = []
            }
            this.getCategoryData(name, categoryCode, activeLoading)
            this[name + 'Active'] = {}
            this[name + 'FilterValue'] = ''
          // this[name + 'Data'].splice(index, 1)
          } else if (res.data === -1) {
            this.$message.warning({
              message: '当前分类已被引用，不可删除！',
              duration: 1500
            })
          }
        })
      }).catch(() => {
        _this.$message({
          message: '已取消删除！',
          type: 'info'
        })
      })
    },
    handleAdd(name) {
      // 当前状态为添加时，必须完成添加状态
      if (this.checkIsAddStatus()) return false
      if (this[name + 'Active'].isEdit !== undefined) this[name + 'Active'].isEdit = false
      const obj = {
        isEdit: true,
        categoryName: '',
        categoryCode: 'new',
        categoryType: this.parentType
      }
      // 判断当前级别
      if (name === 'carName') {
        obj.pCode = this.carTypeActive.categoryCode
        obj.categoryType = this.carTypeActive.categoryType
        this.carNumData = []
      } else if (name === 'carNum') {
        obj.pCode = this.carNameActive.categoryCode
        obj.categoryType = this.carNameActive.categoryType
      }
      this[name + 'Data'].push(obj)
      const Index = this[name + 'Data'].length - 1
      this[name + 'Active'] = this[name + 'Data'][Index]
      this.isAddStatus = true
      // 编辑状态默认焦距选中
      const that = this
      this.$nextTick(() => {
        that.$refs[name + 'Input' + Index][0].focus()
      })
    },
    checkIsAddStatus() {
      // 当前状态为添加时，必须完成添加状态
      if (this.isAddStatus) {
        this.$message.warning({
          message: '请完成添加操作后再做其它操作！',
          showClose: true
        })
        return true
      }
      return false
    },
    onReset(name) {
      this[name + 'FilterValue'] = ''
    }
  }
}
</script>

<style lang="stylus" scoped>
.category-container {
  width 100%
  padding 0 0px 0 20px
  .w200 {
    width 200px
  }
  .w180 {
    width 180px
  }
  .w140 {
    width 140px
  }
  .box-card{
    width 615px
    height 800px;
    margin-right 30px

  }
  .nomal{
    display inline-block;
    width 350px
    height 36px
    color #333
    // margin-right 15px
    text-indent 20px
    line-height 36px
    background #fff
    border 1px solid #333
    border-radius 8px
    cursor  pointer
  }
  .active{
    display inline-block;
    width 350px
    height 36px
    color #fff
    text-indent 20px
    line-height 36px
    background #409eff
    border 1px solid #409eff
    border-radius 8px
    cursor  pointer
  }
  .addButton{
    text-align center
    margin-top 30px
    position fixed
    left 15%
    bottom 37%
  }
  /deep/.el-scrollbar__wrap {
    // overflow scroll
    // height 120%
    // width 110%
  overflow-x hidden
}
  /deep/.el-card__header{
    padding: 18px 30px
  }
  /deep/.el-card__body{
    padding 20px 30px
  }
}
</style>
