<template>
  <div class="WorkflowManage-container">
    <el-card style="margin-top:20px;height:85vh">
      <div>
        <div class="tydic-box">
          <div class="tydic-input">
            流程类型：
            <el-select v-model="formData.sortId" clearable placeholder="请选择">
              <el-option
                v-for="(o,index) in processList"
                :key="index"
                :label="o.name"
                :value="o.code"
              />
            </el-select>
          </div>
          <div class="tydic-input">
            流程名称：
            <el-input v-model="formData.flowName" clearable placeholder="请输入" />
          </div>
          <div class="tydic-input">
            在用状态：
            <el-select v-model="formData.useState" clearable>
              <el-option
                v-for="(o,index) in useState"
                :key="index"
                :label="o.name"
                :value="o.code"
              />
            </el-select>
          </div>
          <div class="tydic-input" style="float:right">
            <el-button type="primary search" size="mini" @click="onSearch"><i class="image-icon search" />查询</el-button>
            <el-button type="primary reset" size="mini" @click="onReset"><i class="image-icon reset" />重置</el-button>
          </div>
          <div>
            <el-button v-permission="'button42'" class="m-b-15" type="primary color3" size="mini" @click="handleAdd"><i class="image-icon add" />新增</el-button>
          </div>
          <div v-loading="isLoading" class="table-box">
            <el-table
              :data="tableData"
              class="custom-table"
              stripe
              border
              max-height="600"
              header-row-class-name="custom-table-header"
            >
              <el-table-column align="center" type="index" label="序号" width="100" :show-overflow-tooltip="true">
                <template slot-scope="scope">
                  {{ scope.$index + 1 + formData.pageSize * (formData.pageNum - 1) }}
                </template>
              </el-table-column>
              <el-table-column
                prop="flowName"
                align="center"
                width="400"
                label="流程名称"
                :show-overflow-tooltip="true"
              />
              <el-table-column
                align="center"
                label="流程类型"
                :show-overflow-tooltip="true"
              >
                <template slot-scope="scope">
                  <span>{{ getFlowName(scope.row.sortId) }}</span>
                </template>
              </el-table-column>
              <!-- <el-table-column
                prop="flowSortNo"
                align="center"
                label="流程编码"
                :show-overflow-tooltip="true"
              /> -->
              <el-table-column
                prop="createByName"
                align="center"
                label="创建人"
                :show-overflow-tooltip="true"
              />
              <el-table-column
                align="center"
                label="在用状态"
                :show-overflow-tooltip="true"
              >
                <template slot-scope="scope">
                  <span>{{ scope.row.useState === '1'?'使用': '停用' }}</span>
                </template>
              </el-table-column>
              <el-table-column
                prop="flowDeptName"
                align="center"
                width="400"
                label="所属机构"
                :show-overflow-tooltip="true"
              />
              <el-table-column align="center" label="操作">
                <template slot-scope="scope">
                  <el-button
                    v-permission="'button43'"
                    type="text"
                    size="small"
                    @click="handleEdit(scope.row)"
                  >编辑</el-button>
                  <el-button
                    v-if="scope.row.useState === '0'"
                    v-permission="'button44'"
                    type="text"
                    size="small"
                    @click="handleUse(scope.row)"
                  >使用</el-button>
                  <el-button
                    v-if="scope.row.useState === '1'"
                    v-permission="'button45'"
                    type="text"
                    size="small"
                    @click="handleStop(scope.row)"
                  ><span style="color:red">停用</span></el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div style="text-align: center">
            <el-pagination
              ref="pagination"
              style="text-align: center;margin-top:15px;"
              background
              :page-size="formData.pageSize"
              :total="total"
              :current-page.sync="formData.pageNum"
              :page-sizes="[5, 10, 15, 20]"
              layout="total, prev, pager, next, jumper"
              @size-change="sizeChange"
              @current-change="curPageChange"
            />
          </div>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { getFlowList, changeFlowState } from '@/api/flowConfig'
export default {
  name: 'WorkflowManage',
  data() {
    return {
      isLoading: false,
      tableData: [],
      processList: [],
      useState: [],
      total: 0,
      formData: {
        flowName: '',
        useState: '',
        sortId: '',
        pageSize: 10,
        pageNum: 1
      },
      oldFormData: null
    }
  },
  computed: {
    ...mapState({
      mapData: state => state.user.mapData
    })
  },
  watch: {
    // 如果路由有变化，会再次执行请求列表的方法
    $route(to, from) {
      if (from.path === '/integratedManage/workflowConfig') {
        return
      }
      this.getList()
    }
  },
  mounted() {
    const _this = this
    _this.processList = _this.mapData.fix_apply_type || []
    _this.useState = _this.mapData.flow_use_state || []
    _this.getList()
  },
  methods: {
    /**
     * 新增流程
     */
    handleAdd() {
      this.$router.push('/integratedManage/workflowConfig/')
    },
    /**
     * 新增流程
     */
    handleEdit(row) {
      this.$router.push({
        name: 'WorkflowConfig',
        params: {
          id: row.flowId
        }
      })
      // this.$router.push({ path: `/integratedManage/workflowConfig/${row.flowId}`, query: { id: row.flowId }})
    },
    /**
     * 转换流程类型名称
     */
    getFlowName(id) {
      let name = ''
      const code = id + ''
      const list = this.processList
      for (let i = 0; i < list.length; i++) {
        if (list[i].code === code) {
          name = list[i].name
          break
        }
      }
      return name
    },
    /**
     * 获取所有流程列表
     */
    getList() {
      const _this = this
      _this.tableData = []
      _this.isLoading = true
      let param = {}
      if (this.oldFormData) {
        param = { ...this.oldFormData }
      } else {
        param = { ...this.formData }
        delete param.pageNum
        delete param.pageSize
        this.oldFormData = { ...param }
      }
      param.pageNum = this.formData.pageNum
      param.pageSize = this.formData.pageSize
      getFlowList(param).then(res => {
        if (res.code === 200) {
          _this.tableData = res.rows
          _this.total = res.total
          _this.isLoading = false
        }
      }).catch(err => {
        console.log(err)
      })
    },
    /**
     * 使用
     */
    handleUse(val) {
      const param = {
        flowId: val.flowId,
        useState: '1'
      }
      param.useState = '1'
      changeFlowState(param).then(res => {
        if (res.code === 200) {
          this.$message.success({
            message: '操作成功',
            showClose: true,
            duration: 1500
          })
          this.getList()
        }
      })
    },
    /**
     * 停用
     */
    handleStop(val) {
      const param = {
        flowId: val.flowId,
        useState: '0'
      }
      param.useState = '0'
      changeFlowState(param).then(res => {
        if (res.code === 200) {
          this.$message.success({
            message: '操作成功',
            showClose: true,
            duration: 1500
          })
          this.getList()
        }
      })
    },
    onSearch() {
      this.pageNum = 1
      this.oldFormData = null
      this.getList()
    },
    onReset() {
      this.formData = {
        flowName: '',
        useState: '',
        sortId: '',
        pageSize: 10,
        pageNum: 1
      }
      this.oldFormData = null
      this.getList()
    },
    sizeChange(val) {
      this.formData.pageSize = val
      this.getList()
    },
    curPageChange(val) {
      this.formData.pageNum = val
      this.getList()
    }
  }
}
</script>

<style lang="stylus" scoped>
.WorkflowManage-container {
  padding 0 20px
  .tydic-box {
    padding 0px 0 10px
  }
  .w200 {
    width 200px
  }
  .w180 {
    width 180px
  }
  .w140 {
    width 140px
  }
  .w-full {
    width 100%
  }
}
</style>

