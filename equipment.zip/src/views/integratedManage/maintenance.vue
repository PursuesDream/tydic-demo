<template>
  <div class="maintenance-container">
    <el-card style="margin-top:20px;height:85vh">
      <div>
        <div>
          <!-- <el-card> -->
          <div class="tydic-box">
            <div class="tydic-input">
              维保单位：
              <el-input v-model="formData.comName" maxlength="50" placeholder="请输入" />
            </div>
            <div class="tydic-input">
              车辆类型：
              <el-select v-model="formData.vehicleType" placeholder="请选择" clearable @change="(val) =>getLxList(val,1)">
                <el-option
                  v-for="(o,index) in vehicleTypeList"
                  :key="index"
                  :label="o.categoryName"
                  :value="o.categoryCode"
                />
              </el-select>
            </div>
            <div class="tydic-input">
              车辆品牌：
              <el-select v-model="formData.vehicleBrand" placeholder="请选择" clearable>
                <el-option
                  v-for="(o,index) in vehicleBrandList"
                  :key="index"
                  :label="o.categoryName"
                  :value="o.categoryCode"
                />
              </el-select>
            </div>
            <div class="tydic-input">
              入库时间：
              <el-date-picker
                v-model="formData.beginTime"
                class="w250"
                type="datetime"
                value-format="yyyy-MM-dd HH:mm:ss"
                placeholder="开始时间"
                :picker-options="rukuStartTime"
              />
              <span style="display: inline-block;margin: 0 10px;">至</span>
              <el-date-picker
                v-model="formData.endTime"
                class="w250"
                style="margin-left: 0;padding-left: 0;"
                type="datetime"
                value-format="yyyy-MM-dd HH:mm:ss"
                placeholder="结束时间"
                :picker-options="rukuEndTime"
              />
            </div>
            <div class="tydic-input" style="float:right">
              <el-button type="primary search" size="mini" @click="onSearch"><i class="image-icon search" />查询</el-button>
              <el-button type="primary reset" size="mini" @click="onReset"><i class="image-icon reset" />重置</el-button>
            </div>
            <div class="tydic-input">
              <el-button v-permission="'button27'" type="primary color3" size="mini" @click="handleAdd"><i class="image-icon add" />新增</el-button>
              <el-button v-permission="'button28'" type="primary color6" size="mini" @click="handleRemove('all')"><i class="image-icon delete" />删除</el-button>
            </div>
            <div v-loading="isLoading" class="table-box">
              <el-table
                :data="tableData"
                class="custom-table"
                max-height="600"
                stripe
                border
                header-row-class-name="custom-table-header"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="50" />
                <el-table-column align="center" type="index" label="序号" width="100" :show-overflow-tooltip="true">
                  <template slot-scope="scope">
                    {{ scope.$index + 1 + pageSize * (curPage - 1) }}
                  </template>
                </el-table-column>
                <el-table-column align="center" label="车辆类型" prop="vehicleType">
                <!-- <template slot-scope="scope">{{ getVehicleBrand(scope.row.vehicleType,'vehicleTypeList') }}</template> -->
                </el-table-column>
                <el-table-column align="center" label="车辆品牌" prop="vehicleBrand">
                <!-- <template slot-scope="scope">{{ getVehicleBrand(scope.row.vehicleBrand,'vehicleBrandList') }}</template> -->
                </el-table-column>
                <el-table-column
                  prop="comName"
                  align="center"
                  label="维保单位名称"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="tel"
                  align="center"
                  label="联系电话"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="address"
                  align="center"
                  label="门店地址"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="inTime"
                  align="center"
                  label="入库时间"
                  :show-overflow-tooltip="true"
                />
                <el-table-column align="center" label="操作">
                  <template slot-scope="scope">
                    <el-button
                      v-permission="'button29'"
                      type="text"
                      size="small"
                      @click="handleEdit(scope.row)"
                    >修改</el-button>
                    <el-button
                      v-permission="'button28'"
                      type="text"
                      size="small"
                      @click="handleRemove(scope.row.comId)"
                    >删除</el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div style="text-align: center">
            <el-pagination
              ref="pagination"
              style="text-align: center;margin-top:30px;"
              background
              :page-size="pageSize"
              :total="total"
              :current-page.sync="curPage"
              :page-sizes="pageSizes"
              layout="total, prev, pager, next, jumper"
              @current-change="handlePageChange"
            />
          </div>
          <el-dialog :title="formTitle" :visible.sync="formVisible" width="654px" custom-class="custom-dialog" :close-on-click-modal="false" :colse-on-press-escape="false" @close="handleDialogClose">
            <el-form ref="addDataForm" :model="addDataForm" :rules="rules" :inline="true" label-width="92px">
              <el-form-item label="车辆类型：" prop="vehicleType" :rules="getRules('车辆类型','change')">
                <el-select v-model="addDataForm.vehicleType" size="mini" placeholder="请选择" class="w200" clearable @change="(val) =>getLxList(val,2)">
                  <el-option
                    v-for="(o,index) in vehicleTypeList"
                    :key="index"
                    :label="o.categoryName"
                    :value="o.categoryCode"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="车辆品牌：" class="mr0" prop="vehicleBrand" :rules="getRules('车辆品牌','change')">
                <el-select v-model="addDataForm.vehicleBrand" placeholder="请选择" size="mini" class="w200">
                  <el-option
                    v-for="(o,index) in vehicleBrandList2"
                    :key="index"
                    :label="o.categoryName"
                    :value="o.categoryCode"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="单位名称：" prop="comName" :rules="getRules('单位名称')">
                <el-input v-model="addDataForm.comName" maxlength="50" size="mini" type="text" placeholder="请输入" class="w200" />
              </el-form-item>
              <el-form-item label="联系电话：" class="mr0" prop="tel">
                <el-input v-model="addDataForm.tel" maxlength="20" size="mini" placeholder="请输入" class="w200" />
              </el-form-item>
              <el-form-item label="单位地址：" class="mr0" prop="address" :rules="getRules('单位地址')">
                <el-input v-model="addDataForm.address" maxlength="100" size="mini" placeholder="请输入" style="width: 502px" />
              </el-form-item>
            </el-form>
            <div style="text-align: center;margin-top:10px">
              <el-button type="primary color1" size="mini" @click="handleDialogSubmit">保存</el-button>
              <el-button type="primary color2" size="mini" @click="handleDialogReset">重置</el-button>
              <el-button type="primary color-cancel" size="mini" @click="formVisible = false">取消</el-button>
            </div>
          </el-dialog>
        <!-- </el-card> -->
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
import { getCategoryList, getfixCompanyList, deleteFixCompany, insertOrUpdateFixCompany, getfixCompanyByID } from '@/api/integratedManage'
import { deepClone } from '@/utils'
// import {  } from '@/api/integratedManage'
const emptyForm = {
  comId: '',
  vehicleType: '',
  vehicleBrand: '',
  tel: '',
  comName: '',
  address: ''
}
export default {
  name: 'Maintenance',
  data() {
    const validateTel = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('手机号不能为空!'))
      } else if (!(/^1[3-9]\d{9}$/.test(this.addDataForm.tel))) {
        callback(new Error('手机号格式不正确'))
      } else {
        callback()
      }
    }
    return {
      formData: {
        comName: '',
        vehicleType: '',
        vehicleBrand: '',
        beginTime: '',
        endTime: ''
      },
      oldFormData: null,
      isLoading: false,
      curPage: 1,
      pageSize: 10,
      total: 0,
      pageSizes: [10, 20, 30],
      vehicleTypeList: [],
      vehicleBrandList: [],
      vehicleBrandList2: [],
      tableData: [],
      multipleSelection: [],
      isEdit: false,
      formTitle: '',
      formVisible: false,
      addDataForm: {
        comId: '', /** 维修单位id */
        vehicleType: '', /** 车辆类型*/
        vehicleBrand: '', /** 车辆品牌*/
        tel: '', /** 联系电话： */
        comName: '', /** 单位名称 */
        address: '' /** 单位地址 */
      },
      rules: {
        tel: [
          { required: true, validator: validateTel, trigger: 'blur' }
        ]
      }
    }
  },
  computed: {
    rukuStartTime() {
      let endTime = this.formData.endTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          endTime = new Date(endTime).getTime()
          if (endTime) {
            if (nowDate > endTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    },
    rukuEndTime() {
      let startTime = this.formData.beginTime
      return {
        disabledDate(now) {
          const nowDate = new Date(now).getTime()
          startTime = new Date(startTime).getTime()
          if (startTime) {
            if (nowDate < startTime) return true
            else return false
          } else {
            return false
          }
        }
      }
    }
  },
  mounted() {
    this.getDataList()
    this.getAllCategory()
  },
  methods: {
    /**
     * 查询所有车辆类型
     */
    getAllCategory() {
      const _this = this
      const params = {
        categoryCode: '',
        categoryType: '1'
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          _this.vehicleTypeList = res.data
        }
      })
    },
    handleEdit(row) {
      const _this = this
      getfixCompanyByID(row.comId).then(res => {
        if (res.code === 200) {
          const obj = deepClone(res.data)
          const params = {
            categoryCode: obj.vehicleType,
            categoryType: '1'
          }
          getCategoryList(params).then(res => {
            _this.vehicleBrandList2 = res.data
          })
          _this.formVisible = true
          _this.formTitle = '编辑单位'
          _this.addDataForm.vehicleType = obj.vehicleType
          _this.addDataForm.vehicleBrand = obj.vehicleBrand
          _this.addDataForm.comId = obj.comId
          _this.addDataForm.comName = obj.comName
          _this.addDataForm.address = obj.address
          _this.addDataForm.tel = obj.tel
        }
      })
    },
    /**
     * 根据车辆类型查询车辆品牌
     */
    getLxList(val, id, cb) {
      const _this = this
      const params = {
        categoryCode: val,
        categoryType: '1'
      }
      if (!val) {
        if (id === 1) {
          _this.vehicleBrandList = []
          _this.formData.vehicleBrand = ''
        } else if (id === 2) {
          _this.vehicleBrandList2 = []
          _this.addDataForm.vehicleBrand = ''
        }
        return
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          if (id === 1) {
            _this.vehicleBrandList = []
            _this.formData.vehicleBrand = ''
            _this.vehicleBrandList = res.data
          } else if (id === 2) {
            _this.vehicleBrandList2 = []
            _this.addDataForm.vehicleBrand = ''
            _this.vehicleBrandList2 = res.data
          }
          // if (cb) cb()
        }
      })
    },
    handleAdd() {
      const _this = this
      _this.formVisible = true
      _this.isEdit = false
      _this.formTitle = '新增单位'
      _this.addDataForm = {
        comId: '', /** 维修单位id */
        vehicleType: '', /** 车辆类型*/
        vehicleBrand: '', /** 车辆品牌*/
        tel: '', /** 联系电话： */
        comName: '', /** 单位名称 */
        address: '' /** 单位地址 */
      }
    },
    /**
    * 条件查询
    */
    onSearch() {
      const _this = this
      this.oldFormData = null
      _this.curPage = 1
      _this.getDataList()
    },
    getDataList() {
      const _this = this
      let data = {}
      if (this.oldFormData) {
        data = { ...this.oldFormData }
      } else {
        data = { ...this.formData }
        this.oldFormData = { ...data }
      }
      const params = {
        pageSize: _this.pageSize,
        pageNum: _this.curPage
      }
      _this.isLoading = true
      getfixCompanyList({ data, params }).then(res => {
        _this.isLoading = false
        if (res.code === 200) {
          this.tableData = res.data.rows
          _this.total = res.data.total
        }
      }).catch(_ => {
        _this.isLoading = false
      })
    },
    handlePageChange(val) {
      this.curPage = val
      this.getDataList()
    },
    onReset() {
      this.formData = {
        comName: '',
        vehicleType: '',
        vehicleBrand: '',
        beginTime: '',
        endTime: ''
      }
      this.oldFormData = null
      this.curPage = 1
      this.pageSize = 10
      this.vehicleBrandList = []
      this.getDataList()
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    handleRemove(id) {
      const _this = this
      let comIds = []
      if (id === 'all') {
        if (this.multipleSelection.length === 0) {
          this.$message.warning({
            message: '请勾选需要删除的内容！',
            showClose: true,
            duration: 1500
          })
          return false
        } else {
          comIds = this.multipleSelection.map(o => {
            return o.comId
          })
        }
      } else {
        comIds = [id]
      }
      _this.$confirm('确定删除所选维保单位吗？', '提示', {
        confirmButtoText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteFixCompany(comIds).then(res => {
          if (res.code === 200) {
            this.$message.success({
              message: '删除成功！',
              showClose: true,
              duration: 1500
            })
            this.getDataList()
          }
        })
      }).catch(() => {
        _this.$message({
          message: '已取消删除！',
          showClose: true,
          type: 'info'
        })
      })
    },
    /**
     * 新增或修改
     */
    handleDialogSubmit() {
      const _this = this
      // if (!(/^1[3-9]\d{9}$/.test(this.addDataForm.tel))) {
      //   this.$message.warning({
      //     message: '请输入格式正确的手机号！',
      //     duration: 1500
      //   })
      //   return false
      // }
      const data = deepClone(this.addDataForm)
      _this.$refs.addDataForm.validate(valid => {
        if (valid) {
          insertOrUpdateFixCompany(data).then(res => {
            if (res.code === 200) {
              this.$message.success({
                message: `${this.formTitle}成功！`,
                showClose: true,
                duration: 2000
              })
              this.formVisible = false
              this.getDataList()
            }
          })
        }
      })
    },
    handleDialogReset() {
      this.addDataForm = deepClone(emptyForm)
      this.$refs.addDataForm.resetFields()
      this.vehicleBrandList2 = []
    },
    handleDialogClose() {
      this.handleDialogReset()
    },
    cancelAdd() {
      this.formVisible = false
      this.handleDialogReset()
    },
    getVehicleBrand(id, listName) {
      let name = ''
      const list = this[listName]
      for (let i = 0; i < list.length; i++) {
        if (list[i].categoryCode === id) {
          name = list[i].categoryName
          break
        }
      }
      return name
    },
    getRules(message, trigger = 'blur') {
      return { required: true, message: message + '不能为空！', trigger }
    }
  }
}
</script>

<style lang="stylus" scoped>
.maintenance-container {
  padding 0 20px
  .tydic-box {
    padding 0px 0 10px
    .tydic-input {
      &~.tydic-input {
        margin-left 81px
      }
    }
  }
  .w200 {
    width 200px
  }
  .w250 {
    width 250px
  }
  .w510 {
    width 510px
  }
}
</style>
<style lang="stylus">
.maintenance-container {
  .custom-dialog {
    .el-dialog__body {
      padding-right 20px
    }
  }
  .el-form-item--medium .el-form-item__label {
    margin-bottom: 10px;
  }
}
</style>
