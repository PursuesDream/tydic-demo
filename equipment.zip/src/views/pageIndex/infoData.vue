<template>
  <div :ref="id" :class="className" />
</template>

<script>
import * as echarts from 'echarts'
import resize from '@/components/Charts/mixins/resize'

export default {
  name: 'InfoData',
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    id: {
      type: String,
      default: 'chart'
    },
    chartData: {
      type: null,
      default: null
    }
  },
  data() {
    return {
      chart: null
    }
  },
  watch: {
    chartData(val) {
      this.initChart()
    }
  },
  mounted() {
    // this.initChart()
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      const that = this
      this.chart = echarts.init(that.$refs[that.id])
      const yData = []
      const chartDataColor = [
        new echarts.graphic.LinearGradient(0, 1, 1, 0, [{
          offset: 0,
          color: '#77352f'
        }, {
          offset: 1,
          color: '#70752e'
        }], false),
        new echarts.graphic.LinearGradient(0, 1, 1, 0, [{
          offset: 0,
          color: '#3218b4'
        }, {
          offset: 1,
          color: '#9b09b1'
        }], false),
        new echarts.graphic.LinearGradient(0, 1, 1, 0, [{
          offset: 0,
          color: '#1938ce'
        }, {
          offset: 1,
          color: '#099fd7'
        }], false),
        new echarts.graphic.LinearGradient(0, 1, 1, 0, [{
          offset: 0,
          color: '#4d1dff'
        }, {
          offset: 1,
          color: '#7f76fe'
        }], false)
      ]
      const data = []
      that.chartData.itemInfo.forEach((item, index) => {
        yData.push(item.title)
        data.push({
          value: item.num,
          itemStyle: {
            color: chartDataColor[index]
          }
        })
      })
      this.chart.setOption({
        grid: {
          top: 20,
          left: '2%',
          right: '2%',
          bottom: '15%',
          containLabel: true
        },
        yAxis: [{
          type: 'category',
          boundaryGap: false,
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            color: '#29c8ff'
          },
          splitLine: {
            show: false
          },
          data: yData
        }],
        xAxis: [{
          type: 'value',
          name: '(%)',
          axisTick: {
            show: false
          },
          axisLine: {
            show: false
          },
          axisLabel: {
            show: false
          },
          splitLine: {
            show: false
          }
        }],
        series: [{
          name: '铁骑资产概况',
          type: 'bar',
          barWidth: 20,
          smooth: true,
          symbol: 'circle',
          symbolSize: 5,
          showSymbol: false,
          lineStyle: {
            normal: {
              width: 1
            }
          },
          itemStyle: {
            normal: {
            //   color: 'rgb(137,189,27)',
            //   borderColor: 'rgba(137,189,2,0.27)',
              barBorderRadius: [0, 15, 15, 0],
              label: {
                show: true,
                position: 'insideLeft'
              }
            }
          },
          data
        }]
      })
    }
  }
}
</script>
