<template>
  <div :class="className">
    <div v-if="isShowBack" class="map-back" @click="handleBack">返回深圳市</div>
    <div ref="indexMapChart" class="chart" />
  </div>
</template>

<script>
import * as echarts from 'echarts'
import { shenzhen } from '@/assets/echarts_map/shenzhen.js'
import { getOrganList } from '@/api/public'
// import 'echarts-gl'
// const SZJsonMap = {
//   '大鹏新区': 'dapeng',
//   '龙岗区': 'longgang',
//   '盐田区': 'yantian',
//   '福田区': 'futian',
//   '南山区': 'nanshan',
//   '宝安区': 'baoan',
//   '光明新区': 'guangming',
//   '罗湖区': 'luohu',
//   '坪山区': 'pingshan',
//   '龙华区': 'longhua'
// }
export default {
  name: 'ChartMap',
  props: {
    className: {
      type: String,
      default() {
        return ''
      }
    },
    mapData: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return {
      publicPath: process.env.BASE_URL,
      isShowBack: false,
      option: {},
      chart: null,
      shenzhenSerie: {}
    }
  },
  mounted() {
    this.initMap()
  },
  methods: {
    handleBack() {
      const SZJson = shenzhen
      echarts.registerMap('深圳', SZJson)
      this.option.series[0] = this.shenzhenSerie
      this.chart.setOption(this.option)
      this.isShowBack = false
    },
    initMap() {
      const SZJson = shenzhen
      const that = this
      that.chart = echarts.init(that.$refs.indexMapChart)
      // 获取青岛地图数据。
      echarts.registerMap('深圳', SZJson)
      this.shenzhenSerie = {
        tooltip: {
          trigger: 'item'
        },
        name: '深圳',
        type: 'map',
        map: '深圳',
        zlevel: 2,
        aspectScale: 0.8,
        zoom: 1.2,
        boxWidth: 180,
        boxDepth: 110, // 地图倾斜度
        regionHeight: 1, // 地图厚度
        label: {
          show: true, // 是否显示市
          textStyle: {
            color: '#26cee8', // 文字颜色
            fontSize: 14, // 文字大小
            fontFamily: '微软雅黑',
            backgroundColor: 'rgba(0,0,0,0)' // 透明度0清空文字背景
          }
        },
        itemStyle: {
          areaColor: '#060735',
          color: '#060735',
          shadowColor: '#00edf0',
          shadowBlur: 5,
          opacity: 1, // 透明度
          borderWidth: 2, // 分界线宽度
          borderColor: '#00edf0' // 分界线颜色
        },
        emphasis: {
          label: {
            show: true,
            textStyle: {
              color: '#fff',
              fontSize: 22,
              fontWeight: 'bold'
            }
          },
          itemStyle: {
            areaColor: '#00edf0',
            color: '#00edf0'
          }
        },
        light: {
          main: {
            color: '#fff',
            intensity: 1,
            shadow: true,
            alpha: 40,
            beta: -190
          },
          ambient: {
            color: '#fff',
            intensity: 1
          }
        },
        viewControl: {
          distance: 145, // 地图视角 控制初始大小
          alpha: 80,
          rotateSensitivity: 0, // 旋转
          zoomSensitivity: 0 // 缩放
        }
      }
      const width = that.chart.getWidth() || 0
      const height = that.chart.getHeight() || 0
      this.option = {
        graphic: {
          elements: [ // 显示背景图
            {
              type: 'image',
              scale: [1, 1],
              style: {
                image: `${that.publicPath}static/images/map-bg.png`,
                width,
                height
              },
              zlevel: 1
            }
          ]
        },
        series: [that.shenzhenSerie]
      }
      that.chart.setOption(that.option)
      that.chart.on('click', chartClick)
      that.chart.on('mapselectchanged', function(param) {
        // for (const key in param.selected) {
        //   if (param.name !== key) {
        //     that.chart.dispatchAction({
        //       type: 'mapUnSelect.',
        //       name: key
        //     })
        //   }
        // }
        if (!param.selected[param.name]) {
          that.$emit('orgCodeData', '')
        }
      })
      function chartClick(param) {
        var selectedPro = param.name
        if (selectedPro) {
          getOrganList(1).then(res => {
            const data = res.data
            data.forEach(item => {
              const name = item.name.substring(0, 2)
              if (name === selectedPro.substring(0, 2)) {
                that.$emit('orgCodeData', item.organCode)
                that.chart.dispatchAction({
                  type: 'mapToggleSelect',
                  name: selectedPro
                })
                // that.chart.setOption(that.option)
              } else {
                that.chart.dispatchAction({
                  type: 'mapUnSelect',
                  name: name === '光明' || name === '大鹏' ? name + '新区' : name + '区'
                })
              }
            })
          })
        }
        // if (that.option.series[0].name === selectedPro) {
        //   return
        // }
        // that.isShowBack = true
        // // 获取点击区域数据
        // const geoKey = SZJsonMap[selectedPro]
        // const geojson = require(`@/assets/echarts_map/${geoKey}.js`)
        // echarts.registerMap(selectedPro, geojson[geoKey])
        // that.option.series[0] = {
        //   tooltip: {
        //     trigger: 'item'
        //   },
        //   name: selectedPro,
        //   type: 'map',
        //   map: selectedPro,
        //   zlevel: 2,
        //   boxWidth: 180,
        //   boxDepth: 110, // 地图倾斜度
        //   regionHeight: 1, // 地图厚度
        //   label: {
        //     show: true, // 是否显示市
        //     textStyle: {
        //       color: '#26cee8', // 文字颜色
        //       fontSize: 14, // 文字大小
        //       fontFamily: '微软雅黑',
        //       backgroundColor: 'rgba(0,0,0,0)' // 透明度0清空文字背景
        //     }
        //   },
        //   itemStyle: {
        //     areaColor: '#060735',
        //     color: '#060735',
        //     shadowColor: '#00edf0',
        //     shadowBlur: 5,
        //     opacity: 1, // 透明度
        //     borderWidth: 2, // 分界线宽度
        //     borderColor: '#00edf0' // 分界线颜色
        //   },
        //   emphasis: {
        //     label: {
        //       show: true,
        //       textStyle: {
        //         color: '#fff',
        //         fontSize: 22,
        //         fontWeight: 'bold'
        //       }
        //     },
        //     itemStyle: {
        //       areaColor: '#00edf0',
        //       color: '#00edf0'
        //     }
        //   }
        // }
        // that.chart.setOption(that.option)
      }
    }
  }
}
</script>

<style lang="stylus" scoped>
.chart {
  width 100%
  height 100%
}
.map-back {
  position absolute
  top 10px
  left 10px
  color white
  font-size 24px
  cursor pointer
  z-index 2
}
</style>
