<template>
  <div class="pageIndex-container">
    <div class="header" @click="linkToAdmin">
      <img ref="headImg" :src="`${publicPath}static/images/index-title.png`">
    </div>
    <div class="chartData-box data1">
      <h4>铁骑品牌占比分析</h4>
      <div class="content">
        <chart id="brand" height="100%" width="100%" :chart-data="brandData" />
      </div>
    </div>
    <div class="chartData-box data2">
      <h4>铁骑型号占比分析</h4>
      <div class="content">
        <chart id="model" height="100%" width="100%" :chart-data="modelData" />
      </div>
    </div>
    <div class="chartData-box data3">
      <h4>铁骑增长趋势分析</h4>
      <div class="content">
        <chart id="riseLine" height="100%" width="100%" :chart-data="riseLineData" />
      </div>
    </div>
    <div class="chartData-box data4">
      <h4>铁骑维保项目距对比分析</h4>
      <div class="content">
        <chart id="maintenance" height="100%" width="100%" :chart-data="maintenanceData" />
      </div>
    </div>
    <div class="chartData-box data5">
      <h4>铁骑运维对比分析</h4>
      <div class="content">
        <div class="tabs">
          <div v-for="(item, index) in tabList" :key="index" class="tab" :class="tabIndex1===index?'tab-active':''" @click="tabClick(1,index,item)">
            {{ item }}
          </div>
        </div>
        <el-table
          :data="tableData"
          class="table"
          header-row-class-name="table-header"
          height="2.4rem"
        >
          <el-table-column prop="brand" width="60" :show-overflow-tooltip="true" align="center" label="品牌" />
          <el-table-column prop="oilUsed" align="center" label="油耗(百公里)" />
          <el-table-column prop="fixNum" align="center" label="平均维修数" />
          <el-table-column prop="fixUsed" align="center" label="平均维修金额" />
          <el-table-column prop="careUsed" align="center" label="平均保养金额" />
        </el-table>
      </div>
    </div>
    <div class="chartData-box data6">
      <h4>维保费用对比分析</h4>
      <div class="content">
        <chart id="costComparison" height="100%" width="100%" :chart-data="costData" />
      </div>
    </div>
    <div class="chartData-info">
      <h4>铁骑资产概况</h4>
      <infoData id="dataInfo" class="content" :chart-data="infoData" />
    </div>
    <ChartMap class-name="chart-map" @orgCodeData="getOrgCode" />
  </div>
</template>

<script>
import { testUrl } from '@/api/user'
import InfoData from './infoData'
import Chart from '@/components/Charts/Keyboard'
import http from '@/api/pageIndex'

import ChartMap from './chartMap'
export default {
  name: 'PageIndex',
  components: {
    ChartMap,
    InfoData,
    Chart
  },
  data() {
    return {
      publicPath: process.env.BASE_URL,
      tabList: [5000, 10000, 20000, 50000],
      tabIndex1: 0,
      tabIndex2: 0,
      currentTab: '5000',
      tableData: [],
      brandData: [],
      modelData: [],
      riseLineData: {},
      maintenanceData: {},
      costData: {},
      infoData: {}
    }
  },
  created() {
    this.getData()
  },
  mounted() {
    this.setHeadImgStyle()
    this.getTableData()
  },
  methods: {
    // 初始化页面数据
    getData(orgCode) {
      const that = this
      const param = {
        organCode: orgCode || ''
      }
      // 铁骑品牌占比分析
      http.DevBrandSummary(param).then(res => {
        that.brandData = res.data
      })
      http.DevCategorySummary(param).then(res => {
        that.modelData = res.data
      })
      http.DevIncrementSummary({ beginTime: '', endTime: '', organCode: orgCode || '' }).then(res => {
        that.riseLineData = res.data
      })
      http.DevFixStatisticSummary(param).then(res => {
        that.maintenanceData = res.data
      })
      http.DevStatisticSummary(param).then(res => {
        that.infoData = res.data
      })
      http.DevFixUsedSummary(param).then(res => {
        that.costData = res.data
      })
      this.getTableData(this.currentTab, orgCode)
    },
    // 铁骑运维对比分析
    getTableData(data, orgCode) {
      const that = this
      const param = {
        mileage: data || that.tabList[0],
        organCode: orgCode || ''
      }
      http.DevOpsSummary(param).then(res => {
        that.tableData = res.data
      })
    },
    tabClick(i, index, item) {
      this['tabIndex' + i] = index
      this.currentTab = item
      this.getTableData(item)
    },
    // 获取orgcode
    getOrgCode(data) {
      this.getData(data)
    },
    getTest() {
      testUrl()
        .then((res) => {
          console.log(res)
        })
        .catch((error) => {
          console.log(error)
        })
    },
    linkToAdmin() {
      this.$router.push({ name: 'TrafficMap' })
    },
    setHeadImgStyle() {
      const that = this
      this.$refs.headImg.addEventListener('load', () => {
        const headImg = that.$refs.headImg
        const width = headImg.offsetWidth / 100 + 'rem'
        const height = headImg.offsetHeight / 100 + 'rem'
        headImg.style.width = width
        headImg.style.height = height
      })
    }
  }
}
</script>

<style lang="stylus" scoped>
.pageIndex-container {
  background-image: url('~@/assets/index_images/bg.png');
  background-size: 100% 100%;
  width: 100%;
  height: 10.8rem;
  position: relative;
}

.header {
  width: 10rem;
  height: 1rem;
  background-image: url('~@/assets/index_images/icon_02.png');
  background-size: 100% 100%;
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);

  >img {
    display: block;
    margin: 0 auto;
    transform: translateY(20%);
    user-select: none;
    cursor: pointer;
  }
}

.chartData-box {
  width: 4.24rem;
  height: 3.34rem;
  background-image: url('~@/assets/index_images/icon_10.png');
  background-size: 100% 100%;
  position: absolute;

  >h4 {
    font-weight: normal;
    font-size: 0.14rem;
    color: #01ffff;
    text-align: center;
    line-height: 0.3rem;
    margin: 0;
    user-select: none;
  }

  .content {
    width: 3.9rem;
    height: 2.78rem;
    margin: 0.13rem 0.17rem;
  }

  &.data1 {
    top: 0.2rem;
    left: 0.2rem;
  }

  &.data2 {
    top: 3.74rem;
    left: 0.2rem;
  }

  &.data3 {
    top: 7.28rem;
    left: 0.2rem;
  }

  &.data4 {
    top: 0.2rem;
    right: 0.2rem;
  }

  &.data5 {
    top: 3.74rem;
    right: 0.2rem;
  }

  &.data6 {
    top: 7.28rem;
    right: 0.2rem;
  }
}

.chartData-info {
  width: 9.7rem;
  height: 2.6rem;
  background-image: url('~@/assets/index_images/icon_14.png');
  background-size: 100% 100%;
  position: absolute;
  bottom: 0.2rem;
  left: 50%;
  transform: translateX(-50%);

  >h4 {
    font-weight: normal;
    font-size: 0.14rem;
    color: #01ffff;
    text-align: center;
    line-height: 0.3rem;
    margin: 0;
    user-select: none;
  }
}

.tabs {
  overflow: hidden;
  margin-bottom: 14px;

  .tab {
    float: left;
    width: 0.75rem;
    height: 0.21rem;
    color: white;
    text-align: center;
    font-size: 0.12rem;
    cursor: pointer;
    line-height: 0.21rem;
    margin-right: 0.29rem;
    background-image: url('~@/assets/index_images/tab_bg.png');
    opacity 0.5

    &:last-child {
      margin-right: 0;
    }
  }

  .tab-active {
    opacity 1
  }

}

.chart-map {
  width 10rem
  height 6.5rem
  position absolute
  top 1.06rem
  left 50%
  transform translateX(-50%)
}
</style>
<style lang="stylus">
.el-message {
  font-size: 16px;
}

.chartData-info {
  .content {
    width: 9.46rem;
    height: 2.04rem;
    margin: 0.13rem 0.12rem;
  }
}

.pageIndex-container {
  .el-table {
    background: transparent;

    th {
      background: #0e2052;
      padding: 4px 0;
      border: none;

      .cell {
        font-size: 12px;
        color: #23abe1;
        padding: 0;
        text-align: center;
      }

      td {
        border: none;
      }
    }

    tr {
      color: white;

      td {
        border: none;
        padding: 9px 0;
      }
    }

    tr:nth-child(2n+1) {
      background: #050a28;
    }

    tr:nth-child(2n) {
      background: #181e38;
    }
  }

  .el-table--enable-row-hover .el-table__body tr:hover>td {
    background-color: initial !important;
  }

  .el-table__body-wrapper::-webkit-scrollbar {
    width: 6px; // 横向滚动条
    height: 6px; // 纵向滚动条 必写
  }

  .el-table__body-wrapper::-webkit-scrollbar-thumb {
    background-color: #ddd;
    border-radius: 3px;
  }

  .el-table::before {
    background-color: transparent;
  }
}
</style>
