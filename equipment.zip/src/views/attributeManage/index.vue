<template>
  <div class="interphone-container">
    <el-card style="margin-top:20px;height:85vh">
      <div>
        <div>
          <div class="tydic-box">
            <div class="tydic-input">
              装备属性：
              <el-select
                v-model="formData.categoryType"
                placeholder="请选择"
                clearable
                @change="getCarType"
              >
                <el-option
                  v-for="(o, index) in attributeData"
                  :key="index"
                  :label="o.name"
                  :value="o.value"
                />
              </el-select>
            </div>
            <div class="tydic-input">
              装备类型：
              <el-select v-model="formData.deviceType" @change="getLxList">
                <el-option
                  v-for="(o,index) in carType"
                  :key="index"
                  :label="o.categoryName"
                  :value="o.categoryCode"
                />
              </el-select>
            </div>
            <div class="tydic-input">
              品牌：
              <el-select v-model="formData.deviceBrand" @change="getPpList">
                <el-option
                  v-for="(o,index) in pinpaiList"
                  :key="index"
                  :label="o.categoryName"
                  :value="o.categoryCode"
                />
              </el-select>
            </div>
            <div class="tydic-input">
              型号：
              <el-select v-model="formData.categoryCode">
                <el-option
                  v-for="(o,index) in xinghaoList"
                  :key="index"
                  :label="o.categoryName"
                  :value="o.categoryCode"
                />
              </el-select>
            </div>
            <div class="tydic-input" style="float: right">
              <el-button
                type="primary search"
                size="mini"
                @click="onSearch"
              ><i class="image-icon search" />查询</el-button>
              <el-button
                type="primary reset"
                size="mini"
                @click="onReset"
              ><i class="image-icon reset" />重置</el-button>
            </div>
            <div v-loading="isLoading" class="table-box">
              <el-table
                :data="tableData"
                class="custom-table"
                stripe
                border
                max-height="600"
                header-row-class-name="custom-table-header"
              >
                <!-- <el-table-column type="selection" width="50" align="center" /> -->
                <el-table-column align="center" type="index" label="序号" width="100" :show-overflow-tooltip="true">
                  <template slot-scope="scope">
                    {{ scope.$index + 1 + pageSize * ( curPage - 1) }}
                  </template>
                </el-table-column>
                <el-table-column
                  prop="deviceTypeName"
                  align="center"
                  label="装备类型"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  prop="deviceBrandName"
                  align="center"
                  label="品牌"
                  :show-overflow-tooltip="true"
                />
                <el-table-column
                  align="center"
                  prop="categoryName"
                  label="型号"
                  :show-overflow-tooltip="true"
                />
                <el-table-column align="center" label="属性参数">
                  <template slot-scope="scope">
                    <el-button
                      type="text"
                      size="small"
                      @click="editAttribute(scope.row)"
                    >
                      <span style="color:red">编辑</span>
                    </el-button>
                  </template>
                </el-table-column>
                <el-table-column
                  prop="updateTime"
                  align="center"
                  label="修改时间"
                  :show-overflow-tooltip="true"
                />
              </el-table>
            </div>
          </div>
          <div style="text-align: center">
            <el-pagination
              ref="pagination"
              style="text-align: center; margin-top: 15px"
              background
              :page-size="pageSize"
              :total="total"
              :current-page.sync="curPage"
              layout="total, prev, pager, next, jumper"
              @size-change="sizeChange"
              @current-change="curPageChange"
            />
          </div>
          <!-- 装备属性设置 -->
          <el-dialog
            title="装备属性设置"
            :visible.sync="formVisible"
            width="1600px"
            custom-class="custom-dialog"
            :close-on-click-modal="false"
            :colse-on-press-escape="false"
          >
            <div>
              <el-form v-if="formVisible" ref="attrData" :inline="true" class="apply-form" :model="attrData">
                <div class="formBox">
                  <el-scrollbar v-loading="showAttr" style="height:300px">
                    <el-table :data="attrData.data" class="attrTable">
                      <el-table-column
                        label="英文名称"
                        align="center"
                      >
                        <template slot-scope="scope">
                          <el-form-item label="" :prop="'data.'+scope.$index+'.attrEnName'" :rules="getRules('英文名称')">
                            <el-input v-model="scope.row.attrEnName" size="small" :disabled="scope.row.isInit === 1" />
                          </el-form-item>
                        </template>
                      </el-table-column>
                      <el-table-column
                        label="属性名称"
                        align="center"
                      >
                        <template slot-scope="scope">
                          <el-form-item label="" :prop="'data.'+scope.$index+'.attrName'" :rules="getRules('属性名称')">
                            <el-input v-model="scope.row.attrName" size="small" :disabled="scope.row.isInit === 1" />
                          </el-form-item>
                        </template>
                      </el-table-column>
                      <el-table-column
                        label="属性值"
                        align="center"
                      >
                        <template slot-scope="scope">
                          <el-form-item label="" :prop="'data.'+scope.$index+'.attrValue'" :show-message="scope.row.paramType === 1 ? true : false" :rules="scope.row.paramType === 1 ? rules.attrValue:[{ required: false, message: '请输入属性值！', trigger: 'change' }]">
                            <el-input v-model="scope.row.attrValue" :disabled="scope.row.paramType === 2 || scope.row.isInit === 1" size="small" />
                          </el-form-item>
                        </template>
                      </el-table-column>
                      <el-table-column
                        label="参数类型"
                        align="center"
                        width="260"
                      >
                        <template slot-scope="scope">
                          <el-form-item label="" :prop="'data.'+scope.$index+'.paramType'" :rules="getRules('参数类型')">
                            <el-radio-group v-model="scope.row.paramType" @change="(val) =>changeParamType(val,scope.row)">
                              <el-radio v-for="(item,value) in paramTypeList" :key="value" :label="item.value" :disabled="scope.row.isInit === 1">{{ item.name }}</el-radio>
                            </el-radio-group>
                          </el-form-item>
                        </template>
                      </el-table-column>
                      <el-table-column
                        label="属性值类型"
                        align="center"
                      >
                        <template slot-scope="scope">
                          <el-form-item label="" :prop="'data.'+scope.$index+'.attrType'" :rules="scope.row.paramType === 2 ? rules.attrType:[{ required: false, message: '请选择属性值类型！', trigger: 'change' }]" :show-message="scope.row.paramType === 2 ? true : false">
                            <el-select
                              v-model="scope.row.attrType"
                              placeholder="请选择"
                              clearable
                              :disabled="scope.row.paramType !== 2 || scope.row.isInit === 1"
                              @change="(val) =>changeAttrType(val,scope.row)"
                            >
                              <el-option
                                v-for="(o, index) in attrType"
                                :key="index"
                                :label="o.name"
                                :value="o.value"
                              />
                            </el-select>
                          </el-form-item>
                        </template>
                      </el-table-column>
                      <el-table-column
                        label="字典类型"
                        align="center"
                      >
                        <template slot-scope="scope">
                          <el-form-item label="" :prop="'data.'+scope.$index+'.dictType'" :rules="scope.row.attrType === 4 && scope.row.paramType === 2 ? rules.dictType:[{ required: false, message: '请选择字典类型！', trigger: 'change' }]" :show-message="scope.row.attrType === 4 && scope.row.paramType === 2 ? true : false">
                            <el-select
                              v-model="scope.row.dictType"
                              placeholder="请选择"
                              clearable
                              :disabled="scope.row.attrType === 1 || scope.row.paramType === 1 || scope.row.isInit === 1"
                            >
                              <el-option
                                v-for="(o, index) in dictTypeList"
                                :key="index"
                                :label="o.name"
                                :value="o.value"
                              />
                            </el-select>
                          </el-form-item>
                        </template>
                      </el-table-column>
                      <el-table-column
                        label="初始化"
                        align="center"
                        width="90"
                      >
                        <template slot-scope="scope">
                          <el-form-item label="" :prop="'data.'+scope.$index+'.isInit'" :rules="getRules('字典类型')">
                            <el-radio v-model="scope.row.isInit" :label="1" disabled style="padding-left:10px">
                              {{ '' }}
                            </el-radio>
                          </el-form-item>
                        </template>
                      </el-table-column>
                      <el-table-column
                        label="展示顺序"
                        align="center"
                        width="180"
                      >
                        <template slot-scope="scope">
                          <el-form-item label="">
                            <el-button size="small" @click="moveUp(scope.row,scope.$index)">上移</el-button>
                            <el-button size="small" @click="moveDown(scope.row,scope.$index)">下移</el-button>
                          </el-form-item>
                        </template>
                      </el-table-column>
                      <el-table-column
                        label="操作"
                        align="center"
                        width="150"
                      >
                        <template slot-scope="scope">
                          <el-form-item label="">
                            <el-button size="small" :disabled="scope.row.isInit === 1" @click="deleteRow(scope.row)">-</el-button>
                            <el-button
                              size="small"
                              @click="increaseRow(scope.row)"
                            >+</el-button>
                          </el-form-item>
                        </template>
                      </el-table-column>
                    </el-table>
                  </el-scrollbar>
                </div>
                <div>
                  <!-- :http-request="handleChangeAudio" -->
                  <p class="tip">温馨提示：图片支持上传 .pdf .jpg,.png；单个文件大小应 &lt;=50MB；最多上传10个文件；此处上传顺序为装备档案图片的显示顺序</p>
                  <div style="width:250px">
                    <el-upload
                      ref="uploadFile"
                      :limit="10"
                      :file-list="imgUrl"
                      accept=".pdf,.jpg,.png"
                      action="aaaa"
                      :on-preview="handlePicPreview"
                      :on-remove="handleFileRemove"
                      :on-exceed="handleFileExceed"
                      :before-upload="handleFileProgress"
                      :http-request="handleChangeAudio"
                    >
                      图片上传：<el-button size="mini" type="primary">点击上传</el-button>
                    </el-upload>
                  </div>

                </div>
                <div style="text-align: center; margin-top: 20px">
                  <el-button
                    type="primary color-commit"
                    size="mini"
                    @click="saveData"
                  >确认</el-button>
                  <el-button
                    type="primary color-cancel"
                    size="mini"
                    @click="formVisible = false"
                  >取消</el-button>
                </div>
              </el-form>
            </div>
          </el-dialog>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
import { getOrganList, getDictType } from '@/api/public'
import { getCategoryList } from '@/api/integratedManage'
import { getAttributeList, delAttributeImg, addAttributeImg, getAllCategoryList, addAttributeList } from '@/api/attributeManage'
import { mapState } from 'vuex'
import { deepClone } from '@/utils'
export default {
  name: 'AttributeManage',
  data() {
    return {
      carType: [],
      xinghaoList: [],
      pinpaiList: [],
      categoryCode: '',
      formData: {
        categoryType: '',
        deviceBrand: '',
        deviceType: '',
        categoryCode: ''
      },
      oldFormData: null,
      pictureUrl: '', // 放大图片地址
      pictureVisible: false,
      curPage: 1,
      pageSize: 10,
      total: 0,
      daduiList: [],
      zhongduiList: [],
      tableData: [
        { parentOrganName: '1' }
      ],
      showAttr: false,
      formVisible: false,
      addDataForm: {
        parentOrganCode: '',
        organCode: '',
        codeNum: '',
        codeType: ''
      },
      isLoading: false,
      imgUrl: [],
      attributeData: [
        { name: '全部', value: '' },
        { name: '车辆', value: '1' },
        { name: '配套装备', value: '2' }
      ],
      attrType: [
        { name: '文本', value: 1 },
        { name: '单选', value: 4 }
      ],
      paramTypeList: [
        { name: '通用参数', value: 1 },
        { name: '个性化参数', value: 2 }
      ],
      dictTypeList: [],
      attrData: {
        data: []
      },
      rules: {
        attrValue: [
          { required: true, message: '请输入通用属性值！', trigger: 'change' }
        ],
        attrType: [
          { required: true, message: '请选择属性值类型！', trigger: 'change' }
        ],
        dictType: [
          { required: true, message: '请选择字典类型！', trigger: 'change' }
        ]
      }
    }
  },
  computed: {
    ...mapState({
      mapData: state => state.user.mapData
    })
  },
  watch: {
    categoryCode(val) {
      if (val) {
        this.categoryCode = val
      }
    }
  },
  mounted() {
    const _this = this
    _this.getCarType('')
    _this.getList()
    _this.getDictType()
  },
  methods: {
    /**
     * 字典类型
     */
    getDictType() {
      getDictType({}).then(res => {
        if (res.code === 200) {
          const _this = this
          const result = res.data
          for (const key in result) {
            _this.dictTypeList.push({ name: result[key], value: key })
          }
        }
      })
    },
    /**
     * 获取车辆类型
     */
    getCarType(val) {
      const _this = this
      this.carType = []
      this.pinpaiList = []
      this.xinghaoList = []
      this.formData.deviceType = ''
      this.formData.deviceBrand = ''
      this.formData.categoryCode = ''
      const params = {
        categoryCode: '',
        categoryType: val
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          _this.carType = res.data
        }
      })
    },
    /**
     * 根据车辆类型查询车辆品牌
     */
    getLxList(val) {
      const _this = this
      this.pinpaiList = []
      this.xinghaoList = []
      this.formData.deviceBrand = ''
      this.formData.categoryCode = ''
      const params = {
        categoryCode: val,
        categoryType: _this.formData.categoryType
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          _this.pinpaiList = res.data
        }
      })
    },
    /**
     * 根据车辆品牌查询车辆型号
     */
    getPpList(val) {
      const _this = this
      this.xinghaoList = []
      this.formData.categoryCode = ''
      const params = {
        categoryCode: val,
        categoryType: _this.formData.categoryType
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          _this.xinghaoList = res.data
        }
      })
    },
    /**
     * 查询属性列表
     */
    getAttributeList(val) {
      this.showAttr = true
      this.imgUrl = []
      getAttributeList(val).then(res => {
        if (res.code === 200) {
          const obj = { attrName: '', paramType: 1, attrValue: '', isInit: 0, attrEnName: '', attrType: '', dictType: '', attrOrder: '', categoryCode: this.categoryCode }
          this.attrData.data = res.data.filter(item => {
            return item.attrType !== 2
          })
          if (this.attrData.data.length === 0) {
            this.attrData.data.push(obj)
          }
          const imgUrls = res.data.filter(item => {
            return item.attrType === 2
          })
          imgUrls.map(item => {
            item.name = item.attrName
          })
          this.imgUrl = imgUrls
          this.showAttr = false
        }
      })
    },
    handlePicPreview(file) {
      this.pictureUrl = file.url
      this.pictureVisible = true
    },
    /**
     * 移除文件
     */
    handleFileRemove(file, fileList) {
      if (!file.path) return false
      const param = {
        path: file.path,
        categoryCode: file.categoryCode,
        attrOrder: file.attrOrder
      }
      const _this = this
      delAttributeImg(param).then(res => {
        console.log(res)
      })
      _this.imgUrl = fileList
    },
    /**
     * 文件变化触发文件转换方法:rules="getRules('通用参数值')"
     */
    handleChangeAudio(files) {
      const file = files.file
      const data = new FormData()
      data.append('file', file)
      const params = this.categoryCode
      addAttributeImg({ params, data }).then(res => {
        if (res.code === 200) {
          const obj = res.data
          this.imgUrl.push(obj)
        }
      })
    },
    handleFileProgress(file) { // 判断文件大小
      var extName = file.name.substring(file.name.lastIndexOf('.')).toLowerCase()
      var AllUpExt = '.jpg|.png|.pdf|'
      if (AllUpExt.indexOf(extName + '|') === -1) {
        this.$message.error('文件格式不正确!')
        return false
      }
      let size = file.size || 0
      size = size / 1024 / 1024
      if (size > 50) {
        this.$message.warning('文件大小不能超出50MB！')
        return false
      }
    },
    handleFileExceed(file, fileList) {
      this.$message.warning('超出最大上传文件个数！')
    },
    /**
     * 查询所有车辆类型
     */
    getAllCategory() {
      const _this = this
      const params = {
        categoryCode: ''
      }
      getCategoryList(params).then(res => {
        if (res.code === 200) {
          _this.carType = res.data
        }
      })
    },
    /**
     * 获取所有型号列表
     */
    getList() {
      this.tableData = []
      this.isLoading = true
      let data = {}
      if (this.oldFormData) {
        data = { ...this.oldFormData }
      } else {
        data = { ...this.formData }
        this.oldFormData = { ...data }
      }
      const params = {
        pageSize: this.pageSize,
        pageNum: this.curPage
      }
      getAllCategoryList({ params, data }).then(res => {
        if (res.data.code === 200) {
          this.tableData = res.data.rows
          this.total = res.data.total
          this.isLoading = false
        }
      })
    },
    getRules(message, trigger = 'blur') {
      return { required: true, message: message + '不能为空！', trigger }
    },
    /**
     * 选择参数类型
     */
    changeParamType(val, row) {
      row.paramType = val
      if (val === 2) {
        row.attrValue = ''
      }
      if (val === 1) {
        row.attrType = ''
        row.dictType = ''
      }
    },
    /**
     * 选择属性类型
     */
    changeAttrType(val, row) {
      row.attrType = val
      if (val === 1) {
        row.dictType = ''
      }
    },
    /**
     * 分页大小
     */
    sizeChange(val) {
      const _this = this
      _this.pageSize = val
      this.getList()
    },
    /**
     * 页数跳转
     */
    curPageChange(val) {
      const _this = this
      _this.curPage = val
      this.getList()
    },
    /**
     * 查询大队
     */
    getOrgan(code, listName) {
      this[listName + 'List'] = []
      this.formData.sszd = ''
      if (!code) {
        return
      }
      getOrganList(code).then(res => {
        if (res.code === 200) {
          this[listName + 'List'] = res.data
        }
      })
    },
    /**
     * 编辑属性
     */
    editAttribute(row) {
      const _this = this
      this.categoryCode = row.categoryCode
      this.getAttributeList(row.categoryCode)
      _this.formVisible = true
    },
    /**
     * 搜索
     */
    onSearch() {
      this.curPage = 1
      this.oldFormData = null
      this.getList()
    },
    /**
     * 重置
     */
    onReset() {
      this.formData = {
        deviceType: '',
        deviceBrand: '',
        categoryType: '',
        categoryCode: ''
      }
      this.pageSize = 10
      this.curPage = 1
      this.pinpaiList = []
      this.xinghaoList = []
      this.oldFormData = null
      this.carType = []
      this.getList()
    },
    /**
     * 上移
     */
    moveUp(row, flag) {
      if (flag === 0) {
        this.$message.warning({
          message: '不能上移第一位！',
          showClose: true,
          duration: 1500
        })
        return
      }
      const index = this.attrData.data.indexOf(row)
      if (index > 0) {
        // 在上一项插入该项
        this.attrData.data.splice(index - 1, 0, (this.attrData.data[index]))
        // 删除后一项
        this.attrData.data.splice(index + 1, 1)
      }
    },
    /**
     * 下移
     */
    moveDown(row, flag) {
      const length = this.attrData.data.length - 1
      if (flag === length) {
        this.$message.warning({
          message: '不能下移最后一位！',
          showClose: true,
          duration: 1500
        })
        return
      }
      const index = this.attrData.data.indexOf(row)
      if (index === (this.attrData.data.length - 1)) {
        return
      }
      // 在下一项插入该项
      this.attrData.data.splice(index + 2, 0, (this.attrData.data[index]))
      // 删除前一项
      this.attrData.data.splice(index, 1)
    },
    /**
     * 删除
     */
    deleteRow(row) {
      const index = this.attrData.data.indexOf(row)
      if (this.attrData.data.length === 1) {
        this.$message.warning('不能删除最后一个属性')
        return
      }
      this.attrData.data.splice(index, 1)
    },
    /**
     * 新增
     */
    increaseRow(row) {
      const index = this.attrData.data.indexOf(row)
      this.attrData.data.splice(index + 1, 0, { attrName: '', paramType: 1, attrValue: '', isInit: 0, attrEnName: '', attrType: '', dictType: '', attrOrder: '', categoryCode: this.categoryCode })
    },
    saveData() {
      this.$refs.attrData.validate(valid => {
        if (valid) {
          const param = deepClone(this.attrData.data)
          addAttributeList(param).then(res => {
            if (res.code === 200) {
              this.$message.success({
                message: '操作成功！',
                showClose: true,
                duration: 1500
              })
              this.formVisible = false
              this.getList()
            }
          })
        }
      })
    }
  }
}
</script>

<style lang="stylus" scoped>
.interphone-container {
  .tydic-box {
    padding: 0px 0 10px;
  }
  // .attrTable{
     /deep/ .el-form--inline .el-form-item{
      margin-right 0px
    }
  // }
  .formBox{
    .el-table .cell{
      height 38px
    }
    /deep/ .el-scrollbar__wrap{
      overflow-x: auto!important
    }
  }
  .custom-dialog .el-form-item {
    margin-bottom: 20px;
  }

  .tydic-box .tydic-input ~ .tydic-input {
    margin-left: 50px;
  }

  padding: 0px 20px;

  .w200 {
    width: 200px;
  }

  .w180 {
    width: 180px;
  }

  .w140 {
    width: 140px;
  }
}

.interphone-container .custom-dialog .el-form-item {
  margin-bottom 0
}
</style>
